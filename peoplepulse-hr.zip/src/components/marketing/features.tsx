"use client";

import { Badge } from "@/components/ui/badge";
import {
  Users, CalendarClock, PlaneTakeoff, Wallet, UserRoundSearch, Target, Megaphone,
  LifeBuoy, Workflow, BarChart3, Sparkles, ShieldCheck, FileCheck2, BellRing,
  Network, ClipboardCheck, Building2, ArrowUpRight, Zap, Lock, Server, EyeOff, History,
  ReceiptText, Boxes, GraduationCap, ClipboardList, FileText, MessageCircle, PenLine,
} from "lucide-react";

const MODULES = [
  { icon: Users, title: "Core HR & Employee Database", desc: "Profiles, documents, reporting hierarchy, org chart, lifecycle events and bulk import/export — one source of truth.", tag: "Core HR" },
  { icon: CalendarClock, title: "Attendance & Shifts", desc: "Web and mobile check-in, shifts, weekly offs, WFH tracking, late arrivals, overtime and correction workflows.", tag: "Time" },
  { icon: PlaneTakeoff, title: "Leave Management", desc: "Configurable policies — CL, SL, EL, comp-off, maternity. Accruals, carry-forward, encashment, holiday-aware balance math.", tag: "Time" },
  { icon: Wallet, title: "Payroll Engine", desc: "Configurable salary structures and statutory components (PF, ESI, PT, TDS) with approvals, payslips and audit trails.", tag: "Payroll" },
  { icon: UserRoundSearch, title: "Recruitment & ATS", desc: "Requisitions, career-ready job posts, candidate pipeline with drag-and-drop stages, interviews, offers and analytics.", tag: "Talent" },
  { icon: Target, title: "Performance", desc: "Review cycles, goals and progress, self + manager evaluations, ratings and calibration — fair and transparent.", tag: "Talent" },
  { icon: Megaphone, title: "Announcements & Engagement", desc: "Company-wide and departmental announcements with acknowledgement tracking, keeping everyone aligned.", tag: "Engagement" },
  { icon: LifeBuoy, title: "HR Helpdesk", desc: "Ticketing with categories, priorities, SLAs, threaded conversations and resolution analytics.", tag: "Service" },
  { icon: Workflow, title: "Workflow Automation", desc: "No-code rules: when an employee joins, create onboarding tasks; when a ticket breaches SLA, escalate. Configurable.", tag: "Automation" },
  { icon: BarChart3, title: "People Analytics", desc: "Headcount, attrition, absenteeism, hiring funnel, payroll cost and department comparisons — all from live records.", tag: "Analytics" },
  { icon: Network, title: "Org Chart & Directory", desc: "Interactive reporting tree and a searchable people directory with contact details and reporting lines.", tag: "Core HR" },
  { icon: ClipboardCheck, title: "Onboarding & Offboarding", desc: "Structured task checklists for joiners and exits — documentation, IT access, knowledge transfer, clearances.", tag: "Core HR" },
  { icon: ReceiptText, title: "Expense Management", desc: "Submit, approve and reimburse claims with INR formatting, category policies and multi-level approval flows.", tag: "Operations" },
  { icon: Boxes, title: "Asset Management", desc: "Track laptops, monitors, phones across the org — allocate, return, maintenance, retire, with full audit history.", tag: "Operations" },
  { icon: GraduationCap, title: "Training & LMS", desc: "Course catalog, enrollments, mandatory compliance tracking, progress and completion scoring.", tag: "Talent" },
  { icon: ClipboardList, title: "Surveys & eNPS", desc: "Anonymous pulse and eNPS surveys with one-click templates, participation tracking and aggregated results.", tag: "Engagement" },
  { icon: FileText, title: "Document Center", desc: "Versioned company policy and SOP library — HR, Legal, IT & Security, Finance, Forms — with tags and search.", tag: "Engagement" },
  { icon: Target, title: "Goals & OKR", desc: "Per-employee quarterly goals with metric, target, current value, progress % and status (On track / At risk / Behind / Completed).", tag: "Talent" },
];

const AI_CAPABILITIES = [
  {
    icon: MessageCircle,
    title: "Conversational HR copilot",
    desc: "Grounded on real company data — headcount, leave balances, payroll, expenses. Asks the right model via OpenRouter with automatic fallback.",
  },
  {
    icon: UserRoundSearch,
    title: "AI resume screening",
    desc: "Score candidates 0–100 against each job opening, with strengths, concerns, and an auto-saved fit summary.",
  },
  {
    icon: PenLine,
    title: "AI drafting",
    desc: "Announcements, emails, and policy documents generated from a single topic, ready to edit and publish.",
  },
];

export function Features() {
  return (
    <>
      {/* Modules grid */}
      <section id="modules" className="py-20 md:py-28">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <Badge variant="secondary" className="mb-4 rounded-full px-3 py-1 text-xs font-medium">One platform</Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Every HR module, deeply integrated
            </h2>
            <p className="mt-4 text-muted-foreground">
              Not a bundle of disconnected tools. Attendance feeds payroll, leave respects holidays,
              onboarding triggers workflows, and analytics reflects everything in real time.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {MODULES.map((m) => (
              <div
                key={m.title}
                className="group relative rounded-2xl border bg-card p-6 transition-all hover:-translate-y-0.5 hover:shadow-lg"
              >
                <div className="flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <m.icon className="h-5 w-5" />
                  </div>
                  <span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-medium text-muted-foreground">
                    {m.tag}
                  </span>
                </div>
                <h3 className="mt-4 text-base font-semibold">{m.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{m.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI capabilities — Pulse AI Pro */}
      <section id="ai" className="py-20 md:py-24">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-primary/8 via-card to-card p-7 md:p-10">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-5">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <Sparkles className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <Badge variant="secondary" className="gap-1.5 rounded-full px-3 py-1 text-xs font-medium">
                  <Sparkles className="h-3 w-3 text-primary" /> New — upgraded
                </Badge>
                <h3 className="mt-2 text-2xl font-bold tracking-tight">
                  Pulse AI Pro — your HR copilot, grounded on live data
                </h3>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                  The upgraded AI layer inside PeoplePulse HR. Three capabilities, all wired
                  to your live, authorised company data — no copy-paste, no hallucinated numbers.
                </p>
              </div>
            </div>

            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {AI_CAPABILITIES.map((c) => (
                <div key={c.title} className="rounded-xl border bg-background/70 p-5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <c.icon className="h-4 w-4" />
                  </div>
                  <h4 className="mt-3 text-sm font-semibold">{c.title}</h4>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{c.desc}</p>
                </div>
              ))}
            </div>

            <div className="pointer-events-none absolute -bottom-12 -right-12 hidden h-56 w-56 rounded-full bg-primary/10 blur-3xl md:block" />
          </div>
        </div>
      </section>

      {/* Bento: why teams switch */}
      <section className="pb-20 md:pb-28">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="grid gap-5 lg:grid-cols-3">
            {/* AI copilot card */}
            <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-primary/8 via-card to-card p-7 lg:col-span-2">
              <Badge variant="secondary" className="mb-4 gap-1.5 rounded-full px-3 py-1 text-xs font-medium">
                <Sparkles className="h-3 w-3 text-primary" /> AI HR Copilot
              </Badge>
              <h3 className="text-xl font-bold">An assistant that knows your organisation</h3>
              <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">
                Ask questions in plain language. The copilot answers from live, authorised data —
                never guessing, always showing its sources. It drafts announcements, summarises
                tickets, explains policies and prepares review talking points.
              </p>
              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {[
                  { icon: FileCheck2, text: "Policy Q&A grounded in your actual documents" },
                  { icon: BellRing, text: "Drafts announcements and comms in your tone" },
                  { icon: BarChart3, text: "Workforce insights from live, permitted data" },
                  { icon: EyeOff, text: "Permission-aware: employees only see their own data" },
                ].map((f) => (
                  <div key={f.text} className="flex items-center gap-3 rounded-xl border bg-background/70 p-3">
                    <f.icon className="h-4 w-4 shrink-0 text-primary" />
                    <span className="text-xs leading-snug text-muted-foreground">{f.text}</span>
                  </div>
                ))}
              </div>
              <div className="pointer-events-none absolute -bottom-10 -right-10 hidden h-48 w-48 rounded-full bg-primary/10 blur-2xl lg:block" />
            </div>

            {/* Employee experience card */}
            <div className="rounded-2xl border bg-card p-7">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-chart-2/10 text-chart-2">
                <Zap className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-bold">Employee self-service done right</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Payslips, leave balances, attendance history, requests and announcements —
                all in a clean personal dashboard that works beautifully on mobile.
              </p>
              <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
                {["Apply for leave in two taps", "Download payslips anytime", "Track request status live", "Raise HR tickets with SLAs"].map((t) => (
                  <li key={t} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" /> {t}
                  </li>
                ))}
              </ul>
            </div>

            {/* Configurability card */}
            <div className="rounded-2xl border bg-card p-7 lg:col-span-1">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-chart-4/10 text-chart-4">
                <Building2 className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-bold">Configured to your policies</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Leave types, accrual rules, notice periods, approval chains, statutory rates,
                brand colours — every organisation gets its own configuration. No code required.
              </p>
            </div>

            {/* Security card */}
            <div className="relative overflow-hidden rounded-2xl border bg-zinc-950 p-7 text-zinc-50 lg:col-span-2 dark:bg-zinc-900">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-lg font-bold">Enterprise security, simply administered</h3>
                  <p className="mt-2 max-w-md text-sm leading-relaxed text-zinc-400">
                    Multi-tenant isolation enforced at the database layer. Scoped roles, audit
                    trails on every sensitive action, and strict payroll access controls.
                  </p>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { icon: Lock, label: "Encrypted credentials (scrypt)" },
                  { icon: Server, label: "Tenant-isolated data" },
                  { icon: History, label: "Full audit trail" },
                  { icon: EyeOff, label: "Least-privilege access" },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl border border-white/10 bg-white/5 p-3">
                    <s.icon className="h-4 w-4 text-emerald-400" />
                    <div className="mt-2 text-[11px] leading-snug text-zinc-300">{s.label}</div>
                  </div>
                ))}
              </div>
              <p className="mt-5 text-[10px] text-zinc-500">
                Security assurance programs (e.g. SOC 2, ISO 27001) require independent audits — we do not claim certifications we have not earned.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export function StatsBand() {
  return (
    <section className="border-y bg-muted/40 py-12">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="grid grid-cols-2 gap-6 text-center md:grid-cols-4">
          {[
            { value: "20", label: "Integrated modules" },
            { value: "100%", label: "Modules on live data" },
            { value: "5", label: "Roles & granular permissions" },
            { value: "<10 min", label: "Time to first employee" },
          ].map((s) => (
            <div key={s.label}>
              <div className="text-3xl font-bold tracking-tight text-primary">{s.value}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
        <p className="mt-8 text-center text-[11px] text-muted-foreground">
          Product capability claims reflect the shipped platform you are using right now. We do not publish invented customer or revenue numbers.
        </p>
      </div>
    </section>
  );
}

export function CtaLink({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 text-primary hover:underline">
      {children}
      <ArrowUpRight className="h-3.5 w-3.5" />
    </span>
  );
}

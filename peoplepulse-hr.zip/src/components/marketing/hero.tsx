"use client";

import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  PlayCircle,
  ShieldCheck,
  Building2,
  Globe2,
  Zap,
  Sparkles,
  Users,
  CalendarClock,
  PlaneTakeoff,
  Wallet,
  ReceiptText,
  Boxes,
  GraduationCap,
  ClipboardList,
} from "lucide-react";

export function Hero() {
  const { setView, setAuthTab } = useAppStore();

  return (
    <section className="relative overflow-hidden pb-10 pt-14 md:pt-24">
      {/* backdrop accents */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-primary/8 blur-3xl dark:bg-primary/12" />
        <div className="absolute -right-40 top-40 h-72 w-72 rounded-full bg-chart-2/10 blur-3xl" />
      </div>

      <div className="container mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-3xl text-center">
          <Badge variant="secondary" className="mb-5 gap-1.5 rounded-full px-3 py-1 text-xs font-medium">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
            </span>
            New — Pulse AI Pro is now included
          </Badge>

          <h1 className="text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl md:text-6xl">
            The complete HR platform
            <span className="block bg-gradient-to-r from-primary via-chart-2 to-chart-1 bg-clip-text text-transparent">
              your people actually love
            </span>
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
            PeoplePulse HR unifies core HR, attendance, leave, payroll, recruitment,
            performance and employee engagement in one secure, AI-assisted workspace —
            built for Indian businesses and global teams alike.
          </p>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" onClick={() => { setAuthTab("register"); setView("auth"); }}>
              Start free — no card needed
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => { setAuthTab("login"); setView("auth"); }}>
              <PlayCircle className="mr-1 h-4 w-4" />
              Explore the live demo
            </Button>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> 14-day full-access trial</span>
            <span className="flex items-center gap-1.5"><Zap className="h-3.5 w-3.5 text-primary" /> Set up in under 10 minutes</span>
            <span className="flex items-center gap-1.5"><Globe2 className="h-3.5 w-3.5 text-primary" /> Multi-currency & multi-jurisdiction</span>
          </div>
        </div>

        {/* Product mockup */}
        <div className="relative mx-auto mt-14 max-w-5xl md:mt-20">
          <div className="absolute -inset-x-8 -top-8 bottom-8 -z-10 rounded-[2.5rem] bg-gradient-to-b from-primary/12 to-transparent blur-2xl" />
          <ProductMockup />
        </div>

        {/* Built-for strip */}
        <div className="mt-14 flex flex-col items-center gap-3">
          <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
            Built for every kind of organisation
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {["Startups", "IT & Technology", "Manufacturing", "Consulting", "Retail & Hospitality", "Education", "Healthcare", "Remote-first teams", "Multinationals"].map((tag) => (
              <span key={tag} className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-xs text-muted-foreground">
                <Building2 className="h-3 w-3 text-primary/70" />
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/** Pure-CSS replica of the app dashboard — always matches the real product's design language. */
function ProductMockup() {
  const bars = [42, 58, 50, 66, 74, 62, 80, 71, 88, 79, 92, 84];

  const kpis = [
    { label: "Headcount", value: "248", delta: "+6 this month" },
    { label: "On leave", value: "9", delta: "3 pre-approved" },
    { label: "Pending", value: "12", delta: "4 urgent" },
    { label: "Payroll", value: "₹42.8L", delta: "Oct — paid" },
  ];

  const moduleChips = [
    { icon: Users, label: "Core HR" },
    { icon: CalendarClock, label: "Attendance" },
    { icon: PlaneTakeoff, label: "Leave" },
    { icon: Wallet, label: "Payroll" },
    { icon: ReceiptText, label: "Expenses" },
    { icon: Boxes, label: "Assets" },
    { icon: GraduationCap, label: "Training" },
    { icon: ClipboardList, label: "Surveys" },
  ];

  const departments = [
    { name: "Engineering", pct: 42, color: "bg-primary" },
    { name: "Sales", pct: 22, color: "bg-chart-2" },
    { name: "Operations", pct: 18, color: "bg-chart-3" },
    { name: "People & HR", pct: 10, color: "bg-chart-4" },
    { name: "Finance", pct: 8, color: "bg-chart-5" },
  ];

  return (
    <div className="overflow-hidden rounded-2xl border bg-card shadow-2xl ring-1 ring-black/5 dark:ring-white/10">
      {/* window chrome */}
      <div className="flex items-center gap-2 border-b bg-muted/60 px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-red-400" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
        <span className="h-2.5 w-2.5 rounded-full bg-green-500" />
        <div className="mx-auto hidden h-5 w-64 items-center justify-center rounded-md bg-background text-[10px] text-muted-foreground sm:flex">
          app.peoplepulse.hr
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-[180px_1fr]">
        {/* sidebar — hidden on mobile (single-column grid lets the main panel take full width, which is what prevents the entire dashboard from being crushed to a 52px sliver) */}
        <div className="hidden flex-col gap-1 border-r bg-sidebar p-3 sm:flex">
          <div className="mb-3 flex items-center gap-2 px-1">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-[11px] font-bold text-primary-foreground">P</div>
            <div className="hidden text-xs font-semibold sm:block">PeoplePulse</div>
          </div>
          {["Dashboard", "Employees", "Attendance", "Leave", "Payroll", "Recruitment", "Analytics", "Assistant"].map((item, i) => (
            <div
              key={item}
              className={`flex items-center gap-2 rounded-md px-2.5 py-1.5 text-[11px] ${
                i === 0 ? "bg-primary/10 font-medium text-primary" : "text-muted-foreground"
              }`}
            >
              <span className={`h-2 w-2 rounded-sm ${i === 0 ? "bg-primary" : "bg-muted-foreground/40"}`} />
              <span className="hidden sm:block">{item}</span>
            </div>
          ))}
          <div className="mt-auto flex items-center gap-2 rounded-md border bg-card px-2 py-1.5">
            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-chart-3/30 text-[9px] font-bold text-amber-700">AR</div>
            <div className="hidden min-w-0 sm:block">
              <div className="truncate text-[10px] font-medium leading-none">Ananya Rao</div>
              <div className="text-[9px] text-muted-foreground">Owner</div>
            </div>
          </div>
        </div>

        {/* main panel */}
        <div className="min-w-0 p-4 md:p-5">
          {/* Greeting header — min-w-0 + truncate so the sub-text never overlaps the right-side badge at any width */}
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold">Good morning, Ananya</div>
              <div className="truncate text-[11px] text-muted-foreground">
                Here is what is happening across Acme Corp today.
              </div>
            </div>
            <div className="hidden shrink-0 items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-[10px] font-medium text-primary md:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" /> 86% present today
            </div>
          </div>

          {/* KPI row — each card has min-w-0 and inner divs are truncated so labels/values/deltas can never wrap chaotically or overlap */}
          <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {kpis.map((kpi) => (
              <div key={kpi.label} className="min-w-0 rounded-xl border bg-background p-3">
                <div className="truncate text-[10px] text-muted-foreground">{kpi.label}</div>
                <div className="mt-0.5 truncate text-lg font-bold leading-tight">{kpi.value}</div>
                <div className="truncate text-[9px] text-primary">{kpi.delta}</div>
              </div>
            ))}
          </div>

          {/* Pulse AI Pro insight callout */}
          <div className="mt-3 rounded-xl border border-primary/20 bg-primary/5 p-3">
            <div className="flex items-center gap-1.5 text-[10px] font-semibold text-primary">
              <Sparkles className="h-3.5 w-3.5" /> Pulse AI Pro
            </div>
            <p className="mt-1 text-[10px] leading-snug text-muted-foreground">
              Your AI copilot summarised 14 leave requests and screened 6 candidates this week.
            </p>
          </div>

          {/* Modules in this workspace — wrapped flex chip strip, never overflows card width */}
          <div className="mt-3">
            <div className="text-[10px] font-medium text-muted-foreground">Modules in this workspace</div>
            <div className="mt-1.5 flex flex-wrap gap-2">
              {moduleChips.map((m) => (
                <div
                  key={m.label}
                  className="flex min-w-0 items-center gap-1.5 rounded-lg border bg-background px-2 py-1 text-[10px] font-medium"
                >
                  <m.icon className="h-3 w-3 shrink-0 text-primary" />
                  <span className="truncate">{m.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* charts row */}
          <div className="mt-3 grid gap-3 lg:grid-cols-5">
            <div className="min-w-0 rounded-xl border bg-background p-3 lg:col-span-3">
              <div className="flex items-center justify-between gap-2">
                <div className="truncate text-[11px] font-medium">Headcount growth — last 12 months</div>
                <span className="shrink-0 rounded-full bg-accent px-2 py-0.5 text-[9px] font-medium text-accent-foreground">Live data</span>
              </div>
              <div className="mt-3 flex h-24 items-end gap-1.5">
                {bars.map((h, i) => (
                  <div key={i} className="group relative h-full min-w-0 flex-1">
                    <div
                      className="absolute inset-x-0 bottom-0 rounded-t-sm bg-primary/80 transition-all group-hover:bg-primary"
                      style={{ height: `${h * 0.9}%` }}
                    />
                  </div>
                ))}
              </div>
              <div className="mt-1.5 flex justify-between text-[8px] text-muted-foreground">
                <span>Nov</span><span>Feb</span><span>May</span><span>Aug</span><span>Oct</span>
              </div>
            </div>

            <div className="min-w-0 rounded-xl border bg-background p-3 lg:col-span-2">
              <div className="truncate text-[11px] font-medium">Department split</div>
              <div className="mt-3 space-y-2">
                {departments.map((d) => (
                  <div key={d.name} className="flex min-w-0 items-center gap-2">
                    <span className="w-20 shrink-0 truncate text-[9px] text-muted-foreground">{d.name}</span>
                    <div className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-muted">
                      <div className={`h-full rounded-full ${d.color}`} style={{ width: `${d.pct}%` }} />
                    </div>
                    <span className="w-7 shrink-0 text-right text-[9px] font-medium">{d.pct}%</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 rounded-lg bg-primary/5 p-2">
                <div className="flex items-center gap-1.5 text-[9px] font-medium text-primary">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" /> AI insight
                </div>
                <p className="mt-1 text-[9px] leading-snug text-muted-foreground">
                  Engineering attrition is trending 2.1% below company average this quarter.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

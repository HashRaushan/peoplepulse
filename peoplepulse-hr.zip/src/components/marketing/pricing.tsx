"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { PRICING_PLANS } from "@/lib/constants";
import { api } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { inr } from "@/lib/hr-utils";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Check, Sparkles, ArrowRight, Loader2 } from "lucide-react";

export function Pricing() {
  const { setView, setAuthTab, setRegPlan } = useAppStore();
  const [annual, setAnnual] = useState(true);
  const [demoOpen, setDemoOpen] = useState(false);

  return (
    <section id="pricing" className="py-20 md:py-28">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <Badge variant="secondary" className="mb-4 gap-1.5 rounded-full px-3 py-1 text-xs font-medium">
            <Sparkles className="h-3 w-3" /> Simple per-employee pricing
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Pricing that scales with your team
          </h2>
          <p className="mt-4 text-muted-foreground">
            Start with a 14-day free trial. Upgrade, downgrade or cancel anytime.
            All plans include every core module — higher tiers add payroll, analytics and AI.
          </p>

          <div className="mt-8 inline-flex items-center rounded-full border bg-card p-1 text-sm font-medium">
            <button
              onClick={() => setAnnual(false)}
              className={cn(
                "rounded-full px-4 py-1.5 transition-colors",
                !annual ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={cn(
                "rounded-full px-4 py-1.5 transition-colors",
                annual ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              Annual
              <span className={cn("ml-2 rounded-full px-2 py-0.5 text-[10px]", annual ? "bg-primary-foreground/20" : "bg-accent text-accent-foreground")}>
                Save 20%
              </span>
            </button>
          </div>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {PRICING_PLANS.map((plan) => {
            const price = annual ? plan.annualPerEmployee : plan.monthlyPerEmployee;
            const isEnterprise = plan.key === "enterprise";
            return (
              <div
                key={plan.key}
                className={cn(
                  "relative flex flex-col rounded-2xl border bg-card p-6 shadow-sm",
                  plan.highlight && "border-primary shadow-lg ring-1 ring-primary/20"
                )}
              >
                {plan.highlight && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-[11px] font-semibold text-primary-foreground">
                    Most popular
                  </span>
                )}
                <h3 className="text-lg font-semibold">{plan.name}</h3>
                <p className="mt-1 min-h-10 text-xs text-muted-foreground">{plan.tagline}</p>
                <div className="mt-5">
                  {isEnterprise ? (
                    <div className="text-3xl font-bold">Custom</div>
                  ) : (
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-bold">{inr(price)}</span>
                      <span className="text-xs text-muted-foreground">/employee /mo</span>
                    </div>
                  )}
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {isEnterprise ? "Volume-based, tailored to your organisation" : annual ? "billed annually" : "billed monthly"}
                  </p>
                </div>
                <Button
                  className="mt-5 w-full"
                  variant={plan.highlight ? "default" : "outline"}
                  onClick={() => {
                    if (isEnterprise) {
                      setDemoOpen(true);
                    } else {
                      setRegPlan(plan.key);
                      setAuthTab("register");
                      setView("auth");
                    }
                  }}
                >
                  {plan.cta}
                  {!isEnterprise && <ArrowRight className="ml-1 h-4 w-4" />}
                </Button>
                <ul className="mt-6 space-y-2.5 text-sm">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          Prices exclusive of GST. Annual plans are invoiced upfront. Enterprise includes volume pricing, SSO and a dedicated success manager. Payments are by UPI or bank transfer with manual verification — no card required.
        </p>

        {/* FAQ */}
        <div className="mx-auto mt-20 max-w-3xl">
          <h3 className="text-center text-2xl font-bold tracking-tight">Frequently asked questions</h3>
          <div className="mt-8 space-y-3">
            {[
              {
                q: "Is there really a free trial?",
                a: "Yes — every plan starts with a 14-day free trial with full access to your chosen tier. No credit card is required to start. Every signup, trial included, is reviewed and approved by the platform administrator — trials are free for 14 days once approved.",
              },
              {
                q: "How do payments work?",
                a: "Pay via UPI or bank transfer (NEFT/IMPS) directly to the platform's account. After transferring, submit your transaction reference (UTR) in the app. The administrator verifies it against their bank statement and activates your workspace — usually within a few hours. You'll receive an email as soon as you're live.",
              },
              {
                q: "How does per-employee pricing work?",
                a: `You pay a flat rate per active employee per month. ${inr(99)}/employee on Growth monthly, or ${inr(79)}/employee billed annually. You are never charged for exited employees, and you can adjust seats anytime from Settings.`,
              },
              {
                q: "Is payroll included in every plan?",
                a: "Payroll processing with configurable statutory components (PF, ESI, PT, TDS) is included from the Growth plan onwards. Starter covers core HR, attendance, leave and self-service. Statutory configurations are effective-dated and must be reviewed by your payroll administrator.",
              },
              {
                q: "Is our data isolated from other companies?",
                a: "Absolutely. PeoplePulse HR is built multi-tenant from the ground up: every record is scoped to your organisation ID at the database layer, and every API request re-verifies your tenant context. Tenant isolation is enforced server-side, never by the frontend.",
              },
              {
                q: "Can we export our data if we leave?",
                a: "Yes. Administrators can export employees, attendance, leave, payroll registers and reports to CSV/Excel at any time. Your data belongs to you — no lock-in.",
              },
              {
                q: "Do you support companies outside India?",
                a: "The platform is internationalised: configurable currency, timezone, country and statutory components. Indian payroll (PF/ESI/PT/TDS) ships with sensible defaults; other jurisdictions are configuration-driven.",
              },
            ].map((item) => (
              <details key={item.q} className="group rounded-xl border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex cursor-pointer items-center justify-between gap-4 text-sm font-medium">
                  {item.q}
                  <span className="text-muted-foreground transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.a}</p>
              </details>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="relative mt-20 overflow-hidden rounded-3xl bg-primary px-6 py-14 text-center text-primary-foreground md:py-16">
          <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
          <div className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
          <h2 className="relative text-2xl font-bold sm:text-3xl">
            Ready to run HR the modern way?
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-sm opacity-90">
            Set up your organisation in minutes. Import employees, configure leave policies,
            run payroll and let the AI copilot handle the routine questions.
          </p>
          <div className="relative mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button
              size="lg"
              variant="secondary"
              onClick={() => {
                setRegPlan("trial");
                setAuthTab("register");
                setView("auth");
              }}
            >
              Start your free trial
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/40 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
              onClick={() => setDemoOpen(true)}
            >
              Book a live demo
            </Button>
          </div>
        </div>
      </div>

      <DemoDialog open={demoOpen} onOpenChange={setDemoOpen} />
    </section>
  );
}

function DemoDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [size, setSize] = useState("51-200");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !company.trim()) {
      toast.error("Please fill in your name, work email and company.");
      return;
    }
    setBusy(true);
    try {
      await api.post("/api/leads", { name, email, company, companySize: size, message, source: "demo" });
      toast.success("Demo request received", {
        description: "Our team will reach out within one business day to schedule your walkthrough.",
      });
      onOpenChange(false);
      setName(""); setEmail(""); setCompany(""); setMessage("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not submit request");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Book a live demo</DialogTitle>
          <DialogDescription>
            Tell us about your organisation and we&apos;ll walk you through the full platform.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="demo-name">Full name</Label>
              <Input id="demo-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Aarav Shah" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="demo-email">Work email</Label>
              <Input id="demo-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="aarav@company.com" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="demo-company">Company</Label>
              <Input id="demo-company" value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Acme Pvt Ltd" />
            </div>
            <div className="grid gap-1.5">
              <Label>Employees</Label>
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["1-10", "11-50", "51-200", "201-500", "501-2000", "2000+"].map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="demo-msg">What would you like to see?</Label>
            <Textarea
              id="demo-msg"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Payroll for a 300-person manufacturing team, attendance shifts, performance cycles…"
              className="min-h-20"
            />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Request demo
          </Button>
          <p className="text-center text-[11px] text-muted-foreground">
            By submitting you agree to be contacted about PeoplePulse HR. No spam, ever.
          </p>
        </form>
      </DialogContent>
    </Dialog>
  );
}

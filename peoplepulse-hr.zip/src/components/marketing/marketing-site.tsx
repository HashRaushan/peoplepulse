"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Menu, X, ArrowRight } from "lucide-react";
import { Hero } from "./hero";
import { Features, StatsBand } from "./features";
import { Pricing } from "./pricing";

const NAV_LINKS = [
  { href: "#modules", label: "Platform" },
  { href: "#ai", label: "AI" },
  { href: "#security", label: "Security" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function MarketingSite() {
  const { setView, setAuthTab } = useAppStore();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* ---------- Header ---------- */}
      <header
        className={cn(
          "sticky top-0 z-50 w-full border-b transition-all",
          scrolled ? "border-border bg-background/85 backdrop-blur-lg" : "border-transparent bg-transparent"
        )}
      >
        <div className="container mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="flex items-center gap-2.5"
            aria-label="PeoplePulse HR home"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-sm font-bold text-primary-foreground shadow-sm">
              P
            </span>
            <span className="text-lg font-bold tracking-tight">
              PeoplePulse<span className="text-primary"> HR</span>
            </span>
          </button>

          <nav className="hidden items-center gap-7 md:flex" aria-label="Main">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-2 md:flex">
            <Button variant="ghost" size="sm" onClick={() => { setAuthTab("login"); setView("auth"); }}>
              Sign in
            </Button>
            <Button size="sm" onClick={() => { setAuthTab("register"); setView("auth"); }}>
              Get started
              <ArrowRight className="ml-1 h-3.5 w-3.5" />
            </Button>
          </div>

          <button
            className="rounded-md p-2 md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {mobileOpen && (
          <div className="border-b bg-background md:hidden">
            <nav className="container mx-auto flex max-w-6xl flex-col gap-1 px-4 py-3" aria-label="Mobile">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="rounded-md px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                >
                  {link.label}
                </a>
              ))}
              <div className="mt-2 flex gap-2 px-3 pb-3">
                <Button variant="outline" className="flex-1" onClick={() => { setAuthTab("login"); setView("auth"); }}>
                  Sign in
                </Button>
                <Button className="flex-1" onClick={() => { setAuthTab("register"); setView("auth"); }}>
                  Get started
                </Button>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* ---------- Body ---------- */}
      <main className="flex-1">
        <Hero />
        <StatsBand />
        <Features />
        <Pricing />
      </main>

      {/* ---------- Footer (sticky bottom) ---------- */}
      <footer className="mt-auto border-t bg-muted/30 pb-[env(safe-area-inset-bottom)]">
        <div className="container mx-auto max-w-6xl px-4 py-14">
          <div className="grid gap-10 md:grid-cols-5">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">P</span>
                <span className="font-bold tracking-tight">PeoplePulse HR</span>
              </div>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
                The intelligent HR platform for modern teams. Core HR, attendance, leave,
                payroll, recruitment, performance, engagement and AI — unified, secure and fast.
              </p>
              <p className="mt-4 text-xs text-muted-foreground">
                Made for businesses in India and around the world.
              </p>
            </div>
            {[
              {
                title: "Platform",
                links: ["Core HR", "Attendance & Shifts", "Leave Management", "Payroll", "Expenses", "Assets", "Recruitment", "Training & LMS", "Performance & Goals", "Surveys & eNPS", "Documents", "People Analytics"],
              },
              {
                title: "Solutions",
                links: ["Startups", "IT & Technology", "Manufacturing", "Retail & Hospitality", "Healthcare", "Remote teams"],
              },
              {
                title: "Company",
                links: ["About", "Security", "Pricing", "Book a demo", "Support", "Status"],
              },
            ].map((col) => (
              <div key={col.title}>
                <h4 className="text-sm font-semibold">{col.title}</h4>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l}>
                      <button
                        onClick={() => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" })}
                        className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                      >
                        {l}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t pt-6 text-xs text-muted-foreground sm:flex-row">
            <p>© {new Date().getFullYear()} PeoplePulse HR. Your company's private HR workspace — data stays on your installation.</p>
            <div className="flex gap-5">
              <span className="cursor-default">Terms</span>
              <span className="cursor-default">Privacy</span>
              <span className="cursor-default">Data Processing</span>
              <span className="cursor-default">Security</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

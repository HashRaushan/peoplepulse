"use client";

/**
 * PeoplePulse HR — Application shell.
 * Sidebar + topbar + notifications + command palette + module router.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "@/lib/store";
import { api, qk } from "@/lib/api-client";
import { NAV_SECTIONS } from "@/lib/constants";
import { cn, initials, ago } from "@/lib/hr-utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator,
} from "@/components/ui/command";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import {
  Menu, Search, Bell, LogOut, Sun, Moon, Command as CommandIcon, Sparkles,
  CheckCheck, ChevronRight,
} from "lucide-react";
import type { ModuleKey, NotificationDto } from "@/lib/types";

// Modules
import { DashboardModule } from "./modules/dashboard";
import { AnalyticsModule } from "./modules/analytics";
import { EmployeesModule } from "./modules/employees";
import { OrgChartModule } from "./modules/org-chart";
import { DirectoryModule } from "./modules/directory";
import { AttendanceModule } from "./modules/attendance";
import { LeaveModule } from "./modules/leave";
import { RecruitmentModule } from "./modules/recruitment";
import { PayrollModule } from "./modules/payroll";
import { PerformanceModule } from "./modules/performance";
import { ExpensesModule } from "./modules/expenses";
import { AssetsModule } from "./modules/assets";
import { TrainingModule } from "./modules/training";
import { SurveysModule } from "./modules/surveys";
import { DocumentsModule } from "./modules/documents";
import { AnnouncementsModule } from "./modules/announcements";
import { HelpdeskModule } from "./modules/helpdesk";
import { WorkflowsModule } from "./modules/workflows";
import { AssistantModule } from "./modules/assistant";
import { SettingsModule } from "./modules/settings";
import { PlatformAdminModule } from "./modules/platform-admin";
import { PendingScreen } from "./pending-screen";

import { ShieldCheck } from "lucide-react";
import type { NavSection } from "@/lib/constants";

/** Extra nav section shown only to the platform super admin. */
const PLATFORM_NAV: NavSection = {
  label: "Platform",
  items: [{ key: "platform", label: "Platform Admin", icon: ShieldCheck, roles: ["owner"] }],
};

export function AppView() {
  const { user, module, setModule, signOut } = useAppStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const qc = useQueryClient();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const notificationsQuery = useQuery({
    queryKey: qk.notifications,
    queryFn: () => api.get<{ items: NotificationDto[] }>("/api/notifications"),
    refetchInterval: 60_000,
  });

  const markReadMutation = useMutation({
    mutationFn: () => api.patch("/api/notifications", { all: true }),
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.notifications }),
  });

  async function handleSignOut() {
    await api.post("/api/auth/logout").catch(() => {});
    // Drop every cached query so the next tenant never sees this one's data.
    qc.clear();
    signOut();
    toast.success("Signed out. See you soon.");
  }

  const visibleSections = useMemo(() => {
    if (!user) return [];
    const base = user.superAdmin ? [...NAV_SECTIONS, PLATFORM_NAV] : NAV_SECTIONS;
    return base
      .map((s) => ({
        ...s,
        items: s.items.filter((i) => i.roles.includes(user.role)),
      }))
      .filter((s) => s.items.length > 0);
  }, [user]);

  const unreadCount = notificationsQuery.data?.items.filter((n) => !n.read).length ?? 0;
  const trialDaysLeft = user?.trialEndsAt
    ? Math.max(0, Math.ceil((new Date(user.trialEndsAt).getTime() - Date.now()) / 86400000))
    : null;

  if (!user) return null;

  // Blocked workspaces (pending approval / rejected / suspended / expired)
  // get the dedicated activation & payment screen instead of the app shell.
  if (user.blocked && !user.superAdmin) {
    return <PendingScreen />;
  }

  const Module = getModule(module, user.role, user.superAdmin);

  const SidebarNav = (
    <nav className="flex h-full flex-col gap-0.5 overflow-y-auto scrollbar-thin px-3 pb-4" aria-label="Modules">
      {visibleSections.map((section) => (
        <div key={section.label} className="mb-1">
          <p className="px-2.5 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/70">
            {section.label}
          </p>
          {section.items.map((item) => {
            const Icon = item.icon;
            const active = module === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  setModule(item.key);
                  setSidebarOpen(false);
                }}
                className={cn(
                  "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-colors",
                  active
                    ? "bg-primary/10 font-medium text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className={cn("h-4 w-4 shrink-0", active ? "text-primary" : "text-muted-foreground/80")} />
                <span className="truncate">{item.label}</span>
                {active && <ChevronRight className="ml-auto h-3.5 w-3.5" />}
              </button>
            );
          })}
        </div>
      ))}
    </nav>
  );

  return (
    <div className="flex min-h-screen bg-muted/30">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r bg-sidebar lg:flex">
        <div className="flex h-16 items-center gap-2.5 border-b px-5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl text-sm font-bold text-white"
            style={{ background: user.brandColor }}
          >
            {user.logoText}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold leading-tight">{user.tenantName}</p>
            <p className="text-[10px] capitalize text-muted-foreground">{user.plan} plan</p>
          </div>
        </div>
        {SidebarNav}
        <div className="border-t p-3">
          <button
            onClick={() => setModule("assistant")}
            className="flex w-full items-center gap-2.5 rounded-xl bg-gradient-to-r from-primary/15 to-chart-2/10 p-3 text-left transition-colors hover:from-primary/25"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sparkles className="h-4 w-4" />
            </span>
            <span>
              <span className="block text-xs font-semibold">Ask Pulse AI</span>
              <span className="block text-[10px] text-muted-foreground">HR copilot, ready to help</span>
            </span>
          </button>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur-lg md:px-6">
          {/* Mobile menu */}
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="flex h-16 items-center gap-2.5 border-b px-5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl text-sm font-bold text-white" style={{ background: user.brandColor }}>
                  {user.logoText}
                </span>
                <span className="truncate text-sm font-bold">{user.tenantName}</span>
              </div>
              {SidebarNav}
            </SheetContent>
          </Sheet>

          {/* Search trigger */}
          <button
            onClick={() => setPaletteOpen(true)}
            className="hidden items-center gap-2 rounded-lg border bg-card px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent sm:flex sm:w-72"
          >
            <Search className="h-4 w-4" />
            <span className="flex-1 text-left">Search or jump to…</span>
            <kbd className="hidden items-center gap-0.5 rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] md:flex">
              <CommandIcon className="h-2.5 w-2.5" />K
            </kbd>
          </button>

          <div className="ml-auto flex items-center gap-1.5">
            {/* Notifications */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[9px] font-bold text-white">
                      {unreadCount}
                    </span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 p-0">
                <div className="flex items-center justify-between border-b px-4 py-3">
                  <p className="text-sm font-semibold">Notifications</p>
                  {unreadCount > 0 && (
                    <Button variant="ghost" size="sm" className="h-6 text-[11px]" onClick={() => markReadMutation.mutate()}>
                      <CheckCheck className="mr-1 h-3 w-3" /> Mark all read
                    </Button>
                  )}
                </div>
                {notificationsQuery.isPending && (
                  <div className="space-y-3 px-4 py-3">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="space-y-1.5">
                        <Skeleton className="h-3.5 w-3/4" />
                        <Skeleton className="h-2.5 w-full" />
                        <Skeleton className="h-2 w-1/4" />
                      </div>
                    ))}
                  </div>
                )}
                <div className="max-h-80 overflow-y-auto scrollbar-thin">
                  {notificationsQuery.data?.items.length === 0 && (
                    <p className="px-4 py-8 text-center text-xs text-muted-foreground">No notifications yet.</p>
                  )}
                  {notificationsQuery.data?.items.map((n) => (
                    <div key={n.id} className={cn("border-b px-4 py-3 last:border-0", !n.read && "bg-primary/5")}>
                      <p className="text-xs font-medium">{n.title}</p>
                      <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">{n.body}</p>
                      <p className="mt-1 text-[10px] text-muted-foreground/70">{ago(n.createdAt)}</p>
                    </div>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Theme */}
            <Button
              variant="ghost" size="icon" aria-label="Toggle theme"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-transform dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-transform dark:rotate-0 dark:scale-100" />
            </Button>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-2 rounded-full border bg-card p-1 pr-2.5 transition-colors hover:bg-accent"
                  aria-label="Account menu"
                >
                  <span
                    className="flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-bold"
                    style={{ backgroundColor: user.brandColor + "22", color: user.brandColor }}
                  >
                    {initials(user.name)}
                  </span>
                  <span className="hidden text-xs font-medium md:block">{user.name.split(" ")[0]}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <p className="text-sm font-semibold">{user.name}</p>
                  <p className="text-xs font-normal text-muted-foreground">{user.email}</p>
                  <Badge variant="secondary" className="mt-1.5 text-[10px] capitalize">{user.role}</Badge>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setModule("settings")}>
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setModule("assistant")}>
                  <Sparkles className="mr-1.5 h-3.5 w-3.5" /> AI Assistant
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-1.5 h-3.5 w-3.5" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Trial banner */}
        {user.planStatus === "trialing" && trialDaysLeft !== null && (
          <div className="flex items-center justify-center gap-2 border-b bg-primary/10 px-4 py-2 text-center text-xs text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            Free trial — {trialDaysLeft} days remaining with full {user.plan} features.
            <button className="font-semibold underline underline-offset-2" onClick={() => setModule("settings")}>
              Manage plan
            </button>
          </div>
        )}

        {/* Module content */}
        <main className="min-w-0 flex-1 p-4 md:p-6 lg:p-8">
          <div className="mx-auto max-w-7xl">{Module}</div>
        </main>

        {/* Footer */}
        <footer className="mt-auto border-t bg-background px-6 py-4 text-center text-[11px] text-muted-foreground">
          PeoplePulse HR · Multi-tenant HRMS platform · Signed in to <span className="font-medium text-foreground">{user.tenantName}</span> · Data isolated per organisation
        </footer>
      </div>

      {/* Command palette */}
      <CommandDialog open={paletteOpen} onOpenChange={setPaletteOpen}>
        <CommandInput placeholder="Type a command or search modules…" />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          {visibleSections.map((section) => (
            <CommandGroup key={section.label} heading={section.label}>
              {section.items.map((item) => (
                <CommandItem
                  key={item.key}
                  onSelect={() => {
                    setModule(item.key);
                    setPaletteOpen(false);
                  }}
                  className="gap-2"
                >
                  <item.icon className="h-4 w-4 text-muted-foreground" />
                  {item.label}
                </CommandItem>
              ))}
            </CommandGroup>
          ))}
          <CommandSeparator />
          <CommandGroup heading="Actions">
            <CommandItem onSelect={() => { handleSignOut(); setPaletteOpen(false); }} className="gap-2">
              <LogOut className="h-4 w-4 text-muted-foreground" /> Sign out
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </div>
  );
}

function getModule(key: ModuleKey, role: string, superAdmin?: boolean) {
  const MGMT = ["owner", "admin", "hr", "manager"];
  const isMGMT = MGMT.includes(role);
  switch (key) {
    case "dashboard": return <DashboardModule />;
    case "analytics":
      return ["owner", "admin", "hr"].includes(role) ? <AnalyticsModule /> : <DashboardModule />;
    case "employees": return isMGMT ? <EmployeesModule /> : <DashboardModule />;
    case "orgchart": return isMGMT ? <OrgChartModule /> : <DashboardModule />;
    case "directory": return <DirectoryModule />;
    case "attendance": return <AttendanceModule />;
    case "leave": return <LeaveModule />;
    case "recruitment": return isMGMT ? <RecruitmentModule /> : <DashboardModule />;
    case "payroll": return <PayrollModule />;
    case "expenses": return <ExpensesModule />;
    case "assets": return <AssetsModule />;
    case "training": return <TrainingModule />;
    case "surveys": return <SurveysModule />;
    case "documents": return <DocumentsModule />;
    case "performance": return <PerformanceModule />;
    case "announcements": return <AnnouncementsModule />;
    case "helpdesk": return <HelpdeskModule />;
    case "workflows":
      return ["owner", "admin", "hr"].includes(role) ? <WorkflowsModule /> : <DashboardModule />;
    case "assistant": return <AssistantModule />;
    case "platform": return superAdmin ? <PlatformAdminModule /> : <DashboardModule />;
    case "settings": return <SettingsModule />;
    default: return <DashboardModule />;
  }
}

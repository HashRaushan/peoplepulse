"use client";

import { useQuery } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { useAppStore } from "@/lib/store";
import { cn, inr, fmtDate, initials, ago } from "@/lib/hr-utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, Cell,
} from "recharts";
import {
  Users, CalendarCheck2, PlaneTakeoff, Clock3, LifeBuoy, TrendingUp, TrendingDown,
  Wallet, UserRoundSearch, ArrowRight, Megaphone, CheckCircle2, PartyPopper,
  Rocket, Check,
} from "lucide-react";
import type { AdminDashboard, EmployeeDashboard, ModuleKey, OrgSetupDto } from "@/lib/types";

const CHART_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

export function DashboardModule() {
  const { user, setModule } = useAppStore();
  const isStaff = user && ["owner", "admin", "hr", "manager"].includes(user.role);

  const { data, dataUpdatedAt, isError, error, refetch, isLoading } = useQuery({
    queryKey: qk.dashboard,
    queryFn: () => api.get<AdminDashboard | EmployeeDashboard>("/api/dashboard"),
  });

  // First-run setup checklist — owners/admins/hr only; auto-hides when complete.
  const setupQuery = useQuery({
    queryKey: qk.orgSetup,
    queryFn: () => api.get<OrgSetupDto>("/api/org/setup"),
    enabled: !!user && ["owner", "admin", "hr"].includes(user.role),
  });

  if (isError) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
        <p className="text-sm font-medium">Could not load your dashboard</p>
        <p className="max-w-md text-sm text-muted-foreground">
          {error instanceof Error ? error.message : "We could not load this data. Please try again."}
        </p>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          Retry
        </Button>
      </div>
    );
  }

  if (isLoading || !user) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-72" />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-72" />
      </div>
    );
  }

  const setup = setupQuery.data;

  if (isStaff && data && "kpis" in data) {
    return (
      <div className="space-y-6">
        {setup && !setup.complete && <SetupChecklistCard setup={setup} onNavigate={setModule} />}
        <AdminDashboardView data={data} updatedAt={dataUpdatedAt} />
      </div>
    );
  }
  if (!isStaff && data && "greeting" in data) return <EmployeeDashboardView data={data} />;
  return null;
}

// ============================== First-run setup checklist ==============================

function SetupChecklistCard({
  setup,
  onNavigate,
}: {
  setup: OrgSetupDto;
  onNavigate: (m: ModuleKey) => void;
}) {
  const steps: { label: string; hint: string; done: boolean; cta: string; module: ModuleKey }[] = [
    {
      label: "Add your employees",
      hint: `${setup.employees} of 2 added`,
      done: setup.employees >= 2,
      cta: "Add employees",
      module: "employees",
    },
    {
      label: "Grant login access",
      hint: `${setup.withLogins} of 2 can sign in`,
      done: setup.withLogins >= 2,
      cta: "Manage access",
      module: "employees",
    },
    {
      label: "Review your leave policy",
      hint: `${setup.leaveTypes} leave ${setup.leaveTypes === 1 ? "type" : "types"} configured`,
      done: setup.leaveTypes >= 1,
      cta: "Open settings",
      module: "settings",
    },
    {
      label: "Welcome your team",
      hint:
        setup.announcements > 0
          ? `${setup.announcements} ${setup.announcements === 1 ? "announcement" : "announcements"} posted`
          : "No announcements yet",
      done: setup.announcements >= 1,
      cta: "Post announcement",
      module: "announcements",
    },
  ];
  const doneCount = steps.filter((s) => s.done).length;

  return (
    <Card className="border-primary/30">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm font-medium">
          <Rocket className="h-4 w-4 text-primary" /> Set up your workspace
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          A few steps to get your company running on PeoplePulse HR
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid gap-2 md:grid-cols-2">
          {steps.map((s, i) => (
            <div key={s.label} className="flex items-center gap-3 rounded-lg border p-3">
              {s.done ? (
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Check className="h-3.5 w-3.5" />
                </span>
              ) : (
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs font-semibold text-muted-foreground">
                  {i + 1}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <div className={cn("truncate text-sm font-medium", s.done && "text-muted-foreground")}>
                  {s.label}
                </div>
                <div className="text-[11px] text-muted-foreground">{s.hint}</div>
              </div>
              <Button
                variant={s.done ? "ghost" : "outline"}
                size="sm"
                className="h-7 shrink-0 text-xs"
                onClick={() => onNavigate(s.module)}
              >
                {s.cta} <ArrowRight className="ml-0.5 h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
        <Progress value={(doneCount / steps.length) * 100} className="h-1.5" />
        <p className="text-[11px] text-muted-foreground">
          {doneCount} of {steps.length} steps complete — this checklist hides itself once everything is done.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================== Admin dashboard ==============================

function AdminDashboardView({ data, updatedAt }: { data: AdminDashboard; updatedAt: number }) {
  const { setModule } = useAppStore();
  const k = data.kpis;

  const tiles = [
    { label: "Headcount", value: String(k.totalEmployees), sub: `${k.headcountChange30d >= 0 ? "+" : ""}${k.headcountChange30d} this month`, icon: Users, positive: k.headcountChange30d >= 0 },
    { label: "Present today", value: `${k.presentPct}%`, sub: `${k.activeToday} checked in · ${k.onLeaveToday} on leave`, icon: CalendarCheck2, positive: true },
    { label: "Pending approvals", value: String(k.pendingApprovals), sub: "leave requests waiting", icon: Clock3, positive: k.pendingApprovals < 5 },
    { label: "Open tickets", value: String(k.openTickets), sub: "HR helpdesk", icon: LifeBuoy, positive: k.openTickets < 5 },
    { label: "Attrition (annualised)", value: `${k.attritionRate}%`, sub: `${k.exits30d} exits in 30 days`, icon: k.attritionRate > 15 ? TrendingUp : TrendingDown, positive: k.attritionRate < 15 },
    { label: "Monthly payroll", value: inr(k.monthlyPayrollCost, { compact: true }), sub: data.payroll.label, icon: Wallet, positive: true },
    { label: "New joiners (30d)", value: String(k.newJoiners30d), sub: "welcome aboard", icon: PartyPopper, positive: true },
    { label: "Open roles", value: String(k.openRoles), sub: "active requisitions", icon: UserRoundSearch, positive: true },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Live overview across your organisation — every number is computed from real records.
          </p>
        </div>
        <Badge variant="secondary" className="gap-1.5">
          Updated {ago(new Date(updatedAt).toISOString())}
        </Badge>
      </div>

      {/* KPI tiles */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="transition-shadow hover:shadow-md">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">{t.label}</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight">{t.value}</p>
                </div>
                <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg", t.positive ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive")}>
                  <t.icon className="h-4 w-4" />
                </div>
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">{t.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Headcount growth — last 12 months</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.headcountTrend} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="hc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.28} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} domain={["dataMin - 5", "dataMax + 3"]} />
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }} />
                  <Area type="monotone" dataKey="count" stroke="var(--chart-1)" strokeWidth={2} fill="url(#hc)" name="Headcount" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Department split</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.departmentSplit} layout="vertical" margin={{ top: 0, right: 12, left: 8, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" width={92} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={14}>
                    {data.departmentSplit.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-1.5 text-[11px] text-muted-foreground">
              {data.departmentSplit.slice(0, 6).map((d, i) => (
                <span key={d.name} className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                  {d.name} · {d.value}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance + leave utilization */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Attendance rate — last 14 working days</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.attendanceTrend} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} interval={1} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }} />
                  <Area type="monotone" dataKey="presentPct" stroke="var(--chart-2)" strokeWidth={2} fill="var(--chart-2)" fillOpacity={0.12} name="Present %" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Leave utilisation by type</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3.5">
            {data.leaveUtilization.map((l) => {
              const pctUsed = l.entitled > 0 ? Math.round((l.used / l.entitled) * 100) : 0;
              return (
                <div key={l.name}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium">{l.name}</span>
                    <span className="text-muted-foreground">{l.used} / {l.entitled} days ({pctUsed}%)</span>
                  </div>
                  <Progress value={pctUsed} className="h-2" />
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Pending approvals + right column */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending leave approvals</CardTitle>
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setModule("leave")}>
              Review all <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardHeader>
          <CardContent>
            {data.pendingLeaveRequests.length === 0 ? (
              <p className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-primary" /> No pending approvals. You are all caught up.
              </p>
            ) : (
              <div className="max-h-64 space-y-2 overflow-y-auto scrollbar-thin">
                {data.pendingLeaveRequests.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setModule("leave")}
                    className="flex w-full items-center gap-3 rounded-lg border bg-card p-3 text-left transition-colors hover:bg-accent/50"
                  >
                    <span
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold"
                      style={{ backgroundColor: r.avatarColor + "22", color: r.avatarColor }}
                    >
                      {initials(r.employeeName)}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{r.employeeName}</span>
                      <span className="block text-xs text-muted-foreground">
                        {r.typeName} · {fmtDate(r.startDate)} → {fmtDate(r.endDate)} · {r.days}d
                      </span>
                    </span>
                    <Badge variant="outline" className="shrink-0 text-[10px]">{r.department}</Badge>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Upcoming holidays</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {data.upcomingHolidays.length === 0 && <p className="text-xs text-muted-foreground">No upcoming holidays configured.</p>}
              {data.upcomingHolidays.map((h) => (
                <div key={h.id} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <PartyPopper className="h-3.5 w-3.5 text-primary" /> {h.name}
                  </span>
                  <span className="text-xs text-muted-foreground">{fmtDate(h.date)}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Latest announcements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {data.recentAnnouncements.slice(0, 3).map((a) => (
                <button key={a.id} onClick={() => setModule("announcements")} className="block w-full text-left">
                  <span className="flex items-center gap-1.5 text-xs font-medium">
                    <Megaphone className="h-3 w-3 text-primary" /> {a.title}
                  </span>
                  <span className="mt-0.5 block text-[11px] text-muted-foreground">{ago(a.createdAt)} · {a.authorName}</span>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ============================== Employee dashboard ==============================

function EmployeeDashboardView({ data }: { data: EmployeeDashboard }) {
  const { setModule } = useAppStore();
  const att = data.myAttendance;
  const totalBalanced = data.myBalances.reduce((s, b) => s + b.available, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Good day, {data.greeting.firstName}</h1>
        <p className="text-sm text-muted-foreground">
          {data.greeting.designation} · {data.greeting.department} — here is your day at a glance.
        </p>
      </div>

      {/* Status tiles */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground">Today</p>
            <p className="mt-1 text-xl font-bold capitalize text-primary">{att.todayStatus ?? "Not checked in"}</p>
            <p className="mt-2 text-[11px] text-muted-foreground">Mark attendance from the Attendance tab</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground">Leave available</p>
            <p className="mt-1 text-2xl font-bold">{totalBalanced}<span className="text-sm font-normal text-muted-foreground"> days</span></p>
            <p className="mt-2 text-[11px] text-muted-foreground">across all leave types</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground">This month</p>
            <p className="mt-1 text-2xl font-bold">{att.present + att.wfh + att.late}<span className="text-sm font-normal text-muted-foreground"> days present</span></p>
            <p className="mt-2 text-[11px] text-muted-foreground">avg {att.avgHours}h/day · {att.late} late</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-xs text-muted-foreground">Latest payslip</p>
            <p className="mt-1 text-2xl font-bold">
              {data.myPayslips[0] ? inr(data.myPayslips[0].net) : "—"}
            </p>
            <p className="mt-2 text-[11px] text-muted-foreground">
              {data.myPayslips[0] ? `${data.myPayslips[0].label} · ${data.myPayslips[0].status}` : "payslips appear after the first payroll run"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Onboarding tasks (if any) */}
      {data.onboardingTasks.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Your onboarding checklist</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-2">
              {data.onboardingTasks.map((t) => (
                <div key={t.id} className="flex items-center gap-2.5 rounded-lg border p-2.5 text-sm">
                  {t.status === "done" ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                  ) : (
                    <span className={cn("h-4 w-4 shrink-0 rounded-full border-2", t.status === "in_progress" ? "border-primary" : "border-muted-foreground/40")} />
                  )}
                  <span className={cn("flex-1 truncate", t.status === "done" && "text-muted-foreground line-through")}>{t.title}</span>
                  <span className="text-[10px] text-muted-foreground">due {fmtDate(t.dueDate)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Balances */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Leave balances</CardTitle>
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setModule("leave")}>
              Apply for leave <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            {data.myBalances.map((b) => (
              <div key={b.leaveTypeId} className="rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium">{b.name}</span>
                  <Badge variant="secondary" className="text-[10px]">{b.code}</Badge>
                </div>
                <p className="mt-1.5 text-xl font-bold">{b.available}<span className="text-xs font-normal text-muted-foreground"> / {b.entitled} days</span></p>
                <Progress value={b.entitled > 0 ? (b.used / b.entitled) * 100 : 0} className="mt-2 h-1.5" />
                <p className="mt-1.5 text-[10px] text-muted-foreground">{b.used} used · {b.pending} pending</p>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Pending requests */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">My pending requests</CardTitle>
          </CardHeader>
          <CardContent>
            {data.myPendingRequests.length === 0 ? (
              <p className="py-4 text-xs text-muted-foreground">No pending requests.</p>
            ) : (
              <div className="space-y-2">
                {data.myPendingRequests.map((r) => (
                  <div key={r.id} className="rounded-lg border p-2.5 text-xs">
                    <span className="font-medium">{r.typeName}</span> · {r.days}d
                    <span className="block text-[10px] text-muted-foreground">{fmtDate(r.startDate)} → {fmtDate(r.endDate)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Holidays + announcements */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming holidays</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-2">
            {data.upcomingHolidays.map((h) => (
              <div key={h.id} className="rounded-lg border p-2.5">
                <p className="text-xs font-medium">{h.name}</p>
                <p className="text-[10px] text-muted-foreground">{fmtDate(h.date)}</p>
              </div>
            ))}
            {data.upcomingHolidays.length === 0 && <p className="text-xs text-muted-foreground">None upcoming.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Announcements</CardTitle>
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setModule("announcements")}>
              View all <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {data.announcements.length === 0 && (
              <p className="text-xs text-muted-foreground">No announcements yet.</p>
            )}
            {data.announcements.slice(0, 3).map((a) => (
              <button key={a.id} onClick={() => setModule("announcements")} className="block w-full text-left">
                <span className="flex items-center gap-1.5 text-xs font-medium">
                  <Megaphone className="h-3 w-3 text-primary" /> {a.title}
                </span>
                <span className="mt-0.5 block line-clamp-1 text-[11px] text-muted-foreground">{a.body}</span>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

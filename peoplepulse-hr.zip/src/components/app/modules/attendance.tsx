"use client";

/**
 * PeoplePulse HR — Attendance module.
 * Team daily log (owner/admin/hr/manager) + personal attendance self-service.
 */

import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CalendarDays, ChevronLeft, ChevronRight, LogIn, LogOut, MapPin, Loader2 } from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { STATUS_LABELS } from "@/lib/constants";
import { cn, fmtDate, initials, isoDaysAgo, monthLabel, todayIso } from "@/lib/hr-utils";
import { formatDistance } from "@/lib/geo";
import { useAppStore } from "@/lib/store";
import { HR_ROLES } from "@/lib/types";
import type {
  AttendanceDto,
  AttendanceStatus,
  AttendanceSummary,
  DepartmentDto,
  GeoFenceConfigDto,
  MyAttendanceResponse,
} from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local helpers =====================

const STRIP_STATUS_CLASSES: Record<AttendanceStatus, string> = {
  present: "bg-primary/80",
  wfh: "bg-chart-2",
  late: "bg-amber-500",
  absent: "bg-destructive",
  leave: "bg-violet-500",
  holiday: "bg-muted",
  half_day: "bg-amber-500",
};

const STRIP_LEGEND: { label: string; className: string }[] = [
  { label: "Present", className: "bg-primary/80" },
  { label: "WFH", className: "bg-chart-2" },
  { label: "Late", className: "bg-amber-500" },
  { label: "Leave", className: "bg-violet-500" },
  { label: "Absent", className: "bg-destructive" },
  { label: "No record", className: "bg-muted/40" },
];

interface TeamAttendanceResponse {
  date: string;
  summary: AttendanceSummary;
  records: AttendanceDto[];
}

interface PunchVars {
  action: "check_in" | "check_out" | "regularize";
  date?: string;
  status?: string;
  note?: string;
  latitude?: number;
  longitude?: number;
  accuracy?: number;
  successMessage: string;
}

function statusBadgeVariant(
  status: AttendanceStatus
): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "present":
      return "default";
    case "wfh":
      return "secondary";
    case "absent":
      return "destructive";
    default:
      return "outline";
  }
}

function Avatar({ name, color, className }: { name: string; color: string; className?: string }) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function StatChip({
  label,
  value,
  valueClassName,
}: {
  label: string;
  value: string | number;
  valueClassName?: string;
}) {
  return (
    <div className="rounded-xl border bg-card px-4 py-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={cn("mt-1 text-2xl font-bold tabular-nums", valueClassName)}>{value}</div>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function currentMonthStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function shiftMonth(month: string, delta: number): string {
  const [y, m] = month.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthTitle(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return monthLabel(m, y);
}

function isSunday(iso: string): boolean {
  return new Date(`${iso}T00:00:00`).getDay() === 0;
}

function hoursText(r: AttendanceDto): string {
  return r.hours != null ? `${r.hours.toFixed(1)} h` : "—";
}

// ===================== Geo-fencing =====================

interface GeoCoords {
  latitude: number;
  longitude: number;
  accuracy: number;
}

/**
 * Request the browser's geolocation as a Promise. Resolves with the GPS coords
 * or rejects with a human-readable error message (permission denied, unavailable, timeout).
 * Only called when the tenant has geo-fencing enabled.
 */
function getLocation(): Promise<GeoCoords> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      reject(new Error("Location services are not available on this device."));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        }),
      (err) => {
        const messages: Record<number, string> = {
          1: "Location access was denied. Please allow location in your browser to check in.",
          2: "Your location could not be determined. Try moving to an open area or enable GPS.",
          3: "Location request timed out. Please try again.",
        };
        reject(new Error(messages[err.code] ?? "Could not get your location. Please try again."));
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  });
}

/** Small badge showing the captured location + distance + inside/outside status. */
function GeoBadge({ r }: { r: AttendanceDto }) {
  if (r.distanceMeters == null && r.geoStatus == null) return null;
  const dist = formatDistance(r.distanceMeters);
  const inside = r.geoStatus === "inside";
  const outside = r.geoStatus === "outside";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium",
        inside && "bg-primary/10 text-primary",
        outside && "bg-amber-500/10 text-amber-600 dark:text-amber-400",
        !inside && !outside && "bg-muted text-muted-foreground"
      )}
      title={
        r.latitude != null && r.longitude != null
          ? `GPS: ${r.latitude.toFixed(5)}, ${r.longitude.toFixed(5)}${
              r.accuracy != null ? ` (±${Math.round(r.accuracy)}m)` : ""
            }`
          : undefined
      }
    >
      <MapPin className="h-3 w-3" />
      {inside ? (dist ? `${dist} · in office` : "In office") : outside ? `${dist ?? ""} · outside` : dist ?? "Location"}
    </span>
  );
}

// ===================== Module =====================

export function AttendanceModule() {
  const { user } = useAppStore();
  const isTeamView = !!user && HR_ROLES.includes(user.role);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Attendance</h1>
        <p className="text-sm text-muted-foreground">
          {isTeamView
            ? "Track daily attendance across the organisation and manage your own log."
            : "Check in, review your attendance history and regularise past entries."}
        </p>
      </div>

      {isTeamView ? (
        <Tabs defaultValue="team">
          <TabsList>
            <TabsTrigger value="team">Team</TabsTrigger>
            <TabsTrigger value="my">My attendance</TabsTrigger>
          </TabsList>
          <TabsContent value="team" className="mt-4">
            <TeamAttendanceView />
          </TabsContent>
          <TabsContent value="my" className="mt-4">
            <MyAttendanceView />
          </TabsContent>
        </Tabs>
      ) : (
        <MyAttendanceView />
      )}
    </div>
  );
}

// ===================== Team view (admin/manager) =====================

function TeamAttendanceView() {
  const [date, setDate] = useState(todayIso());
  const [department, setDepartment] = useState("all");

  const query = useQuery({
    queryKey: qk.attendance({ date, department }),
    queryFn: () =>
      api.get<TeamAttendanceResponse>(
        `/api/attendance?date=${date}${
          department === "all" ? "" : `&department=${encodeURIComponent(department)}`
        }`
      ),
  });

  const departmentsQuery = useQuery({
    queryKey: qk.departments,
    queryFn: () => api.get<{ items: DepartmentDto[] }>("/api/departments"),
  });

  const summary = query.data?.summary;
  const records = query.data?.records ?? [];
  // Real departments from the org, merged with any department present in the
  // current records (so the filter never offers a dead end).
  const departments = Array.from(
    new Set([
      ...(departmentsQuery.data?.items ?? []).map((d) => d.name),
      ...records.map((r) => r.department),
    ])
  ).sort();

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="space-y-1.5">
          <Label htmlFor="attendance-date">Date</Label>
          <Input
            id="attendance-date"
            type="date"
            className="w-full sm:w-44"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Department</Label>
          <Select value={department} onValueChange={setDepartment}>
            <SelectTrigger className="w-full sm:w-56">
              <SelectValue placeholder="All departments" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All departments</SelectItem>
              {departments.map((d) => (
                <SelectItem key={d} value={d}>
                  {d}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {date !== todayIso() ? (
          <Button variant="ghost" size="sm" onClick={() => setDate(todayIso())}>
            Jump to today
          </Button>
        ) : null}
      </div>

      {query.isPending ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-[5.25rem] rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-72 rounded-xl" />
        </div>
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <StatChip label="Present" value={summary?.present ?? 0} valueClassName="text-primary" />
            <StatChip label="WFH" value={summary?.wfh ?? 0} valueClassName="text-chart-2" />
            <StatChip label="Late" value={summary?.late ?? 0} valueClassName="text-amber-500" />
            <StatChip label="Absent" value={summary?.absent ?? 0} valueClassName="text-destructive" />
            <StatChip label="On leave" value={summary?.leave ?? 0} valueClassName="text-violet-500" />
          </div>

          <div className="overflow-hidden rounded-xl border bg-card">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <h3 className="text-sm font-semibold">Daily log — {fmtDate(date)}</h3>
              <span className="text-xs text-muted-foreground">{records.length} employees</span>
            </div>
            {records.length === 0 ? (
              <EmptyState
                icon={<CalendarDays className="h-8 w-8 text-muted-foreground/50" />}
                title="No attendance records"
                description={`Nobody has logged attendance for ${fmtDate(date)} yet.`}
              />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Check in</TableHead>
                    <TableHead>Check out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Note</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <div className="flex items-center gap-2.5">
                          <Avatar name={r.employeeName} color={r.avatarColor} />
                          <div>
                            <div className="font-medium">{r.employeeName}</div>
                            <div className="text-xs text-muted-foreground">{r.employeeCode}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{r.department}</TableCell>
                      <TableCell className="tabular-nums">{r.checkIn ?? "—"}</TableCell>
                      <TableCell className="tabular-nums">{r.checkOut ?? "—"}</TableCell>
                      <TableCell className="tabular-nums">{hoursText(r)}</TableCell>
                      <TableCell>
                        <Badge variant={statusBadgeVariant(r.status)}>
                          {STATUS_LABELS[r.status] ?? r.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <GeoBadge r={r} />
                      </TableCell>
                      <TableCell
                        className="max-w-48 truncate text-muted-foreground"
                        title={r.note ?? undefined}
                      >
                        {r.note ?? "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// ===================== My attendance view =====================

function MyAttendanceView() {
  const qc = useQueryClient();
  const [month, setMonth] = useState(currentMonthStr());
  const [regTarget, setRegTarget] = useState<AttendanceDto | null>(null);
  const [regStatus, setRegStatus] = useState("present");
  const [regNote, setRegNote] = useState("");

  const query = useQuery({
    queryKey: qk.myAttendance(month),
    queryFn: () => api.get<MyAttendanceResponse>(`/api/attendance/me?month=${month}`),
  });

  const punch = useMutation({
    mutationFn: (vars: PunchVars) =>
      api.post<{ record: AttendanceDto }>("/api/attendance/me", {
        action: vars.action,
        ...(vars.date ? { date: vars.date } : {}),
        ...(vars.status ? { status: vars.status } : {}),
        ...(vars.note ? { note: vars.note } : {}),
        ...(vars.latitude != null ? { latitude: vars.latitude } : {}),
        ...(vars.longitude != null ? { longitude: vars.longitude } : {}),
        ...(vars.accuracy != null ? { accuracy: vars.accuracy } : {}),
      }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["my-attendance"] });
      qc.invalidateQueries({ queryKey: ["attendance"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      toast.success(vars.successMessage);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const geoFenceQuery = useQuery({
    queryKey: qk.geoFence,
    queryFn: () => api.get<GeoFenceConfigDto>("/api/org/geo-fence"),
  });
  const geoFence = geoFenceQuery.data;
  const [gettingLocation, setGettingLocation] = useState(false);

  async function handleCheckIn() {
    if (geoFence?.enabled) {
      setGettingLocation(true);
      try {
        const coords = await getLocation();
        punch.mutate({
          action: "check_in",
          latitude: coords.latitude,
          longitude: coords.longitude,
          accuracy: coords.accuracy,
          successMessage: "Checked in. Have a great day.",
        });
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not get your location.");
      } finally {
        setGettingLocation(false);
      }
    } else {
      punch.mutate({ action: "check_in", successMessage: "Checked in. Have a great day." });
    }
  }

  const data = query.data;
  const today = todayIso();
  const todayRec = data?.records.find((r) => r.date === today) ?? null;
  const sundayToday = isSunday(today);
  const viewingCurrentMonth = data?.month === currentMonthStr();

  const monthRecords = useMemo(
    () => [...(data?.records ?? [])].sort((a, b) => b.date.localeCompare(a.date)),
    [data?.records]
  );

  function canRegularise(r: AttendanceDto): boolean {
    return r.date < today && r.date >= isoDaysAgo(7) && r.status !== "holiday";
  }

  function todaySection(): ReactNode {
    if (!viewingCurrentMonth) {
      return (
        <p className="text-sm text-muted-foreground">
          You are viewing {monthTitle(data?.month ?? month)}. Switch back to the current month to
          manage today&apos;s check-in.
        </p>
      );
    }
    if (sundayToday) {
      return (
        <div className="flex flex-col gap-3">
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <CalendarDays className="h-4 w-4" />
            Weekly off — attendance is not tracked on Sundays.
          </p>
          <Button size="lg" className="w-fit" disabled>
            <LogIn /> Check in
          </Button>
        </div>
      );
    }
    if (todayRec?.status === "leave") {
      return (
        <p className="text-sm text-muted-foreground">
          You are on approved leave today — no attendance required.
        </p>
      );
    }
    if (todayRec?.status === "holiday") {
      return (
        <p className="text-sm text-muted-foreground">Company holiday today — enjoy your day off.</p>
      );
    }
    if (!todayRec || !todayRec.checkIn) {
      return (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-muted-foreground">
            {todayRec ? "Checked-in time not recorded yet." : "No attendance logged yet today."}
          </p>
          {geoFence?.enabled && (
            <p className="flex items-center gap-1.5 text-xs text-primary">
              <MapPin className="h-3.5 w-3.5" />
              Location required — check-in is restricted to within{" "}
              {formatDistance(geoFence.officeRadiusMeters) ?? `${geoFence.officeRadiusMeters} m`} of{" "}
              {geoFence.officeLabel ?? "the office"}.
            </p>
          )}
          <Button
            size="lg"
            className="w-fit"
            disabled={punch.isPending || gettingLocation}
            onClick={handleCheckIn}
          >
            {gettingLocation ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Getting location…
              </>
            ) : (
              <>
                <LogIn /> Check in{geoFence?.enabled ? " with location" : ""}
              </>
            )}
          </Button>
        </div>
      );
    }
    if (!todayRec.checkOut) {
      return (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-muted-foreground">
            Checked in at{" "}
            <span className="font-semibold tabular-nums text-foreground">{todayRec.checkIn}</span>
          </p>
          <Button
            size="lg"
            variant="outline"
            className="w-fit"
            disabled={punch.isPending}
            onClick={() =>
              punch.mutate({ action: "check_out", successMessage: "Checked out. See you tomorrow." })
            }
          >
            <LogOut /> Check out
          </Button>
        </div>
      );
    }
    return (
      <div className="flex flex-wrap items-center gap-3">
        <p className="text-sm text-muted-foreground">
          In{" "}
          <span className="font-semibold tabular-nums text-foreground">{todayRec.checkIn}</span>
          {" · "}Out{" "}
          <span className="font-semibold tabular-nums text-foreground">{todayRec.checkOut}</span>
          {" · "}
          <span className="font-semibold tabular-nums text-foreground">{hoursText(todayRec)}</span>
        </p>
        <Badge variant={statusBadgeVariant(todayRec.status)}>
          {STATUS_LABELS[todayRec.status] ?? todayRec.status}
        </Badge>
        <GeoBadge r={todayRec} />
        <p className="text-xs text-muted-foreground">Day complete.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Month navigator */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          aria-label="Previous month"
          onClick={() => setMonth((m) => shiftMonth(m, -1))}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="min-w-36 text-center text-sm font-semibold">{monthTitle(month)}</div>
        <Button
          variant="outline"
          size="icon"
          aria-label="Next month"
          onClick={() => setMonth((m) => shiftMonth(m, 1))}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
        {month !== currentMonthStr() ? (
          <Button variant="ghost" size="sm" onClick={() => setMonth(currentMonthStr())}>
            This month
          </Button>
        ) : null}
      </div>

      {query.isPending ? (
        <div className="space-y-6">
          <div className="grid gap-4 lg:grid-cols-3">
            <Skeleton className="h-48 rounded-xl" />
            <div className="grid grid-cols-2 content-start gap-3 sm:grid-cols-3 lg:col-span-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))}
            </div>
          </div>
          <Skeleton className="h-32 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : !data ? null : (
        <>
          <div className="grid gap-4 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Today</CardTitle>
                <CardDescription>{fmtDate(today)}</CardDescription>
              </CardHeader>
              <CardContent>{todaySection()}</CardContent>
            </Card>
            <div className="grid grid-cols-2 content-start gap-3 sm:grid-cols-3 lg:col-span-2">
              <StatChip
                label="Present"
                value={data.summary.present}
                valueClassName="text-primary"
              />
              <StatChip label="WFH" value={data.summary.wfh} valueClassName="text-chart-2" />
              <StatChip label="Late" value={data.summary.late} valueClassName="text-amber-500" />
              <StatChip
                label="On leave"
                value={data.summary.leave}
                valueClassName="text-violet-500"
              />
              <StatChip
                label="Absent"
                value={data.summary.absent}
                valueClassName="text-destructive"
              />
              <StatChip
                label="Avg hours / day"
                value={data.avgHours != null ? data.avgHours.toFixed(1) : "—"}
              />
            </div>
          </div>

          {/* 30-day strip */}
          <div className="space-y-3 rounded-xl border bg-card p-4">
            <h3 className="text-sm font-semibold">Last 30 days</h3>
            <AttendanceStrip records={data.records} />
          </div>

          {/* Full month log */}
          <div className="overflow-hidden rounded-xl border bg-card">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <h3 className="text-sm font-semibold">{monthTitle(data.month)} log</h3>
              <span className="text-xs text-muted-foreground">{monthRecords.length} entries</span>
            </div>
            {monthRecords.length === 0 ? (
              <EmptyState
                icon={<CalendarDays className="h-8 w-8 text-muted-foreground/50" />}
                title="No attendance records"
                description={`You have no attendance entries for ${monthTitle(data.month)}.`}
              />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Check in</TableHead>
                    <TableHead>Check out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Note</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {monthRecords.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">{fmtDate(r.date)}</TableCell>
                      <TableCell>
                        <Badge variant={statusBadgeVariant(r.status)}>
                          {STATUS_LABELS[r.status] ?? r.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">
                        {r.checkIn ?? "—"}
                      </TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">
                        {r.checkOut ?? "—"}
                      </TableCell>
                      <TableCell className="tabular-nums">{hoursText(r)}</TableCell>
                      <TableCell>
                        <GeoBadge r={r} />
                      </TableCell>
                      <TableCell
                        className="max-w-48 truncate text-muted-foreground"
                        title={r.note ?? undefined}
                      >
                        {r.note ?? "—"}
                      </TableCell>
                      <TableCell className="text-right">
                        {canRegularise(r) ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 px-2 text-xs"
                            disabled={punch.isPending}
                            onClick={() => {
                              setRegTarget(r);
                              setRegStatus(r.status === "wfh" ? "wfh" : "present");
                              setRegNote(r.note ?? "");
                            }}
                          >
                            Regularise
                          </Button>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </>
      )}

      {/* Regularise dialog */}
      <Dialog open={!!regTarget} onOpenChange={(open) => !open && setRegTarget(null)}>
        {regTarget ? (
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>Regularise attendance</DialogTitle>
              <DialogDescription>
                Correct your entry for {fmtDate(regTarget.date)}. HR will review the change.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <RadioGroup value={regStatus} onValueChange={setRegStatus} className="grid-cols-2">
                  <Label className="flex cursor-pointer items-center gap-2 rounded-md border p-3 font-normal">
                    <RadioGroupItem value="present" />
                    Present
                  </Label>
                  <Label className="flex cursor-pointer items-center gap-2 rounded-md border p-3 font-normal">
                    <RadioGroupItem value="wfh" />
                    WFH
                  </Label>
                </RadioGroup>
              </div>
              <div className="space-y-2">
                <Label htmlFor="regularise-note">Note (optional)</Label>
                <Textarea
                  id="regularise-note"
                  className="min-h-20"
                  placeholder="Reason for regularisation, e.g. forgot to check in"
                  value={regNote}
                  onChange={(e) => setRegNote(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRegTarget(null)}>
                Cancel
              </Button>
              <Button
                disabled={punch.isPending}
                onClick={() => {
                  if (!regTarget) return;
                  punch.mutate({
                    action: "regularize",
                    date: regTarget.date,
                    status: regStatus,
                    note: regNote,
                    successMessage: "Regularisation request submitted",
                  });
                  setRegTarget(null);
                }}
              >
                Submit for review
              </Button>
            </DialogFooter>
          </DialogContent>
        ) : null}
      </Dialog>
    </div>
  );
}

// ===================== 30-day strip =====================

function AttendanceStrip({ records }: { records: AttendanceDto[] }) {
  const days = useMemo(() => {
    const out: string[] = [];
    const now = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      out.push(
        `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
          d.getDate()
        ).padStart(2, "0")}`
      );
    }
    return out;
  }, []);

  const byDate = useMemo(() => new Map(records.map((r) => [r.date, r])), [records]);

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-10 gap-1.5">
        {days.map((day) => {
          const rec = byDate.get(day);
          const sunday = isSunday(day);
          const cellClass = rec
            ? STRIP_STATUS_CLASSES[rec.status]
            : sunday
              ? "bg-muted"
              : "bg-muted/40";
          const label = rec
            ? `${fmtDate(day)} — ${STATUS_LABELS[rec.status] ?? rec.status}${
                rec.hours != null ? ` · ${rec.hours.toFixed(1)} h` : ""
              }`
            : `${fmtDate(day)} — ${sunday ? "Weekly off" : "No record"}`;
          return <div key={day} title={label} className={cn("h-5 rounded-sm", cellClass)} />;
        })}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
        {STRIP_LEGEND.map((l) => (
          <span key={l.label} className="flex items-center gap-1.5">
            <span className={cn("size-2.5 rounded-sm", l.className)} />
            {l.label}
          </span>
        ))}
      </div>
    </div>
  );
}

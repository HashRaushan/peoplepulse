"use client";

/**
 * PeoplePulse HR — Goals / OKR section of the Performance module.
 *
 * Rendered inside performance.tsx:
 *   - employees see only this section (self-service goals),
 *   - managerial roles see it as a "Goals" tab next to the review cycle tools.
 *
 * Features: scope (mine / team / all by role), cycle filter, status summary
 * chips, goal cards with progress bars + actions (update progress, change
 * status, edit, delete with confirm), and a create/edit dialog.
 */
import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Flag, MoreHorizontal, Pencil, Plus, Target, Trash2, TrendingUp } from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { STATUS_LABELS } from "@/lib/constants";
import { ago, cn, fmtDate, initials, todayIso } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { GoalDto, GoalStatus } from "@/lib/types";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local types & helpers =====================

type GoalScope = "mine" | "team" | "all";

interface GoalsResponse {
  goals: GoalDto[];
  cycles: string[];
  summary: { total: number; completed: number; onTrack: number; atRisk: number; behind: number };
}

const GOAL_STATUSES: GoalStatus[] = ["on_track", "at_risk", "behind", "completed"];
const HR_ONLY_ROLES = ["owner", "admin", "hr"];

/** Indian fiscal quarter label (FY starts April: FY26-Q1 = Apr-Jun 2025). */
function currentFiscalQuarter(now = new Date()): string {
  const year = now.getFullYear();
  const month = now.getMonth() + 1; // 1-12
  const fy = month >= 4 ? year + 1 : year;
  const quarter = month >= 4 ? Math.ceil((month - 3) / 3) : 4;
  return `FY${String(fy).slice(2)}-Q${quarter}`;
}

function goalProgress(currentValue: number, targetValue: number): number {
  return targetValue > 0 ? Math.min(100, Math.round((currentValue / targetValue) * 100)) : 0;
}

/** Compact number for progress labels: 10 -> "10", 7.5 -> "7.5". */
function fmtNum(n: number): string {
  return Number.isInteger(n) ? String(n) : String(Math.round(n * 10) / 10);
}

function GoalStatusBadge({ status }: { status: GoalStatus }) {
  if (status === "on_track") {
    return (
      <Badge className="border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
        {STATUS_LABELS.on_track}
      </Badge>
    );
  }
  if (status === "at_risk") {
    return (
      <Badge className="border-transparent bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
        {STATUS_LABELS.at_risk}
      </Badge>
    );
  }
  if (status === "behind") {
    return (
      <Badge className="border-transparent bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300">
        {STATUS_LABELS.behind}
      </Badge>
    );
  }
  return <Badge className="border-transparent bg-emerald-600 text-white">{STATUS_LABELS.completed}</Badge>;
}

/** Progress bar tint by status (primary is the emerald brand by default). */
function progressBarClass(status: GoalStatus): string {
  if (status === "at_risk") return "bg-amber-500/20 [&>div]:bg-amber-500";
  if (status === "behind") return "bg-red-500/20 [&>div]:bg-red-500";
  if (status === "completed") return "[&>div]:bg-emerald-600";
  return "";
}

function Avatar({ name, color, className }: { name: string; color: string; className?: string }) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function SummaryChip({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: "emerald" | "amber" | "red" | "solid";
}) {
  const toneClass =
    tone === "emerald"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "amber"
        ? "text-amber-600 dark:text-amber-400"
        : tone === "red"
          ? "text-red-600 dark:text-red-400"
          : tone === "solid"
            ? "rounded-full bg-emerald-600 px-1.5 text-white"
            : "text-foreground";
  return (
    <div className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1 text-xs">
      <span className={cn("font-semibold tabular-nums", toneClass)}>{value}</span>
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

// ===================== Section =====================

export function GoalsSection() {
  const { user } = useAppStore();
  const qc = useQueryClient();
  const role = user?.role ?? "employee";
  const isHrOnly = HR_ONLY_ROLES.includes(role);
  const today = todayIso();

  const permittedScopes = useMemo(() => {
    if (role === "employee") return [{ value: "mine" as const, label: "My goals" }];
    if (role === "manager") {
      return [
        { value: "mine" as const, label: "My goals" },
        { value: "team" as const, label: "My team" },
      ];
    }
    return [
      { value: "mine" as const, label: "My goals" },
      { value: "all" as const, label: "Everyone" },
    ];
  }, [role]);

  const [scope, setScope] = useState<GoalScope>(
    role === "employee" ? "mine" : role === "manager" ? "team" : "all"
  );
  const [cycle, setCycle] = useState(""); // "" = all cycles

  const goalsQuery = useQuery({
    queryKey: qk.goals({ scope, cycle }),
    queryFn: () =>
      api.get<GoalsResponse>(
        `/api/performance/goals?scope=${scope}${cycle ? `&cycle=${encodeURIComponent(cycle)}` : ""}`
      ),
  });

  const goals = goalsQuery.data?.goals ?? [];
  const cycles = goalsQuery.data?.cycles ?? [];
  const summary = goalsQuery.data?.summary;

  function invalidateGoals() {
    qc.invalidateQueries({ queryKey: ["goals"] });
  }

  // ---- create / edit dialog ----
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<GoalDto | null>(null);
  const [editorError, setEditorError] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: "",
    description: "",
    metric: "",
    targetValue: "",
    currentValue: "",
    unit: "",
    cycle: "",
    dueDate: "",
  });

  function setField(field: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function openCreate() {
    setEditing(null);
    setEditorError(null);
    setForm({
      title: "",
      description: "",
      metric: "",
      targetValue: "",
      currentValue: "",
      unit: "",
      cycle: currentFiscalQuarter(),
      dueDate: "",
    });
    setEditorOpen(true);
  }

  function openEdit(goal: GoalDto) {
    setEditing(goal);
    setEditorError(null);
    setForm({
      title: goal.title,
      description: goal.description,
      metric: goal.metric ?? "",
      targetValue: String(goal.targetValue),
      currentValue: String(goal.currentValue),
      unit: goal.unit ?? "",
      cycle: goal.cycle,
      dueDate: goal.dueDate ?? "",
    });
    setEditorOpen(true);
  }

  const saveMutation = useMutation({
    mutationFn: (payload: { id?: string; body: Record<string, unknown> }) =>
      payload.id
        ? api.patch<{ goal: GoalDto }>(`/api/performance/goals/${payload.id}`, {
            action: "update",
            ...payload.body,
          })
        : api.post<{ goal: GoalDto }>("/api/performance/goals", payload.body),
    onSuccess: (_data, payload) => {
      invalidateGoals();
      toast.success(payload.id ? "Goal updated" : "Goal created");
      setEditorOpen(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitEditor() {
    setEditorError(null);
    const title = form.title.trim();
    if (!title) {
      setEditorError("Give your goal a title.");
      return;
    }
    const targetValue = Number(form.targetValue);
    if (!Number.isFinite(targetValue) || targetValue <= 0) {
      setEditorError("Target value must be a number greater than zero.");
      return;
    }
    const body: Record<string, unknown> = {
      title,
      description: form.description.trim(),
      metric: form.metric.trim(),
      unit: form.unit.trim(),
      cycle: form.cycle.trim(),
      targetValue,
      ...(form.dueDate ? { dueDate: form.dueDate } : { dueDate: "" }),
    };
    if (editing) {
      const currentValue = Number(form.currentValue);
      if (!Number.isFinite(currentValue) || currentValue < 0) {
        setEditorError("Current value must be zero or more.");
        return;
      }
      body.currentValue = currentValue;
      saveMutation.mutate({ id: editing.id, body });
    } else {
      saveMutation.mutate({ body });
    }
  }

  // ---- update progress dialog ----
  const [progressGoal, setProgressGoal] = useState<GoalDto | null>(null);
  const [progressValue, setProgressValue] = useState("");

  function openProgress(goal: GoalDto) {
    setProgressGoal(goal);
    setProgressValue(String(goal.currentValue));
  }

  const parsedProgressValue = Number(progressValue);
  const previewProgress = progressGoal
    ? goalProgress(
        Number.isFinite(parsedProgressValue) ? Math.max(0, parsedProgressValue) : progressGoal.currentValue,
        progressGoal.targetValue
      )
    : 0;

  const progressMutation = useMutation({
    mutationFn: (v: { id: string; currentValue: number }) =>
      api.patch<{ goal: GoalDto }>(`/api/performance/goals/${v.id}`, {
        action: "progress",
        currentValue: v.currentValue,
      }),
    onSuccess: (data) => {
      invalidateGoals();
      toast.success(data.goal.status === "completed" ? "Goal completed" : "Progress updated");
      setProgressGoal(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitProgress() {
    if (!progressGoal) return;
    const currentValue = Number(progressValue);
    if (!Number.isFinite(currentValue) || currentValue < 0) {
      toast.error("Current value must be zero or more.");
      return;
    }
    progressMutation.mutate({ id: progressGoal.id, currentValue });
  }

  // ---- change status dialog ----
  const [statusGoal, setStatusGoal] = useState<GoalDto | null>(null);
  const [statusValue, setStatusValue] = useState<GoalStatus>("on_track");

  function openStatus(goal: GoalDto) {
    setStatusGoal(goal);
    setStatusValue(goal.status);
  }

  const statusMutation = useMutation({
    mutationFn: (v: { id: string; status: GoalStatus }) =>
      api.patch<{ goal: GoalDto }>(`/api/performance/goals/${v.id}`, {
        action: "status",
        status: v.status,
      }),
    onSuccess: () => {
      invalidateGoals();
      toast.success("Status updated");
      setStatusGoal(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  // ---- delete confirm ----
  const [deleteGoal, setDeleteGoal] = useState<GoalDto | null>(null);

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.delete<{ ok: boolean }>(`/api/performance/goals/${id}`),
    onSuccess: () => {
      invalidateGoals();
      toast.success("Goal deleted");
      setDeleteGoal(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const showEmployee = scope !== "mine";

  function emptyDescription(): string {
    if (cycle) return `No goals tracked for ${cycle} in this view yet.`;
    if (scope === "mine") return "Create your first goal for this quarter to start tracking progress.";
    if (scope === "team") return "No goals in your team yet. Goals you and your reports create will show up here.";
    return "No goals in the organisation yet. Goals will appear here as people create them.";
  }

  return (
    <div className="space-y-4">
      {/* Filters + actions */}
      <div className="flex flex-wrap items-center gap-2">
        {permittedScopes.length > 1 ? (
          <Select
            value={scope}
            onValueChange={(v) => {
              setScope(v as GoalScope);
              setCycle("");
            }}
          >
            <SelectTrigger className="w-[150px]" aria-label="Goals scope">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {permittedScopes.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : null}
        <Select value={cycle || "all"} onValueChange={(v) => setCycle(v === "all" ? "" : v)}>
          <SelectTrigger className="w-[150px]" aria-label="Filter by cycle">
            <SelectValue placeholder="All cycles" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All cycles</SelectItem>
            {cycles.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button size="sm" className="ml-auto" onClick={openCreate}>
          <Plus /> New goal
        </Button>
      </div>

      {/* Summary chips */}
      {summary ? (
        <div className="flex flex-wrap gap-2">
          <SummaryChip label="Total" value={summary.total} />
          <SummaryChip label="On track" value={summary.onTrack} tone="emerald" />
          <SummaryChip label="At risk" value={summary.atRisk} tone="amber" />
          <SummaryChip label="Behind" value={summary.behind} tone="red" />
          <SummaryChip label="Completed" value={summary.completed} tone="solid" />
        </div>
      ) : null}

      {/* Goal list */}
      {goalsQuery.isPending ? (
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-44 rounded-xl" />
          ))}
        </div>
      ) : goalsQuery.isError ? (
        <LoadError
          message={goalsQuery.error instanceof Error ? goalsQuery.error.message : undefined}
          onRetry={() => goalsQuery.refetch()}
        />
      ) : goals.length === 0 ? (
        <EmptyState
          icon={<Target className="h-8 w-8 text-muted-foreground/50" />}
          title="No goals yet"
          description={emptyDescription()}
        />
      ) : (
        <div className="max-h-[560px] overflow-y-auto scrollbar-thin pr-1">
          <div className="grid gap-4 md:grid-cols-2">
            {goals.map((g) => {
              const isOwner = !!user?.employeeId && g.employeeId === user.employeeId;
              const canManage = isOwner || isHrOnly;
              const overdue = !!g.dueDate && g.dueDate < today && g.status !== "completed";
              return (
                <Card key={g.id} className="gap-4 p-4 sm:p-6">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-semibold leading-snug">{g.title}</h3>
                        <GoalStatusBadge status={g.status} />
                      </div>
                      {g.description ? (
                        <p className="line-clamp-2 text-sm text-muted-foreground">{g.description}</p>
                      ) : null}
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0"
                          aria-label={`Actions for goal: ${g.title}`}
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuItem onClick={() => openProgress(g)}>
                          <TrendingUp /> Update progress
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openStatus(g)}>
                          <Flag /> Change status
                        </DropdownMenuItem>
                        {canManage ? (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openEdit(g)}>
                              <Pencil /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem variant="destructive" onClick={() => setDeleteGoal(g)}>
                              <Trash2 /> Delete
                            </DropdownMenuItem>
                          </>
                        ) : null}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {showEmployee ? (
                    <div className="flex items-center gap-2">
                      <Avatar name={g.employeeName} color={g.avatarColor} className="h-6 w-6 text-[10px]" />
                      <span className="truncate text-xs text-muted-foreground">
                        {g.employeeName} · {g.department}
                      </span>
                    </div>
                  ) : null}

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate text-muted-foreground">
                        {g.metric || "Progress"} · {g.cycle}
                      </span>
                      <span className="shrink-0 font-medium tabular-nums">
                        {fmtNum(g.currentValue)}/{fmtNum(g.targetValue)}
                        {g.unit ? ` ${g.unit}` : ""} · {g.progress}%
                      </span>
                    </div>
                    <Progress value={g.progress} className={cn("h-2", progressBarClass(g.status))} />
                  </div>

                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className={cn("text-muted-foreground", overdue && "font-medium text-destructive")}>
                      {g.dueDate ? `Due ${fmtDate(g.dueDate)}` : "No due date"}
                    </span>
                    <span className="text-muted-foreground">Updated {ago(g.updatedAt)}</span>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Create / edit dialog */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit goal" : "New goal"}</DialogTitle>
            <DialogDescription>
              {editing
                ? "Adjust the goal definition, target or due date."
                : "Define a measurable objective for the quarter. You can log progress as you go."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="goal-title">Title</Label>
              <Input
                id="goal-title"
                placeholder="e.g. Close 10 enterprise deals"
                value={form.title}
                onChange={(e) => setField("title", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="goal-description">Description</Label>
              <Textarea
                id="goal-description"
                className="min-h-16"
                placeholder="Context and why this goal matters"
                value={form.description}
                onChange={(e) => setField("description", e.target.value)}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="goal-metric">Metric</Label>
                <Input
                  id="goal-metric"
                  placeholder="e.g. Deals closed"
                  value={form.metric}
                  onChange={(e) => setField("metric", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="goal-unit">Unit</Label>
                <Input
                  id="goal-unit"
                  placeholder="e.g. deals"
                  value={form.unit}
                  onChange={(e) => setField("unit", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="goal-target">Target value</Label>
                <Input
                  id="goal-target"
                  type="number"
                  min="0"
                  step="any"
                  placeholder="10"
                  value={form.targetValue}
                  onChange={(e) => setField("targetValue", e.target.value)}
                />
              </div>
              {editing ? (
                <div className="space-y-2">
                  <Label htmlFor="goal-current">Current value</Label>
                  <Input
                    id="goal-current"
                    type="number"
                    min="0"
                    step="any"
                    value={form.currentValue}
                    onChange={(e) => setField("currentValue", e.target.value)}
                  />
                </div>
              ) : null}
              <div className="space-y-2">
                <Label htmlFor="goal-cycle">Cycle</Label>
                <Input
                  id="goal-cycle"
                  placeholder="FY27-Q1"
                  value={form.cycle}
                  onChange={(e) => setField("cycle", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="goal-due">Due date</Label>
                <Input
                  id="goal-due"
                  type="date"
                  value={form.dueDate}
                  onChange={(e) => setField("dueDate", e.target.value)}
                />
              </div>
            </div>
            {editorError ? <p className="text-sm text-destructive">{editorError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditorOpen(false)}>
              Cancel
            </Button>
            <Button disabled={saveMutation.isPending} onClick={submitEditor}>
              {editing ? "Save changes" : "Create goal"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update progress dialog */}
      <Dialog open={!!progressGoal} onOpenChange={(open) => !open && setProgressGoal(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Update progress</DialogTitle>
            <DialogDescription>
              {progressGoal?.title} — target {progressGoal ? fmtNum(progressGoal.targetValue) : ""}
              {progressGoal?.unit ? ` ${progressGoal.unit}` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="progress-value">Current value</Label>
              <Input
                id="progress-value"
                type="number"
                min="0"
                step="any"
                value={progressValue}
                onChange={(e) => setProgressValue(e.target.value)}
              />
            </div>
            <div className="space-y-1.5 rounded-lg border bg-muted/40 p-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Progress preview</span>
                <span className="font-medium tabular-nums">{previewProgress}%</span>
              </div>
              <Progress value={previewProgress} className="h-2" />
              {previewProgress >= 100 ? (
                <p className="text-xs text-emerald-600 dark:text-emerald-400">
                  Reaching the target will mark this goal as completed.
                </p>
              ) : null}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProgressGoal(null)}>
              Cancel
            </Button>
            <Button disabled={progressMutation.isPending} onClick={submitProgress}>
              Save progress
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change status dialog */}
      <Dialog open={!!statusGoal} onOpenChange={(open) => !open && setStatusGoal(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Change status</DialogTitle>
            <DialogDescription>{statusGoal?.title}</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="goal-status">Status</Label>
            <Select value={statusValue} onValueChange={(v) => setStatusValue(v as GoalStatus)}>
              <SelectTrigger id="goal-status" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {GOAL_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s] ?? s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStatusGoal(null)}>
              Cancel
            </Button>
            <Button
              disabled={statusMutation.isPending}
              onClick={() => statusGoal && statusMutation.mutate({ id: statusGoal.id, status: statusValue })}
            >
              Save status
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteGoal} onOpenChange={(open) => !open && setDeleteGoal(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this goal?</AlertDialogTitle>
            <AlertDialogDescription>
              &ldquo;{deleteGoal?.title}&rdquo; will be permanently removed for{" "}
              {deleteGoal?.employeeName ?? "the owner"}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                if (deleteGoal) deleteMutation.mutate(deleteGoal.id);
              }}
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete goal"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

/**
 * PeoplePulse HR — Expenses module.
 * Personal claim submissions for everyone, an approvals queue for manager+
 * (managers decide their direct reports' claims) and an org-wide view with
 * payout tracking for owner/admin/hr.
 */

import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Ban,
  Check,
  Clock3,
  IndianRupee,
  Inbox,
  Landmark,
  Plus,
  ReceiptText,
  X,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { EXPENSE_CATEGORIES, STATUS_LABELS } from "@/lib/constants";
import { ago, cn, fmtDate, initials, inr, todayIso } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { ExpenseClaimDto, ExpenseStatus, ExpensesSummaryDto } from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local types & helpers =====================

interface ExpensesResponse {
  claims: ExpenseClaimDto[];
  summary: ExpensesSummaryDto;
}

function StatusBadge({ status }: { status: ExpenseStatus }) {
  switch (status) {
    case "submitted":
      return (
        <Badge
          variant="outline"
          className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400"
        >
          {STATUS_LABELS[status] ?? status}
        </Badge>
      );
    case "approved":
      return (
        <Badge
          variant="outline"
          className="border-emerald-600/40 bg-emerald-600/10 text-emerald-700 dark:text-emerald-400"
        >
          {STATUS_LABELS[status] ?? status}
        </Badge>
      );
    case "rejected":
      return <Badge variant="destructive">{STATUS_LABELS[status] ?? status}</Badge>;
    case "paid":
      return <Badge variant="secondary">{STATUS_LABELS[status] ?? status}</Badge>;
    default:
      return (
        <Badge variant="outline" className="text-muted-foreground">
          {STATUS_LABELS[status] ?? status}
        </Badge>
      );
  }
}

function Avatar({ name, color, className }: { name: string; color: string; className?: string }) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function StatCard({ label, value, hint, icon }: { label: string; value: string; hint?: string; icon?: ReactNode }) {
  return (
    <Card className="py-4">
      <CardContent className="flex items-start justify-between gap-3 px-4">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <p className="mt-1 truncate text-2xl font-bold tabular-nums">{value}</p>
          {hint ? <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p> : null}
        </div>
        {icon ? (
          <div className="rounded-lg bg-emerald-600/10 p-2 text-emerald-700 dark:text-emerald-400">{icon}</div>
        ) : null}
      </CardContent>
    </Card>
  );
}

// ===================== Claims table =====================

interface ClaimsTableProps {
  claims: ExpenseClaimDto[];
  /** Show the employee column (approvals / all-claims tabs). */
  showEmployee?: boolean;
  /** Show the decision (approver, comment, paid-at) column. */
  showDecision?: boolean;
  myEmployeeId?: string | null;
  allowDecide?: boolean;
  allowPay?: boolean;
  allowCancel?: boolean;
  busy?: boolean;
  onDecide?: (claim: ExpenseClaimDto, action: "approve" | "reject") => void;
  onMarkPaid?: (claim: ExpenseClaimDto) => void;
  onCancel?: (claim: ExpenseClaimDto) => void;
}

function ClaimsTable({
  claims,
  showEmployee = false,
  showDecision = false,
  myEmployeeId = null,
  allowDecide = false,
  allowPay = false,
  allowCancel = false,
  busy = false,
  onDecide,
  onMarkPaid,
  onCancel,
}: ClaimsTableProps) {
  return (
    <div className="overflow-hidden rounded-xl border bg-card">
      <div className="max-h-[520px] overflow-y-auto scrollbar-thin">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              {showEmployee ? <TableHead>Employee</TableHead> : null}
              <TableHead>Claim</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Expense date</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Status</TableHead>
              {showDecision ? <TableHead>Decision</TableHead> : null}
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {claims.map((c) => (
              <TableRow key={c.id}>
                {showEmployee ? (
                  <TableCell>
                    <div className="flex items-center gap-2.5">
                      <Avatar name={c.employeeName} color={c.avatarColor} className="h-8 w-8" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium leading-tight">{c.employeeName}</p>
                        <p className="text-xs text-muted-foreground">
                          {c.employeeCode} · {c.department}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                ) : null}
                <TableCell className="max-w-64 whitespace-normal">
                  <p className="font-medium leading-tight">{c.title}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
                    <Badge variant="outline" className="text-[10px]">
                      {c.category}
                    </Badge>
                    {c.description ? (
                      <span className="truncate text-xs text-muted-foreground" title={c.description}>
                        {c.description}
                      </span>
                    ) : null}
                  </div>
                </TableCell>
                <TableCell className="text-right font-medium tabular-nums">{inr(c.amount)}</TableCell>
                <TableCell className="text-muted-foreground">{fmtDate(c.expenseDate)}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{ago(c.createdAt)}</TableCell>
                <TableCell>
                  <StatusBadge status={c.status} />
                </TableCell>
                {showDecision ? (
                  <TableCell className="max-w-44 whitespace-normal">
                    {c.decidedAt ? (
                      <div className="text-xs">
                        <p className="leading-tight">{c.approverName ?? "—"}</p>
                        <p className="text-muted-foreground">
                          {ago(c.decidedAt)}
                          {c.paidAt ? ` · paid ${ago(c.paidAt)}` : ""}
                        </p>
                        {c.comment ? (
                          <p className="truncate text-muted-foreground" title={c.comment}>
                            &ldquo;{c.comment}&rdquo;
                          </p>
                        ) : null}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                ) : null}
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1.5">
                    {allowDecide && c.status === "submitted" ? (
                      <>
                        <Button
                          size="sm"
                          className="h-7 px-2.5 text-xs"
                          disabled={busy}
                          onClick={() => onDecide?.(c, "approve")}
                        >
                          <Check className="h-3.5 w-3.5" /> Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2.5 text-xs text-destructive hover:bg-destructive/10 hover:text-destructive"
                          disabled={busy}
                          onClick={() => onDecide?.(c, "reject")}
                        >
                          <X className="h-3.5 w-3.5" /> Reject
                        </Button>
                      </>
                    ) : null}
                    {allowPay && c.status === "approved" ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 border-emerald-600/40 px-2.5 text-xs text-emerald-700 hover:bg-emerald-600/10 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-400"
                        disabled={busy}
                        onClick={() => onMarkPaid?.(c)}
                      >
                        <IndianRupee className="h-3.5 w-3.5" /> Mark paid
                      </Button>
                    ) : null}
                    {allowCancel && c.status === "submitted" && c.employeeId === myEmployeeId ? (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                        disabled={busy}
                        onClick={() => onCancel?.(c)}
                      >
                        <Ban className="h-3.5 w-3.5" /> Cancel
                      </Button>
                    ) : null}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// ===================== Module =====================

export function ExpensesModule() {
  const user = useAppStore((s) => s.user);
  const qc = useQueryClient();

  const isMGMT = !!user && ["owner", "admin", "hr", "manager"].includes(user.role);
  const isHR = !!user && ["owner", "admin", "hr"].includes(user.role);
  const myEmployeeId = user?.employeeId ?? null;

  const query = useQuery({
    queryKey: qk.expenses(),
    queryFn: () => api.get<ExpensesResponse>("/api/expenses"),
  });

  const claims = useMemo(() => query.data?.claims ?? [], [query.data]);
  const summary = query.data?.summary;

  const myClaims = useMemo(
    () => claims.filter((c) => c.employeeId === myEmployeeId),
    [claims, myEmployeeId]
  );

  // Submitted claims awaiting this user's decision. Nobody self-approves in the
  // UI: own claims are always excluded. Owner/admin/hr see everyone else's
  // claims; managers only their direct reports' claims (their feed is limited
  // to own + direct reports, so "not mine" == direct reports).
  const approvals = useMemo(() => {
    if (!isMGMT) return [];
    return claims.filter(
      (c) => c.status === "submitted" && c.employeeId !== myEmployeeId
    );
  }, [claims, isMGMT, myEmployeeId]);

  // ---- new claim dialog state ----
  const [newOpen, setNewOpen] = useState(false);
  const [formTitle, setFormTitle] = useState("");
  const [formCategory, setFormCategory] = useState("");
  const [formAmount, setFormAmount] = useState("");
  const [formDate, setFormDate] = useState(todayIso());
  const [formDescription, setFormDescription] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  // ---- decision dialog state ----
  const [decision, setDecision] = useState<{
    claim: ExpenseClaimDto;
    action: "approve" | "reject";
  } | null>(null);
  const [decisionComment, setDecisionComment] = useState("");

  // ---- mutations ----
  const createClaim = useMutation({
    mutationFn: (v: {
      title: string;
      category: string;
      amount: number;
      expenseDate: string;
      description?: string;
    }) => api.post<{ claim: ExpenseClaimDto }>("/api/expenses", v),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["expenses"] });
      toast.success("Expense claim submitted for approval");
      setNewOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const decide = useMutation({
    mutationFn: (v: { id: string; action: "approve" | "reject"; comment?: string }) =>
      api.patch<{ claim: ExpenseClaimDto }>(`/api/expenses/${v.id}`, {
        action: v.action,
        ...(v.comment ? { comment: v.comment } : {}),
      }),
    onSuccess: (_data, v) => {
      qc.invalidateQueries({ queryKey: ["expenses"] });
      toast.success(v.action === "approve" ? "Expense claim approved" : "Expense claim rejected");
      setDecision(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const markPaid = useMutation({
    mutationFn: (id: string) =>
      api.patch<{ claim: ExpenseClaimDto }>(`/api/expenses/${id}`, { action: "mark_paid" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["expenses"] });
      toast.success("Expense claim marked as paid");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const cancelClaim = useMutation({
    mutationFn: (id: string) =>
      api.patch<{ claim: ExpenseClaimDto }>(`/api/expenses/${id}`, { action: "cancel" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["expenses"] });
      toast.success("Expense claim cancelled");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const anyPending =
    createClaim.isPending || decide.isPending || markPaid.isPending || cancelClaim.isPending;

  function openNewClaimDialog() {
    setFormTitle("");
    setFormCategory("");
    setFormAmount("");
    setFormDate(todayIso());
    setFormDescription("");
    setFormError(null);
    createClaim.reset();
    setNewOpen(true);
  }

  function submitClaim() {
    setFormError(null);
    const title = formTitle.trim();
    const amount = Number(formAmount);
    if (!title) {
      setFormError("Please enter a claim title.");
      return;
    }
    if (!formCategory) {
      setFormError("Please select an expense category.");
      return;
    }
    if (!Number.isFinite(amount) || !Number.isInteger(amount) || amount <= 0) {
      setFormError("Amount must be a positive whole number in rupees.");
      return;
    }
    if (!formDate) {
      setFormError("Please pick the expense date.");
      return;
    }
    createClaim.mutate({
      title,
      category: formCategory,
      amount,
      expenseDate: formDate,
      ...(formDescription.trim() ? { description: formDescription.trim().slice(0, 500) } : {}),
    });
  }

  function openDecisionDialog(claim: ExpenseClaimDto, action: "approve" | "reject") {
    decide.reset();
    setDecisionComment("");
    setDecision({ claim, action });
  }

  if (!user) return null;

  const statCards = (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        label="Pending my claims"
        value={summary ? String(summary.mySubmitted) : "—"}
        hint="Submitted & awaiting approval"
        icon={<Clock3 className="h-4 w-4" />}
      />
      <StatCard
        label="My approved this month"
        value={summary ? inr(summary.myApprovedMonthTotal) : "—"}
        hint="Approved + paid claims (this month)"
        icon={<IndianRupee className="h-4 w-4" />}
      />
      {isMGMT ? (
        <StatCard
          label="Pending approvals"
          value={summary ? String(summary.pendingApprovalCount) : "—"}
          hint="Claims awaiting your decision"
          icon={<Inbox className="h-4 w-4" />}
        />
      ) : null}
      {isHR ? (
        <StatCard
          label="Org spend this month"
          value={summary ? inr(summary.orgMonthTotal) : "—"}
          hint="Approved + paid org-wide (this month)"
          icon={<Landmark className="h-4 w-4" />}
        />
      ) : null}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Expenses</h1>
          <p className="text-sm text-muted-foreground">
            {isHR
              ? "Track claims across the organisation, approve spend and mark payouts."
              : isMGMT
                ? "Approve your team's expense claims and manage your own submissions."
                : "Submit expense claims and track their approval and payout status."}
          </p>
        </div>
        <Button size="sm" onClick={openNewClaimDialog}>
          <Plus /> New claim
        </Button>
      </div>

      {query.isPending ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: isHR ? 4 : isMGMT ? 3 : 2 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : (
        statCards
      )}

      {isHR ? (
        <Tabs defaultValue="approvals">
          <TabsList>
            <TabsTrigger value="mine">My claims</TabsTrigger>
            <TabsTrigger value="approvals">
              Approvals
              {summary && summary.pendingApprovalCount > 0 ? (
                <Badge variant="secondary" className="ml-1.5 tabular-nums">
                  {summary.pendingApprovalCount}
                </Badge>
              ) : null}
            </TabsTrigger>
            <TabsTrigger value="all">All claims</TabsTrigger>
          </TabsList>
          <TabsContent value="mine" className="mt-4">
            <MyClaimsSection
              claims={myClaims}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              myEmployeeId={myEmployeeId}
              busy={anyPending}
              onCancel={(claim) => cancelClaim.mutate(claim.id)}
            />
          </TabsContent>
          <TabsContent value="approvals" className="mt-4">
            <ApprovalsSection
              claims={approvals}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              busy={anyPending}
              onDecide={openDecisionDialog}
            />
          </TabsContent>
          <TabsContent value="all" className="mt-4">
            <AllClaimsSection
              claims={claims}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              myEmployeeId={myEmployeeId}
              busy={anyPending}
              onDecide={openDecisionDialog}
              onMarkPaid={(claim) => markPaid.mutate(claim.id)}
              onCancel={(claim) => cancelClaim.mutate(claim.id)}
            />
          </TabsContent>
        </Tabs>
      ) : isMGMT ? (
        <Tabs defaultValue="approvals">
          <TabsList>
            <TabsTrigger value="mine">My claims</TabsTrigger>
            <TabsTrigger value="approvals">
              Approvals
              {summary && summary.pendingApprovalCount > 0 ? (
                <Badge variant="secondary" className="ml-1.5 tabular-nums">
                  {summary.pendingApprovalCount}
                </Badge>
              ) : null}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="mine" className="mt-4">
            <MyClaimsSection
              claims={myClaims}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              myEmployeeId={myEmployeeId}
              busy={anyPending}
              onCancel={(claim) => cancelClaim.mutate(claim.id)}
            />
          </TabsContent>
          <TabsContent value="approvals" className="mt-4">
            <ApprovalsSection
              claims={approvals}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              busy={anyPending}
              onDecide={openDecisionDialog}
            />
          </TabsContent>
        </Tabs>
      ) : (
        <Tabs defaultValue="mine">
          <TabsList>
            <TabsTrigger value="mine">My claims</TabsTrigger>
          </TabsList>
          <TabsContent value="mine" className="mt-4">
            <MyClaimsSection
              claims={myClaims}
              isPending={query.isPending}
              isError={query.isError}
              error={query.error instanceof Error ? query.error.message : undefined}
              onRetry={() => query.refetch()}
              myEmployeeId={myEmployeeId}
              busy={anyPending}
              onCancel={(claim) => cancelClaim.mutate(claim.id)}
            />
          </TabsContent>
        </Tabs>
      )}

      {/* New claim dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>New expense claim</DialogTitle>
            <DialogDescription>
              Claims are routed to your reporting manager (or HR) for approval.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="expense-title">Title</Label>
              <Input
                id="expense-title"
                placeholder="e.g. Client visit — Bangalore"
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={formCategory} onValueChange={setFormCategory}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {EXPENSE_CATEGORIES.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="expense-amount">Amount (₹ INR)</Label>
                <Input
                  id="expense-amount"
                  type="number"
                  min={1}
                  step={1}
                  placeholder="e.g. 2400"
                  value={formAmount}
                  onChange={(e) => setFormAmount(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="expense-date">Expense date</Label>
              <Input
                id="expense-date"
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="expense-description">Description (optional)</Label>
              <Textarea
                id="expense-description"
                className="min-h-20"
                placeholder="What was this expense for?"
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
              />
            </div>
            {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
            {createClaim.error ? (
              <p className="text-sm text-destructive">{createClaim.error.message}</p>
            ) : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOpen(false)} disabled={createClaim.isPending}>
              Cancel
            </Button>
            <Button onClick={submitClaim} disabled={createClaim.isPending}>
              {createClaim.isPending ? "Submitting…" : "Submit claim"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve / reject decision dialog */}
      <Dialog open={!!decision} onOpenChange={(open) => !open && setDecision(null)}>
        {decision ? (
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>
                {decision.action === "approve" ? "Approve expense claim" : "Reject expense claim"}
              </DialogTitle>
              <DialogDescription>
                {decision.claim.employeeName} · {decision.claim.category} ·{" "}
                {inr(decision.claim.amount)} · {fmtDate(decision.claim.expenseDate)}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <p className="rounded-md bg-muted px-3 py-2 text-sm font-medium">{decision.claim.title}</p>
              {decision.claim.description ? (
                <p className="text-sm text-muted-foreground">{decision.claim.description}</p>
              ) : null}
              <div className="space-y-2">
                <Label htmlFor="decision-comment">Comment (optional)</Label>
                <Textarea
                  id="decision-comment"
                  placeholder="Message shared with the employee"
                  value={decisionComment}
                  onChange={(e) => setDecisionComment(e.target.value)}
                />
              </div>
              {decide.error ? <p className="text-sm text-destructive">{decide.error.message}</p> : null}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDecision(null)} disabled={decide.isPending}>
                Cancel
              </Button>
              <Button
                variant={decision.action === "reject" ? "destructive" : "default"}
                disabled={decide.isPending}
                onClick={() =>
                  decide.mutate({
                    id: decision.claim.id,
                    action: decision.action,
                    comment: decisionComment,
                  })
                }
              >
                {decide.isPending
                  ? "Working…"
                  : decision.action === "approve"
                    ? "Approve"
                    : "Reject"}
              </Button>
            </DialogFooter>
          </DialogContent>
        ) : null}
      </Dialog>
    </div>
  );
}

// ===================== Tab sections =====================

interface SectionProps {
  claims: ExpenseClaimDto[];
  isPending: boolean;
  isError: boolean;
  error?: string;
  onRetry: () => void;
  busy?: boolean;
}

function MyClaimsSection({
  claims,
  isPending,
  isError,
  error,
  onRetry,
  myEmployeeId,
  busy,
  onCancel,
}: SectionProps & {
  myEmployeeId: string | null;
  busy?: boolean;
  onCancel: (claim: ExpenseClaimDto) => void;
}) {
  return (
    <section className="space-y-3">
      <h2 className="text-base font-semibold">My claims</h2>
      {isPending ? (
        <Skeleton className="h-56 rounded-xl" />
      ) : isError ? (
        <LoadError message={error} onRetry={onRetry} />
      ) : claims.length === 0 ? (
        <EmptyState
          icon={<ReceiptText className="h-8 w-8 text-muted-foreground/50" />}
          title="No expense claims yet"
          description="Submit your first claim with the New claim button — track its approval and payout here."
        />
      ) : (
        <ClaimsTable
          claims={claims}
          showDecision
          myEmployeeId={myEmployeeId}
          allowCancel
          busy={busy}
          onCancel={onCancel}
        />
      )}
    </section>
  );
}

function ApprovalsSection({
  claims,
  isPending,
  isError,
  error,
  onRetry,
  busy,
  onDecide,
}: SectionProps & {
  busy?: boolean;
  onDecide: (claim: ExpenseClaimDto, action: "approve" | "reject") => void;
}) {
  return (
    <section className="space-y-3">
      <h2 className="text-base font-semibold">
        Pending approvals
        {claims.length > 0 ? (
          <Badge variant="secondary" className="ml-2 tabular-nums">
            {claims.length}
          </Badge>
        ) : null}
      </h2>
      {isPending ? (
        <Skeleton className="h-56 rounded-xl" />
      ) : isError ? (
        <LoadError message={error} onRetry={onRetry} />
      ) : claims.length === 0 ? (
        <EmptyState
          icon={<Inbox className="h-8 w-8 text-muted-foreground/50" />}
          title="No pending approvals"
          description="You are all caught up — new claims from your team will appear here."
        />
      ) : (
        <ClaimsTable claims={claims} showEmployee allowDecide busy={busy} onDecide={onDecide} />
      )}
    </section>
  );
}

function AllClaimsSection({
  claims,
  isPending,
  isError,
  error,
  onRetry,
  myEmployeeId,
  busy,
  onDecide,
  onMarkPaid,
  onCancel,
}: SectionProps & {
  myEmployeeId: string | null;
  busy?: boolean;
  onDecide: (claim: ExpenseClaimDto, action: "approve" | "reject") => void;
  onMarkPaid: (claim: ExpenseClaimDto) => void;
  onCancel: (claim: ExpenseClaimDto) => void;
}) {
  return (
    <section className="space-y-3">
      <h2 className="text-base font-semibold">All claims</h2>
      {isPending ? (
        <Skeleton className="h-56 rounded-xl" />
      ) : isError ? (
        <LoadError message={error} onRetry={onRetry} />
      ) : claims.length === 0 ? (
        <EmptyState
          icon={<ReceiptText className="h-8 w-8 text-muted-foreground/50" />}
          title="No claims yet"
          description="Expense claims submitted across the organisation will be listed here."
        />
      ) : (
        <ClaimsTable
          claims={claims}
          showEmployee
          showDecision
          myEmployeeId={myEmployeeId}
          allowDecide
          allowPay
          allowCancel
          busy={busy}
          onDecide={onDecide}
          onMarkPaid={onMarkPaid}
          onCancel={onCancel}
        />
      )}
    </section>
  );
}

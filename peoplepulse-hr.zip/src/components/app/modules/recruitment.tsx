"use client";

/**
 * PeoplePulse HR — Recruitment module (ATS).
 * Job openings, candidate pipeline kanban with drag & drop, funnel stats.
 * Restricted to owner/admin/hr/manager.
 */

import { useMemo, useRef, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  DndContext,
  PointerSensor,
  closestCorners,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { AlertTriangle, Briefcase, Check, Loader2, Lock, Mail, MapPin, Plus, Sparkles, Star, UserCheck, Users } from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { SOURCES, STATUS_LABELS } from "@/lib/constants";
import { cn, fmtDate, initials, inr } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { HR_ROLES } from "@/lib/types";
import type {
  AiScreenResultDto,
  CandidateDto,
  CandidateStage,
  DepartmentDto,
  EmploymentType,
  JobOpeningDto,
  OpeningStatus,
} from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";

// ===================== Local constants & helpers =====================

const STAGES: CandidateStage[] = ["applied", "screening", "interview", "offer", "hired", "rejected"];

const EMPLOYMENT_TYPES: EmploymentType[] = ["full_time", "part_time", "contract", "intern"];

const OPENING_STATUSES: OpeningStatus[] = ["open", "on_hold", "closed"];

interface CandidatePatch {
  stage?: CandidateStage;
  rating?: number;
  notes?: string;
}

interface NewOpeningPayload {
  title: string;
  department: string;
  location: string;
  employmentType: EmploymentType;
  openings: number;
  status: OpeningStatus;
  hiringManager: string;
  minExpYears: number;
  maxSalary: number | null;
  skills: string[];
  description: string;
}

interface NewCandidatePayload {
  openingId: string;
  name: string;
  email: string;
  phone?: string;
  source?: string;
  expectedSalary?: number | null;
  noticePeriod?: string;
  resumeSummary?: string;
}

interface OpeningForm {
  title: string;
  department: string;
  location: string;
  employmentType: EmploymentType;
  openings: string;
  hiringManager: string;
  minExpYears: string;
  maxSalary: string;
  skills: string;
  description: string;
}

interface CandidateForm {
  openingId: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  expectedSalary: string;
  noticePeriod: string;
  resumeSummary: string;
}

const OPENING_FORM_EMPTY: OpeningForm = {
  title: "",
  department: "",
  location: "",
  employmentType: "full_time",
  openings: "1",
  hiringManager: "",
  minExpYears: "0",
  maxSalary: "",
  skills: "",
  description: "",
};

const CANDIDATE_FORM_EMPTY: CandidateForm = {
  openingId: "",
  name: "",
  email: "",
  phone: "",
  source: SOURCES[0],
  expectedSalary: "",
  noticePeriod: "",
  resumeSummary: "",
};

function OpeningStatusBadge({ status }: { status: OpeningStatus }) {
  if (status === "open") return <Badge variant="secondary">Open</Badge>;
  if (status === "on_hold") return <Badge variant="outline">On Hold</Badge>;
  return <Badge className="border-transparent bg-muted text-muted-foreground">Closed</Badge>;
}

function VerdictBadge({ verdict }: { verdict: AiScreenResultDto["verdict"] }) {
  if (verdict === "strong") {
    return (
      <Badge className="border-transparent bg-emerald-500/15 text-emerald-700 dark:text-emerald-400">
        Strong fit
      </Badge>
    );
  }
  if (verdict === "moderate") {
    return (
      <Badge className="border-transparent bg-amber-500/15 text-amber-700 dark:text-amber-400">
        Moderate fit
      </Badge>
    );
  }
  return (
    <Badge className="border-transparent bg-red-500/15 text-red-700 dark:text-red-400">Weak fit</Badge>
  );
}

function RatingStars({
  value,
  onChange,
  size = "md",
}: {
  value: number;
  onChange?: (v: number) => void;
  size?: "sm" | "md";
}) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          aria-label={`Rate ${i} out of 5`}
          disabled={!onChange}
          onClick={() => onChange?.(i)}
          className={cn(
            "rounded-sm disabled:cursor-default",
            onChange && "cursor-pointer transition-transform hover:scale-110"
          )}
        >
          <Star
            className={cn(
              size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4",
              i <= value ? "fill-current text-amber-500" : "text-muted-foreground/40"
            )}
          />
        </button>
      ))}
    </div>
  );
}

function StatChip({
  label,
  value,
  icon,
}: {
  label: string;
  value: string | number;
  icon?: ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl border bg-card px-4 py-3">
      {icon ? <div className="rounded-lg bg-muted p-2 text-muted-foreground">{icon}</div> : null}
      <div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-2xl font-bold tabular-nums">{value}</div>
      </div>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

/** Deduplicate and sort a list of strings (kept outside components for React Compiler friendliness). */
function uniqueSorted(values: string[]): string[] {
  return Array.from(new Set(values)).sort();
}

// ===================== Module =====================

export function RecruitmentModule() {
  const { user } = useAppStore();
  const allowed = !!user && HR_ROLES.includes(user.role);

  if (!allowed) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Recruitment</h1>
          <p className="text-sm text-muted-foreground">Manage job openings and hiring pipelines.</p>
        </div>
        <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-16 text-center">
          <Lock className="h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm font-medium">Restricted area</p>
          <p className="max-w-sm text-sm text-muted-foreground">
            Recruitment tools are available to owners, admins, HR and hiring managers only.
          </p>
        </div>
      </div>
    );
  }

  return <RecruitmentConsole />;
}

// ===================== Console (admin) =====================

function RecruitmentConsole() {
  const qc = useQueryClient();

  const openingsQuery = useQuery({
    queryKey: qk.openings,
    queryFn: () => api.get<{ items: JobOpeningDto[] }>("/api/recruitment/openings"),
  });
  const candidatesQuery = useQuery({
    queryKey: qk.candidates(),
    queryFn: () => api.get<{ items: CandidateDto[] }>("/api/recruitment/candidates"),
  });
  const departmentsQuery = useQuery({
    queryKey: qk.departments,
    queryFn: () => api.get<{ items: DepartmentDto[] }>("/api/departments"),
  });

  const openings = openingsQuery.data?.items ?? [];
  const candidates = candidatesQuery.data?.items ?? [];
  // Real departments from the org, merged with any department already used by
  // existing openings (so historic data stays filterable/selectable).
  const departments = uniqueSorted([
    ...(departmentsQuery.data?.items ?? []).map((d) => d.name),
    ...(openingsQuery.data?.items ?? []).map((o) => o.department),
  ]);

  const [pipelineOpening, setPipelineOpening] = useState("");
  const selectedOpeningId = pipelineOpening || openings[0]?.id || "";
  const pipelineCandidates = useMemo(
    () => candidates.filter((c) => c.openingId === selectedOpeningId),
    [candidates, selectedOpeningId]
  );

  const stats = useMemo(
    () => ({
      openRoles: openings.filter((o) => o.status === "open").length,
      activeCandidates: candidates.filter((c) => c.stage !== "hired" && c.stage !== "rejected")
        .length,
      offersPending: candidates.filter((c) => c.stage === "offer").length,
      hired: candidates.filter((c) => c.stage === "hired").length,
    }),
    [openings, candidates]
  );

  const funnelCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const s of STAGES) counts[s] = 0;
    for (const c of pipelineCandidates) counts[c.stage] = (counts[c.stage] ?? 0) + 1;
    return counts;
  }, [pipelineCandidates]);
  const funnelMax = Math.max(1, ...STAGES.map((s) => funnelCounts[s] ?? 0));

  // ---- dialogs ----
  const [newOpeningOpen, setNewOpeningOpen] = useState(false);
  const [openingForm, setOpeningForm] = useState<OpeningForm>(OPENING_FORM_EMPTY);
  const [openingError, setOpeningError] = useState<string | null>(null);

  const [addCandidateOpen, setAddCandidateOpen] = useState(false);
  const [candidateForm, setCandidateForm] = useState<CandidateForm>(CANDIDATE_FORM_EMPTY);
  const [candidateError, setCandidateError] = useState<string | null>(null);

  const [detail, setDetail] = useState<CandidateDto | null>(null);
  const [detailNotes, setDetailNotes] = useState("");
  const [screenResult, setScreenResult] = useState<AiScreenResultDto | null>(null);

  function openDetail(c: CandidateDto) {
    setDetail(c);
    setDetailNotes(c.notes ?? "");
    setScreenResult(null);
  }

  // ---- mutations ----
  const createOpening = useMutation({
    mutationFn: (payload: NewOpeningPayload) =>
      api.post<{ item: JobOpeningDto }>("/api/recruitment/openings", payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-openings"] });
      toast.success("Job opening created");
      setNewOpeningOpen(false);
      setOpeningForm(OPENING_FORM_EMPTY);
      setOpeningError(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const updateOpening = useMutation({
    mutationFn: (v: { id: string; status: OpeningStatus }) =>
      api.patch<{ item: JobOpeningDto }>(`/api/recruitment/openings/${v.id}`, { status: v.status }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-openings"] });
      toast.success("Opening status updated");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const addCandidate = useMutation({
    mutationFn: (payload: NewCandidatePayload) =>
      api.post<{ item: CandidateDto }>("/api/recruitment/candidates", payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-openings"] });
      qc.invalidateQueries({ queryKey: ["candidates"] });
      toast.success("Candidate added to the pipeline");
      setAddCandidateOpen(false);
      setCandidateForm(CANDIDATE_FORM_EMPTY);
      setCandidateError(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const updateCandidate = useMutation({
    mutationFn: (v: { id: string; patch: CandidatePatch; message?: string }) =>
      api.patch<{ item: CandidateDto }>(`/api/recruitment/candidates/${v.id}`, v.patch),
    onMutate: async ({ id, patch }) => {
      if (!patch.stage) return {};
      await qc.cancelQueries({ queryKey: ["candidates"] });
      const prev = qc.getQueryData<{ items: CandidateDto[] }>(qk.candidates());
      if (prev) {
        qc.setQueryData<{ items: CandidateDto[] }>(qk.candidates(), {
          ...prev,
          items: prev.items.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        });
      }
      return { prev };
    },
    onError: (error: Error, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(qk.candidates(), ctx.prev);
      toast.error(error.message);
    },
    onSuccess: (_data, v) => {
      if (v.message) toast.success(v.message);
      if (v.patch.stage && detail?.id === v.id) {
        setDetail({ ...detail, stage: v.patch.stage });
      }
      if (v.patch.notes && detail?.id === v.id) {
        setDetail({ ...detail, notes: v.patch.notes });
      }
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: ["candidates"] });
    },
  });

  // ---- AI screening ----
  const screenCandidate = useMutation({
    mutationFn: (candidateId: string) =>
      api.post<AiScreenResultDto>("/api/ai/screen", { candidateId }),
    onSuccess: (result) => {
      setScreenResult(result);
      toast.success(`AI screening complete — fit score ${result.score}/100`);
      qc.invalidateQueries({ queryKey: ["candidates"] });
      // Mirror the note the server just appended so the notes editor stays in sync.
      const d = new Date();
      const stamp = `--- AI screening (${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}) ---\n${result.summary} [Fit score: ${result.score}/100]`;
      setDetail((prev) => (prev ? { ...prev, notes: prev.notes ? `${prev.notes}\n\n${stamp}` : stamp } : prev));
      setDetailNotes((n) => (n ? `${n}\n\n${stamp}` : stamp));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // ---- kanban drag ----
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));
  // Suppress the synthetic click that browsers fire right after a drag gesture,
  // so dropping a card does not also open the detail dialog.
  const lastDragEndAt = useRef(0);

  function shouldIgnoreClick(): boolean {
    return Date.now() - lastDragEndAt.current < 150;
  }

  function handleDragEnd(event: DragEndEvent) {
    lastDragEndAt.current = Date.now();
    const { active, over } = event;
    if (!over) return;
    const activeId = String(active.id);
    const overId = String(over.id);
    const dragged = candidates.find((c) => c.id === activeId);
    if (!dragged) return;
    let target: CandidateStage | null = null;
    if (overId.startsWith("col-")) {
      target = overId.slice(4) as CandidateStage;
    } else {
      const overCandidate = candidates.find((c) => c.id === overId);
      if (overCandidate) target = overCandidate.stage;
    }
    if (!target || target === dragged.stage) return;
    updateCandidate.mutate({
      id: dragged.id,
      patch: { stage: target },
      message: `${dragged.name} moved to ${STATUS_LABELS[target] ?? target}`,
    });
  }

  // ---- form submits ----
  function submitOpening() {
    setOpeningError(null);
    if (!openingForm.title.trim()) {
      setOpeningError("Job title is required.");
      return;
    }
    if (!openingForm.department) {
      setOpeningError("Department is required.");
      return;
    }
    if (!openingForm.location.trim()) {
      setOpeningError("Location is required.");
      return;
    }
    if (!openingForm.hiringManager.trim()) {
      setOpeningError("Hiring manager is required.");
      return;
    }
    createOpening.mutate({
      title: openingForm.title.trim(),
      department: openingForm.department,
      location: openingForm.location.trim(),
      employmentType: openingForm.employmentType,
      openings: Math.max(1, Math.floor(Number(openingForm.openings) || 1)),
      status: "open",
      hiringManager: openingForm.hiringManager.trim(),
      minExpYears: Math.max(0, Math.floor(Number(openingForm.minExpYears) || 0)),
      maxSalary: openingForm.maxSalary.trim() ? Math.floor(Number(openingForm.maxSalary)) : null,
      skills: openingForm.skills
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      description: openingForm.description.trim(),
    });
  }

  function submitCandidate() {
    setCandidateError(null);
    if (!candidateForm.openingId) {
      setCandidateError("Select the job opening this candidate applies for.");
      return;
    }
    if (!candidateForm.name.trim()) {
      setCandidateError("Candidate name is required.");
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(candidateForm.email.trim())) {
      setCandidateError("Enter a valid email address.");
      return;
    }
    addCandidate.mutate({
      openingId: candidateForm.openingId,
      name: candidateForm.name.trim(),
      email: candidateForm.email.trim(),
      ...(candidateForm.phone.trim() ? { phone: candidateForm.phone.trim() } : {}),
      source: candidateForm.source,
      ...(candidateForm.expectedSalary.trim()
        ? { expectedSalary: Math.floor(Number(candidateForm.expectedSalary)) }
        : {}),
      ...(candidateForm.noticePeriod.trim() ? { noticePeriod: candidateForm.noticePeriod.trim() } : {}),
      ...(candidateForm.resumeSummary.trim()
        ? { resumeSummary: candidateForm.resumeSummary.trim() }
        : {}),
    });
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Recruitment</h1>
        <p className="text-sm text-muted-foreground">
          Track job openings and move candidates through the hiring pipeline.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatChip label="Open roles" value={stats.openRoles} icon={<Briefcase className="h-4 w-4" />} />
        <StatChip label="Active candidates" value={stats.activeCandidates} icon={<Users className="h-4 w-4" />} />
        <StatChip label="Offers pending" value={stats.offersPending} icon={<Mail className="h-4 w-4" />} />
        <StatChip label="Hired this cycle" value={stats.hired} icon={<UserCheck className="h-4 w-4" />} />
      </div>

      {/* Openings */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Job openings</h2>
          <Button size="sm" onClick={() => setNewOpeningOpen(true)}>
            <Plus /> New opening
          </Button>
        </div>

        {openingsQuery.isPending ? (
          <div className="flex gap-4 overflow-hidden">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-64 w-80 shrink-0 rounded-xl" />
            ))}
          </div>
        ) : openingsQuery.isError ? (
          <LoadError
            message={openingsQuery.error instanceof Error ? openingsQuery.error.message : undefined}
            onRetry={() => openingsQuery.refetch()}
          />
        ) : openings.length === 0 ? (
          <EmptyState
            icon={<Briefcase className="h-8 w-8 text-muted-foreground/50" />}
            title="No job openings yet"
            description="Create your first opening to start building a hiring pipeline."
          />
        ) : (
          <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-thin">
            {openings.map((o) => (
              <div
                key={o.id}
                className="flex w-80 shrink-0 flex-col gap-3 rounded-xl border bg-card p-4"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold leading-tight">{o.title}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{o.department}</div>
                  </div>
                  <OpeningStatusBadge status={o.status} />
                </div>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {o.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Briefcase className="h-3 w-3" />
                    {STATUS_LABELS[o.employmentType] ?? o.employmentType}
                  </span>
                  <span>
                    {o.openings} opening{o.openings === 1 ? "" : "s"}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Manager {o.hiringManager} · {o.minExpYears}+ yrs experience
                  {o.maxSalary ? ` · up to ${inr(o.maxSalary, { compact: true })}` : ""}
                </p>
                <div className="flex flex-wrap gap-1">
                  {o.skills.slice(0, 4).map((s) => (
                    <Badge key={s} variant="secondary" className="text-[10px]">
                      {s}
                    </Badge>
                  ))}
                  {o.skills.length > 4 ? (
                    <Badge variant="outline" className="text-[10px]">
                      +{o.skills.length - 4}
                    </Badge>
                  ) : null}
                </div>
                <div className="mt-auto flex items-center justify-between border-t pt-3">
                  <span className="text-xs text-muted-foreground">
                    {o.candidateCount} candidate{o.candidateCount === 1 ? "" : "s"}
                  </span>
                  <Select
                    value={o.status}
                    onValueChange={(v) =>
                      updateOpening.mutate({ id: o.id, status: v as OpeningStatus })
                    }
                  >
                    <SelectTrigger
                      size="sm"
                      className="h-7 w-28 text-xs"
                      disabled={updateOpening.isPending}
                      aria-label={`Status for ${o.title}`}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {OPENING_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {STATUS_LABELS[s] ?? s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Pipeline */}
      <section className="space-y-3">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <Label className="text-muted-foreground">Pipeline for</Label>
            <Select value={selectedOpeningId} onValueChange={setPipelineOpening}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select an opening" />
              </SelectTrigger>
              <SelectContent>
                {openings.map((o) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.title} ({o.candidateCount})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              size="sm"
              variant="outline"
              disabled={!openings.length}
              onClick={() => {
                setCandidateForm({ ...CANDIDATE_FORM_EMPTY, openingId: selectedOpeningId });
                setCandidateError(null);
                setAddCandidateOpen(true);
              }}
            >
              <Plus /> Add candidate
            </Button>
          </div>

          {/* Funnel — CSS bars */}
          <div className="w-full max-w-xs rounded-xl border bg-card p-3">
            <div className="mb-2 text-xs font-semibold text-muted-foreground">
              Funnel — {openings.find((o) => o.id === selectedOpeningId)?.title ?? "Opening"}
            </div>
            <div className="space-y-1.5">
              {STAGES.map((s) => {
                const count = funnelCounts[s] ?? 0;
                return (
                  <div key={s} className="flex items-center gap-2">
                    <span className="w-16 text-xs text-muted-foreground">
                      {STATUS_LABELS[s] ?? s}
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-primary"
                        style={{ width: `${Math.round((count / funnelMax) * 100)}%` }}
                      />
                    </div>
                    <span className="w-5 text-right text-xs font-medium tabular-nums">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {candidatesQuery.isPending ? (
          <Skeleton className="h-80 rounded-xl" />
        ) : candidatesQuery.isError ? (
          <LoadError
            message={candidatesQuery.error instanceof Error ? candidatesQuery.error.message : undefined}
            onRetry={() => candidatesQuery.refetch()}
          />
        ) : openings.length === 0 ? (
          <EmptyState title="No pipeline yet" description="Create a job opening to start tracking candidates." />
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
            <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-thin">
              {STAGES.map((stage) => (
                <KanbanColumn
                  key={stage}
                  stage={stage}
                  candidates={pipelineCandidates.filter((c) => c.stage === stage)}
                  onOpen={openDetail}
                  shouldIgnoreClick={shouldIgnoreClick}
                  onRate={(c, rating) =>
                    updateCandidate.mutate({
                      id: c.id,
                      patch: { rating },
                      message: `Rated ${c.name} ${rating}/5`,
                    })
                  }
                />
              ))}
            </div>
          </DndContext>
        )}
      </section>

      {/* New opening dialog */}
      <Dialog open={newOpeningOpen} onOpenChange={setNewOpeningOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New job opening</DialogTitle>
            <DialogDescription>Create a role and start sourcing candidates.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="opening-title">Job title</Label>
              <Input
                id="opening-title"
                placeholder="e.g. Senior Frontend Engineer"
                value={openingForm.title}
                onChange={(e) => setOpeningForm((f) => ({ ...f, title: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Department</Label>
                <Select
                  value={openingForm.department}
                  onValueChange={(v) => setOpeningForm((f) => ({ ...f, department: v }))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => (
                      <SelectItem key={d} value={d}>
                        {d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="opening-location">Location</Label>
                <Input
                  id="opening-location"
                  placeholder="e.g. Bengaluru"
                  value={openingForm.location}
                  onChange={(e) => setOpeningForm((f) => ({ ...f, location: e.target.value }))}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Employment type</Label>
                <Select
                  value={openingForm.employmentType}
                  onValueChange={(v) =>
                    setOpeningForm((f) => ({ ...f, employmentType: v as EmploymentType }))
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EMPLOYMENT_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>
                        {STATUS_LABELS[t] ?? t}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="opening-count">Openings</Label>
                <Input
                  id="opening-count"
                  type="number"
                  min={1}
                  value={openingForm.openings}
                  onChange={(e) => setOpeningForm((f) => ({ ...f, openings: e.target.value }))}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="opening-manager">Hiring manager</Label>
                <Input
                  id="opening-manager"
                  placeholder="e.g. Vikram Mehta"
                  value={openingForm.hiringManager}
                  onChange={(e) => setOpeningForm((f) => ({ ...f, hiringManager: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="opening-exp">Min experience (years)</Label>
                <Input
                  id="opening-exp"
                  type="number"
                  min={0}
                  value={openingForm.minExpYears}
                  onChange={(e) => setOpeningForm((f) => ({ ...f, minExpYears: e.target.value }))}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="opening-salary">Max salary (annual, INR)</Label>
              <Input
                id="opening-salary"
                type="number"
                min={0}
                placeholder="e.g. 2400000"
                value={openingForm.maxSalary}
                onChange={(e) => setOpeningForm((f) => ({ ...f, maxSalary: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="opening-skills">Skills (comma separated)</Label>
              <Input
                id="opening-skills"
                placeholder="React, TypeScript, Tailwind"
                value={openingForm.skills}
                onChange={(e) => setOpeningForm((f) => ({ ...f, skills: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="opening-description">Description</Label>
              <Textarea
                id="opening-description"
                className="min-h-24"
                placeholder="What the role involves, team, growth path..."
                value={openingForm.description}
                onChange={(e) => setOpeningForm((f) => ({ ...f, description: e.target.value }))}
              />
            </div>
            {openingError ? <p className="text-sm text-destructive">{openingError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOpeningOpen(false)}>
              Cancel
            </Button>
            <Button disabled={createOpening.isPending} onClick={submitOpening}>
              Create opening
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add candidate dialog */}
      <Dialog open={addCandidateOpen} onOpenChange={setAddCandidateOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add candidate</DialogTitle>
            <DialogDescription>
              New candidates start in the Applied column of the pipeline.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Job opening</Label>
              <Select
                value={candidateForm.openingId}
                onValueChange={(v) => setCandidateForm((f) => ({ ...f, openingId: v }))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select an opening" />
                </SelectTrigger>
                <SelectContent>
                  {openings.map((o) => (
                    <SelectItem key={o.id} value={o.id}>
                      {o.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="candidate-name">Full name</Label>
              <Input
                id="candidate-name"
                placeholder="e.g. Meera Iyer"
                value={candidateForm.name}
                onChange={(e) => setCandidateForm((f) => ({ ...f, name: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="candidate-email">Email</Label>
                <Input
                  id="candidate-email"
                  type="email"
                  placeholder="meera@example.com"
                  value={candidateForm.email}
                  onChange={(e) => setCandidateForm((f) => ({ ...f, email: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="candidate-phone">Phone (optional)</Label>
                <Input
                  id="candidate-phone"
                  placeholder="+91 98xxxxxx"
                  value={candidateForm.phone}
                  onChange={(e) => setCandidateForm((f) => ({ ...f, phone: e.target.value }))}
                />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Source</Label>
                <Select
                  value={candidateForm.source}
                  onValueChange={(v) => setCandidateForm((f) => ({ ...f, source: v }))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SOURCES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="candidate-salary">Expected salary (annual, INR)</Label>
                <Input
                  id="candidate-salary"
                  type="number"
                  min={0}
                  value={candidateForm.expectedSalary}
                  onChange={(e) => setCandidateForm((f) => ({ ...f, expectedSalary: e.target.value }))}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="candidate-notice">Notice period (optional)</Label>
              <Input
                id="candidate-notice"
                placeholder="e.g. 30 days"
                value={candidateForm.noticePeriod}
                onChange={(e) => setCandidateForm((f) => ({ ...f, noticePeriod: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="candidate-resume">Resume summary (optional)</Label>
              <Textarea
                id="candidate-resume"
                className="min-h-20"
                placeholder="Key highlights from the resume"
                value={candidateForm.resumeSummary}
                onChange={(e) => setCandidateForm((f) => ({ ...f, resumeSummary: e.target.value }))}
              />
            </div>
            {candidateError ? <p className="text-sm text-destructive">{candidateError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddCandidateOpen(false)}>
              Cancel
            </Button>
            <Button disabled={addCandidate.isPending} onClick={submitCandidate}>
              Add candidate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Candidate detail dialog */}
      <Dialog open={!!detail} onOpenChange={(open) => !open && setDetail(null)}>
        {detail ? (
          <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                  {initials(detail.name)}
                </span>
                {detail.name}
              </DialogTitle>
              <DialogDescription>
                {detail.openingTitle} · Applied {fmtDate(detail.appliedAt.slice(0, 10))}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground">Email</div>
                  <div className="truncate">{detail.email}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Phone</div>
                  <div>{detail.phone ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Source</div>
                  <div>
                    <Badge variant="outline">{detail.source}</Badge>
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Expected salary</div>
                  <div className="tabular-nums">
                    {detail.expectedSalary != null ? inr(detail.expectedSalary, { compact: true }) : "—"}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Notice period</div>
                  <div>{detail.noticePeriod ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Stage</div>
                  <div>
                    <Badge variant="secondary">{STATUS_LABELS[detail.stage] ?? detail.stage}</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Rating</Label>
                <RatingStars
                  value={detail.rating ?? 0}
                  onChange={(v) =>
                    updateCandidate.mutate({
                      id: detail.id,
                      patch: { rating: v },
                      message: `Rated ${detail.name} ${v}/5`,
                    })
                  }
                />
              </div>

              {detail.resumeSummary ? (
                <div className="space-y-1.5">
                  <Label>Resume summary</Label>
                  <p className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
                    {detail.resumeSummary}
                  </p>
                </div>
              ) : null}

              {/* AI screening */}
              <div className="space-y-3 border-t pt-4">
                <div className="flex items-center justify-between gap-2">
                  <Label className="flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-primary" /> AI screening
                  </Label>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={screenCandidate.isPending}
                    onClick={() => {
                      setScreenResult(null);
                      screenCandidate.mutate(detail.id);
                    }}
                  >
                    {screenCandidate.isPending ? (
                      <Loader2 className="animate-spin" />
                    ) : (
                      <Sparkles />
                    )}
                    {screenResult ? "Re-run" : "AI screen"}
                  </Button>
                </div>

                {screenCandidate.isPending ? (
                  <div className="flex items-center gap-2 rounded-lg border bg-muted/40 p-3 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Screening against {detail.openingTitle}…
                  </div>
                ) : screenCandidate.isError ? (
                  <div className="space-y-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                    <p className="text-sm text-destructive">
                      {screenCandidate.error instanceof Error
                        ? screenCandidate.error.message
                        : "AI screening is unavailable right now."}
                    </p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => screenCandidate.mutate(detail.id)}
                    >
                      Retry
                    </Button>
                  </div>
                ) : screenResult ? (
                  <div className="space-y-3 rounded-lg border bg-muted/40 p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <VerdictBadge verdict={screenResult.verdict} />
                      <span className="text-sm font-semibold tabular-nums">
                        {screenResult.score}/100
                      </span>
                    </div>
                    <Progress value={screenResult.score} aria-label={`Fit score ${screenResult.score} out of 100`} />
                    <p className="text-sm text-muted-foreground">{screenResult.summary}</p>
                    {screenResult.strengths.length > 0 ? (
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                          Strengths
                        </p>
                        <ul className="space-y-1">
                          {screenResult.strengths.map((s, i) => (
                            <li key={`s-${i}`} className="flex items-start gap-1.5 text-sm">
                              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                              <span className="text-muted-foreground">{s}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : null}
                    {screenResult.concerns.length > 0 ? (
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-amber-700 dark:text-amber-400">
                          Concerns
                        </p>
                        <ul className="space-y-1">
                          {screenResult.concerns.map((c, i) => (
                            <li key={`c-${i}`} className="flex items-start gap-1.5 text-sm">
                              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                              <span className="text-muted-foreground">{c}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : null}
                    <p className="text-xs text-muted-foreground">Saved to candidate notes</p>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Screen this candidate against the {detail.openingTitle} opening — the result is
                    saved to their notes.
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="candidate-notes">Notes</Label>
                <Textarea
                  id="candidate-notes"
                  className="min-h-24"
                  placeholder="Interview feedback, coordination notes..."
                  value={detailNotes}
                  onChange={(e) => setDetailNotes(e.target.value)}
                />
                <Button
                  size="sm"
                  variant="outline"
                  disabled={updateCandidate.isPending || detailNotes === (detail.notes ?? "")}
                  onClick={() =>
                    updateCandidate.mutate({
                      id: detail.id,
                      patch: { notes: detailNotes },
                      message: "Notes saved",
                    })
                  }
                >
                  Save notes
                </Button>
              </div>

              <div className="space-y-2 border-t pt-4">
                <Label>Quick move</Label>
                <Select
                  value={detail.stage}
                  onValueChange={(v) =>
                    updateCandidate.mutate({
                      id: detail.id,
                      patch: { stage: v as CandidateStage },
                      message: `${detail.name} moved to ${STATUS_LABELS[v] ?? v}`,
                    })
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STAGES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {STATUS_LABELS[s] ?? s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </DialogContent>
        ) : null}
      </Dialog>
    </div>
  );
}

// ===================== Kanban pieces =====================

function KanbanColumn({
  stage,
  candidates,
  onOpen,
  onRate,
  shouldIgnoreClick,
}: {
  stage: CandidateStage;
  candidates: CandidateDto[];
  onOpen: (c: CandidateDto) => void;
  onRate: (c: CandidateDto, rating: number) => void;
  shouldIgnoreClick: () => boolean;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: `col-${stage}` });

  return (
    <div className="flex w-60 shrink-0 flex-col gap-2 sm:w-72">
      <div className="flex items-center justify-between px-0.5">
        <span className="text-sm font-semibold">{STATUS_LABELS[stage] ?? stage}</span>
        <Badge variant="secondary" className="tabular-nums">
          {candidates.length}
        </Badge>
      </div>
      <SortableContext items={candidates.map((c) => c.id)} strategy={verticalListSortingStrategy}>
        <div
          ref={setNodeRef}
          className={cn(
            "flex max-h-[70vh] min-h-24 flex-col gap-2 overflow-y-auto rounded-xl border bg-muted/40 p-2 scrollbar-thin transition-colors",
            isOver && "border-primary/60 bg-primary/5"
          )}
        >
          {candidates.map((c) => (
            <CandidateCard
              key={c.id}
              candidate={c}
              onOpen={onOpen}
              onRate={onRate}
              shouldIgnoreClick={shouldIgnoreClick}
            />
          ))}
          {candidates.length === 0 ? (
            <div className="rounded-lg border border-dashed px-3 py-6 text-center text-xs text-muted-foreground">
              Drag candidates here
            </div>
          ) : null}
        </div>
      </SortableContext>
    </div>
  );
}

function CandidateCard({
  candidate,
  onOpen,
  onRate,
  shouldIgnoreClick,
}: {
  candidate: CandidateDto;
  onOpen: (c: CandidateDto) => void;
  onRate: (c: CandidateDto, rating: number) => void;
  shouldIgnoreClick: () => boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: candidate.id,
    data: { stage: candidate.stage },
  });

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Translate.toString(transform), transition }}
      {...attributes}
      {...listeners}
      role="button"
      tabIndex={0}
      onClick={() => {
        if (shouldIgnoreClick()) return;
        onOpen(candidate);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          if (!shouldIgnoreClick()) onOpen(candidate);
        }
      }}
      className={cn(
        "cursor-grab touch-none rounded-lg border bg-card p-3 text-left shadow-sm outline-none transition-shadow hover:shadow-md focus-visible:ring-2 focus-visible:ring-ring active:cursor-grabbing",
        isDragging && "opacity-50"
      )}
    >
      <div className="truncate text-sm font-medium">{candidate.name}</div>
      <div className="mt-1">
        <Badge variant="outline" className="px-1.5 py-0 text-[10px]">
          {candidate.source}
        </Badge>
      </div>
      <div
        className="mt-2"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
      >
        <RatingStars
          size="sm"
          value={candidate.rating ?? 0}
          onChange={(v) => onRate(candidate, v)}
        />
      </div>
      <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
        <span className="tabular-nums">
          {candidate.expectedSalary != null ? inr(candidate.expectedSalary, { compact: true }) : "—"}
        </span>
        <span>{candidate.noticePeriod ?? "—"}</span>
      </div>
      <div className="mt-1 text-[11px] text-muted-foreground">
        Applied {fmtDate(candidate.appliedAt.slice(0, 10))}
      </div>
    </div>
  );
}

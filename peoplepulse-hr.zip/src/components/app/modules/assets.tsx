"use client";

/**
 * PeoplePulse HR — Assets module.
 * Inventory management (owner/admin/hr): stats, filters, add/edit assets and
 * the full allocation lifecycle (allocate, return, maintenance, retire).
 * "My assets" self-service for every employee with linked allocations.
 */

import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ArchiveX,
  Boxes,
  MoreHorizontal,
  PackageOpen,
  Pencil,
  Plus,
  RotateCcw,
  Search,
  Undo2,
  UserPlus,
  Wrench,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { ASSET_CATEGORIES } from "@/lib/constants";
import { cn, fmtDate, initials, inr } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { AssetDto, AssetStatus, EmployeeListResponse, MyAssetDto } from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local types & helpers =====================

interface AssetsResponse {
  assets: AssetDto[];
  stats: { total: number; allocated: number; available: number; totalValue: number };
}

const ASSET_STATUS_OPTIONS: { value: AssetStatus; label: string }[] = [
  { value: "available", label: "Available" },
  { value: "allocated", label: "Allocated" },
  { value: "maintenance", label: "Maintenance" },
  { value: "retired", label: "Retired" },
];

const RETURN_CONDITIONS = ["Excellent", "Good", "Fair", "Damaged"] as const;

const ACTION_TOASTS: Record<string, string> = {
  allocate: "Asset allocated",
  return: "Asset returned",
  retire: "Asset retired",
  maintenance_on: "Asset sent for maintenance",
  maintenance_off: "Asset returned to service",
  update: "Asset updated",
};

function statusBadgeClass(status: AssetStatus): string {
  switch (status) {
    case "available":
      return "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-400";
    case "allocated":
      return "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-400";
    case "maintenance":
      return "border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-900 dark:bg-violet-950 dark:text-violet-400";
    default:
      return "border-muted bg-muted text-muted-foreground";
  }
}

function Avatar({ name, className }: { name: string; className?: string }) {
  return (
    <div
      className={cn(
        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

// ===================== Module =====================

export function AssetsModule() {
  const { user } = useAppStore();
  const isMgr = !!user && ["owner", "admin", "hr"].includes(user.role);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Assets</h1>
        <p className="text-sm text-muted-foreground">
          {isMgr
            ? "Track company assets, allocate them to employees and manage their lifecycle."
            : "Company assets currently allocated to you."}
        </p>
      </div>

      {isMgr ? (
        <Tabs defaultValue="inventory">
          <TabsList>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="mine">My assets</TabsTrigger>
          </TabsList>
          <TabsContent value="inventory" className="mt-4">
            <InventoryView />
          </TabsContent>
          <TabsContent value="mine" className="mt-4">
            <MyAssetsView />
          </TabsContent>
        </Tabs>
      ) : (
        <MyAssetsView />
      )}
    </div>
  );
}

// ===================== Inventory (owner/admin/hr) =====================

function InventoryView() {
  const qc = useQueryClient();

  const inventoryQuery = useQuery({
    queryKey: qk.assets(),
    queryFn: () => api.get<AssetsResponse>("/api/assets"),
  });

  // Active employees for the allocate dialog (same pattern as helpdesk assignees).
  const staffQuery = useQuery({
    queryKey: qk.employees({ status: "active", pageSize: 100, purpose: "asset-allocate" }),
    queryFn: () => api.get<EmployeeListResponse>("/api/employees?status=active&pageSize=100"),
  });

  // ---- filters ----
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  // ---- dialogs ----
  const [addOpen, setAddOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<AssetDto | null>(null);
  const [allocateTarget, setAllocateTarget] = useState<AssetDto | null>(null);
  const [returnTarget, setReturnTarget] = useState<AssetDto | null>(null);

  const act = useMutation({
    mutationFn: (v: { id: string; payload: Record<string, unknown> }) =>
      api.patch<{ asset: AssetDto }>(`/api/assets/${v.id}`, v.payload),
    onSuccess: (_data, v) => {
      qc.invalidateQueries({ queryKey: qk.assets() });
      qc.invalidateQueries({ queryKey: qk.myAssets });
      toast.success(ACTION_TOASTS[String(v.payload.action)] ?? "Asset updated");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const createAsset = useMutation({
    mutationFn: (v: {
      name: string;
      category: string;
      serialNumber?: string;
      value?: number;
      purchaseDate?: string;
      notes?: string;
    }) => api.post<{ asset: AssetDto }>("/api/assets", v),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.assets() });
      toast.success("Asset added to inventory");
      setAddOpen(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const assets = inventoryQuery.data?.assets ?? [];
  const stats = inventoryQuery.data?.stats;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return assets.filter((a) => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (categoryFilter !== "all" && a.category !== categoryFilter) return false;
      if (q) {
        const haystack = `${a.name} ${a.assetTag} ${a.serialNumber ?? ""}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [assets, search, statusFilter, categoryFilter]);

  const busy = act.isPending || createAsset.isPending;
  const employees = staffQuery.data?.items ?? [];

  return (
    <div className="space-y-6">
      {/* ---- Stats ---- */}
      {inventoryQuery.isPending ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : inventoryQuery.isError ? (
        <LoadError
          message={inventoryQuery.error instanceof Error ? inventoryQuery.error.message : undefined}
          onRetry={() => inventoryQuery.refetch()}
        />
      ) : stats ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Total assets" value={String(stats.total)} />
          <StatCard label="Allocated" value={String(stats.allocated)} hint="Currently with employees" />
          <StatCard label="Available" value={String(stats.available)} hint="Ready to allocate" />
          <StatCard label="Total value" value={inr(stats.totalValue, { compact: true })} hint="Purchase value (INR)" />
        </div>
      ) : null}

      {/* ---- Filters + Add ---- */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            aria-label="Search assets"
            placeholder="Search by name, tag or serial"
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-40" aria-label="Filter by status">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {ASSET_STATUS_OPTIONS.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-40" aria-label="Filter by category">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {ASSET_CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex-1" />
        <Button
          onClick={() => {
            setAddOpen(true);
          }}
        >
          <Plus /> Add asset
        </Button>
      </div>

      {/* ---- Inventory table ---- */}
      {inventoryQuery.isPending ? (
        <Skeleton className="h-72 rounded-xl" />
      ) : inventoryQuery.isError ? null : assets.length === 0 ? (
        <EmptyState
          icon={<Boxes className="h-8 w-8 text-muted-foreground/50" />}
          title="No assets yet"
          description="Add your first company asset to start tracking allocations."
        />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Boxes className="h-8 w-8 text-muted-foreground/50" />}
          title="No assets match your filters"
          description="Try a different search term, status or category."
        />
      ) : (
        <div className="max-h-[520px] overflow-y-auto scrollbar-thin rounded-xl border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="pl-4">Asset</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Holder</TableHead>
                <TableHead className="text-right">Value</TableHead>
                <TableHead className="w-12 pr-4" aria-label="Actions" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="pl-4">
                    <p className="font-medium">{a.name}</p>
                    <p className="text-xs text-muted-foreground">
                      <span className="font-mono">{a.assetTag}</span>
                      {a.serialNumber ? ` · SN ${a.serialNumber}` : ""}
                    </p>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{a.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusBadgeClass(a.status)}>
                      {ASSET_STATUS_OPTIONS.find((s) => s.value === a.status)?.label ?? a.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {a.currentAllocation ? (
                      <div className="flex items-center gap-2">
                        <Avatar name={a.currentAllocation.employeeName} />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">
                            {a.currentAllocation.employeeName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            since {fmtDate(a.currentAllocation.allocatedAt)}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">{inr(a.value)}</TableCell>
                  <TableCell className="pr-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8"
                          aria-label={`Actions for ${a.name}`}
                          disabled={busy}
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        {a.status === "available" ? (
                          <DropdownMenuItem onClick={() => setAllocateTarget(a)}>
                            <UserPlus /> Allocate
                          </DropdownMenuItem>
                        ) : null}
                        {a.status === "allocated" ? (
                          <DropdownMenuItem onClick={() => setReturnTarget(a)}>
                            <Undo2 /> Return
                          </DropdownMenuItem>
                        ) : null}
                        {a.status === "available" ? (
                          <DropdownMenuItem
                            onClick={() =>
                              act.mutate({ id: a.id, payload: { action: "maintenance_on" } })
                            }
                          >
                            <Wrench /> Send to maintenance
                          </DropdownMenuItem>
                        ) : null}
                        {a.status === "maintenance" ? (
                          <DropdownMenuItem
                            onClick={() =>
                              act.mutate({ id: a.id, payload: { action: "maintenance_off" } })
                            }
                          >
                            <RotateCcw /> Return to service
                          </DropdownMenuItem>
                        ) : null}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setEditTarget(a)}>
                          <Pencil /> Edit details
                        </DropdownMenuItem>
                        {a.status !== "allocated" && a.status !== "retired" ? (
                          <DropdownMenuItem
                            variant="destructive"
                            onClick={() => act.mutate({ id: a.id, payload: { action: "retire" } })}
                          >
                            <ArchiveX /> Retire
                          </DropdownMenuItem>
                        ) : null}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* ---- Add / Edit dialog ---- */}
      <AssetFormDialog
        open={addOpen || !!editTarget}
        onOpenChange={(open) => {
          if (!open) {
            setAddOpen(false);
            setEditTarget(null);
          }
        }}
        mode={editTarget ? "edit" : "create"}
        asset={editTarget}
        pending={busy}
        onSubmit={(values) => {
          if (editTarget) {
            const target = editTarget;
            setEditTarget(null);
            act.mutate({
              id: target.id,
              payload: {
                action: "update",
                name: values.name,
                category: values.category,
                ...(values.value.trim() !== "" ? { value: Number(values.value) } : {}),
                serialNumber: values.serialNumber.trim(),
                notes: values.notes.trim(),
              },
            });
          } else {
            createAsset.mutate({
              name: values.name,
              category: values.category,
              ...(values.serialNumber.trim() ? { serialNumber: values.serialNumber.trim() } : {}),
              ...(values.value.trim() ? { value: Number(values.value) } : {}),
              ...(values.purchaseDate ? { purchaseDate: values.purchaseDate } : {}),
              ...(values.notes.trim() ? { notes: values.notes.trim() } : {}),
            });
          }
        }}
      />

      {/* ---- Allocate dialog ---- */}
      <AllocateDialog
        asset={allocateTarget}
        employees={employees}
        employeesLoading={staffQuery.isPending}
        pending={act.isPending}
        onOpenChange={(open) => {
          if (!open) setAllocateTarget(null);
        }}
        onSubmit={(v) => {
          const target = allocateTarget;
          setAllocateTarget(null);
          if (target) {
            act.mutate({
              id: target.id,
              payload: {
                action: "allocate",
                employeeId: v.employeeId,
                ...(v.notes ? { notes: v.notes } : {}),
              },
            });
          }
        }}
      />

      {/* ---- Return dialog ---- */}
      <ReturnDialog
        asset={returnTarget}
        pending={act.isPending}
        onOpenChange={(open) => {
          if (!open) setReturnTarget(null);
        }}
        onSubmit={(v) => {
          const target = returnTarget;
          setReturnTarget(null);
          if (target) {
            act.mutate({
              id: target.id,
              payload: {
                action: "return",
                ...(v.condition ? { condition: v.condition } : {}),
                ...(v.notes ? { notes: v.notes } : {}),
              },
            });
          }
        }}
      />
    </div>
  );
}

function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card className="gap-1 p-4">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="text-2xl font-bold tabular-nums">{value}</p>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </Card>
  );
}

// ===================== Asset form dialog (add / edit) =====================

interface AssetFormValues {
  name: string;
  category: string;
  serialNumber: string;
  value: string;
  purchaseDate: string;
  notes: string;
}

function emptyAssetForm(): AssetFormValues {
  return {
    name: "",
    category: ASSET_CATEGORIES[0],
    serialNumber: "",
    value: "",
    purchaseDate: "",
    notes: "",
  };
}

function assetToForm(a: AssetDto): AssetFormValues {
  return {
    name: a.name,
    category: a.category,
    serialNumber: a.serialNumber ?? "",
    value: a.value > 0 ? String(a.value) : "",
    purchaseDate: a.purchaseDate ?? "",
    notes: a.notes ?? "",
  };
}

function AssetFormDialog({
  open,
  onOpenChange,
  mode,
  asset,
  pending,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "create" | "edit";
  asset: AssetDto | null;
  pending: boolean;
  onSubmit: (values: AssetFormValues) => void;
}) {
  // The content unmounts when the dialog closes, so its state resets on each opening.
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {open ? (
        <AssetFormContent
          key={asset?.id ?? "new"}
          mode={mode}
          asset={asset}
          pending={pending}
          onSubmit={onSubmit}
          onCancel={() => onOpenChange(false)}
        />
      ) : null}
    </Dialog>
  );
}

function AssetFormContent({
  mode,
  asset,
  pending,
  onSubmit,
  onCancel,
}: {
  mode: "create" | "edit";
  asset: AssetDto | null;
  pending: boolean;
  onSubmit: (values: AssetFormValues) => void;
  onCancel: () => void;
}) {
  const [values, setValues] = useState<AssetFormValues>(() =>
    asset ? assetToForm(asset) : emptyAssetForm()
  );
  const [error, setError] = useState<string | null>(null);

  function set<K extends keyof AssetFormValues>(key: K, v: AssetFormValues[K]) {
    setValues((prev) => ({ ...prev, [key]: v }));
  }

  function submit() {
    setError(null);
    if (!values.name.trim()) {
      setError("Please enter an asset name.");
      return;
    }
    if (values.value.trim() !== "" && (!Number.isFinite(Number(values.value)) || Number(values.value) < 0)) {
      setError("Value must be a non-negative amount in INR.");
      return;
    }
    onSubmit({ ...values, name: values.name.trim() });
  }

  return (
    <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add asset" : `Edit ${asset?.name ?? "asset"}`}</DialogTitle>
          <DialogDescription>
            {mode === "create"
              ? "Register a new company asset. An AST tag is generated automatically."
              : `Update the details of ${asset?.assetTag ?? "this asset"}.`}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="asset-name">Name</Label>
            <Input
              id="asset-name"
              placeholder="e.g. MacBook Pro 14&quot; M3"
              value={values.name}
              onChange={(e) => set("name", e.target.value)}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={values.category} onValueChange={(v) => set("category", v)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {ASSET_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="asset-serial">Serial number</Label>
              <Input
                id="asset-serial"
                placeholder="Optional"
                value={values.serialNumber}
                onChange={(e) => set("serialNumber", e.target.value)}
              />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="asset-value">Value (INR)</Label>
              <Input
                id="asset-value"
                type="number"
                min={0}
                placeholder="e.g. 85000"
                value={values.value}
                onChange={(e) => set("value", e.target.value)}
              />
            </div>
            {mode === "create" ? (
              <div className="space-y-2">
                <Label htmlFor="asset-purchase-date">Purchase date</Label>
                <Input
                  id="asset-purchase-date"
                  type="date"
                  value={values.purchaseDate}
                  onChange={(e) => set("purchaseDate", e.target.value)}
                />
              </div>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="asset-notes">Notes</Label>
            <Textarea
              id="asset-notes"
              className="min-h-20"
              placeholder="Optional notes (config, accessories, warranty…)"
              value={values.notes}
              onChange={(e) => set("notes", e.target.value)}
            />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button disabled={pending} onClick={submit}>
            {mode === "create" ? "Add asset" : "Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
  );
}

// ===================== Allocate dialog =====================

function AllocateDialog({
  asset,
  employees,
  employeesLoading,
  pending,
  onOpenChange,
  onSubmit,
}: {
  asset: AssetDto | null;
  employees: EmployeeListResponse["items"];
  employeesLoading: boolean;
  pending: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (v: { employeeId: string; notes?: string }) => void;
}) {
  // The content unmounts when the dialog closes, so its state resets on each opening.
  return (
    <Dialog open={!!asset} onOpenChange={onOpenChange}>
      {asset ? (
        <AllocateContent
          key={asset.id}
          asset={asset}
          employees={employees}
          employeesLoading={employeesLoading}
          pending={pending}
          onSubmit={onSubmit}
          onCancel={() => onOpenChange(false)}
        />
      ) : null}
    </Dialog>
  );
}

function AllocateContent({
  asset,
  employees,
  employeesLoading,
  pending,
  onSubmit,
  onCancel,
}: {
  asset: AssetDto;
  employees: EmployeeListResponse["items"];
  employeesLoading: boolean;
  pending: boolean;
  onSubmit: (v: { employeeId: string; notes?: string }) => void;
  onCancel: () => void;
}) {
  const [employeeId, setEmployeeId] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);

  function submit() {
    setError(null);
    if (!employeeId) {
      setError("Please select an employee.");
      return;
    }
    onSubmit({ employeeId, notes: notes.trim() || undefined });
  }

  return (
    <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Allocate asset</DialogTitle>
          <DialogDescription>
            {asset.name} ({asset.assetTag}) will be handed over to the selected employee.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Employee</Label>
            {employeesLoading ? (
              <Skeleton className="h-9 w-full" />
            ) : employees.length === 0 ? (
              <p className="rounded-md bg-muted px-3 py-2 text-sm text-muted-foreground">
                No active employees found.
              </p>
            ) : (
              <Select value={employeeId} onValueChange={setEmployeeId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select an employee" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {employees.map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.firstName} {e.lastName} · {e.designation} ({e.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="allocate-notes">Notes (optional)</Label>
            <Textarea
              id="allocate-notes"
              className="min-h-20"
              placeholder="e.g. With charger and sleeve"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button disabled={pending || employeesLoading || employees.length === 0} onClick={submit}>
            Allocate
          </Button>
        </DialogFooter>
      </DialogContent>
  );
}

// ===================== Return dialog =====================

function ReturnDialog({
  asset,
  pending,
  onOpenChange,
  onSubmit,
}: {
  asset: AssetDto | null;
  pending: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (v: { condition: string; notes?: string }) => void;
}) {
  // The content unmounts when the dialog closes, so its state resets on each opening.
  return (
    <Dialog open={!!asset} onOpenChange={onOpenChange}>
      {asset ? (
        <ReturnContent
          key={asset.id}
          asset={asset}
          pending={pending}
          onSubmit={onSubmit}
          onCancel={() => onOpenChange(false)}
        />
      ) : null}
    </Dialog>
  );
}

function ReturnContent({
  asset,
  pending,
  onSubmit,
  onCancel,
}: {
  asset: AssetDto;
  pending: boolean;
  onSubmit: (v: { condition: string; notes?: string }) => void;
  onCancel: () => void;
}) {
  const [condition, setCondition] = useState<string>("Good");
  const [notes, setNotes] = useState("");

  return (
    <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Return asset</DialogTitle>
          <DialogDescription>
            {asset.name} ({asset.assetTag}) will be marked available after{" "}
            {asset.currentAllocation?.employeeName ?? "the holder"} returns it.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Condition on return</Label>
            <Select value={condition} onValueChange={setCondition}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select condition" />
              </SelectTrigger>
              <SelectContent>
                {RETURN_CONDITIONS.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="return-notes">Notes (optional)</Label>
            <Textarea
              id="return-notes"
              className="min-h-20"
              placeholder="e.g. Minor scratches on lid"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            disabled={pending}
            onClick={() => onSubmit({ condition, notes: notes.trim() || undefined })}
          >
            Mark returned
          </Button>
        </DialogFooter>
      </DialogContent>
  );
}

// ===================== My assets =====================

function MyAssetsView() {
  const mineQuery = useQuery({
    queryKey: qk.myAssets,
    queryFn: () => api.get<{ items: MyAssetDto[] }>("/api/assets/me"),
  });

  const items = mineQuery.data?.items ?? [];

  return (
    <div className="space-y-4">
      {mineQuery.isPending ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
      ) : mineQuery.isError ? (
        <LoadError
          message={mineQuery.error instanceof Error ? mineQuery.error.message : undefined}
          onRetry={() => mineQuery.refetch()}
        />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<PackageOpen className="h-8 w-8 text-muted-foreground/50" />}
          title="No assets allocated to you"
          description="Assets allocated to you by HR will appear here with their tags and details."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((m) => (
            <Card key={m.id} className="gap-3 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-medium">{m.name}</p>
                  <p className="mt-1 font-mono text-xs text-muted-foreground">{m.assetTag}</p>
                </div>
                <Badge variant="outline">{m.category}</Badge>
              </div>
              <CardContent className="grid grid-cols-2 gap-x-4 gap-y-2 px-0 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Serial</p>
                  <p className="truncate font-mono text-xs">{m.serialNumber ?? "—"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Allocated on</p>
                  <p className="text-sm">{fmtDate(m.allocatedAt)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Value</p>
                  <p className="tabular-nums">{inr(m.value)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <p className="text-sm text-amber-700 dark:text-amber-400">With you</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

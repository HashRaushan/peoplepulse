"use client";

/**
 * PeoplePulse HR — Directory module.
 * Simple, beautiful searchable people grid available to every role.
 * Client-side search across name, email, code, designation and department.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Contact, Mail, MapPin, Search, Users } from "lucide-react";
import type { EmployeeListResponse, Role, SessionUser } from "@/lib/types";
import { api, qk } from "@/lib/api-client";
import { initials } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

/** Roles that can open the full Employees module from the directory. */
const DIRECTORY_FULL_ACCESS: Role[] = ["owner", "admin", "hr", "manager"];

export function DirectoryModule() {
  const { user } = useAppStore();
  if (!user) return null;
  return <DirectoryInner user={user} />;
}

function DirectoryInner({ user }: { user: SessionUser }) {
  const { setModule } = useAppStore();
  const canViewProfiles = DIRECTORY_FULL_ACCESS.includes(user.role);
  const [search, setSearch] = useState("");

  const directoryQuery = useQuery({
    queryKey: qk.employees({ status: "active", pageSize: 100 }),
    queryFn: () =>
      api.get<EmployeeListResponse>("/api/employees?status=active&pageSize=100"),
  });

  useEffect(() => {
    if (directoryQuery.error) toast.error(directoryQuery.error.message);
  }, [directoryQuery.error]);

  const items = useMemo(() => directoryQuery.data?.items ?? [], [directoryQuery.data]);

  const q = search.trim().toLowerCase();
  const filtered = useMemo(() => {
    if (!q) return items;
    return items.filter((e) =>
      [
        `${e.firstName} ${e.lastName}`,
        e.email,
        e.code,
        e.designation,
        e.department,
      ]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [items, q]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Directory</h1>
          <p className="text-sm text-muted-foreground">
            {directoryQuery.data
              ? `${filtered.length} of ${items.length} ${items.length === 1 ? "colleague" : "colleagues"} · ${user.tenantName}`
              : `Find your colleagues at ${user.tenantName}`}
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute top-1/2 left-2.5 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, email, team or role…"
            className="pl-8"
          />
        </div>
      </div>

      {/* Grid */}
      {directoryQuery.isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-44 rounded-xl" />
          ))}
        </div>
      ) : directoryQuery.isError ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <Contact className="h-8 w-8 text-muted-foreground" />
          <div>
            <div className="font-semibold">Could not load the directory</div>
            <p className="text-sm text-muted-foreground">{directoryQuery.error.message}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => directoryQuery.refetch()}>
            Try again
          </Button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Users className="h-6 w-6 text-primary" />
          </div>
          <div>
            <div className="font-semibold">
              {q ? "No one matches your search" : "No people to show"}
            </div>
            <p className="text-sm text-muted-foreground">
              {q
                ? "Try a different name, team or role."
                : "Active colleagues will appear here once they are added."}
            </p>
          </div>
          {q && (
            <Button variant="outline" size="sm" onClick={() => setSearch("")}>
              Clear search
            </Button>
          )}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((person) => {
            const name = `${person.firstName} ${person.lastName}`.trim();
            return (
              <div
                key={person.id}
                className="flex flex-col gap-3 rounded-xl border bg-card p-4 shadow-sm transition-all hover:border-primary/40 hover:shadow-md"
              >
                <div className="flex items-center gap-3">
                  <div
                    style={{
                      backgroundColor: `${person.avatarColor}22`,
                      color: person.avatarColor,
                    }}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-semibold"
                  >
                    {initials(name)}
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{name}</div>
                    <div className="truncate text-xs text-muted-foreground">
                      {person.designation}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5 text-[11px] text-muted-foreground">
                  <Badge variant="outline" className="text-[10px]">
                    {person.department}
                  </Badge>
                  <span className="flex min-w-0 items-center gap-1">
                    <MapPin className="h-3 w-3 shrink-0" />
                    <span className="truncate">{person.location || "—"}</span>
                  </span>
                  <span className="font-mono">{person.code}</span>
                </div>
                <div className="mt-auto flex items-center gap-2 border-t pt-3">
                  <Button asChild variant="outline" size="sm" className="min-w-0 flex-1">
                    <a href={`mailto:${person.email}`}>
                      <Mail className="h-3.5 w-3.5" /> Email
                    </a>
                  </Button>
                  {canViewProfiles ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setModule("employees")}
                      title="Open the Employees module"
                    >
                      View profile
                    </Button>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled
                      title="Full profiles are available to HR and managers"
                    >
                      View profile
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { useAppStore } from "@/lib/store";
import { cn, inr, fmtDate, fmtDateTime } from "@/lib/hr-utils";
import { PLAN_CREDITS, NAV_SECTIONS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Building2, Palette, CreditCard, ScrollText, CalendarDays, History,
  Loader2, Plus, Download, Check, Crown, ShieldCheck, Lock, DatabaseBackup,
  MapPin, Crosshair, Radar,
} from "lucide-react";
import type { OrgProfileDto, PolicyDto, HolidayDto, AuditLogDto, InvoiceDto, GeoFenceConfigDto } from "@/lib/types";
import { formatDistance } from "@/lib/geo";
import { PaymentPanel } from "../pending-screen";
import { Landmark, BadgeCheck } from "lucide-react";

export function SettingsModule() {
  const { user } = useAppStore();
  const isOwnerAdmin = user && ["owner", "admin"].includes(user.role);
  const isHr = user && ["owner", "admin", "hr"].includes(user.role);

  const [tab, setTab] = useState(isOwnerAdmin ? "organisation" : "policies");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Organisation configuration, branding, billing, policies and governance.</p>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="space-y-4">
        <TabsList className="flex-wrap">
          <TabsTrigger value="organisation" className="gap-1.5"><Building2 className="h-3.5 w-3.5" /> Organisation</TabsTrigger>
          {isOwnerAdmin && <TabsTrigger value="attendance" className="gap-1.5"><MapPin className="h-3.5 w-3.5" /> Attendance</TabsTrigger>}
          {isOwnerAdmin && <TabsTrigger value="billing" className="gap-1.5"><CreditCard className="h-3.5 w-3.5" /> Plan & billing</TabsTrigger>}
          <TabsTrigger value="policies" className="gap-1.5"><ScrollText className="h-3.5 w-3.5" /> Policies</TabsTrigger>
          <TabsTrigger value="holidays" className="gap-1.5"><CalendarDays className="h-3.5 w-3.5" /> Holidays</TabsTrigger>
          <TabsTrigger value="security" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Security</TabsTrigger>
          {isHr && <TabsTrigger value="audit" className="gap-1.5"><History className="h-3.5 w-3.5" /> Audit log</TabsTrigger>}
        </TabsList>

        <TabsContent value="organisation"><OrgSettings /></TabsContent>
        {isOwnerAdmin && <TabsContent value="attendance"><AttendanceSettings /></TabsContent>}
        {isOwnerAdmin && <TabsContent value="billing"><BillingSettings /></TabsContent>}
        <TabsContent value="policies"><PoliciesTab /></TabsContent>
        <TabsContent value="holidays"><HolidaysTab /></TabsContent>
        <TabsContent value="security"><SecurityTab /></TabsContent>
        {isHr && <TabsContent value="audit"><AuditTab /></TabsContent>}
      </Tabs>
    </div>
  );
}

// ============================== Shared error state ==============================

function LoadError({ title, message, onRetry }: { title?: string; message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">{title ?? "Something went wrong"}</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

// ============================== Organisation ==============================

function OrgSettings() {
  const { user } = useAppStore();
  const qc = useQueryClient();
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.orgProfile,
    queryFn: () => api.get<OrgProfileDto>("/api/org/profile"),
  });

  const [form, setForm] = useState<{ name: string; brandColor: string; logoText: string; country: string; currency: string; timezone: string } | null>(null);
  const current = form ?? (data ? { name: data.name, brandColor: data.brandColor, logoText: data.logoText, country: data.country, currency: data.currency, timezone: data.timezone } : null);

  const saveMutation = useMutation({
    mutationFn: (payload: Record<string, string>) => api.patch<OrgProfileDto>("/api/org/profile", payload),
    onSuccess: () => {
      toast.success("Organisation settings saved");
      qc.invalidateQueries({ queryKey: qk.orgProfile });
      setForm(null);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save"),
  });

  if (isError) {
    return (
      <LoadError
        message={error instanceof Error ? error.message : undefined}
        onRetry={() => refetch()}
      />
    );
  }
  if (isLoading || !current) return <Skeleton className="h-72" />;
  const isOwnerAdmin = user && ["owner", "admin"].includes(user.role);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <Building2 className="h-4 w-4 text-primary" /> Company profile
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-1.5">
            <Label>Organisation name</Label>
            <Input value={current.name} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, name: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label>Country</Label>
              <Input value={current.country} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, country: e.target.value })} />
            </div>
            <div className="grid gap-1.5">
              <Label>Currency</Label>
              <Input value={current.currency} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, currency: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label>Timezone</Label>
              <Input value={current.timezone} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, timezone: e.target.value })} />
            </div>
            <div className="grid gap-1.5">
              <Label>Workspace slug</Label>
              <Input value={data!.slug} disabled />
            </div>
          </div>
          <div className="rounded-lg border bg-muted/40 p-3 text-[11px] text-muted-foreground">
            Created {fmtDate(data!.createdAt.slice(0, 10))} · {data!.employeeCount} active employees · seat limit {data!.seats}
          </div>
          {isOwnerAdmin && (
            <Button className="w-full" disabled={!form || saveMutation.isPending} onClick={() => saveMutation.mutate(current)}>
              {saveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save changes
            </Button>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <Palette className="h-4 w-4 text-primary" /> Branding
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="flex items-center gap-4">
            <div
              className="flex h-14 w-14 items-center justify-center rounded-2xl text-xl font-bold text-white"
              style={{ background: current.brandColor }}
            >
              {current.logoText}
            </div>
            <div className="flex-1 space-y-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-1.5">
                  <Label>Logo text</Label>
                  <Input maxLength={2} value={current.logoText} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, logoText: e.target.value.toUpperCase() })} />
                </div>
                <div className="grid gap-1.5">
                  <Label>Brand colour</Label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      className="h-9 w-10 cursor-pointer rounded-md border border-input bg-background p-1"
                      value={current.brandColor}
                      disabled={!isOwnerAdmin}
                      onChange={(e) => setForm({ ...current, brandColor: e.target.value })}
                    />
                    <Input value={current.brandColor} disabled={!isOwnerAdmin} onChange={(e) => setForm({ ...current, brandColor: e.target.value })} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            Branding applies to the workspace logo and accents. Emails, career pages and employee-facing
            documents use these settings in the enterprise edition.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================== Attendance & Geo-fence ==============================

function AttendanceSettings() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: qk.geoFence,
    queryFn: () => api.get<GeoFenceConfigDto>("/api/org/geo-fence"),
  });

  const [form, setForm] = useState<GeoFenceConfigDto | null>(null);
  const [detecting, setDetecting] = useState(false);
  const current = form ?? data ?? null;

  const save = useMutation({
    mutationFn: (vars: Partial<GeoFenceConfigDto>) =>
      api.patch<GeoFenceConfigDto>("/api/org/geo-fence", vars),
    onSuccess: (updated) => {
      setForm(updated);
      qc.invalidateQueries({ queryKey: qk.geoFence });
      toast.success("Attendance geo-fence settings saved.");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function useMyLocation() {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      toast.error("Location services are not available on this device.");
      return;
    }
    setDetecting(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm((f) => ({
          enabled: f?.enabled ?? false,
          officeLabel: f?.officeLabel ?? null,
          officeLatitude: pos.coords.latitude,
          officeLongitude: pos.coords.longitude,
          officeRadiusMeters: f?.officeRadiusMeters ?? 150,
        }));
        setDetecting(false);
        toast.success("Location captured. Review and save to confirm.");
      },
      (err) => {
        setDetecting(false);
        const messages: Record<number, string> = {
          1: "Location access was denied. Please allow location to capture office coordinates.",
          2: "Your location could not be determined. Try moving to an open area or enable GPS.",
          3: "Location request timed out. Please try again.",
        };
        toast.error(messages[err.code] ?? "Could not get your location.");
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }

  if (isLoading) return <Skeleton className="h-72" />;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <Radar className="h-4 w-4 text-primary" /> Geo-fenced check-in
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            When enabled, employees must check in from within {current ? formatDistance(current.officeRadiusMeters) ?? `${current.officeRadiusMeters} m` : "150 m"} of your office. Their GPS coordinates are captured and the distance from the office is recorded on every check-in.
          </p>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Enable toggle */}
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="min-w-0">
              <p className="text-sm font-medium">Require location for check-in</p>
              <p className="text-xs text-muted-foreground">
                Block check-ins from outside the office radius. Disable to allow check-in from anywhere.
              </p>
            </div>
            <Switch
              checked={current?.enabled ?? false}
              onCheckedChange={(checked) => {
                if (checked && current?.officeLatitude == null) {
                  toast.error("Set the office location before enabling geo-fencing.");
                  return;
                }
                setForm((f) => ({
                  enabled: checked,
                  officeLabel: f?.officeLabel ?? null,
                  officeLatitude: f?.officeLatitude ?? null,
                  officeLongitude: f?.officeLongitude ?? null,
                  officeRadiusMeters: f?.officeRadiusMeters ?? 150,
                }));
              }}
            />
          </div>

          {/* Office location */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="office-label">Office label</Label>
              <Input
                id="office-label"
                placeholder="e.g. Bengaluru HQ"
                value={current?.officeLabel ?? ""}
                onChange={(e) =>
                  setForm((f) => ({
                    enabled: f?.enabled ?? false,
                    officeLabel: e.target.value,
                    officeLatitude: f?.officeLatitude ?? null,
                    officeLongitude: f?.officeLongitude ?? null,
                    officeRadiusMeters: f?.officeRadiusMeters ?? 150,
                  }))
                }
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="office-lat">Office latitude</Label>
                <Input
                  id="office-lat"
                  type="number"
                  step="any"
                  placeholder="12.9716"
                  value={current?.officeLatitude ?? ""}
                  onChange={(e) =>
                    setForm((f) => ({
                      enabled: f?.enabled ?? false,
                      officeLabel: f?.officeLabel ?? null,
                      officeLatitude: e.target.value === "" ? null : Number(e.target.value),
                      officeLongitude: f?.officeLongitude ?? null,
                      officeRadiusMeters: f?.officeRadiusMeters ?? 150,
                    }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="office-lng">Office longitude</Label>
                <Input
                  id="office-lng"
                  type="number"
                  step="any"
                  placeholder="77.5946"
                  value={current?.officeLongitude ?? ""}
                  onChange={(e) =>
                    setForm((f) => ({
                      enabled: f?.enabled ?? false,
                      officeLabel: f?.officeLabel ?? null,
                      officeLatitude: f?.officeLatitude ?? null,
                      officeLongitude: e.target.value === "" ? null : Number(e.target.value),
                      officeRadiusMeters: f?.officeRadiusMeters ?? 150,
                    }))
                  }
                />
              </div>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={useMyLocation} disabled={detecting}>
              {detecting ? (
                <>
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> Detecting…
                </>
              ) : (
                <>
                  <Crosshair className="mr-1.5 h-3.5 w-3.5" /> Use my current location
                </>
              )}
            </Button>
          </div>

          {/* Radius */}
          <div className="space-y-2">
            <Label htmlFor="radius">Allowed radius (metres)</Label>
            <Input
              id="radius"
              type="number"
              min={10}
              max={50000}
              placeholder="150"
              value={current?.officeRadiusMeters ?? 150}
              onChange={(e) =>
                setForm((f) => ({
                  enabled: f?.enabled ?? false,
                  officeLabel: f?.officeLabel ?? null,
                  officeLatitude: f?.officeLatitude ?? null,
                  officeLongitude: f?.officeLongitude ?? null,
                  officeRadiusMeters: e.target.value === "" ? 150 : Number(e.target.value),
                }))
              }
            />
            <p className="text-[11px] text-muted-foreground">
              Typical office radius: 100–300 m. Increase for large campuses, decrease for stricter enforcement.
            </p>
          </div>

          {/* Status preview */}
          {current?.officeLatitude != null && current?.officeLongitude != null && (
            <div className="flex items-start gap-2 rounded-lg bg-primary/5 p-3 text-xs text-primary">
              <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>
                {current.enabled
                  ? `Geo-fencing is ON. Employees must be within ${formatDistance(current.officeRadiusMeters) ?? `${current.officeRadiusMeters} m`} of ${current.officeLabel ?? "the office"} to check in.`
                  : `Geo-fencing is OFF. Location is not required for check-in. Coordinates will still be recorded if the office is configured.`}
              </span>
            </div>
          )}

          {/* Privacy note */}
          <p className="text-[11px] text-muted-foreground">
            Location is captured only at the moment of check-in — there is no continuous tracking.
            Coordinates are stored per attendance record and visible to HR and managers.
          </p>

          <div className="flex justify-end gap-2">
            <Button
              disabled={save.isPending}
              onClick={() => {
                if (!current) return;
                save.mutate({
                  enabled: current.enabled,
                  officeLabel: current.officeLabel,
                  officeLatitude: current.officeLatitude,
                  officeLongitude: current.officeLongitude,
                  officeRadiusMeters: current.officeRadiusMeters,
                });
              }}
            >
              {save.isPending ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Check className="mr-1.5 h-4 w-4" />}
              Save settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================== Billing ==============================

function BillingSettings() {
  const { user } = useAppStore();
  const [payOpen, setPayOpen] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: qk.orgProfile,
    queryFn: () => api.get<OrgProfileDto>("/api/org/profile"),
  });
  const invoicesQuery = useQuery({
    queryKey: qk.invoices,
    queryFn: () => api.get<{ items: InvoiceDto[] }>("/api/invoices"),
  });
  const billingQuery = useQuery({
    queryKey: qk.billingOverview,
    queryFn: () => api.get<{ proofs: { utr: string; amount: number; status: string }[]; config: { paidUntil: string | null; trialEndsAt: string | null } }> ("/api/billing/overview"),
  });
  const pendingProof = billingQuery.data?.proofs.find((p) => p.status === "submitted") ?? null;

  if (isLoading || !data) return <Skeleton className="h-72" />;
  const trialDaysLeft = data.trialEndsAt ? Math.max(0, Math.ceil((new Date(data.trialEndsAt).getTime() - Date.now()) / 86400000)) : null;
  const paidUntil = billingQuery.data?.config.paidUntil ?? user?.paidUntil ?? null;
  const moduleCount = user
    ? NAV_SECTIONS.reduce((n, s) => n + s.items.filter((i) => i.roles.includes(user.role)).length, 0)
    : 0;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <Crown className="h-4 w-4 text-primary" /> {PLAN_CREDITS[data.plan as keyof typeof PLAN_CREDITS]?.label ?? data.plan} plan
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {data.seats} seats included · {data.employeeCount} in use
                </p>
              </div>
              <Badge variant={data.planStatus === "active" ? "default" : "secondary"} className="capitalize">
                {data.planStatus}
              </Badge>
            </div>
            {trialDaysLeft !== null && (
              <div className="mt-4 rounded-lg border border-primary/30 bg-primary/5 p-3 text-xs text-primary">
                Free trial — {trialDaysLeft} days remaining. All {PLAN_CREDITS[data.plan as keyof typeof PLAN_CREDITS]?.label ?? data.plan} features are unlocked until then.
              </div>
            )}
            {paidUntil && (
              <div className="mt-4 flex items-center gap-2 rounded-lg border p-3 text-xs">
                <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-primary" />
                <span className="text-muted-foreground">
                  Subscription active until <span className="font-medium text-foreground">{fmtDate(paidUntil)}</span>
                </span>
              </div>
            )}
            {pendingProof && (
              <div className="mt-3 flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/5 p-3 text-xs text-amber-700 dark:text-amber-400">
                <Landmark className="h-3.5 w-3.5 shrink-0" />
                <span>
                  Reference <span className="font-mono font-medium">{pendingProof.utr}</span> ({inr(pendingProof.amount)}) is awaiting verification — your workspace stays active once verified.
                </span>
              </div>
            )}
            <div className="mt-4 space-y-1.5">
              <p className="text-sm font-semibold">
                {PLAN_CREDITS[data.plan as keyof typeof PLAN_CREDITS]?.monthly === "custom"
                  ? "Custom pricing"
                  : `${inr(Number(PLAN_CREDITS[data.plan as keyof typeof PLAN_CREDITS]?.monthly ?? 0))}/employee/month`}
              </p>
              <p className="text-[11px] text-muted-foreground">
                Pay via UPI or bank transfer (NEFT/IMPS) with manual verification — no card required.
              </p>
            </div>
            <Button className="mt-4 w-full sm:w-auto" onClick={() => setPayOpen(true)}>
              <Landmark className="mr-2 h-4 w-4" />
              {data.planStatus === "trialing" ? "Upgrade to a paid plan" : "Renew / change plan"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Usage</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <UsageRow label="Employees" used={data.employeeCount} total={data.seats} />
            <UsageRow label="Modules enabled" used={moduleCount} total={moduleCount} suffix="" />
            <p className="pt-2 text-[10px] text-muted-foreground">
              Seat and module usage reflect your current plan.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <CreditCard className="h-4 w-4 text-primary" /> Invoices & payment history
          </CardTitle>
        </CardHeader>
        <CardContent>
          {invoicesQuery.isLoading && <Skeleton className="h-24" />}
          {invoicesQuery.isError && (
            <LoadError
              title="Could not load invoices"
              message={invoicesQuery.error instanceof Error ? invoicesQuery.error.message : undefined}
              onRetry={() => invoicesQuery.refetch()}
            />
          )}
          {invoicesQuery.data?.items.length === 0 && (
            <p className="py-6 text-center text-xs text-muted-foreground">No invoices yet — they appear after your first billing cycle.</p>
          )}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                  <th className="py-2 pr-3 font-medium">Invoice</th>
                  <th className="py-2 pr-3 font-medium">Period</th>
                  <th className="py-2 pr-3 font-medium">Seats</th>
                  <th className="py-2 pr-3 text-right font-medium">Amount</th>
                  <th className="py-2 pr-3 text-right font-medium">GST (18%)</th>
                  <th className="py-2 pr-3 text-right font-medium">Total</th>
                  <th className="py-2 pr-3 font-medium">Status</th>
                  <th className="py-2 text-right font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {invoicesQuery.data?.items.map((inv) => (
                  <tr key={inv.id} className="border-b border-border/60 last:border-0">
                    <td className="py-2.5 pr-3 font-mono text-xs">{inv.number}</td>
                    <td className="py-2.5 pr-3 text-xs">{inv.periodLabel}</td>
                    <td className="py-2.5 pr-3 text-xs">{inv.seats}</td>
                    <td className="py-2.5 pr-3 text-right text-xs">{inr(inv.amount)}</td>
                    <td className="py-2.5 pr-3 text-right text-xs text-muted-foreground">{inr(inv.tax)}</td>
                    <td className="py-2.5 pr-3 text-right text-xs font-semibold">{inr(inv.total)}</td>
                    <td className="py-2.5 pr-3">
                      <Badge variant={inv.status === "paid" ? "default" : "secondary"} className="text-[10px] capitalize">{inv.status}</Badge>
                    </td>
                    <td className="py-2.5 text-right">
                      <Button
                        variant="ghost" size="sm" className="h-7 px-2 text-[11px]"
                        onClick={() => {
                          import("@/lib/hr-utils").then(({ downloadCsv }) =>
                            downloadCsv(inv.number, [
                              { description: `${inv.plan} plan — ${inv.periodLabel}`, seats: inv.seats, amount: inv.amount, gst: inv.tax, total: inv.total },
                            ], [
                              { key: "description", label: "Description" }, { key: "seats", label: "Seats" },
                              { key: "amount", label: "Amount (INR)" }, { key: "gst", label: "GST" }, { key: "total", label: "Total" },
                            ])
                          );
                        }}
                      >
                        <Download className="mr-1 h-3 w-3" /> Download
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[10px] text-muted-foreground">
            Payments are made via UPI or bank transfer (NEFT/IMPS) to the platform's account and verified manually
            against the transaction reference (UTR) you submit. PeoplePulse HR never stores card details.
          </p>
        </CardContent>
      </Card>

      {/* Payment / renewal dialog */}
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto scrollbar-thin">
          <DialogHeader>
            <DialogTitle>Pay or renew your subscription</DialogTitle>
            <DialogDescription>
              Choose a plan, transfer the amount to the platform&apos;s account and submit the transaction
              reference (UTR). Your subscription is extended as soon as the payment is verified.
            </DialogDescription>
          </DialogHeader>
          <PaymentPanel variant="renew" />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function UsageRow({ label, used, total, suffix = "" }: { label: string; used: number; total: number; suffix?: string }) {
  const pct = total > 0 ? Math.min(100, Math.round((used / total) * 100)) : 0;
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground">{used} / {total}{suffix}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-muted">
        <div className={cn("h-full rounded-full", pct > 90 ? "bg-destructive" : "bg-primary")} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

// ============================== Policies ==============================

function PoliciesTab() {
  const qc = useQueryClient();
  const { user } = useAppStore();
  const isHr = user && ["owner", "admin", "hr"].includes(user.role);
  const [viewPolicy, setViewPolicy] = useState<PolicyDto | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("HR Policy");
  const [content, setContent] = useState("");

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.policies,
    queryFn: () => api.get<{ items: PolicyDto[] }>("/api/policies"),
  });

  const createMutation = useMutation({
    mutationFn: () => api.post<{ item: PolicyDto }>("/api/policies", { title, category, content }),
    onSuccess: () => {
      toast.success("Policy published");
      setCreateOpen(false); setTitle(""); setContent("");
      qc.invalidateQueries({ queryKey: qk.policies });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not publish"),
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-medium">
          <ScrollText className="h-4 w-4 text-primary" /> Policy documents
        </CardTitle>
        {isHr && (
          <Button size="sm" variant="outline" onClick={() => setCreateOpen(true)}>
            <Plus className="mr-1.5 h-3.5 w-3.5" /> New policy
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {isLoading && <Skeleton className="h-32" />}
        {isError && (
          <LoadError
            title="Could not load policies"
            message={error instanceof Error ? error.message : undefined}
            onRetry={() => refetch()}
          />
        )}
        <div className="grid gap-3 md:grid-cols-2">
          {data?.items.map((p) => (
            <button
              key={p.id}
              onClick={() => setViewPolicy(p)}
              className="rounded-xl border p-4 text-left transition-colors hover:bg-accent/50"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">{p.title}</span>
                <Badge variant="secondary" className="text-[10px]">v{p.version}</Badge>
              </div>
              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{p.content.replace(/[#*]/g, "").slice(0, 120)}…</p>
              <div className="mt-2 flex items-center gap-2 text-[10px] text-muted-foreground">
                <Badge variant="outline" className="text-[9px]">{p.category}</Badge>
                <span>{p.audience}</span>
                <span>· updated {fmtDate(p.updatedAt.slice(0, 10))}</span>
              </div>
            </button>
          ))}
        </div>
        {data?.items.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">No policies published yet.</p>
        )}
      </CardContent>

      <Dialog open={!!viewPolicy} onOpenChange={(v) => !v && setViewPolicy(null)}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{viewPolicy?.title}</DialogTitle>
            <DialogDescription>
              {viewPolicy?.category} · v{viewPolicy?.version} · updated by {viewPolicy?.updatedBy}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[55vh]">
            <div className="whitespace-pre-wrap p-1 text-sm leading-relaxed text-muted-foreground">
              {viewPolicy?.content.replace(/^#+\s/gm, "").replace(/\*\*/g, "")}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Publish a policy</DialogTitle>
            <DialogDescription>Policies are visible to all employees and versioned automatically.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-1.5">
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Travel & Expense Policy" />
            </div>
            <div className="grid gap-1.5">
              <Label>Category</Label>
              <Input value={category} onChange={(e) => setCategory(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label>Content</Label>
              <Textarea className="min-h-40" value={content} onChange={(e) => setContent(e.target.value)} placeholder="## Overview&#10;Describe the policy…" />
            </div>
            <Button disabled={!title.trim() || !content.trim() || createMutation.isPending} onClick={() => createMutation.mutate()}>
              {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Publish policy
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

// ============================== Holidays ==============================

function HolidaysTab() {
  const qc = useQueryClient();
  const { user } = useAppStore();
  const isHr = user && ["owner", "admin", "hr"].includes(user.role);
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [type, setType] = useState<"public" | "optional">("public");

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.holidays,
    queryFn: () => api.get<{ items: HolidayDto[] }>("/api/holidays"),
  });

  const createMutation = useMutation({
    mutationFn: () => api.post<{ item: HolidayDto }>("/api/holidays", { name, date, type }),
    onSuccess: () => {
      toast.success("Holiday added");
      setName(""); setDate("");
      qc.invalidateQueries({ queryKey: qk.holidays });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not add holiday"),
  });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-medium">
          <CalendarDays className="h-4 w-4 text-primary" /> Holiday calendar
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isHr && (
          <div className="mb-4 flex flex-wrap items-end gap-3 rounded-xl border bg-muted/30 p-4">
            <div className="grid flex-1 gap-1.5 min-w-40">
              <Label className="text-xs">Holiday name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Diwali" />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-40" />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Type</Label>
              <div className="flex gap-2">
                <Button type="button" size="sm" variant={type === "public" ? "default" : "outline"} onClick={() => setType("public")}>Public</Button>
                <Button type="button" size="sm" variant={type === "optional" ? "default" : "outline"} onClick={() => setType("optional")}>Optional</Button>
              </div>
            </div>
            <Button size="sm" disabled={!name.trim() || !date || createMutation.isPending} onClick={() => createMutation.mutate()}>
              {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            </Button>
          </div>
        )}

        {isLoading && <Skeleton className="h-32" />}
        {isError && (
          <LoadError
            title="Could not load holidays"
            message={error instanceof Error ? error.message : undefined}
            onRetry={() => refetch()}
          />
        )}
        {data && data.items.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">No holidays configured yet.</p>
        )}
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {data?.items.map((h) => (
            <div key={h.id} className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">{h.name}</p>
                <p className="text-[11px] text-muted-foreground">{fmtDate(h.date)}</p>
              </div>
              <Badge variant={h.type === "public" ? "default" : "outline"} className="text-[10px] capitalize">{h.type}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================== Security ==============================

function SecurityTab() {
  const { user } = useAppStore();
  const isOwner = user?.role === "owner";
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const changeMutation = useMutation({
    mutationFn: () =>
      api.post<{ ok: boolean }>("/api/auth/change-password", { currentPassword, newPassword }),
    onSuccess: () => {
      toast.success("Password updated");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const submitPassword = () => {
    if (newPassword.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("New passwords do not match.");
      return;
    }
    if (newPassword === currentPassword) {
      setError("New password must be different from your current password.");
      return;
    }
    setError(null);
    changeMutation.mutate();
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <Lock className="h-4 w-4 text-primary" /> Change password
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="current-password">Current password</Label>
            <Input
              id="current-password"
              type="password"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="new-password">New password</Label>
            <Input
              id="new-password"
              type="password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
            <p className="text-[11px] text-muted-foreground">At least 8 characters.</p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="confirm-password">Confirm new password</Label>
            <Input
              id="confirm-password"
              type="password"
              autoComplete="new-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
          {error && (
            <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-2.5 text-xs text-destructive">
              {error}
            </p>
          )}
          <Button
            className="w-full"
            disabled={changeMutation.isPending || !currentPassword || !newPassword || !confirmPassword}
            onClick={submitPassword}
          >
            {changeMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Update password
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <DatabaseBackup className="h-4 w-4 text-primary" /> Data &amp; backup
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <p className="text-xs leading-relaxed text-muted-foreground">
            Your organisation's data lives in this PeoplePulse installation's database. Download a
            full snapshot anytime and store it somewhere safe.
          </p>
          <div className="grid gap-1.5">
            <Button
              className="w-full sm:w-auto"
              disabled={!isOwner}
              onClick={() => {
                window.location.href = "/api/org/backup";
              }}
            >
              <Download className="mr-1.5 h-4 w-4" /> Download backup
            </Button>
            {!isOwner && (
              <p className="text-[11px] text-muted-foreground">
                Only the organisation owner can download backups.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================== Audit log ==============================

function AuditTab() {
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.audit(),
    queryFn: () => api.get<{ items: AuditLogDto[]; total: number }>("/api/audit?pageSize=60"),
  });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-medium">
          <History className="h-4 w-4 text-primary" /> Audit trail{!isError && ` — ${data?.total ?? 0} events`}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading && <Skeleton className="h-64" />}
        {isError && (
          <LoadError
            title="Could not load the audit trail"
            message={error instanceof Error ? error.message : undefined}
            onRetry={() => refetch()}
          />
        )}
        {data && data.items.length === 0 && !isLoading && (
          <p className="py-8 text-center text-xs text-muted-foreground">
            No audit events recorded yet — actions will appear here as your team uses the workspace.
          </p>
        )}
        <ScrollArea className="max-h-[32rem]">
          <div className="space-y-1">
            {data?.items.map((a) => (
              <div key={a.id} className="flex items-start gap-3 rounded-lg border p-3">
                <span
                  className={cn(
                    "mt-1 h-2 w-2 shrink-0 rounded-full",
                    a.severity === "critical" ? "bg-destructive" : a.severity === "warning" ? "bg-amber-500" : "bg-primary"
                  )}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs">
                    <span className="font-medium">{a.actorName}</span>
                    <span className="text-muted-foreground"> ({a.actorRole}) · </span>
                    <span className="font-mono text-[11px] text-muted-foreground">{a.action}</span>
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{a.summary}</p>
                </div>
                <span className="shrink-0 text-[10px] text-muted-foreground">{fmtDateTime(a.createdAt)}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
        <p className="mt-3 text-[10px] text-muted-foreground">
          Sensitive actions — payroll, employee changes, permissions and settings — are logged immutably for compliance review.
        </p>
      </CardContent>
    </Card>
  );
}

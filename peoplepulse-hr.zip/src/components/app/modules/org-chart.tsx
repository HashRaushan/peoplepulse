"use client";

/**
 * PeoplePulse HR — Org Chart module.
 * Interactive, pure-CSS reporting tree with collapse/expand per branch,
 * expand-all / collapse-all controls and horizontal scrolling on small screens.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ChevronDown,
  ChevronsDownUp,
  ChevronsUpDown,
  Network,
  RotateCcw,
  Users,
} from "lucide-react";
import type { OrgChartNode } from "@/lib/types";
import { api, qk } from "@/lib/api-client";
import { cn, initials } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

function collectParentIds(node: OrgChartNode, acc: string[] = []): string[] {
  if (node.children.length > 0) {
    acc.push(node.id);
    node.children.forEach((c) => collectParentIds(c, acc));
  }
  return acc;
}

function countNodes(node: OrgChartNode): number {
  return 1 + node.children.reduce((sum, c) => sum + countNodes(c), 0);
}

function collectDepartments(node: OrgChartNode, set: Set<string>): void {
  set.add(node.department);
  node.children.forEach((c) => collectDepartments(c, set));
}

export function OrgChartModule() {
  const { user } = useAppStore();
  if (!user) return null;
  return <OrgChartInner />;
}

function OrgChartInner() {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const chartQuery = useQuery({
    queryKey: qk.orgChart,
    queryFn: () => api.get<{ root: OrgChartNode }>("/api/org-chart"),
  });

  useEffect(() => {
    if (chartQuery.error) toast.error(chartQuery.error.message);
  }, [chartQuery.error]);

  const root = chartQuery.data?.root ?? null;

  const stats = useMemo(() => {
    if (!root) return null;
    const departments = new Set<string>();
    collectDepartments(root, departments);
    return { people: countNodes(root), departments: departments.size };
  }, [root]);

  const parentIds = useMemo(() => (root ? collectParentIds(root) : []), [root]);

  const toggle = (id: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Org Chart</h1>
          <p className="text-sm text-muted-foreground">
            {stats
              ? `${stats.people} ${stats.people === 1 ? "person" : "people"} across ${stats.departments} ${stats.departments === 1 ? "department" : "departments"}`
              : "Reporting structure"}
            {" · Click a person to collapse their branch"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCollapsed(new Set())}
            disabled={collapsed.size === 0}
          >
            <ChevronsUpDown /> Expand all
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCollapsed(new Set(parentIds))}
            disabled={collapsed.size === parentIds.length}
          >
            <ChevronsDownUp /> Collapse all
          </Button>
          {collapsed.size > 0 && (
            <Button variant="ghost" size="sm" onClick={() => setCollapsed(new Set())}>
              <RotateCcw /> Reset
            </Button>
          )}
        </div>
      </div>

      {/* Tree */}
      {chartQuery.isLoading ? (
        <div className="flex flex-col items-center gap-6 py-10">
          <Skeleton className="h-24 w-56 rounded-xl" />
          <div className="flex gap-6">
            <Skeleton className="h-6 w-px" />
            <Skeleton className="h-6 w-px" />
            <Skeleton className="h-6 w-px" />
          </div>
          <div className="flex gap-6">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-56 rounded-xl" />
            ))}
          </div>
        </div>
      ) : chartQuery.isError ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <Network className="h-8 w-8 text-muted-foreground" />
          <div>
            <div className="font-semibold">Could not load the org chart</div>
            <p className="text-sm text-muted-foreground">{chartQuery.error.message}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => chartQuery.refetch()}>
            Try again
          </Button>
        </div>
      ) : !root ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Network className="h-6 w-6 text-primary" />
          </div>
          <div>
            <div className="font-semibold">No org chart yet</div>
            <p className="text-sm text-muted-foreground">
              Add employees with reporting managers to build the tree.
            </p>
          </div>
        </div>
      ) : (
        <div className="scrollbar-thin overflow-x-auto rounded-xl border bg-card p-6">
          <div className="flex min-w-max justify-center">
            <OrgNode node={root} collapsed={collapsed} onToggle={toggle} isRoot />
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border bg-card px-4 py-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <ChevronDown className="h-3.5 w-3.5" />
          Chevron count = direct reports
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-3 w-1 rounded-full bg-primary" />
          Left accent = person&apos;s avatar colour
        </span>
        <span className="flex items-center gap-1.5">
          <Users className="h-3.5 w-3.5" />
          Click a person to collapse their branch
        </span>
      </div>
    </div>
  );
}

/* ---------------- Recursive node ---------------- */

function OrgNode({
  node,
  collapsed,
  onToggle,
  isRoot = false,
}: {
  node: OrgChartNode;
  collapsed: Set<string>;
  onToggle: (id: string) => void;
  isRoot?: boolean;
}) {
  const isCollapsed = collapsed.has(node.id);
  const hasChildren = node.children.length > 0;

  return (
    <div className="flex flex-col items-center">
      <button
        type="button"
        onClick={() => hasChildren && onToggle(node.id)}
        className={cn(
          "relative w-52 rounded-xl border bg-card p-3 text-left shadow-sm transition-all",
          hasChildren ? "cursor-pointer hover:border-primary/40 hover:shadow-md" : "cursor-default",
          isRoot && "ring-2 ring-primary/20",
          isCollapsed && "opacity-80"
        )}
        style={{ borderLeft: `3px solid ${node.avatarColor}` }}
      >
        <div className="flex items-center gap-2.5">
          <div
            style={{ backgroundColor: `${node.avatarColor}22`, color: node.avatarColor }}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold"
          >
            {initials(node.name)}
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">{node.name}</div>
            <div className="truncate text-[11px] text-muted-foreground">{node.designation}</div>
          </div>
        </div>
        <div className="mt-2.5 flex items-center justify-between gap-2">
          <Badge variant="outline" className="max-w-[9rem] truncate text-[10px]">
            {node.department}
          </Badge>
          {hasChildren ? (
            <span className="flex shrink-0 items-center gap-1 text-[10px] text-muted-foreground">
              <Users className="h-3 w-3" />
              {node.children.length}
              <ChevronDown
                className={cn("h-3.5 w-3.5 transition-transform", isCollapsed && "-rotate-90")}
              />
            </span>
          ) : (
            <span className="shrink-0 font-mono text-[10px] text-muted-foreground">{node.code}</span>
          )}
        </div>
      </button>

      {hasChildren && !isCollapsed && (
        <>
          {/* Vertical connector from this card down to the children row */}
          <div className="h-6 w-px shrink-0 bg-border" />
          <div className="flex items-start">
            {node.children.map((child, i) => (
              <div
                key={child.id}
                className="relative flex flex-col items-center px-3 pt-6"
              >
                {/* Horizontal connector segments between siblings */}
                {i > 0 && <div className="absolute top-0 left-0 h-px w-1/2 bg-border" />}
                {i < node.children.length - 1 && (
                  <div className="absolute top-0 right-0 h-px w-1/2 bg-border" />
                )}
                {/* Vertical stub from the sibling rail down to the child card */}
                <div className="absolute top-0 left-1/2 h-6 w-px bg-border" />
                <OrgNode node={child} collapsed={collapsed} onToggle={onToggle} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

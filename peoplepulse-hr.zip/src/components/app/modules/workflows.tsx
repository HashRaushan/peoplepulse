"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { cn, fmtDateTime, ago } from "@/lib/hr-utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  Workflow as WorkflowIcon, PlayCircle, Zap, CheckCircle2, XCircle, Clock,
  ArrowRight, Activity, GitBranch,
} from "lucide-react";
import type { WorkflowDto, WorkflowExecutionDto } from "@/lib/types";

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

export function WorkflowsModule() {
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.workflows,
    queryFn: () => api.get<{ items: WorkflowDto[] }>("/api/workflows"),
  });

  const workflows = data?.items ?? [];
  const selected = selectedId ?? workflows[0]?.id ?? null;

  const executionsQuery = useQuery({
    queryKey: qk.workflowExecutions(selected ?? ""),
    queryFn: () => api.get<{ items: WorkflowExecutionDto[] }>(`/api/workflows/${selected}/executions`),
    enabled: !!selected,
  });

  const toggleMutation = useMutation({
    mutationFn: (vars: { id: string; active: boolean }) =>
      api.patch<{ item: WorkflowDto }>(`/api/workflows/${vars.id}`, { active: vars.active }),
    onSuccess: (res) => {
      toast.success(`Workflow ${res.item.active ? "activated" : "paused"}`);
      qc.invalidateQueries({ queryKey: qk.workflows });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not update workflow"),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Workflow automation</h1>
        <p className="text-sm text-muted-foreground">
          Event-driven rules that run automatically as things happen across your HR operations.
        </p>
      </div>

      {isLoading && (
        <div className="grid gap-4 lg:grid-cols-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}</div>
      )}

      {!isLoading && isError && (
        <LoadError
          message={error instanceof Error ? error.message : undefined}
          onRetry={() => refetch()}
        />
      )}

      {!isLoading && !isError && workflows.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 p-10 text-center">
            <WorkflowIcon className="h-8 w-8 text-muted-foreground/50" />
            <p className="text-sm font-medium">No workflows yet</p>
            <p className="max-w-md text-sm text-muted-foreground">
              Automation rules created during workspace setup will appear here.
            </p>
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && workflows.length > 0 && (
      <div className="grid gap-4 lg:grid-cols-2">
        {workflows.map((w) => (
          <Card
            key={w.id}
            className={cn(
              "cursor-pointer transition-all hover:shadow-md",
              w.id === selected && "ring-1 ring-primary/40",
              !w.active && "opacity-75"
            )}
            onClick={() => setSelectedId(w.id)}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                    w.active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                  )}>
                    <WorkflowIcon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold">{w.name}</h3>
                      <Badge variant={w.active ? "default" : "secondary"} className="text-[10px]">
                        {w.active ? "Active" : "Paused"}
                      </Badge>
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{w.description}</p>
                  </div>
                </div>
                <Switch
                  checked={w.active}
                  disabled={toggleMutation.isPending}
                  onClick={(e) => e.stopPropagation()}
                  onCheckedChange={(checked) => toggleMutation.mutate({ id: w.id, active: checked })}
                  aria-label={`Toggle ${w.name}`}
                />
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Zap className="h-3 w-3 text-primary" /> Trigger: {w.triggerLabel}
                </span>
                <span className="flex items-center gap-1">
                  <Activity className="h-3 w-3" /> {w.executionCount} runs
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" /> Last: {w.lastRunAt ? ago(w.lastRunAt) : "never"}
                </span>
                <Badge variant="outline" className="text-[10px]">{w.category}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      )}

      {/* Execution history */}
      {selected && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <GitBranch className="h-4 w-4 text-primary" />
              Execution history — {workflows.find((w) => w.id === selected)?.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {executionsQuery.isLoading && <Skeleton className="h-40" />}
            {executionsQuery.data && executionsQuery.data.items.length === 0 && (
              <p className="py-6 text-center text-xs text-muted-foreground">
                No executions recorded yet. This workflow will appear here when its trigger fires.
              </p>
            )}
            <ScrollArea className="max-h-96">
              <div className="space-y-3">
                {executionsQuery.data?.items.map((ex) => (
                  <div key={ex.id} className="rounded-xl border p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {ex.status === "success" ? (
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                        ) : ex.status === "failed" ? (
                          <XCircle className="h-4 w-4 text-destructive" />
                        ) : (
                          <PlayCircle className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="text-xs font-medium">{ex.summary}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                        <Badge variant="secondary" className="text-[9px]">{ex.trigger}</Badge>
                        {fmtDateTime(ex.startedAt)}
                      </div>
                    </div>
                    <div className="mt-3 space-y-1.5 border-l-2 border-border pl-4">
                      {ex.steps.map((s, i) => (
                        <div key={i} className="flex items-start gap-2 text-[11px]">
                          <span className={cn("mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full", s.ok ? "bg-primary" : "bg-destructive")} />
                          <span>
                            <span className="font-medium">{s.name}</span>
                            <span className="text-muted-foreground"> — {s.detail}</span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Info card */}
      <Card className="border-dashed">
        <CardContent className="flex items-start gap-3 p-5">
          <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <p className="text-xs leading-relaxed text-muted-foreground">
            Workflows listen to live events across the platform — new joiners, leave requests, payroll reviews
            and ticket SLAs — and execute their configured steps automatically. Every execution is logged with
            its trigger, steps and outcome for full auditability. Organisations can create fully custom rules
            (conditions, multi-level approvals, scheduled actions and webhooks) in the enterprise edition.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

"use client";

/**
 * PeoplePulse HR — Document Center module.
 * A company-shared library every signed-in role can browse. Owners, admins
 * and HR can publish new documents, revise existing ones (each save bumps
 * the version) and retire them — all with audit + toast feedback.
 */

import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  FileText,
  Loader2,
  MoreVertical,
  Pencil,
  Plus,
  Search,
  SearchX,
  Trash2,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { DOCUMENT_CATEGORIES } from "@/lib/constants";
import { ago, cn } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { DocumentDto } from "@/lib/types";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local helpers =====================

type DocumentsResponse = { documents: DocumentDto[] };

/** Muted category badge tones (emerald brand, no indigo/blue). */
const CATEGORY_STYLES: Record<string, string> = {
  "HR Policy":
    "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300",
  Legal:
    "border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950 dark:text-rose-300",
  "IT & Security":
    "border-slate-300 bg-slate-100 text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300",
  Finance:
    "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300",
  SOP: "border-teal-200 bg-teal-50 text-teal-700 dark:border-teal-900 dark:bg-teal-950 dark:text-teal-300",
  Forms:
    "border-orange-200 bg-orange-50 text-orange-700 dark:border-orange-900 dark:bg-orange-950 dark:text-orange-300",
  Other:
    "border-stone-300 bg-stone-100 text-stone-700 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-300",
};

function categoryClass(category: string): string {
  return CATEGORY_STYLES[category] ?? CATEGORY_STYLES.Other;
}

/** Split a comma-separated tag input into clean unique tags. */
function parseTagInput(value: string): string[] {
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const part of value.split(",")) {
    const tag = part.trim();
    if (!tag || seen.has(tag)) continue;
    seen.add(tag);
    tags.push(tag);
  }
  return tags;
}

// ===================== Module =====================

export function DocumentsModule() {
  const { user } = useAppStore();
  const isMgr = !!user && ["owner", "admin", "hr"].includes(user.role);

  const qc = useQueryClient();

  // ---- filters ----
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  // Debounce the search box so typing does not hammer the API.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  const filters = useMemo(() => ({ category, q: search }), [category, search]);
  const queryString = useMemo(() => {
    const params = new URLSearchParams();
    if (filters.category) params.set("category", filters.category);
    if (filters.q) params.set("q", filters.q);
    const qs = params.toString();
    return qs ? `?${qs}` : "";
  }, [filters]);

  const documentsQuery = useQuery({
    queryKey: qk.documents(filters),
    queryFn: () => api.get<DocumentsResponse>(`/api/documents${queryString}`),
  });

  const documents = documentsQuery.data?.documents ?? [];
  const hasFilters = filters.category !== "" || filters.q !== "";

  // ---- view dialog ----
  const [viewing, setViewing] = useState<DocumentDto | null>(null);

  // ---- add / edit dialog ----
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<DocumentDto | null>(null);
  const [formTitle, setFormTitle] = useState("");
  const [formCategory, setFormCategory] = useState(DOCUMENT_CATEGORIES[0]);
  const [formAudience, setFormAudience] = useState("All Employees");
  const [formTags, setFormTags] = useState("");
  const [formContent, setFormContent] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  function openAdd() {
    setEditing(null);
    setFormTitle("");
    setFormCategory(DOCUMENT_CATEGORIES[0]);
    setFormAudience("All Employees");
    setFormTags("");
    setFormContent("");
    setFormError(null);
    setEditorOpen(true);
  }

  function openEdit(doc: DocumentDto) {
    setEditing(doc);
    setFormTitle(doc.title);
    setFormCategory(doc.category);
    setFormAudience(doc.audience);
    setFormTags(doc.tags.join(", "));
    setFormContent(doc.content);
    setFormError(null);
    setEditorOpen(true);
  }

  const saveMutation = useMutation({
    mutationFn: (values: {
      title: string;
      category: string;
      content: string;
      audience: string;
      tags: string[];
    }) =>
      editing
        ? api.patch<{ document: DocumentDto }>(`/api/documents/${editing.id}`, values)
        : api.post<{ document: DocumentDto }>("/api/documents", values),
    onSuccess: (_data, _values) => {
      qc.invalidateQueries({ queryKey: ["documents"] });
      toast.success(editing ? "Document updated" : "Document published");
      setEditorOpen(false);
      setEditing(null);
    },
    onError: (error: Error) => setFormError(error.message),
  });

  function handleSave() {
    setFormError(null);
    const title = formTitle.trim();
    const content = formContent.trim();
    if (!title) {
      setFormError("Please enter a document title.");
      return;
    }
    if (!content) {
      setFormError("Please enter the document content.");
      return;
    }
    saveMutation.mutate({
      title,
      category: formCategory,
      content,
      audience: formAudience.trim() || "All Employees",
      tags: parseTagInput(formTags),
    });
  }

  // ---- delete confirm ----
  const [deleting, setDeleting] = useState<DocumentDto | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/api/documents/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["documents"] });
      toast.success("Document deleted");
      setDeleting(null);
      setDeleteError(null);
    },
    onError: (error: Error) => setDeleteError(error.message),
  });

  const count = documents.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Documents</h1>
          <p className="text-sm text-muted-foreground">
            Company document library · {documentsQuery.isPending ? "…" : `${count} document${count === 1 ? "" : "s"}`}
          </p>
        </div>
        {isMgr ? (
          <Button onClick={openAdd}>
            <Plus className="h-4 w-4" /> Add document
          </Button>
        ) : null}
      </div>

      {/* Search + category chips */}
      <div className="space-y-3">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search documents by title or content…"
            className="pl-9"
            aria-label="Search documents"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by category">
          <button
            type="button"
            onClick={() => setCategory("")}
            className={cn(
              "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
              category === ""
                ? "border-primary bg-primary text-primary-foreground"
                : "bg-background text-muted-foreground hover:bg-muted hover:text-foreground"
            )}
          >
            All
          </button>
          {DOCUMENT_CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                category === c
                  ? "border-primary bg-primary text-primary-foreground"
                  : "bg-background text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Library */}
      {documentsQuery.isPending ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-52 rounded-xl" />
          ))}
        </div>
      ) : documentsQuery.isError ? (
        <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
          <p className="text-sm font-medium">Something went wrong</p>
          <p className="max-w-md text-sm text-muted-foreground">
            {documentsQuery.error instanceof Error
              ? documentsQuery.error.message
              : "We could not load the document library. Please try again."}
          </p>
          <Button variant="outline" size="sm" onClick={() => documentsQuery.refetch()}>
            Retry
          </Button>
        </div>
      ) : documents.length === 0 ? (
        <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
          {hasFilters ? (
            <>
              <SearchX className="h-8 w-8 text-muted-foreground/50" />
              <p className="text-sm font-medium">No results for your filters</p>
              <p className="max-w-md text-sm text-muted-foreground">
                Try a different search term or pick another category.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-1"
                onClick={() => {
                  setSearchInput("");
                  setCategory("");
                }}
              >
                Clear filters
              </Button>
            </>
          ) : (
            <>
              <FileText className="h-8 w-8 text-muted-foreground/50" />
              <p className="text-sm font-medium">No documents yet</p>
              <p className="max-w-md text-sm text-muted-foreground">
                {isMgr
                  ? "Publish the first document so your team has one place to find it."
                  : "Documents published by HR will appear here."}
              </p>
              {isMgr ? (
                <Button size="sm" className="mt-1" onClick={openAdd}>
                  <Plus className="h-4 w-4" /> Add document
                </Button>
              ) : null}
            </>
          )}
        </div>
      ) : (
        <div className="scrollbar-thin max-h-[640px] overflow-y-auto pr-1">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {documents.map((doc) => (
              <Card
                key={doc.id}
                role="button"
                tabIndex={0}
                onClick={() => setViewing(doc)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setViewing(doc);
                  }
                }}
                className="cursor-pointer gap-3 py-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <CardHeader className="px-4">
                  <div className="flex items-start justify-between gap-2">
                    <Badge variant="outline" className={cn("font-medium", categoryClass(doc.category))}>
                      {doc.category}
                    </Badge>
                    {isMgr ? (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 shrink-0"
                            aria-label={`Actions for ${doc.title}`}
                            onClick={(e) => e.stopPropagation()}
                            onKeyDown={(e) => e.stopPropagation()}
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenuItem onClick={() => openEdit(doc)}>
                            <Pencil className="h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => {
                              setDeleteError(null);
                              setDeleting(doc);
                            }}
                          >
                            <Trash2 className="h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    ) : null}
                  </div>
                  <CardTitle className="text-base leading-snug">{doc.title}</CardTitle>
                  <CardDescription className="sr-only">
                    Category {doc.category}, version {doc.version}
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-4">
                  <p className="line-clamp-2 min-h-10 text-sm text-muted-foreground">{doc.excerpt}</p>
                </CardContent>
                <CardFooter className="flex-col items-start gap-2 px-4">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
                    <span className="font-medium text-foreground/70">v{doc.version}</span>
                    <span aria-hidden>·</span>
                    <span>{doc.audience}</span>
                    <span aria-hidden>·</span>
                    <span>
                      {doc.updatedBy} · {ago(doc.updatedAt)}
                    </span>
                  </div>
                  {doc.tags.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {doc.tags.slice(0, 3).map((tag) => (
                        <Badge
                          key={tag}
                          variant="outline"
                          className="px-1.5 py-0 text-[10px] font-normal text-muted-foreground"
                        >
                          {tag}
                        </Badge>
                      ))}
                      {doc.tags.length > 3 ? (
                        <Badge variant="outline" className="px-1.5 py-0 text-[10px] font-normal text-muted-foreground">
                          +{doc.tags.length - 3}
                        </Badge>
                      ) : null}
                    </div>
                  ) : null}
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* View dialog */}
      <Dialog open={!!viewing} onOpenChange={(open) => !open && setViewing(null)}>
        {viewing ? (
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className={cn("font-medium", categoryClass(viewing.category))}>
                  {viewing.category}
                </Badge>
                <Badge variant="secondary" className="tabular-nums">
                  v{viewing.version}
                </Badge>
              </div>
              <DialogTitle className="text-left">{viewing.title}</DialogTitle>
              <DialogDescription className="text-left">
                {viewing.audience} · Updated by {viewing.updatedBy} · {ago(viewing.updatedAt)}
              </DialogDescription>
            </DialogHeader>
            <div className="scrollbar-thin max-h-[60vh] overflow-y-auto rounded-lg border bg-muted/30 p-4">
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{viewing.content}</p>
            </div>
            {isMgr ? (
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    const doc = viewing;
                    setViewing(null);
                    openEdit(doc);
                  }}
                >
                  <Pencil className="h-4 w-4" /> Edit document
                </Button>
              </DialogFooter>
            ) : null}
          </DialogContent>
        ) : null}
      </Dialog>

      {/* Add / edit dialog */}
      <Dialog
        open={editorOpen}
        onOpenChange={(open) => {
          if (!open) {
            setEditorOpen(false);
            setEditing(null);
          }
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit document" : "Add document"}</DialogTitle>
            <DialogDescription>
              {editing
                ? `Saving updates "${editing.title}" and publishes version v${editing.version + 1}.`
                : "Publish a new document to the company library."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="doc-title">Title</Label>
                <Input
                  id="doc-title"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Remote Work Policy"
                  maxLength={120}
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={formCategory} onValueChange={setFormCategory}>
                  <SelectTrigger className="w-full" aria-label="Category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DOCUMENT_CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="doc-audience">Audience</Label>
                <Input
                  id="doc-audience"
                  value={formAudience}
                  onChange={(e) => setFormAudience(e.target.value)}
                  placeholder="All Employees"
                  maxLength={80}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="doc-tags">Tags</Label>
                <Input
                  id="doc-tags"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="remote, policy, wfh"
                />
                <p className="text-xs text-muted-foreground">Comma-separated keywords.</p>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="doc-content">Content</Label>
              <Textarea
                id="doc-content"
                className="min-h-64"
                value={formContent}
                onChange={(e) => setFormContent(e.target.value)}
                placeholder="Write the document content…"
              />
              <p className="text-xs text-muted-foreground">
                Plain text or markdown — shown as written.
              </p>
            </div>
            {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditorOpen(false)} disabled={saveMutation.isPending}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Saving…
                </>
              ) : editing ? (
                "Save changes"
              ) : (
                "Publish document"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog
        open={!!deleting}
        onOpenChange={(open) => {
          if (!open) {
            setDeleting(null);
            setDeleteError(null);
          }
        }}
      >
        {deleting ? (
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete &ldquo;{deleting.title}&rdquo;?</AlertDialogTitle>
              <AlertDialogDescription>
                This permanently removes the document. Employees will immediately lose access to it.
              </AlertDialogDescription>
            </AlertDialogHeader>
            {deleteError ? <p className="text-sm text-destructive">{deleteError}</p> : null}
            <AlertDialogFooter>
              <AlertDialogCancel disabled={deleteMutation.isPending}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                disabled={deleteMutation.isPending}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={(e) => {
                  e.preventDefault(); // keep the dialog open while deleting
                  deleteMutation.mutate(deleting.id);
                }}
              >
                {deleteMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Deleting…
                  </>
                ) : (
                  "Delete document"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        ) : null}
      </AlertDialog>
    </div>
  );
}

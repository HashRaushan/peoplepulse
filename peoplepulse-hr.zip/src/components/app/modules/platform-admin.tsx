"use client";

/**
 * PeoplePulse HR — Platform Admin module (super admin console).
 * Approve tenant signups, verify manual payment references (UTRs),
 * suspend/extend workspaces and manage the platform's payment channels.
 */

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  BadgeCheck,
  Ban,
  Building2,
  CalendarPlus,
  Check,
  CheckCircle2,
  Clock3,
  FileX2,
  IndianRupee,
  Inbox,
  Landmark,
  Loader2,
  MoreHorizontal,
  Pencil,
  Plus,
  ReceiptText,
  Rocket,
  Search,
  Smartphone,
  Trash2,
  X,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { STATUS_LABELS } from "@/lib/constants";
import { cn, fmtDate, fmtDateTime, inr } from "@/lib/hr-utils";
import type {
  AdminStatsDto,
  AdminTenantDto,
  PaymentMethodDto,
  PaymentProofDto,
} from "@/lib/types";
import { ProofStatusBadge } from "@/components/app/pending-screen";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local types =====================

interface AdminTenantsResponse {
  items: AdminTenantDto[];
  stats: AdminStatsDto;
}

interface PaymentMethodsResponse {
  items: PaymentMethodDto[];
}

type TenantActionName =
  | "approve"
  | "reject"
  | "suspend"
  | "verify"
  | "reject-proof"
  | "extend";

interface TenantActionInput {
  tenantId: string;
  tenantName: string;
  action: TenantActionName;
  reason?: string;
  proofId?: string;
  utr?: string;
  months?: number;
}

type TenantDialog =
  | { kind: "reject"; tenant: AdminTenantDto }
  | { kind: "reject-proof"; tenant: AdminTenantDto }
  | { kind: "suspend"; tenant: AdminTenantDto }
  | { kind: "verify"; tenant: AdminTenantDto }
  | { kind: "extend"; tenant: AdminTenantDto };

type TenantFilter = "all" | "pending" | "active" | "trials" | "blocked";

// ===================== Helpers =====================

const TENANT_FILTERS: { value: TenantFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "active", label: "Active" },
  { value: "trials", label: "Trials" },
  { value: "blocked", label: "Blocked" },
];

/** A non-pending workspace with a submitted reference the admin can verify. */
function canVerifyProof(t: AdminTenantDto): boolean {
  return t.latestProof?.status === "submitted" && t.planStatus !== "pending";
}

function canSuspend(t: AdminTenantDto): boolean {
  return t.planStatus !== "pending" && t.planStatus !== "rejected";
}

function canExtend(t: AdminTenantDto): boolean {
  return t.planStatus === "active" || t.planStatus === "past_due";
}

function planStatusBadge(status: string): ReactNode {
  const label = STATUS_LABELS[status] ?? status;
  switch (status) {
    case "active":
      return <Badge variant="default">{label}</Badge>;
    case "trialing":
      return (
        <Badge
          variant="outline"
          className="border-emerald-600/40 bg-emerald-600/10 text-emerald-700 dark:text-emerald-400"
        >
          {label}
        </Badge>
      );
    case "pending":
      return (
        <Badge
          variant="outline"
          className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400"
        >
          {label}
        </Badge>
      );
    case "rejected":
      return <Badge variant="destructive">{label}</Badge>;
    default:
      return (
        <Badge variant="secondary" className="text-muted-foreground">
          {label}
        </Badge>
      );
  }
}

/** What the admin needs to do for an inbox row, or null when nothing is pending. */
function inboxItem(
  t: AdminTenantDto
): { text: string; action: "approve" | "verify" } | null {
  if (t.planStatus === "pending") {
    return t.price
      ? { text: `Approve paid signup — ${inr(t.price.total)}`, action: "approve" }
      : { text: "Approve trial", action: "approve" };
  }
  if (canVerifyProof(t) && t.latestProof) {
    return {
      text: `Verify UTR ${t.latestProof.utr} — ${inr(t.latestProof.amount)}`,
      action: "verify",
    };
  }
  return null;
}

/** One tenant action POST — shared by the inbox quick buttons and the tenant dialogs. */
function useTenantAction() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (v: TenantActionInput) => {
      const body: Record<string, unknown> = { action: v.action };
      if (v.reason !== undefined) body.reason = v.reason;
      if (v.proofId !== undefined) body.proofId = v.proofId;
      if (v.months !== undefined) body.months = v.months;
      return api.post<{ ok: true; paidUntil?: string }>(
        `/api/admin/tenants/${v.tenantId}`,
        body
      );
    },
    onSuccess: (data, v) => {
      qc.invalidateQueries({ queryKey: qk.adminTenants });
      switch (v.action) {
        case "approve":
          toast.success(`${v.tenantName} approved — the buyer has been notified by email.`);
          break;
        case "reject":
          toast.success(`Signup for ${v.tenantName} rejected.`);
          break;
        case "suspend":
          toast.success(`${v.tenantName} suspended.`);
          break;
        case "verify":
          toast.success(
            `UTR ${v.utr ?? ""} verified — ${v.tenantName} is paid until ${fmtDate(data.paidUntil ?? null)}.`
          );
          break;
        case "reject-proof":
          toast.success(
            `UTR ${v.utr ?? ""} rejected — the buyer can submit a new reference.`
          );
          break;
        case "extend":
          toast.success(
            `${v.tenantName} extended to ${fmtDate(data.paidUntil ?? null)}.`
          );
          break;
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

// ===================== Shared bits =====================

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function StatTile({
  label,
  value,
  icon,
  highlight,
}: {
  label: string;
  value: string;
  icon: ReactNode;
  highlight?: boolean;
}) {
  return (
    <Card className={cn("py-4", highlight && "border-amber-500/50 bg-amber-500/5")}>
      <CardContent className="flex items-start justify-between gap-2 px-4">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          <p className="mt-1 truncate text-2xl font-bold tabular-nums">{value}</p>
        </div>
        <div
          className={cn(
            "shrink-0 rounded-lg p-2",
            highlight
              ? "bg-amber-500/15 text-amber-700 dark:text-amber-400"
              : "bg-emerald-600/10 text-emerald-700 dark:text-emerald-400"
          )}
        >
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

function ProofSummary({ proof }: { proof: PaymentProofDto }) {
  return (
    <div className="grid gap-2 rounded-lg border bg-muted/40 p-3 text-sm">
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Reference (UTR)</span>
        <span className="font-mono font-medium">{proof.utr}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Amount</span>
        <span className="font-semibold">{inr(proof.amount)}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Payer</span>
        <span className="min-w-0 truncate">{proof.payerName}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Paid on</span>
        <span>{fmtDate(proof.paidAt)}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Method</span>
        <span>{STATUS_LABELS[proof.method] ?? proof.method}</span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Plan</span>
        <span className="capitalize">
          {proof.plan} · {STATUS_LABELS[proof.cycle] ?? proof.cycle} · {proof.seats} seats
        </span>
      </div>
      <div className="flex items-center justify-between gap-4">
        <span className="text-muted-foreground">Submitted</span>
        <span>{fmtDateTime(proof.createdAt)}</span>
      </div>
      {proof.note ? (
        <div className="flex items-start justify-between gap-4">
          <span className="shrink-0 text-muted-foreground">Note</span>
          <span className="min-w-0 text-right">{proof.note}</span>
        </div>
      ) : null}
    </div>
  );
}

function Detail({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="shrink-0 text-xs text-muted-foreground">{label}</dt>
      <dd className="min-w-0 truncate text-right text-sm font-medium">{value}</dd>
    </div>
  );
}

// ===================== Overview tab =====================

function OverviewTab({
  items,
  stats,
  act,
  openDialog,
}: {
  items: AdminTenantDto[];
  stats: AdminStatsDto;
  act: ReturnType<typeof useTenantAction>;
  openDialog: (d: TenantDialog) => void;
}) {
  const busyFor = (tenantId: string, action: TenantActionName): boolean =>
    act.isPending &&
    act.variables?.tenantId === tenantId &&
    act.variables?.action === action;

  const inbox = useMemo(() => {
    const rows: { tenant: AdminTenantDto; need: { text: string; action: "approve" | "verify" } }[] = [];
    for (const t of items) {
      const need = inboxItem(t);
      if (need) rows.push({ tenant: t, need });
    }
    // Pending signups first, everything else newest-first (server order).
    rows.sort(
      (a, b) =>
        Number(b.tenant.planStatus === "pending") - Number(a.tenant.planStatus === "pending")
    );
    return rows;
  }, [items]);

  const tiles: { label: string; value: string; icon: ReactNode; highlight?: boolean }[] = [
    { label: "Total workspaces", value: String(stats.total), icon: <Building2 className="h-4 w-4" /> },
    {
      label: "Pending approvals",
      value: String(stats.pending),
      icon: <Clock3 className="h-4 w-4" />,
      highlight: stats.pending > 0,
    },
    { label: "Active subscriptions", value: String(stats.active), icon: <BadgeCheck className="h-4 w-4" /> },
    { label: "Trials running", value: String(stats.trialing), icon: <Rocket className="h-4 w-4" /> },
    {
      label: "Awaiting UTR verification",
      value: String(stats.pendingProofs),
      icon: <ReceiptText className="h-4 w-4" />,
      highlight: stats.pendingProofs > 0,
    },
    { label: "Approx. MRR", value: inr(stats.mrr), icon: <IndianRupee className="h-4 w-4" /> },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {tiles.map((tile) => (
          <StatTile key={tile.label} {...tile} />
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Inbox className="h-4 w-4 text-primary" />
            Inbox — needs your action
          </CardTitle>
          <CardDescription>
            New signups awaiting approval and payment references awaiting verification.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          {inbox.length === 0 ? (
            <div className="flex flex-col items-center gap-1.5 rounded-lg border border-dashed px-6 py-10 text-center">
              <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              <p className="text-sm font-medium">
                All caught up — nothing needs your review.
              </p>
            </div>
          ) : (
            inbox.map((row) => (
              <div
                key={`${row.tenant.id}-${row.need.action}`}
                className="flex flex-col gap-3 rounded-lg border bg-card p-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{row.tenant.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {row.tenant.ownerEmail}
                  </p>
                  <p className="mt-1 text-sm font-medium text-amber-700 dark:text-amber-400">
                    {row.need.text}
                  </p>
                </div>
                <div className="shrink-0">
                  {row.need.action === "approve" ? (
                    <Button
                      size="sm"
                      disabled={act.isPending}
                      onClick={() =>
                        act.mutate({
                          tenantId: row.tenant.id,
                          tenantName: row.tenant.name,
                          action: "approve",
                        })
                      }
                    >
                      {busyFor(row.tenant.id, "approve") ? (
                        <Loader2 className="animate-spin" />
                      ) : (
                        <Check />
                      )}
                      Approve
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      disabled={act.isPending}
                      onClick={() => openDialog({ kind: "verify", tenant: row.tenant })}
                    >
                      <BadgeCheck />
                      Verify UTR
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ===================== Tenants tab =====================

function TenantsTab({
  items,
  act,
  openDialog,
}: {
  items: AdminTenantDto[];
  act: ReturnType<typeof useTenantAction>;
  openDialog: (d: TenantDialog) => void;
}) {
  const [filter, setFilter] = useState<TenantFilter>("all");
  const [search, setSearch] = useState("");

  const busyFor = (tenantId: string, action: TenantActionName): boolean =>
    act.isPending &&
    act.variables?.tenantId === tenantId &&
    act.variables?.action === action;

  const counts = useMemo(() => {
    const c: Record<TenantFilter, number> = {
      all: items.length,
      pending: 0,
      active: 0,
      trials: 0,
      blocked: 0,
    };
    for (const t of items) {
      if (t.planStatus === "pending") c.pending += 1;
      if (t.planStatus === "active") c.active += 1;
      if (t.planStatus === "trialing") c.trials += 1;
      if (t.blocked) c.blocked += 1;
    }
    return c;
  }, [items]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((t) => {
      if (filter === "pending" && t.planStatus !== "pending") return false;
      if (filter === "active" && t.planStatus !== "active") return false;
      if (filter === "trials" && t.planStatus !== "trialing") return false;
      if (filter === "blocked" && !t.blocked) return false;
      if (q) {
        const haystack =
          `${t.name} ${t.slug} ${t.ownerName} ${t.ownerEmail} ${t.plan}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [items, filter, search]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {TENANT_FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setFilter(f.value)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                filter === f.value
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {f.label}
              <span className="ml-1.5 tabular-nums opacity-70">{counts[f.value]}</span>
            </button>
          ))}
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, owner, email or plan"
            className="pl-8"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
          <Search className="h-5 w-5 text-muted-foreground" />
          <p className="text-sm font-medium">No workspaces match</p>
          <p className="text-sm text-muted-foreground">
            Try a different filter or search term.
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border bg-card">
          <Table className="min-w-[920px]">
            <TableHeader>
              <TableRow>
                <TableHead>Workspace</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Valid until</TableHead>
                <TableHead>Latest UTR</TableHead>
                <TableHead>Price</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((t) => {
                const isPendingTenant = t.planStatus === "pending";
                const hasSubmittedProof = t.latestProof?.status === "submitted";
                const showVerifyInline = hasSubmittedProof && !isPendingTenant;
                const showSuspend = canSuspend(t);
                const showExtend = canExtend(t);
                const showMenu = hasSubmittedProof || showSuspend || showExtend;
                return (
                  <TableRow key={t.id}>
                    <TableCell>
                      <div className="font-medium">{t.name}</div>
                      <div className="text-xs text-muted-foreground">/{t.slug}</div>
                      <div className="text-xs text-muted-foreground">{t.ownerEmail}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col items-start gap-1">
                        <Badge variant="secondary" className="capitalize">
                          {t.plan}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {STATUS_LABELS[t.cycle] ?? t.cycle} · {t.seats} seats ·{" "}
                          {t.employeeCount} employees
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col items-start gap-1">
                        {planStatusBadge(t.planStatus)}
                        {t.blocked && t.blocked !== t.planStatus ? (
                          <Badge
                            variant="outline"
                            className="border-amber-500/40 bg-amber-500/10 text-[10px] text-amber-700 dark:text-amber-400"
                            title={t.statusReason ?? undefined}
                          >
                            {STATUS_LABELS[t.blocked] ?? t.blocked}
                          </Badge>
                        ) : null}
                      </div>
                      {t.statusReason ? (
                        <p
                          className="max-w-[220px] truncate text-xs text-muted-foreground"
                          title={t.statusReason}
                        >
                          {t.statusReason}
                        </p>
                      ) : null}
                    </TableCell>
                    <TableCell className="text-sm">
                      {fmtDate(t.paidUntil ?? t.trialEndsAt)}
                    </TableCell>
                    <TableCell>
                      {t.latestProof ? (
                        <div className="flex flex-col items-start gap-1">
                          <span className="font-mono text-xs">{t.latestProof.utr}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-muted-foreground">
                              {inr(t.latestProof.amount)}
                            </span>
                            <ProofStatusBadge status={t.latestProof.status} />
                          </div>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm">
                      {t.price ? inr(t.price.total) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {isPendingTenant ? (
                          <>
                            <Button
                              size="sm"
                              disabled={act.isPending}
                              onClick={() =>
                                act.mutate({
                                  tenantId: t.id,
                                  tenantName: t.name,
                                  action: "approve",
                                })
                              }
                            >
                              {busyFor(t.id, "approve") ? (
                                <Loader2 className="animate-spin" />
                              ) : (
                                <Check />
                              )}
                              Approve
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-destructive hover:text-destructive"
                              onClick={() => openDialog({ kind: "reject", tenant: t })}
                            >
                              <X />
                              Reject
                            </Button>
                          </>
                        ) : null}
                        {showVerifyInline ? (
                          <Button
                            size="sm"
                            disabled={act.isPending}
                            onClick={() => openDialog({ kind: "verify", tenant: t })}
                          >
                            <BadgeCheck />
                            Verify UTR
                          </Button>
                        ) : null}
                        {showMenu ? (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal />
                                <span className="sr-only">Row actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {hasSubmittedProof ? (
                                <DropdownMenuItem
                                  variant="destructive"
                                  onClick={() => openDialog({ kind: "reject-proof", tenant: t })}
                                >
                                  <FileX2 />
                                  Reject UTR…
                                </DropdownMenuItem>
                              ) : null}
                              {showExtend ? (
                                <DropdownMenuItem
                                  onClick={() => openDialog({ kind: "extend", tenant: t })}
                                >
                                  <CalendarPlus />
                                  Extend subscription…
                                </DropdownMenuItem>
                              ) : null}
                              {showSuspend ? (
                                <DropdownMenuItem
                                  variant="destructive"
                                  onClick={() => openDialog({ kind: "suspend", tenant: t })}
                                >
                                  <Ban />
                                  Suspend workspace…
                                </DropdownMenuItem>
                              ) : null}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        ) : null}
                        {!isPendingTenant && !showVerifyInline && !showMenu ? (
                          <span className="text-muted-foreground">—</span>
                        ) : null}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

// ===================== Tenant action dialogs =====================

function TenantDialogs({
  dialog,
  onClose,
  act,
}: {
  dialog: TenantDialog | null;
  onClose: () => void;
  act: ReturnType<typeof useTenantAction>;
}) {
  const [reason, setReason] = useState("");
  const [months, setMonths] = useState("1");
  const [error, setError] = useState<string | null>(null);
  // (Form state resets via the remount key on <TenantDialogs> when a dialog opens.)

  const busy = act.isPending;
  const tenant = dialog?.tenant ?? null;
  const proof = tenant?.latestProof ?? null;
  const verifyMonths = proof?.cycle === "annual" ? 12 : 1;

  function submit(kind: NonNullable<TenantDialog>["kind"]) {
    if (!tenant) return;
    setError(null);
    const trimmedReason = reason.trim();
    if ((kind === "reject" || kind === "reject-proof") && !trimmedReason) {
      setError("Please add a short reason — it is included in the email to the buyer.");
      return;
    }
    if (kind === "extend") {
      const m = Number(months);
      if (!Number.isInteger(m) || m < 1 || m > 36) {
        setError("Enter a whole number of months between 1 and 36.");
        return;
      }
      act.mutate(
        { tenantId: tenant.id, tenantName: tenant.name, action: "extend", months: m },
        { onSuccess: onClose }
      );
      return;
    }
    if (kind === "verify") {
      if (!proof) return;
      act.mutate(
        {
          tenantId: tenant.id,
          tenantName: tenant.name,
          action: "verify",
          proofId: proof.id,
          utr: proof.utr,
        },
        { onSuccess: onClose }
      );
      return;
    }
    if (kind === "reject-proof") {
      if (!proof) return;
      act.mutate(
        {
          tenantId: tenant.id,
          tenantName: tenant.name,
          action: "reject-proof",
          proofId: proof.id,
          utr: proof.utr,
          reason: trimmedReason,
        },
        { onSuccess: onClose }
      );
      return;
    }
    // reject / suspend
    act.mutate(
      {
        tenantId: tenant.id,
        tenantName: tenant.name,
        action: kind,
        ...(trimmedReason ? { reason: trimmedReason } : {}),
      },
      { onSuccess: onClose }
    );
  }

  const reasonField = (required: boolean) => (
    <div className="grid gap-1.5">
      <Label htmlFor="tenant-dialog-reason">
        Reason {required ? "(required)" : "(optional)"}
      </Label>
      <Textarea
        id="tenant-dialog-reason"
        rows={3}
        value={reason}
        onChange={(e) => {
          setReason(e.target.value);
          if (error) setError(null);
        }}
        placeholder="e.g. We could not match this reference against our bank statement."
      />
    </div>
  );

  return (
    <>
      {/* Reject signup */}
      <Dialog
        open={dialog?.kind === "reject"}
        onOpenChange={(o) => {
          if (!o) onClose();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reject signup</DialogTitle>
            <DialogDescription>
              Decline {tenant?.name ?? "this workspace"} ({tenant?.ownerEmail ?? "—"}). The
              reason below is emailed to the buyer.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            {reasonField(true)}
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button variant="outline" disabled={busy} onClick={onClose}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                disabled={busy}
                onClick={() => submit("reject")}
              >
                {busy ? <Loader2 className="animate-spin" /> : null}
                Reject signup
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Verify UTR */}
      <Dialog
        open={dialog?.kind === "verify"}
        onOpenChange={(o) => {
          if (!o) onClose();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Verify payment reference</DialogTitle>
            <DialogDescription>
              Confirm this reference appears in your{" "}
              {proof ? (STATUS_LABELS[proof.method] ?? proof.method).toLowerCase() : "bank"}{" "}
              statement. Verifying issues a paid invoice and extends{" "}
              {tenant?.name ?? "the workspace"} by {verifyMonths} month
              {verifyMonths === 1 ? "" : "s"}.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            {proof ? <ProofSummary proof={proof} /> : null}
            <DialogFooter>
              <Button variant="outline" disabled={busy} onClick={onClose}>
                Cancel
              </Button>
              <Button disabled={busy} onClick={() => submit("verify")}>
                {busy ? <Loader2 className="animate-spin" /> : <BadgeCheck />}
                Verify payment
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reject UTR */}
      <Dialog
        open={dialog?.kind === "reject-proof"}
        onOpenChange={(o) => {
          if (!o) onClose();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reject payment reference</DialogTitle>
            <DialogDescription>
              Mark reference {proof?.utr ?? ""} from {tenant?.name ?? "this workspace"} as
              unverifiable. The buyer will be asked to check their statement and resubmit.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            {proof ? <ProofSummary proof={proof} /> : null}
            {reasonField(true)}
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button variant="outline" disabled={busy} onClick={onClose}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                disabled={busy}
                onClick={() => submit("reject-proof")}
              >
                {busy ? <Loader2 className="animate-spin" /> : null}
                Reject reference
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Suspend workspace */}
      <Dialog
        open={dialog?.kind === "suspend"}
        onOpenChange={(o) => {
          if (!o) onClose();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Suspend workspace</DialogTitle>
            <DialogDescription>
              {tenant?.name ?? "This workspace"} immediately loses access. Access is
              restored when you verify a payment or grant months manually.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            {reasonField(false)}
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button variant="outline" disabled={busy} onClick={onClose}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                disabled={busy}
                onClick={() => submit("suspend")}
              >
                {busy ? <Loader2 className="animate-spin" /> : null}
                Suspend workspace
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Extend subscription */}
      <Dialog
        open={dialog?.kind === "extend"}
        onOpenChange={(o) => {
          if (!o) onClose();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Extend subscription</DialogTitle>
            <DialogDescription>
              Manually grant free months to {tenant?.name ?? "this workspace"} — useful for
              comps, apologies or offline arrangements.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="extend-months">Months to grant (1–36)</Label>
              <Input
                id="extend-months"
                type="number"
                min={1}
                max={36}
                value={months}
                onChange={(e) => {
                  setMonths(e.target.value);
                  if (error) setError(null);
                }}
              />
              <p className="text-xs text-muted-foreground">
                Added on top of the current paid-through date
                {tenant?.paidUntil ? ` (${fmtDate(tenant.paidUntil)})` : ""}.
              </p>
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button variant="outline" disabled={busy} onClick={onClose}>
                Cancel
              </Button>
              <Button disabled={busy} onClick={() => submit("extend")}>
                {busy ? <Loader2 className="animate-spin" /> : <CalendarPlus />}
                Extend
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ===================== Payment methods tab =====================

interface MethodFormState {
  label: string;
  type: "upi" | "bank";
  upiId: string;
  accountHolder: string;
  accountNumber: string;
  ifsc: string;
  bankName: string;
  accountType: string;
  instructions: string;
  sortOrder: string;
  active: boolean;
}

function methodFormState(m: PaymentMethodDto | null): MethodFormState {
  if (m) {
    return {
      label: m.label,
      type: m.type,
      upiId: m.upiId ?? "",
      accountHolder: m.accountHolder ?? "",
      accountNumber: m.accountNumber ?? "",
      ifsc: m.ifsc ?? "",
      bankName: m.bankName ?? "",
      accountType: m.accountType ?? "",
      instructions: m.instructions ?? "",
      sortOrder: String(m.sortOrder),
      active: m.active,
    };
  }
  return {
    label: "",
    type: "upi",
    upiId: "",
    accountHolder: "",
    accountNumber: "",
    ifsc: "",
    bankName: "",
    accountType: "",
    instructions: "",
    sortOrder: "20",
    active: true,
  };
}

function MethodFormDialog({
  open,
  method,
  busy,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  method: PaymentMethodDto | null;
  busy: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (payload: Record<string, unknown>) => void;
}) {
  const [form, setForm] = useState<MethodFormState>(() => methodFormState(method));
  const [error, setError] = useState<string | null>(null);
  const isEdit = method !== null;

  function set<K extends keyof MethodFormState>(key: K, value: MethodFormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function submit() {
    setError(null);
    const label = form.label.trim();
    if (!label) {
      setError("Label is required.");
      return;
    }
    const upiId = form.upiId.trim();
    const accountNumber = form.accountNumber.trim();
    const ifsc = form.ifsc.trim().toUpperCase();
    if (form.type === "upi" && !/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(upiId)) {
      setError("Enter a valid UPI ID (e.g. name@bank).");
      return;
    }
    if (form.type === "bank") {
      if (!/^[0-9]{5,20}$/.test(accountNumber)) {
        setError("Enter a valid account number (5–20 digits).");
        return;
      }
      if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) {
        setError("Enter a valid IFSC code (e.g. BARB0PHAGWA).");
        return;
      }
    }
    const sortOrder = Number(form.sortOrder.trim());
    if (!Number.isFinite(sortOrder)) {
      setError("Display order must be a number.");
      return;
    }

    const payload: Record<string, unknown> = {
      label,
      instructions: form.instructions.trim() || null,
      active: form.active,
      sortOrder: Math.floor(sortOrder),
      ...(form.type === "upi"
        ? { upiId }
        : {
            accountHolder: form.accountHolder.trim() || null,
            accountNumber,
            ifsc,
            bankName: form.bankName.trim() || null,
            accountType: form.accountType.trim() || null,
          }),
      // The channel type can only be set when creating.
      ...(isEdit ? {} : { type: form.type }),
    };
    onSubmit(payload);
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (error) setError(null);
        onOpenChange(o);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit payment method" : "Add payment method"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Update this channel. Changes take effect immediately on the buyer payment screen."
              : "Add a UPI ID or bank account buyers can transfer to when purchasing a plan."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="pm-label">
              Label <span className="text-destructive">*</span>
            </Label>
            <Input
              id="pm-label"
              value={form.label}
              onChange={(e) => set("label", e.target.value)}
              placeholder="e.g. Company UPI"
            />
          </div>

          <div className="grid gap-1.5">
            <Label>Type</Label>
            <Select
              value={form.type}
              onValueChange={(v) => set("type", v === "bank" ? "bank" : "upi")}
              disabled={isEdit}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="upi">UPI</SelectItem>
                <SelectItem value="bank">Bank transfer</SelectItem>
              </SelectContent>
            </Select>
            {isEdit ? (
              <p className="text-xs text-muted-foreground">
                The channel type cannot be changed after creation.
              </p>
            ) : null}
          </div>

          {form.type === "upi" ? (
            <div className="grid gap-1.5">
              <Label htmlFor="pm-upi">
                UPI ID <span className="text-destructive">*</span>
              </Label>
              <Input
                id="pm-upi"
                className="font-mono"
                value={form.upiId}
                onChange={(e) => set("upiId", e.target.value)}
                placeholder="name@bank"
              />
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="pm-holder">Account holder</Label>
                <Input
                  id="pm-holder"
                  value={form.accountHolder}
                  onChange={(e) => set("accountHolder", e.target.value)}
                  placeholder="e.g. PeoplePulse Labs Pvt Ltd"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="pm-bank">Bank name</Label>
                <Input
                  id="pm-bank"
                  value={form.bankName}
                  onChange={(e) => set("bankName", e.target.value)}
                  placeholder="e.g. Bank of Baroda"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="pm-account">
                  Account number <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="pm-account"
                  className="font-mono"
                  value={form.accountNumber}
                  onChange={(e) => set("accountNumber", e.target.value)}
                  placeholder="5–20 digits"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="pm-ifsc">
                  IFSC <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="pm-ifsc"
                  className="font-mono uppercase"
                  value={form.ifsc}
                  onChange={(e) => set("ifsc", e.target.value.toUpperCase())}
                  placeholder="BARB0PHAGWA"
                />
              </div>
              <div className="grid gap-1.5 sm:col-span-2">
                <Label htmlFor="pm-account-type">Account type</Label>
                <Input
                  id="pm-account-type"
                  value={form.accountType}
                  onChange={(e) => set("accountType", e.target.value)}
                  placeholder="e.g. Savings / Current"
                />
              </div>
            </div>
          )}

          <div className="grid gap-1.5">
            <Label htmlFor="pm-instructions">Instructions for buyers</Label>
            <Textarea
              id="pm-instructions"
              rows={3}
              value={form.instructions}
              onChange={(e) => set("instructions", e.target.value)}
              placeholder="e.g. Pay from your company account and keep the UTR handy — you will need it in step 3."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="pm-sort">Display order</Label>
              <Input
                id="pm-sort"
                type="number"
                value={form.sortOrder}
                onChange={(e) => set("sortOrder", e.target.value)}
              />
            </div>
            <div className="flex items-center justify-between gap-2 rounded-lg border px-3">
              <Label htmlFor="pm-active">Active</Label>
              <Switch
                id="pm-active"
                checked={form.active}
                onCheckedChange={(c) => set("active", c)}
              />
            </div>
          </div>

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <DialogFooter>
            <Button variant="outline" disabled={busy} onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button disabled={busy} onClick={submit}>
              {busy ? <Loader2 className="animate-spin" /> : null}
              {isEdit ? "Save changes" : "Add method"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function PaymentMethodCard({
  method,
  toggleBusy,
  onToggle,
  onEdit,
  onDelete,
}: {
  method: PaymentMethodDto;
  toggleBusy: boolean;
  onToggle: (active: boolean) => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const isUpi = method.type === "upi";
  return (
    <Card>
      <CardContent className="grid gap-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-2.5">
            <div className="mt-0.5 shrink-0 rounded-lg bg-primary/10 p-2 text-primary">
              {isUpi ? <Smartphone className="h-4 w-4" /> : <Landmark className="h-4 w-4" />}
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{method.label}</p>
              <p className="text-xs text-muted-foreground">
                {STATUS_LABELS[method.type] ?? method.type} · order {method.sortOrder}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {method.active ? "Active" : "Hidden"}
            </span>
            <Switch
              checked={method.active}
              disabled={toggleBusy}
              onCheckedChange={onToggle}
              aria-label={`Show "${method.label}" to buyers`}
            />
          </div>
        </div>

        <dl className="grid gap-1.5">
          {isUpi ? (
            <>
              {method.upiId ? (
                <Detail label="UPI ID" value={<span className="font-mono">{method.upiId}</span>} />
              ) : null}
              {method.accountHolder ? (
                <Detail label="Holder" value={method.accountHolder} />
              ) : null}
            </>
          ) : (
            <>
              {method.accountHolder ? (
                <Detail label="Account holder" value={method.accountHolder} />
              ) : null}
              {method.accountNumber ? (
                <Detail
                  label="Account number"
                  value={<span className="font-mono">{method.accountNumber}</span>}
                />
              ) : null}
              {method.ifsc ? (
                <Detail label="IFSC" value={<span className="font-mono">{method.ifsc}</span>} />
              ) : null}
              {method.bankName || method.accountType ? (
                <Detail
                  label="Bank"
                  value={[method.bankName, method.accountType].filter(Boolean).join(" · ")}
                />
              ) : null}
            </>
          )}
        </dl>

        {method.instructions ? (
          <p className="rounded-lg bg-muted/50 p-2.5 text-xs leading-relaxed text-muted-foreground">
            {method.instructions}
          </p>
        ) : null}

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={onEdit}>
            <Pencil /> Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-destructive hover:text-destructive"
            onClick={onDelete}
          >
            <Trash2 /> Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function PaymentMethodsTab() {
  const qc = useQueryClient();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<PaymentMethodDto | null>(null);
  const [deleting, setDeleting] = useState<PaymentMethodDto | null>(null);
  // Bumped on every open so the dialog mounts with fresh form state.
  const [formSession, setFormSession] = useState(0);

  const methodsQuery = useQuery({
    queryKey: qk.adminPaymentMethods,
    queryFn: () => api.get<PaymentMethodsResponse>("/api/admin/payment-methods"),
  });

  const saveMutation = useMutation({
    mutationFn: (v: { id: string | null; payload: Record<string, unknown> }) =>
      v.id === null
        ? api.post<{ method: PaymentMethodDto }>("/api/admin/payment-methods", v.payload)
        : api.patch<{ method: PaymentMethodDto }>(
            `/api/admin/payment-methods/${v.id}`,
            v.payload
          ),
    onSuccess: (_data, v) => {
      qc.invalidateQueries({ queryKey: qk.adminPaymentMethods });
      toast.success(v.id === null ? "Payment method added" : "Payment method updated");
      setFormOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: (v: { id: string; active: boolean }) =>
      api.patch<{ method: PaymentMethodDto }>(`/api/admin/payment-methods/${v.id}`, {
        active: v.active,
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.adminPaymentMethods });
    },
    onError: (e: Error) => {
      // Refetch so the switch snaps back to the server state.
      qc.invalidateQueries({ queryKey: qk.adminPaymentMethods });
      toast.error(e.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) =>
      api.delete<{ ok: true }>(`/api/admin/payment-methods/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.adminPaymentMethods });
      toast.success("Payment method deleted");
      setDeleting(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function openAdd() {
    setEditing(null);
    setFormSession((s) => s + 1);
    setFormOpen(true);
  }

  function openEdit(method: PaymentMethodDto) {
    setEditing(method);
    setFormSession((s) => s + 1);
    setFormOpen(true);
  }

  function handleMethodSubmit(payload: Record<string, unknown>) {
    if (editing) {
      const orig = editing as unknown as Record<string, unknown>;
      const diff: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(payload)) {
        if (orig[key] !== value) diff[key] = value;
      }
      if (Object.keys(diff).length === 0) {
        toast.info("No changes to save.");
        setFormOpen(false);
        return;
      }
      saveMutation.mutate({ id: editing.id, payload: diff });
      return;
    }
    saveMutation.mutate({ id: null, payload });
  }

  const methods = methodsQuery.data?.items ?? [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-base font-semibold">Payment channels</h2>
        <Button size="sm" onClick={openAdd}>
          <Plus /> Add payment method
        </Button>
      </div>

      {methodsQuery.isPending ? (
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-60 rounded-xl" />
          <Skeleton className="h-60 rounded-xl" />
        </div>
      ) : methodsQuery.isError ? (
        <LoadError
          message={methodsQuery.error.message}
          onRetry={() => methodsQuery.refetch()}
        />
      ) : methods.length === 0 ? (
        <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
          <Landmark className="h-5 w-5 text-muted-foreground" />
          <p className="text-sm font-medium">No payment channels yet</p>
          <p className="max-w-md text-sm text-muted-foreground">
            Add the UPI ID or bank account buyers should transfer to when they purchase a
            plan.
          </p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {methods.map((m) => (
            <PaymentMethodCard
              key={m.id}
              method={m}
              toggleBusy={toggleActive.isPending && toggleActive.variables?.id === m.id}
              onToggle={(active) => toggleActive.mutate({ id: m.id, active })}
              onEdit={() => openEdit(m)}
              onDelete={() => setDeleting(m)}
            />
          ))}
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        These are the accounts buyers see on the payment screen. Changes take effect
        immediately.
      </p>

      <MethodFormDialog
        key={formSession}
        open={formOpen}
        method={editing}
        busy={saveMutation.isPending}
        onOpenChange={(o) => {
          if (!o) setFormOpen(false);
        }}
        onSubmit={handleMethodSubmit}
      />

      <AlertDialog
        open={deleting !== null}
        onOpenChange={(o) => {
          if (!o) setDeleting(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete payment method</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting
                ? `"${deleting.label}" will immediately disappear from the buyer payment screen. This cannot be undone.`
                : "This cannot be undone."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white shadow-xs hover:bg-destructive/90"
              disabled={deleteMutation.isPending}
              onClick={(e) => {
                e.preventDefault();
                if (deleting) deleteMutation.mutate(deleting.id);
              }}
            >
              {deleteMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Delete channel
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===================== Skeletons =====================

function OverviewSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-56 rounded-xl" />
    </div>
  );
}

function TenantsSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-9 w-full sm:w-72" />
      </div>
      <Skeleton className="h-96 rounded-xl" />
    </div>
  );
}

// ===================== Module =====================

export function PlatformAdminModule() {
  const [dialog, setDialog] = useState<TenantDialog | null>(null);
  const act = useTenantAction();

  const tenantsQuery = useQuery({
    queryKey: qk.adminTenants,
    queryFn: () => api.get<AdminTenantsResponse>("/api/admin/tenants"),
  });

  const data = tenantsQuery.data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Platform Admin</h1>
            {data && data.stats.pending > 0 ? (
              <Badge
                variant="outline"
                className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400"
              >
                {data.stats.pending} awaiting approval
              </Badge>
            ) : null}
          </div>
          <p className="text-sm text-muted-foreground">
            Approve signups, verify payment references and manage the platform&apos;s
            payment channels.
          </p>
        </div>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="grid w-full grid-cols-3 sm:inline-flex sm:w-auto">
          <TabsTrigger value="overview" className="text-xs sm:text-sm">
            Overview
          </TabsTrigger>
          <TabsTrigger value="tenants" className="text-xs sm:text-sm">
            Tenants
          </TabsTrigger>
          <TabsTrigger value="payment-methods" className="text-xs sm:text-sm">
            Payment methods
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          {tenantsQuery.isPending ? (
            <OverviewSkeleton />
          ) : tenantsQuery.isError ? (
            <LoadError
              message={tenantsQuery.error.message}
              onRetry={() => tenantsQuery.refetch()}
            />
          ) : data ? (
            <OverviewTab
              items={data.items}
              stats={data.stats}
              act={act}
              openDialog={setDialog}
            />
          ) : null}
        </TabsContent>

        <TabsContent value="tenants" className="mt-4">
          {tenantsQuery.isPending ? (
            <TenantsSkeleton />
          ) : tenantsQuery.isError ? (
            <LoadError
              message={tenantsQuery.error.message}
              onRetry={() => tenantsQuery.refetch()}
            />
          ) : data ? (
            <TenantsTab items={data.items} act={act} openDialog={setDialog} />
          ) : null}
        </TabsContent>

        <TabsContent value="payment-methods" className="mt-4">
          <PaymentMethodsTab />
        </TabsContent>
      </Tabs>

      <TenantDialogs
        key={`${dialog?.kind ?? "none"}-${dialog?.tenant.id ?? ""}-${dialog?.tenant.latestProof?.id ?? ""}`}
        dialog={dialog}
        onClose={() => setDialog(null)}
        act={act}
      />
    </div>
  );
}

"use client";

/**
 * PeoplePulse HR — Employees module.
 * Searchable, filterable employee grid with a detail sheet
 * (profile / leave / attendance / onboarding / career), add & edit dialogs,
 * exit flow, CSV import wizard and CSV export.
 */
import { useEffect, useMemo, useState } from "react";
import {
  keepPreviousData,
  useMutation,
  useQuery,
  useQueryClient,
  type QueryClient,
} from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Briefcase,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Circle,
  CircleCheck,
  CircleDashed,
  Copy,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  ListChecks,
  Loader2,
  LogOut,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  RotateCcw,
  Search,
  Shuffle,
  Upload,
  UserPlus,
  UserRound,
  Users,
  Wallet,
} from "lucide-react";
import type {
  BulkImportResponse,
  DepartmentDto,
  EmployeeDetail,
  EmployeeListItem,
  EmployeeListResponse,
  EmployeeStatus,
  EmploymentType,
  Role,
  SessionUser,
} from "@/lib/types";
import { STATUS_LABELS } from "@/lib/constants";
import { api, qk } from "@/lib/api-client";
import {
  cn,
  downloadCsv,
  fmtDate,
  inr,
  initials,
  parseCsv,
  todayIso,
} from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const PAGE_SIZE = 12;
const HR_GROUP: Role[] = ["owner", "admin", "hr"];
const EMPLOYEE_STATUSES: EmployeeStatus[] = ["active", "probation", "notice", "exited"];
const EMPLOYMENT_TYPES: EmploymentType[] = ["full_time", "part_time", "contract", "intern"];
const ONBOARDING_LABELS: Record<string, string> = {
  pending: "Pending",
  in_progress: "In Progress",
  done: "Done",
};
const IMPORT_COLUMNS = "name,email,department,designation,ctc,joinDate,phone,location";
const SAMPLE_CSV = [
  IMPORT_COLUMNS,
  "Aarav Sharma,aarav.sharma@example.com,Engineering,Senior Backend Engineer,2400000,2024-07-15,+91 98200 11223,Bengaluru",
  "Diya Patel,diya.patel@example.in,Design,Product Designer,1800000,2024-09-02,+91 99400 55112,Pune",
  "Vikram Nair,vikram.nair@example.com,Sales,Account Executive,1200000,2025-01-06,+91 98100 77341,Mumbai",
  "Ananya Krishnan,ananya.krishnan@example.in,People,HR Associate,900000,2025-02-17,+91 97400 22190,Kochi",
  "Rahul Verma,rahul.verma@example.com,Engineering,QA Engineer,1450000,2023-11-20,+91 97200 61085,Ahmedabad",
].join("\n");

const LOGIN_ROLES_BASE = [
  { value: "employee", label: "Employee" },
  { value: "manager", label: "Manager" },
];
const LOGIN_ROLES_ELEVATED = [
  { value: "hr", label: "HR" },
  { value: "admin", label: "Admin" },
];

interface LoginPayload {
  email: string;
  password: string;
  role: string;
}

function fullName(e: { firstName: string; lastName: string }): string {
  return `${e.firstName} ${e.lastName}`.trim();
}

/** Invalidate every query derived from the employee roster (dashboard, org chart, departments, setup). */
function invalidateEmployeeDependents(qc: QueryClient) {
  qc.invalidateQueries({ queryKey: qk.dashboard });
  qc.invalidateQueries({ queryKey: qk.orgChart });
  qc.invalidateQueries({ queryKey: qk.departments });
  qc.invalidateQueries({ queryKey: qk.orgSetup });
}

function Avatar({
  name,
  color,
  className,
}: {
  name: string;
  color: string;
  className?: string;
}) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function statusBadge(status: string) {
  const label = STATUS_LABELS[status] ?? status;
  switch (status) {
    case "active":
      return <Badge variant="secondary">{label}</Badge>;
    case "probation":
      return (
        <Badge variant="outline" className="border-amber-600/40 text-amber-700 dark:text-amber-400">
          {label}
        </Badge>
      );
    case "notice":
      return (
        <Badge variant="outline" className="border-destructive/40 text-destructive">
          {label}
        </Badge>
      );
    default:
      return (
        <Badge variant="outline" className="text-muted-foreground">
          {label}
        </Badge>
      );
  }
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Mail;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-2.5 rounded-lg border p-2.5">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <div className="text-[11px] text-muted-foreground">{label}</div>
        <div className="truncate text-sm font-medium">{value}</div>
      </div>
    </div>
  );
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/** Client-side generator: 14 chars, guaranteed upper + lower + digit + symbol. */
function generatePassword(): string {
  const classes = [
    "ABCDEFGHJKLMNPQRSTUVWXYZ",
    "abcdefghijkmnpqrstuvwxyz",
    "23456789",
    "!@#$%^&*_-+=",
  ];
  const chars = classes.map((c) => c[Math.floor(Math.random() * c.length)]);
  const pool = classes.join("");
  while (chars.length < 14) chars.push(pool[Math.floor(Math.random() * pool.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).then(
    () => toast.success("Copied"),
    () => toast.error("Could not copy — select the text manually.")
  );
}

export function EmployeesModule() {
  const { user } = useAppStore();
  if (!user) return null;
  return <EmployeesInner user={user} />;
}

function EmployeesInner({ user }: { user: SessionUser }) {
  const isHrGroup = HR_GROUP.includes(user.role);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("all");
  const [status, setStatus] = useState("active");
  const [employmentType, setEmploymentType] = useState("all");
  const [page, setPage] = useState(1);

  const [addOpen, setAddOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchText), 400);
    return () => clearTimeout(t);
  }, [searchText]);

  // Reset to page 1 whenever the filters change (render-time adjustment).
  const filterSignature = `${search}|${department}|${status}|${employmentType}`;
  const [lastFilterSignature, setLastFilterSignature] = useState(filterSignature);
  if (lastFilterSignature !== filterSignature) {
    setLastFilterSignature(filterSignature);
    setPage(1);
  }

  const filters = useMemo(
    () => ({
      ...(search ? { search } : {}),
      ...(department !== "all" ? { department } : {}),
      ...(status !== "all" ? { status } : {}),
      ...(employmentType !== "all" ? { employmentType } : {}),
      page,
      pageSize: PAGE_SIZE,
    }),
    [search, department, status, employmentType, page]
  );

  const listQuery = useQuery({
    queryKey: qk.employees(filters),
    queryFn: () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([k, v]) => params.set(k, String(v)));
      return api.get<EmployeeListResponse>(`/api/employees?${params.toString()}`);
    },
    placeholderData: keepPreviousData,
  });

  useEffect(() => {
    if (listQuery.error) toast.error(listQuery.error.message);
  }, [listQuery.error]);

  // Department options: the organisation's configured departments, merged with
  // any departments already present on employee records.
  const departmentsQuery = useQuery({
    queryKey: qk.departments,
    queryFn: () => api.get<{ items: DepartmentDto[] }>("/api/departments"),
  });
  const departments = Array.from(
    new Set([
      ...(departmentsQuery.data?.items ?? []).map((d) => d.name),
      ...(listQuery.data?.departments ?? []),
    ])
  ).sort();
  const hasActiveFilters =
    searchText.trim() !== "" ||
    department !== "all" ||
    status !== "active" ||
    employmentType !== "all";

  const resetFilters = () => {
    setSearchText("");
    setSearch("");
    setDepartment("all");
    setStatus("active");
    setEmploymentType("all");
  };

  const handleExport = () => {
    const items = listQuery.data?.items ?? [];
    if (items.length === 0) {
      toast.error("Nothing to export for the current filters.");
      return;
    }
    downloadCsv(
      "employees.csv",
      items.map((e) => ({
        name: fullName(e),
        code: e.code,
        email: e.email,
        department: e.department,
        designation: e.designation,
        location: e.location,
        joinDate: e.joinDate,
        status: STATUS_LABELS[e.status] ?? e.status,
        ctc: e.ctc,
      })),
      [
        { key: "name", label: "Name" },
        { key: "code", label: "Code" },
        { key: "email", label: "Email" },
        { key: "department", label: "Department" },
        { key: "designation", label: "Designation" },
        { key: "location", label: "Location" },
        { key: "joinDate", label: "Join Date" },
        { key: "status", label: "Status" },
        { key: "ctc", label: "Annual CTC (INR)" },
      ]
    );
    toast.success(`Exported ${items.length} employees to CSV.`);
  };

  const openEmployee = (id: string) => {
    setSelectedId(id);
    setSheetOpen(true);
  };

  const data = listQuery.data;
  const total = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const start = total === 0 ? 0 : (data?.page ?? page) * PAGE_SIZE - PAGE_SIZE + 1;
  const end = Math.min((data?.page ?? page) * PAGE_SIZE, total);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Employees</h1>
          <p className="text-sm text-muted-foreground">
            {data
              ? `${total} ${total === 1 ? "employee" : "employees"} · ${user.tenantName}`
              : `Manage your people · ${user.tenantName}`}
          </p>
        </div>
        {isHrGroup && (
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download /> Export CSV
            </Button>
            <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
              <Upload /> Import
            </Button>
            <Button size="sm" onClick={() => setAddOpen(true)}>
              <UserPlus /> Add Employee
            </Button>
          </div>
        )}
      </div>

      {/* Filter bar */}
      <Card className="gap-0 py-0">
        <CardContent className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
          <div className="relative min-w-0 flex-1">
            <Search className="absolute top-1/2 left-2.5 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Search by name, email or code…"
              className="pl-8"
            />
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            <Select value={department} onValueChange={setDepartment}>
              <SelectTrigger className="w-full sm:w-44">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All departments</SelectItem>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {EMPLOYEE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s] ?? s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={employmentType} onValueChange={setEmploymentType}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="Employment type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {EMPLOYMENT_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {STATUS_LABELS[t] ?? t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={resetFilters}
            disabled={!hasActiveFilters}
            className="shrink-0"
          >
            <RotateCcw /> Reset
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {listQuery.isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-44 rounded-xl" />
          ))}
        </div>
      ) : listQuery.isError ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <Users className="h-8 w-8 text-muted-foreground" />
          <div>
            <div className="font-semibold">Could not load employees</div>
            <p className="text-sm text-muted-foreground">{listQuery.error.message}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => listQuery.refetch()}>
            Try again
          </Button>
        </div>
      ) : (data?.items.length ?? 0) === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Users className="h-6 w-6 text-primary" />
          </div>
          <div>
            <div className="font-semibold">No employees found</div>
            <p className="text-sm text-muted-foreground">
              {hasActiveFilters
                ? "Try adjusting or resetting the filters."
                : "Add your first employee or import a roster to get started."}
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {hasActiveFilters && (
              <Button variant="outline" size="sm" onClick={resetFilters}>
                <RotateCcw /> Reset filters
              </Button>
            )}
            {isHrGroup && !hasActiveFilters && (
              <>
                <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
                  <Upload /> Import CSV
                </Button>
                <Button size="sm" onClick={() => setAddOpen(true)}>
                  <Plus /> Add Employee
                </Button>
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {data?.items.map((emp) => (
            <EmployeeCard
              key={emp.id}
              employee={emp}
              showCtc={isHrGroup}
              onClick={() => openEmployee(emp.id)}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {data && total > 0 && (
        <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            Showing {start}–{end} of {total}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              <ChevronLeft /> Prev
            </Button>
            <span className="text-xs text-muted-foreground">
              Page {data.page ?? page} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              Next <ChevronRight />
            </Button>
          </div>
        </div>
      )}

      {/* Detail sheet */}
      <Sheet open={sheetOpen} onOpenChange={(o) => setSheetOpen(o)}>
        <SheetContent side="right" className="w-full gap-0 p-0 sm:max-w-xl">
          {selectedId && (
            <EmployeeSheetBody
              key={selectedId}
              id={selectedId}
              user={user}
              departments={departments}
              onExited={() => setSheetOpen(false)}
            />
          )}
        </SheetContent>
      </Sheet>

      {/* Add employee */}
      {isHrGroup && (
        <AddEmployeeDialog
          open={addOpen}
          onOpenChange={setAddOpen}
          departments={departments}
          user={user}
        />
      )}

      {/* Import wizard */}
      {isHrGroup && <ImportDialog open={importOpen} onOpenChange={setImportOpen} />}
    </div>
  );
}

/* ---------------- Employee card ---------------- */

function EmployeeCard({
  employee,
  showCtc,
  onClick,
}: {
  employee: EmployeeListItem;
  showCtc: boolean;
  onClick: () => void;
}) {
  const name = fullName(employee);
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex flex-col gap-3 rounded-xl border bg-card p-4 text-left shadow-sm transition-all hover:border-primary/40 hover:shadow-md"
    >
      <div className="flex items-start justify-between gap-2">
        <Avatar name={name} color={employee.avatarColor} className="h-10 w-10 text-sm" />
        {statusBadge(employee.status)}
      </div>
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold group-hover:text-primary">{name}</div>
        <div className="truncate text-xs text-muted-foreground">{employee.designation}</div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge variant="outline" className="text-[10px]">
          {employee.department}
        </Badge>
        <span className="font-mono text-[11px] text-muted-foreground">{employee.code}</span>
        {employee.hasLogin && (
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="flex items-center text-muted-foreground/70" aria-label="Has login access">
                <KeyRound className="h-3 w-3" />
              </span>
            </TooltipTrigger>
            <TooltipContent>Has login access</TooltipContent>
          </Tooltip>
        )}
      </div>
      <div className="mt-auto flex items-center justify-between gap-2 border-t pt-2.5 text-[11px] text-muted-foreground">
        <span className="flex min-w-0 items-center gap-1">
          <MapPin className="h-3 w-3 shrink-0" />
          <span className="truncate">{employee.location || "—"}</span>
        </span>
        {showCtc && (
          <span className="shrink-0 font-medium text-foreground/80">
            {inr(employee.ctc, { compact: true })}
          </span>
        )}
      </div>
    </button>
  );
}

/* ---------------- Detail sheet ---------------- */

function EmployeeSheetBody({
  id,
  user,
  departments,
  onExited,
}: {
  id: string;
  user: SessionUser;
  departments: string[];
  onExited: () => void;
}) {
  const qc = useQueryClient();
  const isHrGroup = HR_GROUP.includes(user.role);
  const [editOpen, setEditOpen] = useState(false);
  const [exitOpen, setExitOpen] = useState(false);
  const [accessOpen, setAccessOpen] = useState(false);

  const detailQuery = useQuery({
    queryKey: qk.employee(id),
    queryFn: () => api.get<EmployeeDetail>(`/api/employees/${id}`),
  });

  const detail = detailQuery.data;

  const exitMutation = useMutation({
    mutationFn: () => api.delete<{ success: boolean }>(`/api/employees/${id}`),
    onSuccess: () => {
      toast.success("Employee record removed");
      qc.invalidateQueries({ queryKey: ["employees"] });
      invalidateEmployeeDependents(qc);
      onExited();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (detailQuery.isLoading) {
    return (
      <div className="space-y-4 p-4">
        <SheetTitle className="sr-only">Loading employee</SheetTitle>
        <SheetDescription className="sr-only">Employee details are loading.</SheetDescription>
        <div className="flex items-center gap-3">
          <Skeleton className="h-12 w-12 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-5 w-44" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (detailQuery.isError || !detail) {
    return (
      <SheetHeader className="border-b">
        <SheetTitle>Could not load employee</SheetTitle>
        <SheetDescription className="text-destructive">
          {detailQuery.error?.message ?? "Something went wrong."}
        </SheetDescription>
      </SheetHeader>
    );
  }

  const name = fullName(detail);
  const attendanceCounts: { status: string; count: number }[] = [];
  const counts: Record<string, number> = {};
  detail.attendance30d.forEach((a) => {
    counts[a.status] = (counts[a.status] ?? 0) + 1;
  });
  Object.entries(counts).forEach(([status, count]) => attendanceCounts.push({ status, count }));

  return (
    <>
      <SheetHeader className="border-b pb-4">
        <div className="flex items-center gap-3 pr-8">
          <Avatar name={name} color={detail.avatarColor} className="h-12 w-12 text-base" />
          <div className="min-w-0">
            <SheetTitle className="truncate">{name}</SheetTitle>
            <SheetDescription className="truncate">
              {detail.designation} · {detail.department}
            </SheetDescription>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {statusBadge(detail.status)}
          <Badge variant="outline" className="font-mono text-[10px]">
            {detail.code}
          </Badge>
          <Badge variant="outline">{STATUS_LABELS[detail.employmentType] ?? detail.employmentType}</Badge>
          {detail.managerName && (
            <Badge variant="outline">Reports to {detail.managerName}</Badge>
          )}
          <span className="text-xs text-muted-foreground">Joined {fmtDate(detail.joinDate)}</span>
        </div>
      </SheetHeader>

      <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto p-4">
        <Tabs defaultValue="profile">
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="profile" className="flex-none px-3">
              Profile
            </TabsTrigger>
            <TabsTrigger value="leave" className="flex-none px-3">
              Leave
            </TabsTrigger>
            <TabsTrigger value="attendance" className="flex-none px-3">
              Attendance
            </TabsTrigger>
            <TabsTrigger value="onboarding" className="flex-none px-3">
              Onboarding
            </TabsTrigger>
            <TabsTrigger value="career" className="flex-none px-3">
              Career
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-4">
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <InfoRow icon={Mail} label="Email" value={detail.email} />
              <InfoRow icon={Phone} label="Phone" value={detail.phone || "—"} />
              <InfoRow icon={MapPin} label="Location" value={detail.location || "—"} />
              <InfoRow icon={CalendarDays} label="Date of birth" value={fmtDate(detail.dob)} />
              <InfoRow icon={UserRound} label="Gender" value={detail.gender || "—"} />
              <InfoRow
                icon={Briefcase}
                label="Employment type"
                value={STATUS_LABELS[detail.employmentType] ?? detail.employmentType}
              />
              <InfoRow icon={Users} label="Manager" value={detail.managerName || "—"} />
              <InfoRow icon={CalendarDays} label="Joined on" value={fmtDate(detail.joinDate)} />
              {isHrGroup && (
                <InfoRow icon={Wallet} label="Annual CTC" value={inr(detail.ctc)} />
              )}
              <InfoRow
                icon={Phone}
                label="Emergency contact"
                value={detail.emergencyContact || "—"}
              />
            </div>
            {/* Login access */}
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3">
              <div className="flex min-w-0 items-start gap-2.5">
                <KeyRound className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0">
                  <div className="text-[11px] text-muted-foreground">Access</div>
                  {detail.hasLogin ? (
                    <>
                      <div className="truncate text-sm font-medium">{detail.loginEmail ?? detail.email}</div>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        <Badge
                          variant="outline"
                          className="border-emerald-600/40 bg-emerald-600/10 text-[10px] text-emerald-700 dark:text-emerald-400"
                        >
                          Login active
                        </Badge>
                        {detail.loginRole && (
                          <Badge variant="outline" className="text-[10px] capitalize">
                            {detail.loginRole}
                          </Badge>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="text-sm text-muted-foreground">No login access</div>
                  )}
                </div>
              </div>
              {isHrGroup && (
                <Button variant="outline" size="sm" className="shrink-0" onClick={() => setAccessOpen(true)}>
                  {detail.hasLogin ? "Manage access" : "Grant access"}
                </Button>
              )}
            </div>
          </TabsContent>

          <TabsContent value="leave" className="mt-4 space-y-4">
            {detail.balances.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
                No leave balances configured for this employee.
              </div>
            ) : (
              detail.balances.map((b) => (
                <div key={b.leaveTypeId} className="space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-1">
                    <span className="text-sm font-medium">{b.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {b.used} used · {b.pending} pending · {b.available} of {b.entitled} left
                    </span>
                  </div>
                  <Progress
                    value={b.entitled > 0 ? Math.min(100, ((b.used + b.pending) / b.entitled) * 100) : 0}
                    className="h-1.5"
                  />
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="attendance" className="mt-4 space-y-4">
            <div className="flex flex-wrap gap-1.5">
              {attendanceCounts.length === 0 ? (
                <p className="text-sm text-muted-foreground">No attendance records in the last 30 days.</p>
              ) : (
                attendanceCounts.map(({ status, count }) => (
                  <Badge key={status} variant="secondary" className="gap-1.5">
                    {STATUS_LABELS[status] ?? status}
                    <span className="font-mono text-[10px] opacity-70">{count}</span>
                  </Badge>
                ))
              )}
            </div>
            <div className="scrollbar-thin max-h-80 divide-y overflow-y-auto rounded-lg border">
              {detail.attendance30d.map((a) => (
                <div key={a.date} className="flex items-center justify-between gap-3 p-2.5 text-sm">
                  <span className="font-medium">{fmtDate(a.date)}</span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {a.checkIn ?? "--:--"} – {a.checkOut ?? "--:--"}
                  </span>
                  <Badge variant="outline" className="text-[10px]">
                    {STATUS_LABELS[a.status] ?? a.status}
                  </Badge>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="onboarding" className="mt-4 space-y-2.5">
            {detail.onboardingTasks.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
                No onboarding checklist for this employee.
              </div>
            ) : (
              [...detail.onboardingTasks]
                .sort((a, b) => a.order - b.order)
                .map((t) => (
                  <div key={t.id} className="flex items-center gap-3 rounded-lg border p-3">
                    {t.status === "done" ? (
                      <CircleCheck className="h-4 w-4 shrink-0 text-primary" />
                    ) : t.status === "in_progress" ? (
                      <CircleDashed className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                    ) : (
                      <Circle className="h-4 w-4 shrink-0 text-muted-foreground" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{t.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {t.assignee} · due {fmtDate(t.dueDate)}
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                      {ONBOARDING_LABELS[t.status] ?? t.status}
                    </Badge>
                  </div>
                ))
            )}
          </TabsContent>

          <TabsContent value="career" className="mt-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Payslips issued</div>
                <div className="text-xl font-bold">{detail.payslipCount}</div>
              </div>
              {isHrGroup && (
                <div className="rounded-lg border p-3">
                  <div className="text-xs text-muted-foreground">Last payslip (net)</div>
                  <div className="text-xl font-bold">
                    {detail.lastPayslipNet !== null ? inr(detail.lastPayslipNet) : "—"}
                  </div>
                </div>
              )}
            </div>
            <div className="rounded-lg border p-3">
              <div className="text-xs text-muted-foreground">Review status</div>
              <div className="text-sm font-medium">
                {detail.reviewStatus
                  ? STATUS_LABELS[detail.reviewStatus] ?? detail.reviewStatus
                  : "No active review cycle"}
              </div>
            </div>
            {detail.exitDate && (
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">Exit date</div>
                <div className="text-sm font-medium">{fmtDate(detail.exitDate)}</div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {isHrGroup && (
        <SheetFooter className="flex-row items-center justify-end gap-2 border-t">
          <Button variant="outline" onClick={() => setEditOpen(true)}>
            <Pencil /> Edit
          </Button>
          {detail.status !== "exited" && (
            <Button variant="destructive" onClick={() => setExitOpen(true)}>
              <LogOut /> Exit
            </Button>
          )}
        </SheetFooter>
      )}

      <EditEmployeeDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        detail={detail}
        departments={departments}
      />

      {isHrGroup && (
        <ManageAccessDialog
          open={accessOpen}
          onOpenChange={setAccessOpen}
          detail={detail}
          user={user}
        />
      )}

      <AlertDialog open={exitOpen} onOpenChange={setExitOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently deletes {name}&apos;s record including leave balances, attendance
              history and onboarding tasks. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={exitMutation.isPending}
              onClick={(e) => {
                e.preventDefault();
                exitMutation.mutate();
              }}
            >
              {exitMutation.isPending && <Loader2 className="animate-spin" />}
              Delete employee
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ---------------- Add employee dialog ---------------- */

const emptyAddForm = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  department: "",
  designation: "",
  location: "",
  joinDate: todayIso(),
  employmentType: "full_time" as EmploymentType,
  ctc: "",
  dob: "",
  gender: "",
  managerId: "none",
  createLogin: true,
  loginRole: "employee",
  loginPassword: "",
};

function useManagerOptions(open: boolean) {
  return useQuery({
    queryKey: qk.employees({ pageSize: 100 }),
    queryFn: () => api.get<EmployeeListResponse>("/api/employees?pageSize=100"),
    enabled: open,
  });
}

function ManagerSelect({
  value,
  onChange,
  excludeId,
  managersQuery,
}: {
  value: string;
  onChange: (v: string) => void;
  excludeId?: string;
  managersQuery: ReturnType<typeof useManagerOptions>;
}) {
  const options = (managersQuery.data?.items ?? []).filter((m) => m.id !== excludeId);
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder="Reporting manager" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="none">No manager</SelectItem>
        {options.map((m) => (
          <SelectItem key={m.id} value={m.id}>
            {fullName(m)} · {m.designation}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function AddEmployeeDialog({
  open,
  onOpenChange,
  departments,
  user,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  departments: string[];
  user: SessionUser;
}) {
  const qc = useQueryClient();
  const [form, setForm] = useState(emptyAddForm);
  const [createdLogin, setCreatedLogin] = useState<LoginPayload | null>(null);
  const managersQuery = useManagerOptions(open);
  const canGrantElevated = user.role === "owner" || user.role === "admin";

  const set = (key: keyof typeof emptyAddForm, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  const createMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.post<{ employee: EmployeeListItem; login?: LoginPayload }>("/api/employees", payload),
    onSuccess: (res) => {
      toast.success(`${fullName(res.employee)} added to the team`);
      setForm(emptyAddForm);
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["employees"] });
      invalidateEmployeeDependents(qc);
      if (res.login) setCreatedLogin(res.login);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const submit = () => {
    if (
      !form.firstName.trim() ||
      !form.lastName.trim() ||
      !form.email.trim() ||
      !form.department ||
      !form.designation.trim() ||
      !form.joinDate
    ) {
      toast.error("First name, last name, email, department, designation and join date are required.");
      return;
    }
    if (form.createLogin && form.loginPassword.trim() && form.loginPassword.trim().length < 8) {
      toast.error("Login password must be at least 8 characters — or leave it blank to auto-generate.");
      return;
    }
    const payload: Record<string, unknown> = {
      firstName: form.firstName.trim(),
      lastName: form.lastName.trim(),
      email: form.email.trim(),
      department: form.department,
      designation: form.designation.trim(),
      joinDate: form.joinDate,
      employmentType: form.employmentType,
    };
    if (form.phone.trim()) payload.phone = form.phone.trim();
    if (form.location.trim()) payload.location = form.location.trim();
    const ctc = Number(form.ctc.replace(/[^\d.]/g, ""));
    if (form.ctc.trim() !== "" && Number.isFinite(ctc) && ctc > 0) payload.ctc = ctc;
    if (form.dob) payload.dob = form.dob;
    if (form.gender.trim()) payload.gender = form.gender.trim();
    if (form.managerId !== "none") payload.managerId = form.managerId;
    if (form.createLogin) {
      payload.createLogin = true;
      payload.loginRole = form.loginRole;
      if (form.loginPassword.trim()) payload.loginPassword = form.loginPassword.trim();
    }
    createMutation.mutate(payload);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add employee</DialogTitle>
            <DialogDescription>
              Create a new employee record for {`your organisation`}.
            </DialogDescription>
          </DialogHeader>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="add-first">First name</Label>
            <Input id="add-first" value={form.firstName} onChange={(e) => set("firstName", e.target.value)} placeholder="Ananya" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-last">Last name</Label>
            <Input id="add-last" value={form.lastName} onChange={(e) => set("lastName", e.target.value)} placeholder="Rao" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-email">Work email</Label>
            <Input id="add-email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="ananya.rao@company.in" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-phone">Phone</Label>
            <Input id="add-phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 98XXX XXXXX" />
          </div>
          <div className="space-y-1.5">
            <Label>Department</Label>
            <Select value={form.department} onValueChange={(v) => set("department", v)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-designation">Designation</Label>
            <Input id="add-designation" value={form.designation} onChange={(e) => set("designation", e.target.value)} placeholder="Senior Engineer" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-location">Location</Label>
            <Input id="add-location" value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="Bengaluru" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-join">Join date</Label>
            <Input id="add-join" type="date" value={form.joinDate} onChange={(e) => set("joinDate", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Employment type</Label>
            <Select value={form.employmentType} onValueChange={(v) => set("employmentType", v)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {EMPLOYMENT_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {STATUS_LABELS[t] ?? t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-ctc">Annual CTC (INR)</Label>
            <Input id="add-ctc" inputMode="numeric" value={form.ctc} onChange={(e) => set("ctc", e.target.value)} placeholder="1200000" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-dob">Date of birth</Label>
            <Input id="add-dob" type="date" value={form.dob} onChange={(e) => set("dob", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-gender">Gender</Label>
            <Input id="add-gender" value={form.gender} onChange={(e) => set("gender", e.target.value)} placeholder="Female" />
          </div>
          <div className="col-span-1 space-y-1.5 sm:col-span-2">
            <Label>Reporting manager</Label>
            <ManagerSelect value={form.managerId} onChange={(v) => set("managerId", v)} managersQuery={managersQuery} />
          </div>
          {/* Login access */}
          <div className="col-span-1 space-y-3 rounded-lg border p-3 sm:col-span-2">
            <div className="flex items-start gap-2.5">
              <Checkbox
                id="add-create-login"
                checked={form.createLogin}
                onCheckedChange={(v) => set("createLogin", v === true)}
                className="mt-0.5"
              />
              <div className="grid gap-0.5">
                <Label htmlFor="add-create-login" className="cursor-pointer">
                  Create login access for this employee
                </Label>
                <p className="text-xs text-muted-foreground">
                  They can sign in immediately with this email and password.
                </p>
              </div>
            </div>
            {form.createLogin && (
              <>
                <div className="space-y-1.5">
                  <Label>Login role</Label>
                  <LoginRoleSelect
                    value={form.loginRole}
                    onChange={(v) => set("loginRole", v)}
                    allowElevated={canGrantElevated}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="add-login-password">Password</Label>
                  <LoginPasswordField
                    id="add-login-password"
                    value={form.loginPassword}
                    onChange={(v) => set("loginPassword", v)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Leave blank to auto-generate a strong password — it is shown to you once after creating.
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={createMutation.isPending}>
            {createMutation.isPending && <Loader2 className="animate-spin" />}
            Add employee
          </Button>
        </DialogFooter>
        </DialogContent>
      </Dialog>
      <LoginCreatedDialog login={createdLogin} onClose={() => setCreatedLogin(null)} />
    </>
  );
}

/* ---------------- Login access management ---------------- */

function LoginRoleSelect({
  value,
  onChange,
  allowElevated,
}: {
  value: string;
  onChange: (v: string) => void;
  allowElevated: boolean;
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder="Role" />
      </SelectTrigger>
      <SelectContent>
        {LOGIN_ROLES_BASE.map((r) => (
          <SelectItem key={r.value} value={r.value}>
            {r.label}
          </SelectItem>
        ))}
        {allowElevated &&
          LOGIN_ROLES_ELEVATED.map((r) => (
            <SelectItem key={r.value} value={r.value}>
              {r.label}
            </SelectItem>
          ))}
        {value === "owner" && (
          <SelectItem value="owner" disabled>
            Owner
          </SelectItem>
        )}
      </SelectContent>
    </Select>
  );
}

function LoginPasswordField({
  id,
  value,
  onChange,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const [show, setShow] = useState(true);
  return (
    <div className="flex gap-2">
      <Input
        id={id}
        type={show ? "text" : "password"}
        autoComplete="new-password"
        className="font-mono"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Auto-generated"
      />
      <Button type="button" variant="outline" className="shrink-0" onClick={() => onChange(generatePassword())}>
        <Shuffle /> Generate
      </Button>
      <Button
        type="button"
        variant="outline"
        size="icon"
        className="shrink-0"
        aria-label={show ? "Hide password" : "Show password"}
        onClick={() => setShow((s) => !s)}
      >
        {show ? <EyeOff /> : <Eye />}
      </Button>
    </div>
  );
}

function PasswordRevealBox({ password }: { password: string }) {
  return (
    <div className="space-y-2 rounded-lg border border-emerald-600/30 bg-emerald-600/5 p-3">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
          Password — shown only once
        </span>
        <Button
          variant="outline"
          size="sm"
          className="h-7 px-2 text-[11px]"
          onClick={() => copyToClipboard(password)}
        >
          <Copy className="h-3 w-3" /> Copy
        </Button>
      </div>
      <div className="break-all rounded-md border bg-background px-2.5 py-2 font-mono text-sm">
        {password}
      </div>
      <p className="text-[11px] text-muted-foreground">
        This password is shown only once. Share it securely with the employee.
      </p>
    </div>
  );
}

function LoginCreatedDialog({
  login,
  onClose,
}: {
  login: LoginPayload | null;
  onClose: () => void;
}) {
  return (
    <Dialog open={!!login} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-primary" /> Login created
          </DialogTitle>
          <DialogDescription>
            The employee can now sign in with the email and password below.
          </DialogDescription>
        </DialogHeader>
        {login && (
          <div className="space-y-3">
            <InfoRow icon={Mail} label="Sign-in email" value={login.email} />
            <PasswordRevealBox password={login.password} />
          </div>
        )}
        <DialogFooter>
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ManageAccessDialog({
  open,
  onOpenChange,
  detail,
  user,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  detail: EmployeeDetail;
  user: SessionUser;
}) {
  const qc = useQueryClient();
  const canGrantElevated = user.role === "owner" || user.role === "admin";
  // roleDraft is the in-progress select value; falls back to the employee's live role.
  const [roleDraft, setRoleDraft] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [revealed, setRevealed] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [revokeOpen, setRevokeOpen] = useState(false);

  const role = roleDraft ?? detail.loginRole ?? "employee";

  /** Clear transient dialog state (called from close handlers, not effects). */
  const resetLocalState = () => {
    setRoleDraft(null);
    setPassword("");
    setRevealed(null);
    setError(null);
    setRevokeOpen(false);
  };

  const handleOpenChange = (o: boolean) => {
    if (!o) resetLocalState();
    onOpenChange(o);
  };

  const accessMutation = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      api.post<{
        access: { hasLogin: boolean; email: string; role: string; password: string | null };
      }>(`/api/employees/${detail.id}/access`, body),
    onSuccess: (res, body) => {
      setError(null);
      setPassword("");
      setRoleDraft(null);
      qc.invalidateQueries({ queryKey: qk.employee(detail.id) });
      qc.invalidateQueries({ queryKey: ["employees"] });
      if (body.action === "revoke") {
        toast.success("Access revoked — the employee record is kept.");
        resetLocalState();
        onOpenChange(false);
      } else if (body.action === "role") {
        toast.success("Role updated");
      } else {
        toast.success(body.action === "grant" ? "Login created" : "Password reset");
        setRevealed(res.access.password ?? null);
      }
    },
    onError: (e: Error) => setError(e.message),
  });

  const name = fullName(detail);
  const pending = accessMutation.isPending ? String(accessMutation.variables?.action ?? "") : "";

  const submitPasswordAction = () => {
    const trimmed = password.trim();
    if (trimmed && trimmed.length < 8) {
      setError("Password must be at least 8 characters — or leave it blank to auto-generate.");
      return;
    }
    setError(null);
    accessMutation.mutate(
      detail.hasLogin
        ? { action: "reset", ...(trimmed ? { password: trimmed } : {}) }
        : { action: "grant", role, ...(trimmed ? { password: trimmed } : {}) }
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-primary" />
            {detail.hasLogin ? "Manage access" : "Grant access"} — {name}
          </DialogTitle>
          <DialogDescription>
            {detail.hasLogin
              ? `${detail.loginEmail ?? "This account"} signs in with the ${detail.loginRole ?? "employee"} role.`
              : `${name} cannot sign in yet. Create a login to give them access.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {error && (
            <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-2.5 text-xs text-destructive">
              {error}
            </p>
          )}
          {revealed && <PasswordRevealBox password={revealed} />}

          {detail.hasLogin ? (
            <>
              <div className="space-y-1.5">
                <Label>Reset password</Label>
                <LoginPasswordField id="access-new-password" value={password} onChange={setPassword} />
                <p className="text-xs text-muted-foreground">
                  Optional — leave blank for a server-generated password, shown to you once.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  disabled={accessMutation.isPending}
                  onClick={submitPasswordAction}
                >
                  {pending === "reset" ? <Loader2 className="animate-spin" /> : <RotateCcw />}
                  Reset password
                </Button>
              </div>

              <div className="space-y-1.5">
                <Label>Change role</Label>
                <div className="flex gap-2">
                  <LoginRoleSelect value={role} onChange={setRoleDraft} allowElevated={canGrantElevated} />
                  <Button
                    variant="outline"
                    className="shrink-0"
                    disabled={accessMutation.isPending || role === detail.loginRole}
                    onClick={() => {
                      setError(null);
                      accessMutation.mutate({ action: "role", role });
                    }}
                  >
                    {pending === "role" ? <Loader2 className="animate-spin" /> : <Check />}
                    Save
                  </Button>
                </div>
              </div>

              <div className="space-y-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                <div className="text-xs font-medium text-destructive">Danger zone</div>
                <p className="text-xs text-muted-foreground">
                  Revoke this login. The employee record is kept; they will no longer be able to sign in.
                </p>
                <Button
                  variant="destructive"
                  size="sm"
                  disabled={accessMutation.isPending}
                  onClick={() => setRevokeOpen(true)}
                >
                  <LogOut /> Revoke access
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Role</Label>
                <LoginRoleSelect value={role} onChange={setRoleDraft} allowElevated={canGrantElevated} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="access-password">Password</Label>
                <LoginPasswordField id="access-password" value={password} onChange={setPassword} />
                <p className="text-xs text-muted-foreground">
                  Optional — leave blank for a server-generated password, shown to you once.
                </p>
              </div>
              <Button className="w-full" disabled={accessMutation.isPending} onClick={submitPasswordAction}>
                {pending === "grant" ? <Loader2 className="animate-spin" /> : <UserPlus />}
                Create login
              </Button>
            </div>
          )}
        </div>

        <AlertDialog open={revokeOpen} onOpenChange={setRevokeOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Revoke access for {name}?</AlertDialogTitle>
              <AlertDialogDescription>
                The employee record is kept; they will no longer be able to sign in.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-white hover:bg-destructive/90"
                disabled={accessMutation.isPending}
                onClick={(e) => {
                  e.preventDefault();
                  setError(null);
                  accessMutation.mutate({ action: "revoke" });
                }}
              >
                {accessMutation.isPending && <Loader2 className="animate-spin" />}
                Revoke access
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Edit employee dialog ---------------- */

function EditEmployeeDialog({
  open,
  onOpenChange,
  detail,
  departments,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  detail: EmployeeDetail;
  departments: string[];
}) {
  const qc = useQueryClient();
  const managersQuery = useManagerOptions(open);

  const [form, setForm] = useState(() => ({
    firstName: detail.firstName,
    lastName: detail.lastName,
    phone: detail.phone,
    department: detail.department,
    designation: detail.designation,
    location: detail.location,
    ctc: detail.ctc ? String(detail.ctc) : "",
    status: detail.status as EmployeeStatus,
    managerId: detail.managerId ?? "none",
  }));

  // Re-sync the form when a different employee is opened (render-time adjustment).
  const formSignature = `${detail.id}:${open}`;
  const [lastFormSignature, setLastFormSignature] = useState(formSignature);
  if (lastFormSignature !== formSignature) {
    setLastFormSignature(formSignature);
    setForm({
      firstName: detail.firstName,
      lastName: detail.lastName,
      phone: detail.phone,
      department: detail.department,
      designation: detail.designation,
      location: detail.location,
      ctc: detail.ctc ? String(detail.ctc) : "",
      status: detail.status,
      managerId: detail.managerId ?? "none",
    });
  }

  const set = (key: keyof typeof form, value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  const updateMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.patch<{ employee: EmployeeListItem }>(`/api/employees/${detail.id}`, payload),
    onSuccess: () => {
      toast.success("Employee updated");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["employees"] });
      qc.invalidateQueries({ queryKey: qk.employee(detail.id) });
      invalidateEmployeeDependents(qc);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const submit = () => {
    if (!form.firstName.trim() || !form.lastName.trim() || !form.designation.trim() || !form.department) {
      toast.error("First name, last name, department and designation are required.");
      return;
    }
    const payload: Record<string, unknown> = {
      firstName: form.firstName.trim(),
      lastName: form.lastName.trim(),
      phone: form.phone.trim(),
      department: form.department,
      designation: form.designation.trim(),
      location: form.location.trim(),
      status: form.status,
      managerId: form.managerId === "none" ? null : form.managerId,
    };
    const ctc = Number(form.ctc.replace(/[^\d.]/g, ""));
    if (form.ctc.trim() !== "" && Number.isFinite(ctc) && ctc > 0) payload.ctc = ctc;
    updateMutation.mutate(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit {fullName(detail)}</DialogTitle>
          <DialogDescription>Update the employee record. Changes apply immediately.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="edit-first">First name</Label>
            <Input id="edit-first" value={form.firstName} onChange={(e) => set("firstName", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-last">Last name</Label>
            <Input id="edit-last" value={form.lastName} onChange={(e) => set("lastName", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-phone">Phone</Label>
            <Input id="edit-phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Department</Label>
            <Select value={form.department} onValueChange={(v) => set("department", v)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-designation">Designation</Label>
            <Input id="edit-designation" value={form.designation} onChange={(e) => set("designation", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-location">Location</Label>
            <Input id="edit-location" value={form.location} onChange={(e) => set("location", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-ctc">Annual CTC (INR)</Label>
            <Input id="edit-ctc" inputMode="numeric" value={form.ctc} onChange={(e) => set("ctc", e.target.value)} placeholder="1200000" />
          </div>
          <div className="space-y-1.5">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {EMPLOYEE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s] ?? s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-1 space-y-1.5 sm:col-span-2">
            <Label>Reporting manager</Label>
            <ManagerSelect
              value={form.managerId}
              onChange={(v) => set("managerId", v)}
              excludeId={detail.id}
              managersQuery={managersQuery}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={updateMutation.isPending}>
            {updateMutation.isPending && <Loader2 className="animate-spin" />}
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Import wizard ---------------- */

function ImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const qc = useQueryClient();
  const [csv, setCsv] = useState("");
  const [result, setResult] = useState<BulkImportResponse | null>(null);
  const [createLogins, setCreateLogins] = useState(true);
  const [defaultPassword, setDefaultPassword] = useState("");

  // Reset the form whenever the dialog closes (render-time adjustment).
  if (!open && (csv !== "" || result !== null || !createLogins || defaultPassword !== "")) {
    setCsv("");
    setResult(null);
    setCreateLogins(true);
    setDefaultPassword("");
  }

  const parsedCount = useMemo(() => {
    let rows = parseCsv(csv);
    if (rows.length === 0) return 0;
    if (rows[0].join(",").toLowerCase().includes("email")) rows = rows.slice(1);
    return rows.filter((r) => r.length >= 4 && r[0] && r[1]).length;
  }, [csv]);

  const importMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.post<BulkImportResponse>("/api/employees/import", payload),
    onSuccess: (data) => {
      setResult(data);
      qc.invalidateQueries({ queryKey: ["employees"] });
      invalidateEmployeeDependents(qc);
      toast.success(
        `Import finished — ${data.created} created${data.failed > 0 ? `, ${data.failed} failed` : ""}`
      );
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const submit = () => {
    let rows = parseCsv(csv);
    if (rows.length === 0) {
      toast.error("Paste some CSV rows first.");
      return;
    }
    if (rows[0].join(",").toLowerCase().includes("email")) rows = rows.slice(1);
    const mapped = rows
      .filter((r) => r.length >= 4 && r[0] && r[1])
      .map((r) => {
        const ctcRaw = (r[4] ?? "").replace(/[₹,\s]/g, "");
        const ctc = Number(ctcRaw);
        return {
          name: r[0],
          email: r[1],
          department: r[2],
          designation: r[3],
          ...(Number.isFinite(ctc) && ctc > 0 ? { ctc } : {}),
          ...(r[5] ? { joinDate: r[5] } : {}),
          ...(r[6] ? { phone: r[6] } : {}),
          ...(r[7] ? { location: r[7] } : {}),
        };
      });
    if (mapped.length === 0) {
      toast.error(`No valid rows found. Expected columns: ${IMPORT_COLUMNS}`);
      return;
    }
    if (createLogins && defaultPassword.length > 0 && defaultPassword.length < 8) {
      toast.error("The default password must be at least 8 characters.");
      return;
    }
    importMutation.mutate({
      rows: mapped,
      ...(createLogins ? { createLogins: true, ...(defaultPassword ? { defaultPassword } : {}) } : {}),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Import employees</DialogTitle>
          <DialogDescription>
            Paste CSV rows with columns: <span className="font-mono text-xs">{IMPORT_COLUMNS}</span>
            . The header row is detected and skipped automatically.
          </DialogDescription>
        </DialogHeader>

        {!result ? (
          <>
            <div className="space-y-1.5">
              <Label htmlFor="import-csv">CSV data</Label>
              <Textarea
                id="import-csv"
                value={csv}
                onChange={(e) => setCsv(e.target.value)}
                rows={10}
                className="font-mono text-xs"
                placeholder={`${IMPORT_COLUMNS}\nRohan Deshpande,rohan.d@company.in,Engineering,Backend Engineer,1200000,2025-01-06,+91 98XXX XXXXX,Bengaluru`}
              />
              <p className="text-xs text-muted-foreground">
                {parsedCount} valid {parsedCount === 1 ? "row" : "rows"} detected
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={() => setCsv(SAMPLE_CSV)}>
                <ListChecks /> Load sample
              </Button>
              <Button variant="outline" size="sm" onClick={() => downloadText("employee-import-template.csv", `${IMPORT_COLUMNS}\n`)}>
                <Download /> Download template
              </Button>
            </div>
            <div className="space-y-3 rounded-lg border bg-muted/30 p-3">
              <div className="flex items-start gap-2">
                <Checkbox
                  id="import-logins"
                  checked={createLogins}
                  onCheckedChange={(v) => setCreateLogins(v === true)}
                  className="mt-0.5"
                />
                <div className="grid gap-1">
                  <Label htmlFor="import-logins" className="text-sm font-medium">
                    Create login access for every imported employee
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Each employee can sign in immediately with their email and the shared initial password below.
                  </p>
                </div>
              </div>
              {createLogins && (
                <div className="grid gap-1.5 pl-6">
                  <Label htmlFor="import-password">Shared initial password (optional)</Label>
                  <Input
                    id="import-password"
                    value={defaultPassword}
                    onChange={(e) => setDefaultPassword(e.target.value)}
                    className="font-mono text-xs"
                    placeholder="Leave blank to auto-generate a strong password"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Everyone should change it from Settings → Security after their first sign-in.
                  </p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={submit} disabled={importMutation.isPending || parsedCount === 0}>
                {importMutation.isPending && <Loader2 className="animate-spin" />}
                Import {parsedCount > 0 ? parsedCount : ""} {parsedCount === 1 ? "employee" : "employees"}
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">{result.created} created</Badge>
              {result.failed > 0 && <Badge variant="destructive">{result.failed} failed</Badge>}
              {result.loginsCreated != null && result.loginsCreated > 0 && (
                <Badge className="bg-primary/10 text-primary hover:bg-primary/10">
                  {result.loginsCreated} logins created
                </Badge>
              )}
            </div>
            {result.loginPassword && (
              <div className="rounded-lg border bg-muted/40 p-3">
                <p className="text-xs font-semibold">Shared initial password</p>
                <div className="mt-2 flex items-center gap-2">
                  <code className="flex-1 truncate rounded bg-card px-2 py-1.5 font-mono text-xs">
                    {result.loginPassword}
                  </code>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(result.loginPassword ?? "");
                      toast.success("Copied");
                    }}
                  >
                    Copy
                  </Button>
                </div>
                <p className="mt-2 text-[11px] text-muted-foreground">
                  Shown only once — share it securely with your team. Employees can change it under Settings → Security.
                </p>
              </div>
            )}
            <div className="scrollbar-thin max-h-72 overflow-auto rounded-lg border">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/50 text-left text-xs text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 font-medium">#</th>
                    <th className="px-3 py-2 font-medium">Name</th>
                    <th className="px-3 py-2 font-medium">Email</th>
                    <th className="px-3 py-2 font-medium">Status</th>
                    <th className="px-3 py-2 font-medium">Message</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {result.rows.map((r) => (
                    <tr key={`${r.row}-${r.email}`} className={r.status === "error" ? "bg-destructive/5" : undefined}>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{r.row}</td>
                      <td className="px-3 py-2">{r.name || "—"}</td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{r.email || "—"}</td>
                      <td className="px-3 py-2">
                        {r.status === "ok" ? (
                          <Badge variant="secondary">OK</Badge>
                        ) : (
                          <Badge variant="destructive">Error</Badge>
                        )}
                      </td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{r.message ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setResult(null);
                  setCsv("");
                }}
              >
                <Upload /> Import more
              </Button>
              <Button onClick={() => onOpenChange(false)}>Done</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

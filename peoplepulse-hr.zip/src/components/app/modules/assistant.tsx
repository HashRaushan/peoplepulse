"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { useAppStore } from "@/lib/store";
import { cn, fmtDateTime } from "@/lib/hr-utils";
import { AI_SUGGESTIONS } from "@/lib/constants";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Sparkles, Send, Loader2, Trash2, ShieldCheck, User, RotateCcw } from "lucide-react";
import ReactMarkdown from "react-markdown";
import type { AiChatMessageDto } from "@/lib/types";

export function AssistantModule() {
  const { user } = useAppStore();
  const qc = useQueryClient();
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.aiHistory,
    queryFn: () => api.get<{ items: AiChatMessageDto[] }>("/api/ai/history"),
  });

  // Model badge config (route maintained separately; badge falls back to "AI").
  const configQuery = useQuery({
    queryKey: ["ai-config"],
    queryFn: () => api.get<{ configured: boolean; modelLabel: string }>("/api/ai/config"),
  });

  const messages = data?.items ?? [];

  const chatMutation = useMutation({
    mutationFn: (message: string) => api.post<{ reply: string }>("/api/ai/chat", { message }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.aiHistory });
    },
    onError: (e) => {
      toast.error(e instanceof Error ? e.message : "The assistant is unavailable right now.");
    },
    onSettled: () => setThinking(false),
  });

  const clearMutation = useMutation({
    mutationFn: () => api.delete("/api/ai/history"),
    onSuccess: () => {
      toast.success("Conversation cleared");
      qc.invalidateQueries({ queryKey: qk.aiHistory });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, thinking]);

  function send(text: string) {
    const message = text.trim();
    if (!message || thinking) return;
    setInput("");
    setThinking(true);
    chatMutation.mutate(message);
  }

  const isStaff = user && ["owner", "admin", "hr", "manager"].includes(user.role);

  return (
    <div className="flex h-[calc(100vh-9.5rem)] flex-col space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <Sparkles className="h-6 w-6 text-primary" /> AI Assistant
          </h1>
          <p className="text-sm text-muted-foreground">
            Pulse answers from live, authorised data — {isStaff ? "organisation aggregates for HR" : "your own information"}.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge
            variant="outline"
            className="gap-1.5 border-primary/30 bg-primary/5 px-2.5 py-1 text-primary"
            title="Powered by OpenRouter"
          >
            <Sparkles className="h-3 w-3" /> Pulse AI Pro · {configQuery.data?.modelLabel ?? "AI"}
          </Badge>
          {messages.length > 0 && (
            <Button variant="outline" size="sm" onClick={() => clearMutation.mutate()} disabled={clearMutation.isPending}>
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" /> New conversation
            </Button>
          )}
        </div>
      </div>

      <Card className="flex min-h-0 flex-1 flex-col">
        <CardContent className="flex min-h-0 flex-1 flex-col p-0">
          {/* Messages */}
          <div className="min-h-0 flex-1 overflow-y-auto scrollbar-thin p-4 md:p-6">
            {isError && (
              <div className="mx-auto mb-4 flex max-w-2xl flex-wrap items-center justify-between gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                <span className="min-w-0">
                  Could not load your conversation history.
                  {error instanceof Error ? ` (${error.message})` : ""}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 shrink-0 px-2 text-xs"
                  onClick={() => refetch()}
                >
                  Retry
                </Button>
              </div>
            )}
            {isLoading && <Skeleton className="h-20" />}
            {!isLoading && !isError && messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center gap-4 py-10 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                  <Sparkles className="h-7 w-7 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold">Ask Pulse anything about HR here</p>
                  <p className="mt-1 max-w-md text-xs text-muted-foreground">
                    It knows your {isStaff ? "organisation's headcount, pending approvals, payroll status and policies" : "leave balances, payslips, attendance and company policies"} — and always says so when it does not know.
                  </p>
                </div>
                <div className="flex max-w-lg flex-wrap justify-center gap-2">
                  {AI_SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      onClick={() => send(s)}
                      className="rounded-full border bg-card px-3 py-1.5 text-[11px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mx-auto max-w-2xl space-y-4">
              {messages.map((m) => (
                <div key={m.id} className={cn("flex gap-3", m.role === "user" && "flex-row-reverse")}>
                  <div
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                      m.role === "assistant" ? "bg-primary text-primary-foreground" : "bg-muted"
                    )}
                  >
                    {m.role === "assistant" ? <Sparkles className="h-4 w-4" /> : <User className="h-4 w-4 text-muted-foreground" />}
                  </div>
                  <div className={cn("max-w-[85%]", m.role === "user" && "text-right")}>
                    <div
                      className={cn(
                        "inline-block rounded-2xl px-4 py-2.5 text-left text-sm leading-relaxed",
                        m.role === "assistant"
                          ? "rounded-tl-sm bg-muted"
                          : "rounded-tr-sm bg-primary text-primary-foreground"
                      )}
                    >
                      {m.role === "assistant" ? (
                        <ReactMarkdown
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            ul: ({ children }) => <ul className="mb-2 list-disc pl-4 last:mb-0">{children}</ul>,
                            ol: ({ children }) => <ol className="mb-2 list-decimal pl-4 last:mb-0">{children}</ol>,
                            li: ({ children }) => <li className="mb-0.5">{children}</li>,
                            strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                            code: ({ children }) => (
                              <code className="rounded bg-background/70 px-1 py-0.5 font-mono text-[12px]">{children}</code>
                            ),
                          }}
                        >
                          {m.content}
                        </ReactMarkdown>
                      ) : (
                        <span className="whitespace-pre-wrap">{m.content}</span>
                      )}
                    </div>
                    <p className="mt-1 text-[10px] text-muted-foreground">{fmtDateTime(m.createdAt)}</p>
                  </div>
                </div>
              ))}

              {thinking && (
                <div className="flex gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div className="flex items-center gap-1.5 rounded-2xl rounded-tl-sm bg-muted px-4 py-3">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:0ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:150ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:300ms]" />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          </div>

          {/* Composer */}
          <div className="border-t p-3 md:p-4">
            <form
              className="mx-auto flex max-w-2xl items-end gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
            >
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send(input);
                  }
                }}
                rows={1}
                placeholder="Ask about leave, payroll, policies, attendance…"
                className="max-h-32 min-h-11 flex-1 resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
                aria-label="Message"
              />
              <Button type="submit" size="icon" className="h-11 w-11 shrink-0 rounded-xl" disabled={!input.trim() || thinking} aria-label="Send message">
                {thinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </form>
            <p className="mx-auto mt-2 flex max-w-2xl items-center gap-1.5 text-[10px] text-muted-foreground">
              <ShieldCheck className="h-3 w-3 shrink-0 text-primary" />
              Permission-aware: answers use only data you are authorised to see. Pulse cannot take actions — approvals and changes happen in the app.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

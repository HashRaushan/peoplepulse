"use client";

/**
 * PeoplePulse HR — Announcements module.
 * Company-wide feed (pinned first) with acknowledge tracking, plus a
 * publish form for owner/admin/hr and a categories legend for everyone.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCheck, Loader2, Megaphone, Pin, Send, Sparkles } from "lucide-react";
import type { AnnouncementDto, Role, SessionUser } from "@/lib/types";
import { STATUS_LABELS } from "@/lib/constants";
import { api, qk } from "@/lib/api-client";
import { ago, cn } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

const HR_GROUP: Role[] = ["owner", "admin", "hr"];
const ANNOUNCEMENT_CATEGORIES = ["company", "department", "policy", "event", "celebration"];

/** Feed item; the API reports whether the signed-in user has already acknowledged. */
type AnnouncementWithAck = AnnouncementDto & { hasAcked?: boolean };
type AnnouncementsResponse = { items: AnnouncementWithAck[] };

const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  company: "Org-wide news and milestones",
  department: "Updates for specific teams",
  policy: "Handbook and process changes",
  event: "Offsites, town halls and meetups",
  celebration: "Birthdays, work anniversaries and wins",
};

function categoryBadge(category: string) {
  const label = STATUS_LABELS[category] ?? category;
  switch (category) {
    case "company":
      return <Badge variant="secondary">{label}</Badge>;
    case "policy":
      return <Badge variant="outline">{label}</Badge>;
    case "event":
      return <Badge variant="secondary">{label}</Badge>;
    default:
      return <Badge variant="default">{label}</Badge>;
  }
}

export function AnnouncementsModule() {
  const { user } = useAppStore();
  if (!user) return null;
  return <AnnouncementsInner user={user} />;
}

function AnnouncementsInner({ user }: { user: SessionUser }) {
  const queryClient = useQueryClient();
  const isHrGroup = HR_GROUP.includes(user.role);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [ackedIds, setAckedIds] = useState<Set<string>>(new Set());

  const feedQuery = useQuery({
    queryKey: qk.announcements,
    queryFn: () => api.get<AnnouncementsResponse>("/api/announcements"),
  });

  useEffect(() => {
    if (feedQuery.error) toast.error(feedQuery.error.message);
  }, [feedQuery.error]);

  const sorted = useMemo(() => {
    const items = [...(feedQuery.data?.items ?? [])];
    items.sort(
      (a, b) =>
        Number(b.pinned) - Number(a.pinned) ||
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return items;
  }, [feedQuery.data]);

  const toggleExpanded = (id: string) =>
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const ackMutation = useMutation({
    mutationFn: (id: string) =>
      api.post<{ item: AnnouncementWithAck }>(`/api/announcements/${id}/ack`),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: qk.announcements });
      const prev = queryClient.getQueryData<AnnouncementsResponse>(qk.announcements);
      queryClient.setQueryData<AnnouncementsResponse>(qk.announcements, (old) =>
        old
          ? {
              items: old.items.map((a) =>
                a.id === id
                  ? { ...a, acknowledgedCount: a.acknowledgedCount + 1, hasAcked: true }
                  : a
              ),
            }
          : old
      );
      return { prev, id };
    },
    onError: (error: Error, _id, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(qk.announcements, ctx.prev);
      if (ctx?.id) {
        setAckedIds((prev) => {
          const next = new Set(prev);
          next.delete(ctx.id as string);
          return next;
        });
      }
      toast.error(error.message);
    },
    onSuccess: () => toast.success("Thanks for acknowledging"),
  });

  const acknowledge = (id: string) => {
    setAckedIds((prev) => new Set(prev).add(id));
    ackMutation.mutate(id);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Announcements</h1>
        <p className="text-sm text-muted-foreground">
          {sorted.length > 0
            ? `${sorted.length} ${sorted.length === 1 ? "announcement" : "announcements"} · ${user.tenantName}`
            : `Company news and updates · ${user.tenantName}`}
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Feed */}
        <div className="space-y-4 lg:col-span-2">
          {feedQuery.isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-48 rounded-xl" />
            ))
          ) : feedQuery.isError ? (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
              <Megaphone className="h-8 w-8 text-muted-foreground" />
              <div>
                <div className="font-semibold">Could not load announcements</div>
                <p className="text-sm text-muted-foreground">{feedQuery.error.message}</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => feedQuery.refetch()}>
                Try again
              </Button>
            </div>
          ) : sorted.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Megaphone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="font-semibold">No announcements yet</div>
                <p className="text-sm text-muted-foreground">
                  {isHrGroup
                    ? "Publish the first one to keep everyone in the loop."
                    : "When HR shares news, it will show up here."}
                </p>
              </div>
              {isHrGroup && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    document
                      .getElementById("publish-announcement")
                      ?.scrollIntoView({ behavior: "smooth", block: "center" })
                  }
                >
                  <Megaphone /> Publish an announcement
                </Button>
              )}
            </div>
          ) : (
            sorted.map((a) => {
              const isLong = a.body.length > 280 || a.body.split("\n").length > 4;
              const expanded = expandedIds.has(a.id);
              // Server-truth (hasAcked) with optimistic local set for instant feedback.
              const acked = ackedIds.has(a.id) || a.hasAcked === true;
              return (
                <Card
                  key={a.id}
                  className={cn("gap-0 py-4", a.pinned && "border-primary/40")}
                >
                  <CardHeader className="px-4 pb-3">
                    <div className="flex flex-wrap items-center gap-2">
                      {categoryBadge(a.category)}
                      {a.pinned && (
                        <Badge variant="default" className="gap-1">
                          <Pin className="h-3 w-3" /> Pinned
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-base leading-snug">{a.title}</CardTitle>
                    <CardDescription>
                      {a.authorName} · {ago(a.createdAt)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 px-4">
                    <p
                      className={cn(
                        "text-sm whitespace-pre-line text-muted-foreground",
                        !expanded && isLong && "line-clamp-4"
                      )}
                    >
                      {a.body}
                    </p>
                    {isLong && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 text-xs text-primary"
                        onClick={() => toggleExpanded(a.id)}
                      >
                        {expanded ? "Show less" : "Show more"}
                      </Button>
                    )}
                    <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-3">
                      <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <CheckCheck className="h-3.5 w-3.5" />
                        {a.acknowledgedCount} acknowledged
                      </span>
                      {acked ? (
                        <Badge variant="secondary" className="gap-1">
                          <CheckCheck className="h-3 w-3" /> Acknowledged
                        </Badge>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => acknowledge(a.id)}
                          disabled={ackMutation.isPending}
                        >
                          {ackMutation.isPending && ackMutation.variables === a.id ? (
                            <Loader2 className="animate-spin" />
                          ) : (
                            <CheckCheck />
                          )}
                          Acknowledge
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {isHrGroup && <PublishCard user={user} />}
          <Card className="gap-0 py-4">
            <CardHeader className="px-4 pb-3">
              <CardTitle className="text-sm">Categories</CardTitle>
              <CardDescription>What each announcement type means.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2.5 px-4">
              {ANNOUNCEMENT_CATEGORIES.map((c) => (
                <div key={c} className="flex items-center justify-between gap-2">
                  {categoryBadge(c)}
                  <span className="text-right text-xs text-muted-foreground">
                    {CATEGORY_DESCRIPTIONS[c]}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Publish form (HR only) ---------------- */

function PublishCard({ user }: { user: SessionUser }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    title: "",
    category: "company",
    body: "",
    pinned: false,
  });

  const publishMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.post<{ item: AnnouncementDto }>("/api/announcements", payload),
    onSuccess: () => {
      toast.success("Announcement published");
      setForm({ title: "", category: "company", body: "", pinned: false });
      qc.invalidateQueries({ queryKey: qk.announcements });
      qc.invalidateQueries({ queryKey: qk.dashboard });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Draft the announcement body with AI (fills the Message textarea; user can edit before posting).
  const draftMutation = useMutation({
    mutationFn: (topic: string) =>
      api.post<{ text: string }>("/api/ai/draft", { kind: "announcement", topic }),
    onSuccess: (data) => {
      setForm((f) => ({ ...f, body: data.text }));
      toast.success("Draft ready — review and edit before publishing");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const submit = () => {
    if (!form.title.trim() || !form.body.trim()) {
      toast.error("A title and message are required.");
      return;
    }
    publishMutation.mutate({
      title: form.title.trim(),
      body: form.body.trim(),
      category: form.category,
      pinned: form.pinned,
    });
  };

  return (
    <Card id="publish-announcement" className="gap-0 py-4">
      <CardHeader className="px-4 pb-3">
        <CardTitle className="text-sm">Publish announcement</CardTitle>
        <CardDescription>Reach everyone at {user.tenantName}.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 px-4">
        <div className="space-y-1.5">
          <Label htmlFor="ann-title">Title</Label>
          <Input
            id="ann-title"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            placeholder="e.g. Quarterly all-hands this Friday"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Category</Label>
          <Select
            value={form.category}
            onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ANNOUNCEMENT_CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {STATUS_LABELS[c] ?? c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <Label htmlFor="ann-body">Message</Label>
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="h-7 gap-1.5 px-2.5 text-xs"
              disabled={draftMutation.isPending}
              onClick={() => draftMutation.mutate(form.title.trim() || "a company update")}
            >
              {draftMutation.isPending ? (
                <Loader2 className="animate-spin" />
              ) : (
                <Sparkles />
              )}
              {draftMutation.isPending ? "Drafting…" : "Draft with AI"}
            </Button>
          </div>
          <Textarea
            id="ann-body"
            rows={5}
            value={form.body}
            onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
            placeholder="Share the details your team should know…"
          />
        </div>
        <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
          <div>
            <div className="text-sm font-medium">Pin to top</div>
            <div className="text-xs text-muted-foreground">Pinned posts stay first in the feed.</div>
          </div>
          <Switch
            checked={form.pinned}
            onCheckedChange={(v) => setForm((f) => ({ ...f, pinned: v }))}
            aria-label="Pin to top"
          />
        </div>
        <Button className="w-full" onClick={submit} disabled={publishMutation.isPending}>
          {publishMutation.isPending ? (
            <Loader2 className="animate-spin" />
          ) : (
            <Send />
          )}
          Publish
        </Button>
      </CardContent>
    </Card>
  );
}

"use client";

/**
 * PeoplePulse HR — Training & Learning module.
 * Course library with self-enrollment and progress tracking (everyone), my
 * learning history, and course catalog management (owner/admin/hr).
 */

import { useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  BadgeCheck,
  BookOpen,
  GraduationCap,
  Pencil,
  Plus,
  ShieldCheck,
  Shuffle,
  Target,
  Trash2,
  Users,
  Wifi,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { TRAINING_CATEGORIES } from "@/lib/constants";
import { cn, fmtDate } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { MyLearningDto, TrainingCourseDto } from "@/lib/types";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local types & helpers =====================

interface TrainingStats {
  published: number;
  mandatory: number;
  myActive: number;
  myCompleted: number;
  completionRate: number;
}

interface TrainingCoursesResponse {
  courses: TrainingCourseDto[];
  stats: TrainingStats;
}

interface CourseFormValues {
  title: string;
  description: string;
  category: string;
  mode: string;
  durationHours: string;
  provider: string;
  mandatory: boolean;
}

interface ProgressTarget {
  enrollmentId: string;
  title: string;
  progress: number;
}

const COURSE_MODES: { value: string; label: string; icon: typeof Wifi }[] = [
  { value: "online", label: "Online", icon: Wifi },
  { value: "in_person", label: "In Person", icon: Users },
  { value: "hybrid", label: "Hybrid", icon: Shuffle },
];

const EMPTY_FORM: CourseFormValues = {
  title: "",
  description: "",
  category: "General",
  mode: "online",
  durationHours: "1",
  provider: "",
  mandatory: false,
};

function modeMeta(mode: string): { label: string; icon: typeof Wifi } {
  return COURSE_MODES.find((m) => m.value === mode) ?? { label: mode || "—", icon: BookOpen };
}

/** Enrollment status -> short label + badge classes (enrolled muted / amber / emerald). */
function enrollmentStatus(status: string): { label: string; className: string } {
  switch (status) {
    case "in_progress":
      return {
        label: "In Progress",
        className: "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300",
      };
    case "completed":
      return {
        label: "Completed",
        className:
          "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300",
      };
    default:
      return { label: "Enrolled", className: "" };
  }
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function invalidateTraining(qc: QueryClient) {
  void qc.invalidateQueries({ queryKey: qk.trainingCourses() });
  void qc.invalidateQueries({ queryKey: qk.myLearning });
}

// ===================== Module =====================

export function TrainingModule() {
  const { user } = useAppStore();
  const isMgr = !!user && ["owner", "admin", "hr"].includes(user.role);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Training</h1>
        <p className="text-sm text-muted-foreground">
          {isMgr
            ? "Publish courses, track completions and manage the learning catalogue."
            : "Browse the course library, enroll yourself and track your learning progress."}
        </p>
      </div>

      <Tabs defaultValue="library">
        <TabsList>
          <TabsTrigger value="library">Library</TabsTrigger>
          <TabsTrigger value="mine">My learning</TabsTrigger>
          {isMgr ? <TabsTrigger value="manage">Manage</TabsTrigger> : null}
        </TabsList>
        <TabsContent value="library" className="mt-4">
          <LibraryView isMgr={isMgr} canEnroll={!!user?.employeeId} />
        </TabsContent>
        <TabsContent value="mine" className="mt-4">
          <MyLearningView />
        </TabsContent>
        {isMgr ? (
          <TabsContent value="manage" className="mt-4">
            <ManageView />
          </TabsContent>
        ) : null}
      </Tabs>
    </div>
  );
}

// ===================== Library (everyone) =====================

function LibraryView({ isMgr, canEnroll }: { isMgr: boolean; canEnroll: boolean }) {
  const query = useQuery({
    queryKey: qk.trainingCourses(),
    queryFn: () => api.get<TrainingCoursesResponse>("/api/training/courses"),
  });

  const [progressTarget, setProgressTarget] = useState<ProgressTarget | null>(null);

  const courses = query.data?.courses ?? [];

  return (
    <div className="space-y-4">
      {query.isPending ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : courses.length === 0 ? (
        <EmptyState
          icon={<GraduationCap className="h-8 w-8 text-muted-foreground/50" />}
          title="No courses in the library yet"
          description={
            isMgr
              ? "Create your first course from the Manage tab to start building the library."
              : "Your HR team has not published any training courses yet."
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {courses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              isMgr={isMgr}
              canEnroll={canEnroll}
              onOpenProgress={(enrollment) =>
                setProgressTarget({
                  enrollmentId: enrollment.id,
                  title: course.title,
                  progress: enrollment.progress,
                })
              }
            />
          ))}
        </div>
      )}

      <UpdateProgressDialog target={progressTarget} onClose={() => setProgressTarget(null)} />
    </div>
  );
}

function CourseCard({
  course,
  isMgr,
  canEnroll,
  onOpenProgress,
}: {
  course: TrainingCourseDto;
  isMgr: boolean;
  canEnroll: boolean;
  onOpenProgress: (enrollment: NonNullable<TrainingCourseDto["myEnrollment"]>) => void;
}) {
  const qc = useQueryClient();
  const meta = modeMeta(course.mode);
  const ModeIcon = meta.icon;
  const mine = course.myEnrollment;

  const enroll = useMutation({
    mutationFn: () => api.post<{ enrollment: MyLearningDto }>(`/api/training/courses/${course.id}/enroll`),
    onSuccess: () => {
      invalidateTraining(qc);
      toast.success(`Enrolled in "${course.title}"`);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <Card
      className={cn(
        "flex h-full flex-col gap-3 py-4",
        !course.published && "border-dashed opacity-75"
      )}
    >
      <CardHeader className="px-4">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="outline">{course.category}</Badge>
          {course.mandatory ? (
            <Badge
              variant="outline"
              className="border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300"
            >
              Mandatory
            </Badge>
          ) : null}
          {!course.published ? <Badge variant="secondary">Unpublished</Badge> : null}
        </div>
        <CardTitle className="text-base leading-snug">{course.title}</CardTitle>
        <CardDescription className="line-clamp-2 min-h-10">
          {course.description || "No description provided."}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col justify-between gap-4 px-4">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <ModeIcon className="h-3.5 w-3.5" aria-hidden />
            {meta.label}
          </span>
          <span className="tabular-nums">{course.durationHours}h</span>
          {course.provider ? <span className="truncate">· {course.provider}</span> : null}
        </div>

        {isMgr ? (
          <p className="text-xs text-muted-foreground tabular-nums">
            {course.enrolledCount} enrolled · {course.completedCount} completed
          </p>
        ) : null}

        <div className="space-y-2">
          {!mine ? (
            <Button
              size="sm"
              className="w-full"
              disabled={enroll.isPending || !canEnroll}
              title={canEnroll ? undefined : "Your account is not linked to an employee record"}
              onClick={() => enroll.mutate()}
            >
              {enroll.isPending ? "Enrolling…" : "Enroll"}
            </Button>
          ) : mine.status === "completed" ? (
            <div
              className={cn(
                "flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm",
                "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300"
              )}
            >
              <span className="flex items-center gap-1.5 font-medium">
                <BadgeCheck className="h-4 w-4" aria-hidden /> Completed
              </span>
              {mine.score !== null ? (
                <span className="tabular-nums">Score {mine.score}/100</span>
              ) : null}
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{enrollmentStatus(mine.status).label}</span>
                <span className="tabular-nums font-medium text-foreground">{mine.progress}%</span>
              </div>
              <Progress className="h-2" value={mine.progress} />
              <Button size="sm" variant="outline" className="w-full" onClick={() => onOpenProgress(mine)}>
                Update progress
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ===================== Update progress dialog =====================

function UpdateProgressDialog({ target, onClose }: { target: ProgressTarget | null; onClose: () => void }) {
  return (
    <Dialog open={!!target} onOpenChange={(open) => !open && onClose()}>
      {target ? <UpdateProgressForm key={target.enrollmentId} target={target} onClose={onClose} /> : null}
    </Dialog>
  );
}

function UpdateProgressForm({ target, onClose }: { target: ProgressTarget; onClose: () => void }) {
  const qc = useQueryClient();
  const [progress, setProgress] = useState(target.progress);
  const [score, setScore] = useState("");

  const save = useMutation({
    mutationFn: (v: { id: string; progress: number }) =>
      api.patch<{ enrollment: MyLearningDto }>(`/api/training/enrollments/${v.id}`, { progress: v.progress }),
    onSuccess: (data) => {
      invalidateTraining(qc);
      toast.success(
        data.enrollment.status === "completed"
          ? "Course marked as complete"
          : `Progress saved — ${data.enrollment.progress}%`
      );
      onClose();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const complete = useMutation({
    mutationFn: (v: { id: string; score?: number }) =>
      api.patch<{ enrollment: MyLearningDto }>(`/api/training/enrollments/${v.id}`, {
        action: "complete",
        ...(v.score !== undefined ? { score: v.score } : {}),
      }),
    onSuccess: () => {
      invalidateTraining(qc);
      toast.success("Course marked as complete");
      onClose();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitComplete() {
    const trimmed = score.trim();
    if (trimmed !== "") {
      const n = Number(trimmed);
      if (!Number.isInteger(n) || n < 0 || n > 100) {
        toast.error("Score must be an integer between 0 and 100.");
        return;
      }
      complete.mutate({ id: target.enrollmentId, score: n });
    } else {
      complete.mutate({ id: target.enrollmentId });
    }
  }

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Update progress</DialogTitle>
        <DialogDescription>{target.title}</DialogDescription>
      </DialogHeader>
      <div className="space-y-5">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="course-progress">Progress</Label>
            <span className="text-sm font-semibold tabular-nums">{progress}%</span>
          </div>
          <Slider
            id="course-progress"
            value={[progress]}
            onValueChange={(v) => setProgress(v[0] ?? 0)}
            min={0}
            max={100}
            step={5}
            aria-label="Course progress percentage"
          />
          <p className="text-xs text-muted-foreground">
            Reaching 100% marks the course as completed automatically.
          </p>
        </div>
        <div className="space-y-2 rounded-lg border p-3">
          <Label htmlFor="course-score">Mark complete</Label>
          <div className="flex gap-2">
            <Input
              id="course-score"
              type="number"
              min={0}
              max={100}
              placeholder="Score (optional)"
              value={score}
              onChange={(e) => setScore(e.target.value)}
              className="flex-1"
            />
            <Button
              variant="outline"
              className="border-emerald-200 text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800 dark:border-emerald-900 dark:text-emerald-300 dark:hover:bg-emerald-950"
              disabled={complete.isPending || save.isPending}
              onClick={submitComplete}
            >
              Mark complete
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Optionally record an assessment score between 0 and 100.
          </p>
        </div>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose} disabled={save.isPending || complete.isPending}>
          Cancel
        </Button>
        <Button
          disabled={save.isPending || complete.isPending}
          onClick={() => save.mutate({ id: target.enrollmentId, progress })}
        >
          {save.isPending ? "Saving…" : "Save progress"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

// ===================== My learning (everyone) =====================

function MyLearningView() {
  const query = useQuery({
    queryKey: qk.myLearning,
    queryFn: () => api.get<{ items: MyLearningDto[] }>("/api/training/me"),
  });

  const [progressTarget, setProgressTarget] = useState<ProgressTarget | null>(null);

  const items = query.data?.items ?? [];
  const completed = items.filter((i) => i.status === "completed").length;

  return (
    <div className="space-y-4">
      {items.length > 0 ? (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <span>
            <span className="font-semibold text-foreground tabular-nums">{items.length}</span> course
            {items.length === 1 ? "" : "s"} in progress or completed
          </span>
          <span>
            <span className="font-semibold text-emerald-600 tabular-nums dark:text-emerald-400">{completed}</span>{" "}
            completed
          </span>
        </div>
      ) : null}

      {query.isPending ? (
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-44 rounded-xl" />
          ))}
        </div>
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<GraduationCap className="h-8 w-8 text-muted-foreground/50" />}
          title="No enrollments yet"
          description="Browse the library and enroll in a course — your progress will show up here."
        />
      ) : (
        <div className="max-h-[520px] overflow-y-auto scrollbar-thin pr-1">
          <div className="grid gap-4 md:grid-cols-2">
            {items.map((item) => (
              <MyLearningCard key={item.id} item={item} onOpenProgress={setProgressTarget} />
            ))}
          </div>
        </div>
      )}

      <UpdateProgressDialog target={progressTarget} onClose={() => setProgressTarget(null)} />
    </div>
  );
}

function MyLearningCard({
  item,
  onOpenProgress,
}: {
  item: MyLearningDto;
  onOpenProgress: (target: ProgressTarget) => void;
}) {
  const meta = modeMeta(item.mode);
  const ModeIcon = meta.icon;
  const status = enrollmentStatus(item.status);

  return (
    <Card className="gap-3 py-4">
      <CardHeader className="px-4">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base leading-snug">{item.title}</CardTitle>
          <Badge variant={status.className ? "outline" : "secondary"} className={status.className}>
            {status.label}
          </Badge>
        </div>
        <CardDescription className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs">
          <span className="flex items-center gap-1.5">
            <ModeIcon className="h-3.5 w-3.5" aria-hidden />
            {meta.label}
          </span>
          <span className="tabular-nums">{item.durationHours}h</span>
          {item.mandatory ? (
            <span className="font-medium text-amber-700 dark:text-amber-400">Mandatory</span>
          ) : null}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 px-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{item.category}</span>
            <span className="tabular-nums font-medium text-foreground">{item.progress}%</span>
          </div>
          <Progress className="h-2" value={item.progress} />
        </div>
        <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>Enrolled {fmtDate(item.enrolledAt.slice(0, 10))}</span>
          {item.score !== null ? (
            <span className="font-medium text-foreground tabular-nums">Score {item.score}/100</span>
          ) : item.completedAt ? (
            <span>Completed {fmtDate(item.completedAt.slice(0, 10))}</span>
          ) : null}
        </div>
        {item.status !== "completed" ? (
          <Button
            size="sm"
            variant="outline"
            className="w-full"
            onClick={() =>
              onOpenProgress({ enrollmentId: item.id, title: item.title, progress: item.progress })
            }
          >
            Update progress
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}

// ===================== Manage (owner/admin/hr) =====================

function ManageView() {
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: qk.trainingCourses(),
    queryFn: () => api.get<TrainingCoursesResponse>("/api/training/courses"),
  });

  const courses = query.data?.courses ?? [];
  const stats = query.data?.stats;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<TrainingCourseDto | null>(null);
  const [deleting, setDeleting] = useState<TrainingCourseDto | null>(null);

  const togglePublish = useMutation({
    mutationFn: (id: string) =>
      api.patch<{ course: TrainingCourseDto }>(`/api/training/courses/${id}`, { action: "toggle_publish" }),
    onSuccess: (data) => {
      invalidateTraining(qc);
      toast.success(data.course.published ? "Course published" : "Course unpublished");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.delete<{ ok: boolean }>(`/api/training/courses/${id}`),
    onSuccess: () => {
      invalidateTraining(qc);
      toast.success("Course deleted");
      setDeleting(null);
    },
    onError: (error: Error) => {
      toast.error(error.message);
      setDeleting(null);
    },
  });

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      {query.isPending ? (
        <div className="grid gap-4 sm:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="gap-2 py-4">
            <CardHeader className="px-4">
              <CardDescription className="flex items-center gap-1.5 text-xs">
                <BookOpen className="h-3.5 w-3.5" aria-hidden /> Published courses
              </CardDescription>
              <CardTitle className="text-3xl tabular-nums">{stats?.published ?? 0}</CardTitle>
            </CardHeader>
            <CardContent className="px-4 text-xs text-muted-foreground">
              of {courses.length} course{courses.length === 1 ? "" : "s"} in the catalogue
            </CardContent>
          </Card>
          <Card className="gap-2 py-4">
            <CardHeader className="px-4">
              <CardDescription className="flex items-center gap-1.5 text-xs">
                <ShieldCheck className="h-3.5 w-3.5" aria-hidden /> Mandatory courses
              </CardDescription>
              <CardTitle className="text-3xl tabular-nums">{stats?.mandatory ?? 0}</CardTitle>
            </CardHeader>
            <CardContent className="px-4 text-xs text-muted-foreground">
              required for compliance across the org
            </CardContent>
          </Card>
          <Card className="gap-2 py-4">
            <CardHeader className="px-4">
              <CardDescription className="flex items-center gap-1.5 text-xs">
                <Target className="h-3.5 w-3.5" aria-hidden /> Completion rate
              </CardDescription>
              <CardTitle className="text-3xl tabular-nums">{stats?.completionRate ?? 0}%</CardTitle>
            </CardHeader>
            <CardContent className="px-4">
              <Progress className="h-2" value={stats?.completionRate ?? 0} aria-label="Completion rate" />
              <p className="mt-1.5 text-xs text-muted-foreground">
                completed enrollments across all courses
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Course catalogue */}
      <section className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-base font-semibold">Course catalogue</h2>
          <Button
            size="sm"
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            <Plus /> New course
          </Button>
        </div>

        {query.isPending ? (
          <Skeleton className="h-72 rounded-xl" />
        ) : query.isError ? (
          <LoadError
            message={query.error instanceof Error ? query.error.message : undefined}
            onRetry={() => query.refetch()}
          />
        ) : courses.length === 0 ? (
          <EmptyState
            icon={<GraduationCap className="h-8 w-8 text-muted-foreground/50" />}
            title="No courses yet"
            description="Create your first training course — it will be published to the library right away."
          />
        ) : (
          <div className="max-h-[520px] overflow-y-auto scrollbar-thin rounded-xl border bg-card">
            <Table>
              <TableHeader className="sticky top-0 z-10 bg-card">
                <TableRow>
                  <TableHead>Course</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Mode</TableHead>
                  <TableHead className="text-right">Duration</TableHead>
                  <TableHead>Enrolled</TableHead>
                  <TableHead>Published</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map((course) => {
                  const meta = modeMeta(course.mode);
                  return (
                    <TableRow key={course.id}>
                      <TableCell className="max-w-56">
                        <span className="flex items-center gap-2">
                          <span className="truncate font-medium" title={course.title}>
                            {course.title}
                          </span>
                          {course.mandatory ? (
                            <Badge
                              variant="outline"
                              className="shrink-0 border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300"
                            >
                              Mandatory
                            </Badge>
                          ) : null}
                          {!course.published ? (
                            <Badge variant="secondary" className="shrink-0">
                              Unpublished
                            </Badge>
                          ) : null}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{course.category}</TableCell>
                      <TableCell className="text-muted-foreground">{meta.label}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {course.durationHours}h
                      </TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">
                        {course.enrolledCount} / {course.completedCount}
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={course.published}
                          disabled={togglePublish.isPending}
                          onCheckedChange={() => togglePublish.mutate(course.id)}
                          aria-label={`Toggle published for ${course.title}`}
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            aria-label={`Edit ${course.title}`}
                            onClick={() => {
                              setEditing(course);
                              setFormOpen(true);
                            }}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                            aria-label={`Delete ${course.title}`}
                            disabled={remove.isPending}
                            onClick={() => setDeleting(course)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </section>

      <CourseFormDialog
        open={formOpen}
        course={editing}
        onOpenChange={(open) => {
          setFormOpen(open);
          if (!open) setEditing(null);
        }}
      />

      <AlertDialog open={!!deleting} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleting?.title}"?</AlertDialogTitle>
            <AlertDialogDescription>
              The course will be removed from the library. Courses with existing enrollments cannot be
              deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={remove.isPending}
              onClick={() => deleting && remove.mutate(deleting.id)}
            >
              {remove.isPending ? "Deleting…" : "Delete course"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===================== Course create/edit dialog =====================

function CourseFormDialog({
  open,
  course,
  onOpenChange,
}: {
  open: boolean;
  course: TrainingCourseDto | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {open ? <CourseForm key={course?.id ?? "new"} course={course} onOpenChange={onOpenChange} /> : null}
    </Dialog>
  );
}

function CourseForm({
  course,
  onOpenChange,
}: {
  course: TrainingCourseDto | null;
  onOpenChange: (open: boolean) => void;
}) {
  const qc = useQueryClient();
  const [form, setForm] = useState<CourseFormValues>(
    course
      ? {
          title: course.title,
          description: course.description,
          category: course.category,
          mode: course.mode,
          durationHours: String(course.durationHours),
          provider: course.provider ?? "",
          mandatory: course.mandatory,
        }
      : EMPTY_FORM
  );
  const [formError, setFormError] = useState<string | null>(null);

  const create = useMutation({
    mutationFn: (v: CourseFormValues) =>
      api.post<{ course: TrainingCourseDto }>("/api/training/courses", {
        title: v.title.trim(),
        description: v.description.trim(),
        category: v.category,
        mode: v.mode,
        durationHours: Number(v.durationHours),
        provider: v.provider.trim() || undefined,
        mandatory: v.mandatory,
      }),
    onSuccess: (data) => {
      invalidateTraining(qc);
      toast.success(`Course "${data.course.title}" created`);
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const update = useMutation({
    mutationFn: (v: CourseFormValues) =>
      api.patch<{ course: TrainingCourseDto }>(`/api/training/courses/${course?.id ?? ""}`, {
        action: "update",
        title: v.title.trim(),
        description: v.description.trim(),
        category: v.category,
        mode: v.mode,
        durationHours: Number(v.durationHours),
        provider: v.provider.trim() || null,
        mandatory: v.mandatory,
      }),
    onSuccess: (data) => {
      invalidateTraining(qc);
      toast.success(`Course "${data.course.title}" updated`);
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submit() {
    setFormError(null);
    if (form.title.trim().length < 3) {
      setFormError("Title must be at least 3 characters.");
      return;
    }
    const duration = Number(form.durationHours);
    if (!Number.isFinite(duration) || duration <= 0) {
      setFormError("Duration must be greater than 0 hours.");
      return;
    }
    if (course) {
      update.mutate(form);
    } else {
      create.mutate(form);
    }
  }

  const pending = create.isPending || update.isPending;

  return (
    <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-lg">
      <DialogHeader>
        <DialogTitle>{course ? "Edit course" : "New course"}</DialogTitle>
        <DialogDescription>
          {course
            ? "Changes apply immediately to the library."
            : "The course will be published to the library right away."}
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="course-title">Title</Label>
          <Input
            id="course-title"
            placeholder="e.g. Workplace Safety Essentials"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="course-description">Description</Label>
          <Textarea
            id="course-description"
            className="min-h-20"
            placeholder="What will participants learn?"
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {TRAINING_CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Mode</Label>
            <Select value={form.mode} onValueChange={(v) => setForm((f) => ({ ...f, mode: v }))}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a mode" />
              </SelectTrigger>
              <SelectContent>
                {COURSE_MODES.map((m) => (
                  <SelectItem key={m.value} value={m.value}>
                    {m.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="course-duration">Duration (hours)</Label>
            <Input
              id="course-duration"
              type="number"
              min={0.5}
              step={0.5}
              value={form.durationHours}
              onChange={(e) => setForm((f) => ({ ...f, durationHours: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="course-provider">Provider (optional)</Label>
            <Input
              id="course-provider"
              placeholder="e.g. Coursera"
              value={form.provider}
              onChange={(e) => setForm((f) => ({ ...f, provider: e.target.value }))}
            />
          </div>
        </div>
        <div className="flex items-center justify-between rounded-lg border p-3">
          <div className="space-y-0.5">
            <Label htmlFor="course-mandatory">Mandatory</Label>
            <p className="text-xs text-muted-foreground">Required for everyone in the organisation.</p>
          </div>
          <Switch
            id="course-mandatory"
            checked={form.mandatory}
            onCheckedChange={(v) => setForm((f) => ({ ...f, mandatory: v }))}
          />
        </div>
        {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>
          Cancel
        </Button>
        <Button disabled={pending} onClick={submit}>
          {pending ? "Saving…" : course ? "Save changes" : "Create course"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

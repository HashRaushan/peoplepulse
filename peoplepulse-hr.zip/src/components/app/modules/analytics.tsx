"use client";

import { useQuery } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { inr } from "@/lib/hr-utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, PieChart, Pie, Cell, Legend, LineChart, Line,
} from "recharts";
import { BarChart3, Users2, CalendarCheck, UserRoundSearch, LifeBuoy, Target } from "lucide-react";
import type { AnalyticsResponse } from "@/lib/types";

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const tooltipStyle = { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 };

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

export function AnalyticsModule() {
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.analytics,
    queryFn: () => api.get<AnalyticsResponse>("/api/analytics"),
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-4 lg:grid-cols-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-64" />)}</div>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">People analytics</h1>
          <p className="text-sm text-muted-foreground">
            Every metric is computed live from your organisation&apos;s records — no sample data.
          </p>
        </div>
        <LoadError
          message={error instanceof Error ? error.message : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  const t = data.ticketMetrics;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">People analytics</h1>
        <p className="text-sm text-muted-foreground">
          Every metric is computed live from your organisation&apos;s records — no sample data.
        </p>
      </div>

      {/* Headcount movement */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <Users2 className="h-4 w-4 text-primary" /> Headcount movement — hires vs exits (12 months)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.headcountTrend} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="hired" name="Joined" fill="var(--chart-1)" radius={[3, 3, 0, 0]} barSize={12} />
                <Bar dataKey="exited" name="Exited" fill="var(--chart-4)" radius={[3, 3, 0, 0]} barSize={12} />
                <Line type="monotone" dataKey="total" name="Total headcount" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Tenure + gender */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Tenure distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.tenureBuckets.map((b) => {
              const total = data.tenureBuckets.reduce((s, x) => s + x.value, 0) || 1;
              return (
                <div key={b.name}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="font-medium">{b.name}</span>
                    <span className="text-muted-foreground">{b.value} people</span>
                  </div>
                  <Progress value={(b.value / total) * 100} className="h-2" />
                </div>
              );
            })}
            <div className="mt-4 border-t pt-4">
              <p className="mb-2 text-xs font-medium">Gender split</p>
              <div className="h-36">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={data.genderSplit} dataKey="value" nameKey="name" innerRadius={34} outerRadius={54} paddingAngle={3}>
                      {data.genderSplit.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={tooltipStyle} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Department attendance */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <CalendarCheck className="h-4 w-4 text-primary" /> Attendance rate by department (30 days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.deptAttendance} layout="vertical" margin={{ top: 0, right: 16, left: 30, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v}%`} />
                  <Bar dataKey="rate" fill="var(--chart-2)" radius={[0, 4, 4, 0]} barSize={16} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Hiring funnel */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <UserRoundSearch className="h-4 w-4 text-primary" /> Recruitment funnel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2.5">
              {data.hiringFunnel.map((s, i) => {
                const max = Math.max(...data.hiringFunnel.map((x) => x.count), 1);
                return (
                  <div key={s.stage} className="flex items-center gap-3">
                    <span className="w-20 text-xs font-medium">{s.stage}</span>
                    <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                      <div
                        className="flex h-full items-center justify-end rounded-md px-2 text-[10px] font-semibold text-white"
                        style={{ width: `${Math.max(8, (s.count / max) * 100)}%`, background: COLORS[i % COLORS.length] }}
                      >
                        {s.count}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 border-t pt-3">
              <p className="mb-2 text-xs font-medium">Source of candidates</p>
              <div className="flex flex-wrap gap-1.5">
                {data.sourceOfHire.map((s, i) => (
                  <span key={s.name} className="flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px]">
                    <span className="h-2 w-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    {s.name} · {s.value}
                  </span>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payroll cost */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <BarChart3 className="h-4 w-4 text-primary" /> Payroll cost trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.payrollCostTrend.length === 0 ? (
              <p className="py-10 text-center text-xs text-muted-foreground">No payroll runs yet.</p>
            ) : (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data.payrollCostTrend} margin={{ top: 4, right: 8, left: 4, bottom: 0 }}>
                    <defs>
                      <linearGradient id="pc" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.3} />
                        <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} tickFormatter={(v: number) => inr(v, { compact: true })} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => inr(v)} />
                    <Area type="monotone" dataKey="gross" name="Gross" stroke="var(--chart-3)" strokeWidth={2} fill="url(#pc)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Tickets */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <LifeBuoy className="h-4 w-4 text-primary" /> HR service desk
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{t.openCount}</p>
                <p className="text-[11px] text-muted-foreground">Open</p>
              </div>
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{t.resolvedCount}</p>
                <p className="text-[11px] text-muted-foreground">Resolved</p>
              </div>
              <div className="rounded-lg border p-3 text-center">
                <p className="text-2xl font-bold">{t.avgResolutionHours !== null ? `${t.avgResolutionHours}h` : "—"}</p>
                <p className="text-[11px] text-muted-foreground">Avg resolution</p>
              </div>
            </div>
            <div className="mt-4 space-y-2">
              {t.byCategory.map((c, i) => {
                const max = Math.max(...t.byCategory.map((x) => x.value), 1);
                return (
                  <div key={c.name} className="flex items-center gap-3 text-xs">
                    <span className="w-20 text-muted-foreground">{c.name}</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full" style={{ width: `${(c.value / max) * 100}%`, background: COLORS[i % COLORS.length] }} />
                    </div>
                    <span className="w-6 text-right font-medium">{c.value}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Performance distribution */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Target className="h-4 w-4 text-primary" /> Performance rating distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.ratingDistribution} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="rating" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Bar dataKey="count" name="Reviews" fill="var(--chart-1)" radius={[4, 4, 0, 0]} barSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            {/* Leave utilisation */}
            <div className="mt-4 border-t pt-3">
              <p className="mb-2 text-xs font-medium">Leave utilisation by type</p>
              <div className="space-y-2">
                {data.leaveUtilizationByType.map((l) => {
                  const pct = l.entitled > 0 ? Math.round((l.used / l.entitled) * 100) : 0;
                  return (
                    <div key={l.name} className="flex items-center gap-3 text-xs">
                      <span className="w-32 truncate text-muted-foreground">{l.name}</span>
                      <Progress value={pct} className="h-2 flex-1" />
                      <span className="w-10 text-right font-medium">{pct}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

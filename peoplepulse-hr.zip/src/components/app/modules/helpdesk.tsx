"use client";

/**
 * PeoplePulse HR — Helpdesk module.
 * Ticket inbox with scope tabs (My tickets / All tickets for HR roles),
 * status/category/priority filters, a selectable list with SLA indicators,
 * a threaded detail panel with reply, status and assign actions, and a
 * new-ticket dialog available to every role.
 */
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  LifeBuoy,
  Loader2,
  MessageSquare,
  Plus,
  RotateCcw,
  Send,
  Timer,
} from "lucide-react";
import type { EmployeeListResponse, Role, SessionUser, TicketDto, TicketPriority, TicketStatus } from "@/lib/types";
import { STATUS_LABELS, TICKET_CATEGORIES } from "@/lib/constants";
import { api, qk } from "@/lib/api-client";
import { ago, cn, fmtDateTime } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

type TicketsResponse = { items: TicketDto[] };
type Scope = "mine" | "all";

const HR_GROUP: Role[] = ["owner", "admin", "hr"];
const TICKET_STATUSES: TicketStatus[] = ["open", "in_progress", "resolved", "closed"];
const TICKET_PRIORITIES: TicketPriority[] = ["low", "medium", "high", "urgent"];

function statusBadge(status: string) {
  const label = STATUS_LABELS[status] ?? status;
  switch (status) {
    case "open":
      return <Badge variant="default">{label}</Badge>;
    case "in_progress":
      return <Badge variant="secondary">{label}</Badge>;
    case "resolved":
      return (
        <Badge variant="outline" className="border-primary/40 text-primary">
          {label}
        </Badge>
      );
    case "closed":
      return (
        <Badge variant="outline" className="text-muted-foreground">
          {label}
        </Badge>
      );
    default:
      return <Badge variant="outline">{label}</Badge>;
  }
}

function priorityBadge(priority: string) {
  const label = STATUS_LABELS[priority] ?? priority;
  switch (priority) {
    case "low":
      return <Badge variant="secondary">{label}</Badge>;
    case "medium":
      return <Badge variant="default">{label}</Badge>;
    case "high":
      return (
        <Badge variant="outline" className="border-destructive/40 text-destructive">
          {label}
        </Badge>
      );
    case "urgent":
      return <Badge variant="destructive">{label}</Badge>;
    default:
      return <Badge variant="outline">{label}</Badge>;
  }
}

function fmtHours(hours: number): string {
  if (hours >= 24) return `${(hours / 24).toFixed(1)}d`;
  if (hours >= 1) return `${Math.round(hours)}h`;
  return `${Math.max(1, Math.round(hours * 60))}m`;
}

function isOverdue(t: TicketDto): boolean {
  return (
    t.ageHours > t.slaHours && t.status !== "resolved" && t.status !== "closed"
  );
}

export function HelpdeskModule() {
  const { user } = useAppStore();
  if (!user) return null;
  return <HelpdeskInner user={user} />;
}

function HelpdeskInner({ user }: { user: SessionUser }) {
  const qc = useQueryClient();
  const canSeeAll = HR_GROUP.includes(user.role);

  const [scope, setScope] = useState<Scope>("mine");
  const [status, setStatus] = useState("all");
  const [category, setCategory] = useState("all");
  const [priority, setPriority] = useState("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const [newOpen, setNewOpen] = useState(false);
  const [newForm, setNewForm] = useState({
    subject: "",
    category: TICKET_CATEGORIES[0],
    priority: "medium" as TicketPriority,
    message: "",
  });

  const filters = useMemo(
    () => ({
      scope,
      ...(status !== "all" ? { status } : {}),
      ...(category !== "all" ? { category } : {}),
      ...(priority !== "all" ? { priority } : {}),
    }),
    [scope, status, category, priority]
  );

  const ticketsQuery = useQuery({
    queryKey: qk.tickets(filters),
    queryFn: () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([k, v]) => params.set(k, String(v)));
      return api.get<TicketsResponse>(`/api/tickets?${params.toString()}`);
    },
  });

  // Real assignee options: the organisation's active employees (HR view only).
  const staffQuery = useQuery({
    queryKey: qk.employees({ status: "active", pageSize: 100, purpose: "assign" }),
    queryFn: () =>
      api.get<EmployeeListResponse>("/api/employees?status=active&pageSize=100"),
    enabled: canSeeAll,
  });

  useEffect(() => {
    if (ticketsQuery.error) toast.error(ticketsQuery.error.message);
  }, [ticketsQuery.error]);

  const tickets = useMemo(() => ticketsQuery.data?.items ?? [], [ticketsQuery.data]);

  // Keep the selected ticket valid as the list loads/changes (render-time
  // adjustment — avoids cascading effect updates).
  if (tickets.length === 0) {
    if (selectedId !== null) setSelectedId(null);
  } else if (selectedId === null || !tickets.some((t) => t.id === selectedId)) {
    setSelectedId(tickets[0].id);
  }

  const [lastSelectedId, setLastSelectedId] = useState(selectedId);
  if (lastSelectedId !== selectedId) {
    setLastSelectedId(selectedId);
    setReply("");
  }

  const selected = tickets.find((t) => t.id === selectedId) ?? null;

  const actionMutation = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Record<string, unknown> }) =>
      api.patch<{ item: TicketDto }>(`/api/tickets/${id}`, payload),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["tickets"] });
      // Status changes move the dashboard's open-ticket counts — keep it fresh.
      if (vars.payload.action !== "reply") {
        qc.invalidateQueries({ queryKey: qk.dashboard });
      }
      if (vars.payload.action === "reply") {
        setReply("");
        toast.success("Reply sent");
      } else if (vars.payload.action === "status") {
        toast.success(`Status updated to ${STATUS_LABELS[String(vars.payload.status)]}`);
      } else {
        toast.success("Ticket assigned");
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.post<{ item: TicketDto }>("/api/tickets", payload),
    onSuccess: () => {
      toast.success("Ticket created — the HR desk will get back to you soon");
      setNewOpen(false);
      setNewForm({
        subject: "",
        category: TICKET_CATEGORIES[0],
        priority: "medium",
        message: "",
      });
      qc.invalidateQueries({ queryKey: ["tickets"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const sendReply = () => {
    if (!selected || !reply.trim()) return;
    actionMutation.mutate({
      id: selected.id,
      payload: { action: "reply", message: reply.trim() },
    });
  };

  const submitNew = () => {
    if (!newForm.subject.trim() || !newForm.message.trim()) {
      toast.error("A subject and message are required.");
      return;
    }
    createMutation.mutate({
      subject: newForm.subject.trim(),
      category: newForm.category,
      priority: newForm.priority,
      message: newForm.message.trim(),
    });
  };

  const hasActiveFilters = status !== "all" || category !== "all" || priority !== "all";
  const resetFilters = () => {
    setStatus("all");
    setCategory("all");
    setPriority("all");
  };

  const selectedAssignee = selected?.assignedTo ?? null;
  const assigneeOptions = Array.from(
    new Set(
      [
        user.name,
        ...(staffQuery.data?.items ?? []).map((e) =>
          `${e.firstName} ${e.lastName}`.trim()
        ),
        ...(selectedAssignee ? [selectedAssignee] : []),
      ].filter(Boolean)
    )
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Helpdesk</h1>
          <p className="text-sm text-muted-foreground">
            {ticketsQuery.data
              ? `${tickets.length} ${tickets.length === 1 ? "ticket" : "tickets"}`
              : "HR support desk"}
            {" · The People team will get back to you."}
          </p>
        </div>
        <Button size="sm" onClick={() => setNewOpen(true)}>
          <Plus /> New ticket
        </Button>
      </div>

      {/* Scope tabs */}
      {canSeeAll && (
        <Tabs value={scope} onValueChange={(v) => setScope(v as Scope)}>
          <TabsList>
            <TabsTrigger value="mine">My tickets</TabsTrigger>
            <TabsTrigger value="all">All tickets</TabsTrigger>
          </TabsList>
        </Tabs>
      )}

      {/* Filters */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 lg:max-w-2xl">
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {TICKET_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {STATUS_LABELS[s] ?? s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {TICKET_CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            {TICKET_PRIORITIES.map((p) => (
              <SelectItem key={p} value={p}>
                {STATUS_LABELS[p] ?? p}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* List + detail */}
      <div className="grid gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        {/* List */}
        <div className="scrollbar-thin max-h-[70vh] space-y-2 overflow-y-auto pr-1">
          {ticketsQuery.isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-lg" />
            ))
          ) : ticketsQuery.isError ? (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-8 text-center">
              <LifeBuoy className="h-8 w-8 text-muted-foreground" />
              <div>
                <div className="font-semibold">Could not load tickets</div>
                <p className="text-sm text-muted-foreground">{ticketsQuery.error.message}</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => ticketsQuery.refetch()}>
                Try again
              </Button>
            </div>
          ) : tickets.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-8 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <LifeBuoy className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="font-semibold">No tickets — your HR desk is clear</div>
                <p className="text-sm text-muted-foreground">
                  {hasActiveFilters
                    ? "Try widening the filters to see more tickets."
                    : "Raise a ticket any time and the HR team will respond."}
                </p>
              </div>
              {hasActiveFilters ? (
                <Button variant="outline" size="sm" onClick={resetFilters}>
                  <RotateCcw /> Reset filters
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setNewOpen(true)}>
                  <Plus /> New ticket
                </Button>
              )}
            </div>
          ) : (
            tickets.map((t) => {
              const active = t.id === selectedId;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSelectedId(t.id)}
                  className={cn(
                    "w-full rounded-lg border bg-card p-3 text-left shadow-sm transition-colors hover:bg-accent/50",
                    active && "border-primary/50 bg-accent"
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] text-muted-foreground">{t.ticketNo}</span>
                    {statusBadge(t.status)}
                  </div>
                  <div className="mt-1 truncate text-sm font-medium">{t.subject}</div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                    <Badge variant="outline" className="text-[10px]">
                      {t.category}
                    </Badge>
                    {priorityBadge(t.priority)}
                    {isOverdue(t) && (
                      <span className="text-[10px] font-semibold text-destructive">
                        SLA breached
                      </span>
                    )}
                  </div>
                  <div className="mt-1.5 flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                    <span className="min-w-0 truncate">
                      {canSeeAll ? t.requesterName : "You"} · {ago(t.createdAt)}
                    </span>
                    <span className="flex shrink-0 items-center gap-1">
                      <Timer className="h-3 w-3" />
                      {fmtHours(t.ageHours)} / {t.slaHours}h
                    </span>
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Detail */}
        <div>
          {selected ? (
            <Card className="flex h-full flex-col gap-0 overflow-hidden py-0">
              <CardHeader className="border-b pb-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <CardTitle className="text-base leading-snug">{selected.subject}</CardTitle>
                    <CardDescription className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="font-mono text-[11px]">{selected.ticketNo}</span>
                      <span aria-hidden>·</span>
                      <span>{selected.requesterName}</span>
                      <span aria-hidden>·</span>
                      <span>opened {ago(selected.createdAt)}</span>
                      {selected.resolvedAt && (
                        <>
                          <span aria-hidden>·</span>
                          <span>resolved {fmtDateTime(selected.resolvedAt)}</span>
                        </>
                      )}
                    </CardDescription>
                  </div>
                  {statusBadge(selected.status)}
                </div>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <Badge variant="outline">{selected.category}</Badge>
                  {priorityBadge(selected.priority)}
                  {selected.assignedTo && (
                    <Badge variant="secondary">Assigned: {selected.assignedTo}</Badge>
                  )}
                  {isOverdue(selected) ? (
                    <span className="text-xs font-semibold text-destructive">
                      SLA breached — {fmtHours(selected.ageHours)} of {selected.slaHours}h
                    </span>
                  ) : (
                    <span className="text-xs text-muted-foreground">
                      SLA {fmtHours(selected.ageHours)} of {selected.slaHours}h
                    </span>
                  )}
                </div>
              </CardHeader>

              {/* Thread */}
              <div className="scrollbar-thin max-h-[46vh] min-h-0 flex-1 space-y-3 overflow-y-auto p-4 lg:max-h-none">
                {selected.messages.map((m, i) => (
                  <div
                    key={`${m.at}-${i}`}
                    className={cn("flex", m.role === "hr" ? "justify-end" : "justify-start")}
                  >
                    <div
                      className={cn(
                        "max-w-[85%] rounded-xl px-3 py-2 text-sm",
                        m.role === "hr" ? "bg-primary/10" : "bg-muted"
                      )}
                    >
                      <div className="mb-0.5 flex items-center gap-2 text-[11px] text-muted-foreground">
                        <span className="font-medium">{m.author}</span>
                        <span>{ago(m.at)}</span>
                      </div>
                      <p className="whitespace-pre-line">{m.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Reply + HR controls */}
              <div className="space-y-3 border-t p-4">
                {canSeeAll && (
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    <Select
                      value={selected.status}
                      onValueChange={(v) =>
                        actionMutation.mutate({
                          id: selected.id,
                          payload: { action: "status", status: v },
                        })
                      }
                    >
                      <SelectTrigger className="w-full" aria-label="Ticket status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {TICKET_STATUSES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {STATUS_LABELS[s] ?? s}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={selected.assignedTo ?? ""}
                      onValueChange={(v) =>
                        actionMutation.mutate({
                          id: selected.id,
                          payload: { action: "assign", assignedTo: v },
                        })
                      }
                    >
                      <SelectTrigger className="w-full" aria-label="Assign ticket">
                        <SelectValue placeholder="Assign to…" />
                      </SelectTrigger>
                      <SelectContent>
                        {assigneeOptions.map((name) => (
                          <SelectItem key={name} value={name}>
                            {name}
                            {name === user.name ? " (you)" : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div className="flex items-end gap-2">
                  <Textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    placeholder="Write a reply…"
                    rows={2}
                    className="min-h-0 flex-1 resize-none"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) sendReply();
                    }}
                  />
                  <Button
                    onClick={sendReply}
                    disabled={!reply.trim() || actionMutation.isPending}
                    aria-label="Send reply"
                  >
                    {actionMutation.isPending ? (
                      <Loader2 className="animate-spin" />
                    ) : (
                      <Send />
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            !ticketsQuery.isLoading &&
            !ticketsQuery.isError && (
              <div className="flex h-full min-h-48 flex-col items-center justify-center gap-3 rounded-xl border border-dashed p-8 text-center">
                <MessageSquare className="h-8 w-8 text-muted-foreground" />
                <div>
                  <div className="font-semibold">No ticket selected</div>
                  <p className="text-sm text-muted-foreground">
                    Pick a ticket from the list to view the conversation.
                  </p>
                </div>
              </div>
            )
          )}
        </div>
      </div>

      {/* New ticket dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New support ticket</DialogTitle>
            <DialogDescription>
              Describe your issue and the HR desk will get back to you.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="tk-subject">Subject</Label>
              <Input
                id="tk-subject"
                value={newForm.subject}
                onChange={(e) => setNewForm((f) => ({ ...f, subject: e.target.value }))}
                placeholder="e.g. Payslip for last month is missing"
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select
                  value={newForm.category}
                  onValueChange={(v) => setNewForm((f) => ({ ...f, category: v }))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TICKET_CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select
                  value={newForm.priority}
                  onValueChange={(v) => setNewForm((f) => ({ ...f, priority: v as TicketPriority }))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TICKET_PRIORITIES.map((p) => (
                      <SelectItem key={p} value={p}>
                        {STATUS_LABELS[p] ?? p}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tk-message">Message</Label>
              <Textarea
                id="tk-message"
                rows={5}
                value={newForm.message}
                onChange={(e) => setNewForm((f) => ({ ...f, message: e.target.value }))}
                placeholder="Add any details that will help us resolve this faster…"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submitNew} disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="animate-spin" />}
              Create ticket
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

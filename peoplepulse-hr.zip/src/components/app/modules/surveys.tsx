"use client";

/**
 * PeoplePulse HR — Surveys & eNPS module.
 *
 * Owner/admin/hr create surveys (eNPS / pulse / custom) with rating (1-10),
 * multiple-choice and open-text questions. Everyone in the workspace can
 * respond once per survey; managers see aggregated results (participation,
 * averages, distributions, verbatim answers) with no employee identities.
 */

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  BarChart3,
  CheckCircle2,
  ClipboardList,
  EyeOff,
  Plus,
  Trash2,
  Zap,
} from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { ago, cn, fmtDate } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import type { OrgProfileDto, SurveyDetailDto, SurveyListItemDto } from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local constants & helpers =====================

const MGR_ROLES = ["owner", "admin", "hr"];

const SURVEY_TYPE_LABELS: Record<string, string> = {
  enps: "eNPS",
  pulse: "Pulse",
  custom: "Custom",
};

const QUESTION_TYPE_LABELS: Record<string, string> = {
  rating_10: "Rating 1–10",
  choice: "Choice",
  text: "Open text",
};

type QuestionType = "rating_10" | "choice" | "text";
type SurveyType = "enps" | "pulse" | "custom";

interface SurveysResponse {
  surveys: SurveyListItemDto[];
}

/** A question row in the create-survey builder (options kept comma-separated). */
interface DraftQuestion {
  text: string;
  type: QuestionType;
  options: string;
}

function surveyTypeLabel(type: string): string {
  return SURVEY_TYPE_LABELS[type] ?? type;
}

function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? (
        <p className="max-w-md text-sm text-muted-foreground">{description}</p>
      ) : null}
      {action}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function participationPct(responseCount: number, totalEmployees: number): number {
  if (totalEmployees <= 0) return 0;
  return Math.min(100, Math.round((responseCount / totalEmployees) * 100));
}

// ===================== Module =====================

export function SurveysModule() {
  const { user } = useAppStore();
  const isMgr = !!user && MGR_ROLES.includes(user.role);
  const company = user?.tenantName ?? "your company";

  const [createOpen, setCreateOpen] = useState(false);
  const [createTemplate, setCreateTemplate] = useState<"blank" | "enps">("blank");
  const [respondTo, setRespondTo] = useState<SurveyListItemDto | null>(null);
  const [resultsFor, setResultsFor] = useState<SurveyListItemDto | null>(null);

  const surveysQuery = useQuery({
    queryKey: qk.surveys,
    queryFn: () => api.get<SurveysResponse>("/api/surveys"),
  });

  // Headcount denominator for the participation bars (managers only).
  const orgQuery = useQuery({
    queryKey: qk.orgProfile,
    queryFn: () => api.get<OrgProfileDto>("/api/org/profile"),
    enabled: isMgr,
  });
  const totalEmployees = orgQuery.data?.employeeCount ?? 0;

  const surveys = surveysQuery.data?.surveys ?? [];

  function openCreate(template: "blank" | "enps") {
    setCreateTemplate(template);
    setCreateOpen(true);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Surveys</h1>
          <p className="text-sm text-muted-foreground">
            {isMgr
              ? "Run eNPS and pulse checks, track participation and see what people are saying."
              : "Share honest feedback through company surveys — your voice shapes what we improve."}
          </p>
        </div>
        {isMgr ? (
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => openCreate("enps")}>
              <Zap className="h-4 w-4" />
              Use eNPS template
            </Button>
            <Button onClick={() => openCreate("blank")}>
              <Plus className="h-4 w-4" />
              New survey
            </Button>
          </div>
        ) : null}
      </div>

      {surveysQuery.isPending ? (
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      ) : surveysQuery.isError ? (
        <LoadError
          message={surveysQuery.error instanceof Error ? surveysQuery.error.message : undefined}
          onRetry={() => surveysQuery.refetch()}
        />
      ) : surveys.length === 0 ? (
        <EmptyState
          icon={<ClipboardList className="h-8 w-8 text-muted-foreground/50" />}
          title="No surveys yet"
          description={
            isMgr
              ? "Create your first eNPS or pulse survey to hear how the team is doing."
              : "When HR publishes a survey it will appear here for you to answer."
          }
          action={
            isMgr ? (
              <Button size="sm" variant="outline" onClick={() => openCreate("enps")}>
                <Zap className="h-4 w-4" />
                Use eNPS template
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="scrollbar-thin max-h-[520px] overflow-y-auto pr-1">
          <div className="grid gap-4 md:grid-cols-2">
            {surveys.map((s) => (
              <SurveyCard
                key={s.id}
                survey={s}
                isMgr={isMgr}
                totalEmployees={totalEmployees}
                onRespond={() => setRespondTo(s)}
                onViewResults={() => setResultsFor(s)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Create survey (managers) */}
      <CreateSurveyDialog
        open={createOpen}
        template={createTemplate}
        company={company}
        onOpenChange={setCreateOpen}
      />

      {/* Respond to a survey */}
      <Dialog open={!!respondTo} onOpenChange={(open) => !open && setRespondTo(null)}>
        {respondTo ? <RespondDialogContent survey={respondTo} onDone={() => setRespondTo(null)} /> : null}
      </Dialog>

      {/* Results (managers) */}
      <Dialog open={!!resultsFor} onOpenChange={(open) => !open && setResultsFor(null)}>
        {resultsFor ? <ResultsDialogContent survey={resultsFor} /> : null}
      </Dialog>
    </div>
  );
}

// ===================== Survey card =====================

function SurveyCard({
  survey,
  isMgr,
  totalEmployees,
  onRespond,
  onViewResults,
}: {
  survey: SurveyListItemDto;
  isMgr: boolean;
  totalEmployees: number;
  onRespond: () => void;
  onViewResults: () => void;
}) {
  const qc = useQueryClient();

  const closeSurvey = useMutation({
    mutationFn: () => api.patch(`/api/surveys/${survey.id}`, { action: "close" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.surveys });
      qc.invalidateQueries({ queryKey: qk.survey(survey.id) });
      toast.success("Survey closed to new responses");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const pct = participationPct(survey.responseCount, totalEmployees);
  const isActive = survey.status === "active";

  return (
    <Card className="flex h-full flex-col gap-3 py-4">
      <CardHeader className="px-4">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="outline">{surveyTypeLabel(survey.type)}</Badge>
          {isActive ? (
            <Badge className="border-emerald-600/40 bg-emerald-600/10 text-emerald-700 dark:text-emerald-400">
              Active
            </Badge>
          ) : (
            <Badge variant="secondary">Closed</Badge>
          )}
          {survey.anonymous ? (
            <Badge variant="outline" className="gap-1 text-muted-foreground">
              <EyeOff className="h-3 w-3" />
              Anonymous
            </Badge>
          ) : null}
        </div>
        <CardTitle className="text-base leading-snug">{survey.title}</CardTitle>
        {survey.description ? (
          <CardDescription className="line-clamp-2">{survey.description}</CardDescription>
        ) : null}
        <p className="text-xs text-muted-foreground">
          Created {ago(survey.createdAt)}
          {survey.closesAt ? ` · Closes ${fmtDate(survey.closesAt.slice(0, 10))}` : ""}
        </p>
      </CardHeader>

      <CardContent className="flex-1 space-y-3 px-4">
        <p className="text-xs text-muted-foreground">
          {survey.questionCount} question{survey.questionCount === 1 ? "" : "s"} ·{" "}
          {survey.responseCount} response{survey.responseCount === 1 ? "" : "s"}
        </p>

        {isMgr ? (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                {survey.responseCount} of {totalEmployees} employee
                {totalEmployees === 1 ? "" : "s"} responded
              </span>
              <span className="tabular-nums">{pct}%</span>
            </div>
            <Progress value={pct} aria-label="Participation" />
          </div>
        ) : null}
      </CardContent>

      <CardFooter className="flex-wrap gap-2 px-4">
        {survey.hasResponded ? (
          <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-600/40 bg-emerald-600/10 px-2.5 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Responded
          </span>
        ) : isActive ? (
          <Button size="sm" onClick={onRespond}>
            Respond
          </Button>
        ) : null}

        {isMgr ? (
          <>
            <Button size="sm" variant="outline" onClick={onViewResults}>
              <BarChart3 className="h-4 w-4" />
              View results
            </Button>
            {isActive ? (
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                disabled={closeSurvey.isPending}
                onClick={() => closeSurvey.mutate()}
              >
                Close survey
              </Button>
            ) : null}
          </>
        ) : null}
      </CardFooter>
    </Card>
  );
}

// ===================== Create survey dialog (managers) =====================

function blankQuestion(): DraftQuestion {
  return { text: "", type: "rating_10", options: "" };
}

function CreateSurveyDialog({
  open,
  template,
  company,
  onOpenChange,
}: {
  open: boolean;
  template: "blank" | "enps";
  company: string;
  onOpenChange: (open: boolean) => void;
}) {
  // The form content is keyed by template and only mounted while open, so it
  // always starts fresh (blank or pre-filled eNPS) without effect resets.
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {open ? (
        <CreateSurveyDialogContent
          key={template}
          template={template}
          company={company}
          onOpenChange={onOpenChange}
        />
      ) : null}
    </Dialog>
  );
}

function CreateSurveyDialogContent({
  template,
  company,
  onOpenChange,
}: {
  template: "blank" | "enps";
  company: string;
  onOpenChange: (open: boolean) => void;
}) {
  const qc = useQueryClient();

  const [title, setTitle] = useState(template === "enps" ? "Employee eNPS Survey" : "");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<SurveyType>(template === "enps" ? "enps" : "pulse");
  const [anonymous, setAnonymous] = useState(true);
  const [closesAt, setClosesAt] = useState("");
  const [questions, setQuestions] = useState<DraftQuestion[]>(() =>
    template === "enps"
      ? [
          {
            text: `How likely are you to recommend ${company} as a place to work?`,
            type: "rating_10",
            options: "",
          },
          { text: "What is one thing we could improve?", type: "text", options: "" },
        ]
      : [blankQuestion()]
  );
  const [formError, setFormError] = useState<string | null>(null);

  function updateQuestion(index: number, patch: Partial<DraftQuestion>) {
    setQuestions((prev) =>
      prev.map((q, i) => (i === index ? { ...q, ...patch } : q))
    );
  }

  function removeQuestion(index: number) {
    setQuestions((prev) => prev.filter((_, i) => i !== index));
  }

  function addQuestion() {
    setQuestions((prev) => [...prev, blankQuestion()]);
  }

  const create = useMutation({
    mutationFn: () =>
      api.post<{ survey: SurveyListItemDto }>("/api/surveys", {
        title,
        description,
        type,
        anonymous,
        ...(closesAt ? { closesAt } : {}),
        questions: questions.map((q) => ({
          text: q.text,
          type: q.type,
          ...(q.type === "choice"
            ? { options: q.options.split(",").map((o) => o.trim()).filter(Boolean) }
            : {}),
        })),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.surveys });
      toast.success("Survey created and published");
      onOpenChange(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submit() {
    setFormError(null);
    if (!title.trim()) {
      setFormError("Please enter a survey title.");
      return;
    }
    if (questions.length === 0) {
      setFormError("Add at least one question.");
      return;
    }
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.text.trim()) {
        setFormError(`Question ${i + 1} needs text.`);
        return;
      }
      if (q.type === "choice") {
        const options = q.options.split(",").map((o) => o.trim()).filter(Boolean);
        if (options.length < 2) {
          setFormError(`Question ${i + 1} needs at least 2 options (comma-separated).`);
          return;
        }
      }
    }
    create.mutate();
  }

  return (
    <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-2xl">
      <DialogHeader>
        <DialogTitle>New survey</DialogTitle>
        <DialogDescription>
          {template === "enps"
            ? "eNPS template loaded — tweak the questions or publish as is."
            : "Build a survey with rating, choice and open-text questions."}
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="survey-title">Title</Label>
            <Input
              id="survey-title"
              placeholder="e.g. Q3 engagement pulse"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="survey-type">Type</Label>
            <Select value={type} onValueChange={(v) => setType(v as SurveyType)}>
              <SelectTrigger id="survey-type" className="w-full">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="enps">eNPS</SelectItem>
                <SelectItem value="pulse">Pulse</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="survey-description">Description (optional)</Label>
          <Input
            id="survey-description"
            placeholder="What is this survey about?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
            <div className="space-y-0.5">
              <Label htmlFor="survey-anonymous">Anonymous responses</Label>
              <p className="text-xs text-muted-foreground">Responses stay confidential</p>
            </div>
            <Switch
              id="survey-anonymous"
              checked={anonymous}
              onCheckedChange={setAnonymous}
              aria-label="Anonymous responses"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="survey-closes">Closes on (optional)</Label>
            <Input
              id="survey-closes"
              type="date"
              value={closesAt}
              min={new Date().toISOString().slice(0, 10)}
              onChange={(e) => setClosesAt(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label>Questions</Label>
            <span className="text-xs text-muted-foreground">
              {questions.length} of max 30
            </span>
          </div>

          <div className="space-y-3">
            {questions.map((q, i) => (
              <div key={i} className="space-y-2 rounded-lg border p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="shrink-0 text-xs font-semibold text-muted-foreground">
                    Q{i + 1}
                  </span>
                  <Input
                    aria-label={`Question ${i + 1} text`}
                    placeholder="Ask something specific…"
                    value={q.text}
                    onChange={(e) => updateQuestion(i, { text: e.target.value })}
                    className="min-w-40 flex-1"
                  />
                  <Select
                    value={q.type}
                    onValueChange={(v) => updateQuestion(i, { type: v as QuestionType })}
                  >
                    <SelectTrigger aria-label={`Question ${i + 1} type`} className="w-[140px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rating_10">Rating 1–10</SelectItem>
                      <SelectItem value="choice">Choice</SelectItem>
                      <SelectItem value="text">Open text</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="shrink-0 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                    aria-label={`Remove question ${i + 1}`}
                    onClick={() => removeQuestion(i)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {q.type === "choice" ? (
                  <Input
                    aria-label={`Question ${i + 1} options`}
                    placeholder="Options, comma-separated (at least 2) — e.g. Yes, No, Not sure"
                    value={q.options}
                    onChange={(e) => updateQuestion(i, { options: e.target.value })}
                  />
                ) : null}
              </div>
            ))}
          </div>

          <Button type="button" variant="outline" size="sm" onClick={addQuestion}>
            <Plus className="h-4 w-4" />
            Add question
          </Button>
        </div>

        {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={() => onOpenChange(false)}>
          Cancel
        </Button>
        <Button onClick={submit} disabled={create.isPending}>
          {create.isPending ? "Publishing…" : "Publish survey"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

// ===================== Respond dialog =====================

function RespondDialogContent({
  survey,
  onDone,
}: {
  survey: SurveyListItemDto;
  onDone: () => void;
}) {
  const qc = useQueryClient();
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);

  const detailQuery = useQuery({
    queryKey: qk.survey(survey.id),
    queryFn: () => api.get<SurveyDetailDto>(`/api/surveys/${survey.id}`),
  });

  const detail = detailQuery.data;
  const questions = detail?.questions ?? [];

  const submitResponse = useMutation({
    mutationFn: (payload: { questionId: string; value: string }[]) =>
      api.post(`/api/surveys/${survey.id}/responses`, { answers: payload }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.surveys });
      qc.invalidateQueries({ queryKey: qk.survey(survey.id) });
      toast.success("Response submitted — thank you!");
      onDone();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function setAnswer(questionId: string, value: string) {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  }

  function submit() {
    setFormError(null);
    const payload: { questionId: string; value: string }[] = [];
    for (const q of questions) {
      const value = (answers[q.id] ?? "").trim();
      if (q.type === "text") {
        if (value !== "") payload.push({ questionId: q.id, value });
      } else {
        if (!value) {
          setFormError("Please answer every rating and choice question.");
          return;
        }
        payload.push({ questionId: q.id, value });
      }
    }
    submitResponse.mutate(payload);
  }

  return (
    <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-lg">
      <DialogHeader>
        <DialogTitle>{survey.title}</DialogTitle>
        <DialogDescription>
          {survey.anonymous
            ? "Your responses stay confidential and are never tied to your name."
            : "Your response is recorded against your employee record."}
        </DialogDescription>
      </DialogHeader>

      {detailQuery.isPending ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-10 w-full" />
            </div>
          ))}
        </div>
      ) : detailQuery.isError ? (
        <LoadError
          message={detailQuery.error instanceof Error ? detailQuery.error.message : undefined}
          onRetry={() => detailQuery.refetch()}
        />
      ) : detail?.survey.hasResponded ? (
        <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed px-6 py-8 text-center">
          <CheckCircle2 className="h-8 w-8 text-emerald-600" />
          <p className="text-sm font-medium">You have already responded</p>
          <p className="text-sm text-muted-foreground">
            Each employee can answer a survey once. Thank you for participating!
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-6">
            {questions.map((q, i) => (
              <div key={q.id} className="space-y-2.5">
                <div className="flex items-start justify-between gap-3">
                  <Label className="text-sm font-medium leading-snug">
                    <span className="mr-1.5 text-muted-foreground">Q{i + 1}.</span>
                    {q.text}
                  </Label>
                  {q.type === "text" ? (
                    <span className="shrink-0 text-xs text-muted-foreground">Optional</span>
                  ) : null}
                </div>

                {q.type === "rating_10" ? (
                  <div className="grid grid-cols-5 gap-2 sm:grid-cols-10" role="group" aria-label={`Rating for question ${i + 1}`}>
                    {Array.from({ length: 10 }, (_, idx) => String(idx + 1)).map((n) => {
                      const selected = answers[q.id] === n;
                      return (
                        <button
                          key={n}
                          type="button"
                          aria-pressed={selected}
                          onClick={() => setAnswer(q.id, n)}
                          className={cn(
                            "h-11 rounded-md border text-sm font-semibold tabular-nums transition-colors",
                            selected
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-input bg-background hover:bg-accent"
                          )}
                        >
                          {n}
                        </button>
                      );
                    })}
                  </div>
                ) : q.type === "choice" ? (
                  <RadioGroup
                    value={answers[q.id] ?? ""}
                    onValueChange={(v) => setAnswer(q.id, v)}
                    className="gap-2"
                  >
                    {q.options.map((option) => (
                      <Label
                        key={option}
                        className="flex cursor-pointer items-center gap-2.5 rounded-md border p-3 text-sm font-normal hover:bg-accent"
                      >
                        <RadioGroupItem value={option} />
                        {option}
                      </Label>
                    ))}
                  </RadioGroup>
                ) : (
                  <Textarea
                    aria-label={`Answer for question ${i + 1}`}
                    placeholder="Share your thoughts (optional)…"
                    value={answers[q.id] ?? ""}
                    onChange={(e) => setAnswer(q.id, e.target.value)}
                    className="min-h-20"
                  />
                )}
              </div>
            ))}
          </div>

          {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
        </>
      )}

      <DialogFooter>
        <Button variant="outline" onClick={onDone}>
          Cancel
        </Button>
        <Button
          onClick={submit}
          disabled={submitResponse.isPending || detailQuery.isPending || !!detail?.survey.hasResponded}
        >
          {submitResponse.isPending ? "Submitting…" : "Submit response"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

// ===================== Results dialog (managers) =====================

function ResultsDialogContent({ survey }: { survey: SurveyListItemDto }) {
  const detailQuery = useQuery({
    queryKey: qk.survey(survey.id),
    queryFn: () => api.get<SurveyDetailDto>(`/api/surveys/${survey.id}`),
  });

  const detail = detailQuery.data;
  const results = detail?.results ?? null;

  return (
    <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-2xl">
      <DialogHeader>
        <DialogTitle className="flex flex-wrap items-center gap-2">
          <BarChart3 className="h-5 w-5 text-emerald-600" />
          {survey.title}
        </DialogTitle>
        <DialogDescription>
          Aggregated results — individual identities are never shown
          {survey.anonymous ? " and this survey is anonymous." : "."}
        </DialogDescription>
      </DialogHeader>

      {detailQuery.isPending ? (
        <div className="space-y-4">
          <Skeleton className="h-16 w-full rounded-lg" />
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-24 w-full rounded-lg" />
            </div>
          ))}
        </div>
      ) : detailQuery.isError ? (
        <LoadError
          message={detailQuery.error instanceof Error ? detailQuery.error.message : undefined}
          onRetry={() => detailQuery.refetch()}
        />
      ) : !results ? (
        <EmptyState
          title="Results unavailable"
          description="Aggregated results are only available to HR administrators."
        />
      ) : (
        <div className="space-y-5">
          <div className="space-y-2 rounded-lg border bg-muted/30 p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-sm font-medium">
                {detail?.survey.responseCount ?? 0} of {results.totalEmployees} employee
                {results.totalEmployees === 1 ? "" : "s"} responded
              </p>
              <p className="text-2xl font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                {results.participation}%
              </p>
            </div>
            <Progress value={results.participation} aria-label="Participation rate" />
          </div>

          <div className="scrollbar-thin max-h-[520px] space-y-6 overflow-y-auto pr-1">
            {(detail?.questions ?? []).map((q, i) => {
              const r = results.perQuestion.find((p) => p.questionId === q.id);
              const maxCount = Math.max(1, ...(r?.distribution.map((d) => d.count) ?? [0]));
              return (
                <div key={q.id} className="space-y-3 rounded-lg border p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <p className="text-sm font-medium leading-snug">
                      <span className="mr-1.5 text-muted-foreground">Q{i + 1}.</span>
                      {q.text}
                    </p>
                    <Badge variant="outline" className="shrink-0 text-muted-foreground">
                      {QUESTION_TYPE_LABELS[q.type] ?? q.type}
                    </Badge>
                  </div>

                  {q.type === "rating_10" ? (
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-4xl font-bold tabular-nums">
                        {r?.average != null ? r.average : "—"}
                      </span>
                      <span className="text-sm text-muted-foreground">/ 10 average</span>
                    </div>
                  ) : null}

                  {r && r.distribution.length > 0 ? (
                    <div className="space-y-1.5">
                      {r.distribution.map((d) => (
                        <div key={d.label} className="flex items-center gap-2.5 text-xs">
                          <span className="w-16 shrink-0 truncate text-right text-muted-foreground">
                            {d.label}
                          </span>
                          <div className="h-4 flex-1 overflow-hidden rounded bg-muted">
                            <div
                              className="h-full rounded bg-emerald-600/80"
                              style={{
                                width: d.count === 0 ? "0%" : `${Math.max(6, Math.round((d.count / maxCount) * 100))}%`,
                              }}
                            />
                          </div>
                          <span className="w-6 shrink-0 text-right font-medium tabular-nums">
                            {d.count}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : q.type !== "text" ? (
                    <p className="text-xs text-muted-foreground">No responses yet.</p>
                  ) : null}

                  {q.type === "text" ? (
                    r && r.textAnswers.length > 0 ? (
                      <ul className="space-y-2">
                        {r.textAnswers.map((answer, idx) => (
                          <li
                            key={idx}
                            className="rounded-md border border-l-2 border-l-emerald-600/60 bg-muted/40 px-3 py-2 text-sm"
                          >
                            {answer}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-muted-foreground">No written answers yet.</p>
                    )
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </DialogContent>
  );
}

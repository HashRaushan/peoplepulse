"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, qk } from "@/lib/api-client";
import { useAppStore } from "@/lib/store";
import { cn, inr, fmtDate, fmtDateTime, monthLabel, todayIso, initials } from "@/lib/hr-utils";
import { STATUS_LABELS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  Wallet, FileText, Plus, CheckCircle2, Send, Banknote, Printer, Download,
  Loader2, ShieldAlert,
} from "lucide-react";
import type { PayrollRunDto, PayrollRunSummary, PayslipDto } from "@/lib/types";

const runStatusVariant: Record<string, "secondary" | "default" | "outline" | "destructive"> = {
  draft: "secondary", in_review: "outline", approved: "default", paid: "default",
};

interface MyPayslip extends PayslipDto {
  label: string;
  month: number;
  year: number;
  runStatus: string;
}

export function PayrollModule() {
  const { user } = useAppStore();
  const isStaff = user && ["owner", "admin", "hr"].includes(user.role);

  if (!user) return null;
  return isStaff ? <PayrollConsole /> : <MyPayslips />;
}

// ============================== HR payroll console ==============================

function PayrollConsole() {
  const { user } = useAppStore();
  const qc = useQueryClient();
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [payslipView, setPayslipView] = useState<PayslipDto | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [newMonth, setNewMonth] = useState(String(new Date().getMonth() + 1));
  const [newYear, setNewYear] = useState(String(new Date().getFullYear()));

  const runsQuery = useQuery({
    queryKey: qk.payrollRuns,
    queryFn: () => api.get<{ items: PayrollRunSummary[] }>("/api/payroll/runs"),
  });

  const runs = runsQuery.data?.items ?? [];
  const selectedId = selectedRunId ?? runs[0]?.id ?? null;

  const runQuery = useQuery({
    queryKey: qk.payrollRun(selectedId ?? ""),
    queryFn: () => api.get<PayrollRunDto>(`/api/payroll/runs/${selectedId}`),
    enabled: !!selectedId,
  });

  function invalidateDashboard() {
    qc.invalidateQueries({ queryKey: qk.dashboard });
  }

  const actionMutation = useMutation({
    mutationFn: (vars: { id: string; action: string }) =>
      api.patch<{ run: PayrollRunSummary }>(`/api/payroll/runs/${vars.id}`, { action: vars.action }),
    onSuccess: (res) => {
      toast.success(`Payroll run ${res.run.label} is now ${STATUS_LABELS[res.run.status] ?? res.run.status}`);
      qc.invalidateQueries({ queryKey: qk.payrollRuns });
      if (selectedId) qc.invalidateQueries({ queryKey: qk.payrollRun(selectedId) });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Action failed"),
  });

  const createMutation = useMutation({
    mutationFn: () => api.post<{ run: PayrollRunSummary }>("/api/payroll/runs", { month: Number(newMonth), year: Number(newYear) }),
    onSuccess: (res) => {
      toast.success(`Created ${res.run.label} payroll run`, { description: `${res.run.employeeCount} payslips generated in draft.` });
      setNewOpen(false);
      setSelectedRunId(res.run.id);
      qc.invalidateQueries({ queryKey: qk.payrollRuns });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not create run"),
  });

  const run = runQuery.data;
  const canSubmit = run?.status === "draft";
  const canApprove = run?.status === "in_review";
  const canPay = run?.status === "approved";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Payroll</h1>
          <p className="text-sm text-muted-foreground">
            Process, review and approve payroll runs. Statutory components are configurable.
          </p>
        </div>
        <Button onClick={() => setNewOpen(true)}>
          <Plus className="mr-1.5 h-4 w-4" /> New payroll run
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-4">
        {/* Runs list */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Payroll runs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {runsQuery.isLoading && [...Array(4)].map((_, i) => <Skeleton key={i} className="h-14" />)}
            {runsQuery.isError && (
              <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed px-3 py-8 text-center">
                <ShieldAlert className="h-5 w-5 text-destructive" />
                <p className="text-xs text-muted-foreground">
                  {runsQuery.error instanceof Error
                    ? runsQuery.error.message
                    : "Could not load payroll runs."}
                </p>
                <Button variant="outline" size="sm" onClick={() => runsQuery.refetch()}>
                  Retry
                </Button>
              </div>
            )}
            {runs.map((r) => (
              <button
                key={r.id}
                onClick={() => setSelectedRunId(r.id)}
                className={cn(
                  "w-full rounded-lg border p-3 text-left transition-colors",
                  r.id === selectedId ? "border-primary bg-primary/5" : "hover:bg-accent/50"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{r.label}</span>
                  <Badge variant={runStatusVariant[r.status] ?? "secondary"} className="text-[10px]">
                    {STATUS_LABELS[r.status] ?? r.status}
                  </Badge>
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {r.employeeCount} employees · net {inr(r.netTotal, { compact: true })}
                </p>
              </button>
            ))}
            {!runsQuery.isLoading && !runsQuery.isError && runs.length === 0 && (
              <p className="py-6 text-center text-xs text-muted-foreground">No payroll runs yet.</p>
            )}
          </CardContent>
        </Card>

        {/* Run detail */}
        <div className="space-y-4 lg:col-span-3">
          {runQuery.isLoading && <Skeleton className="h-64" />}
          {run && (
            <>
              <Card>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <h2 className="text-lg font-bold">{run.label}</h2>
                        <Badge variant={runStatusVariant[run.status] ?? "secondary"}>
                          {STATUS_LABELS[run.status] ?? run.status}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Processed {run.processedAt ? fmtDateTime(run.processedAt) : "—"}
                        {run.approvedBy && ` · Approved by ${run.approvedBy} ${fmtDateTime(run.approvedAt ?? undefined)}`}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {canSubmit && (
                        <Button size="sm" variant="outline" disabled={actionMutation.isPending} onClick={() => actionMutation.mutate({ id: run.id, action: "submit_review" })}>
                          <Send className="mr-1.5 h-3.5 w-3.5" /> Submit for review
                        </Button>
                      )}
                      {canApprove && (
                        <Button size="sm" disabled={actionMutation.isPending} onClick={() => actionMutation.mutate({ id: run.id, action: "approve" })}>
                          {actionMutation.isPending ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />}
                          Approve run
                        </Button>
                      )}
                      {canPay && (
                        <Button size="sm" disabled={actionMutation.isPending} onClick={() => actionMutation.mutate({ id: run.id, action: "mark_paid" })}>
                          <Banknote className="mr-1.5 h-3.5 w-3.5" /> Mark as paid
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-3">
                    <div className="rounded-lg border p-3">
                      <p className="text-[11px] text-muted-foreground">Employees</p>
                      <p className="mt-0.5 text-xl font-bold">{run.employeeCount}</p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <p className="text-[11px] text-muted-foreground">Gross total</p>
                      <p className="mt-0.5 text-xl font-bold">{inr(run.grossTotal, { compact: true })}</p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <p className="text-[11px] text-muted-foreground">Net disbursement</p>
                      <p className="mt-0.5 text-xl font-bold">{inr(run.netTotal, { compact: true })}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Payslips ({run.payslips.length})</CardTitle>
                  <Button
                    variant="outline" size="sm" className="h-7 text-xs"
                    onClick={() => {
                      import("@/lib/hr-utils").then(({ downloadCsv }) =>
                        downloadCsv(`payroll-${run.label.replace(" ", "-")}`, run.payslips as unknown as Record<string, unknown>[], [
                          { key: "employeeCode", label: "Code" }, { key: "employeeName", label: "Employee" },
                          { key: "department", label: "Department" }, { key: "daysPaid", label: "Days Paid" },
                          { key: "lopDays", label: "LOP" }, { key: "gross", label: "Gross" },
                          { key: "pf", label: "PF" }, { key: "esic", label: "ESIC" },
                          { key: "pt", label: "PT" }, { key: "tds", label: "TDS" }, { key: "net", label: "Net" },
                        ])
                      );
                    }}
                  >
                    <Download className="mr-1.5 h-3 w-3" /> Export register
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="max-h-[26rem] overflow-auto scrollbar-thin">
                    <table className="w-full text-sm">
                      <thead className="sticky top-0 bg-card">
                        <tr className="border-b text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                          <th className="py-2 pr-2 font-medium">Employee</th>
                          <th className="py-2 pr-2 font-medium">Days</th>
                          <th className="py-2 pr-2 text-right font-medium">Gross</th>
                          <th className="py-2 pr-2 text-right font-medium">Deductions</th>
                          <th className="py-2 pr-2 text-right font-medium">Net</th>
                          <th className="py-2 text-right font-medium"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {run.payslips.map((p) => {
                          const ded = p.pf + p.esic + p.pt + p.tds + p.otherDeductions;
                          return (
                            <tr key={p.id} className="border-b border-border/60 last:border-0 hover:bg-accent/40">
                              <td className="py-2.5 pr-2">
                                <div className="flex items-center gap-2">
                                  <span
                                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold"
                                    style={{ backgroundColor: "#05966922", color: "#059669" }}
                                  >
                                    {initials(p.employeeName)}
                                  </span>
                                  <div>
                                    <p className="text-xs font-medium leading-tight">{p.employeeName}</p>
                                    <p className="text-[10px] text-muted-foreground">{p.employeeCode} · {p.department}</p>
                                  </div>
                                </div>
                              </td>
                              <td className="py-2.5 pr-2 text-xs text-muted-foreground">
                                {p.daysPaid}{p.lopDays > 0 && <span className="text-destructive"> ({p.lopDays} LOP)</span>}
                              </td>
                              <td className="py-2.5 pr-2 text-right text-xs">{inr(p.gross)}</td>
                              <td className="py-2.5 pr-2 text-right text-xs text-muted-foreground">{inr(ded)}</td>
                              <td className="py-2.5 pr-2 text-right text-xs font-semibold">{inr(p.net)}</td>
                              <td className="py-2.5 text-right">
                                <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px]" onClick={() => setPayslipView(p)}>
                                  View
                                </Button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
          {runQuery.isError && (
            <Card><CardContent className="flex items-center gap-2 p-6 text-sm text-muted-foreground">
              <ShieldAlert className="h-4 w-4 text-destructive" /> Could not load this payroll run.
            </CardContent></Card>
          )}
        </div>
      </div>

      {/* New run dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>New payroll run</DialogTitle>
            <DialogDescription>
              Generates draft payslips for all active employees using the configured salary structures
              and statutory components. You can review before approving.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="mb-1.5 text-xs font-medium">Month</p>
              <Select value={newMonth} onValueChange={setNewMonth}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["January","February","March","April","May","June","July","August","September","October","November","December"].map((m, i) => (
                    <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium">Year</p>
              <Select value={newYear} onValueChange={setNewYear}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[0, 1].map((d) => {
                    const y = String(new Date().getFullYear() - d);
                    return <SelectItem key={y} value={y}>{y}</SelectItem>;
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="rounded-lg border bg-muted/40 p-3 text-[11px] leading-relaxed text-muted-foreground">
            <ShieldAlert className="mr-1 inline h-3.5 w-3.5 text-amber-600" />
            Statutory values (PF, ESI, PT, TDS) are configurable per organisation and effective-dated.
            Review generated payslips and verify against current statutory rules before disbursement.
          </div>
          <Button disabled={createMutation.isPending} onClick={() => createMutation.mutate()}>
            {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Process payroll
          </Button>
        </DialogContent>
      </Dialog>

      {/* Payslip viewer */}
      <PayslipDialog payslip={payslipView} onClose={() => setPayslipView(null)} orgName={user?.tenantName ?? ""} />
    </div>
  );
}

// ============================== Employee payslips ==============================

function MyPayslips() {
  const [view, setView] = useState<MyPayslip | null>(null);
  const { user } = useAppStore();

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: qk.myPayslips,
    queryFn: () => api.get<{ items: MyPayslip[] }>("/api/payroll/me"),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My payslips</h1>
        <p className="text-sm text-muted-foreground">Download your monthly payslips as they are finalised.</p>
      </div>

      {isLoading && <Skeleton className="h-40" />}
      {isError && (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 p-10 text-center">
            <ShieldAlert className="h-8 w-8 text-destructive" />
            <p className="text-sm font-medium">Something went wrong</p>
            <p className="max-w-md text-xs text-muted-foreground">
              {error instanceof Error ? error.message : "We could not load your payslips. Please try again."}
            </p>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}
      {!isError && data && data.items.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 p-10 text-center">
            <Wallet className="h-8 w-8 text-muted-foreground/50" />
            <p className="text-sm font-medium">No payslips yet</p>
            <p className="text-xs text-muted-foreground">Your payslips will appear here after the first payroll run is processed.</p>
          </CardContent>
        </Card>
      )}
      {data && data.items.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.items.map((p) => (
            <Card key={p.id} className="transition-shadow hover:shadow-md">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{p.label}</p>
                      <p className="text-[11px] text-muted-foreground">{p.daysPaid} paid days{p.lopDays > 0 ? ` · ${p.lopDays} LOP` : ""}</p>
                    </div>
                  </div>
                  <Badge variant={runStatusVariant[p.runStatus] ?? "secondary"} className="text-[10px]">
                    {STATUS_LABELS[p.runStatus] ?? p.runStatus}
                  </Badge>
                </div>
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <p className="text-[11px] text-muted-foreground">Net pay</p>
                    <p className="text-xl font-bold">{inr(p.net)}</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setView(p)}>
                    View payslip
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <PayslipDialog payslip={view} onClose={() => setView(null)} orgName={user?.tenantName ?? ""} employeeView />
    </div>
  );
}

// ============================== Payslip dialog (printable) ==============================

function PayslipDialog({
  payslip, onClose, orgName, employeeView,
}: {
  payslip: (PayslipDto & { label?: string }) | null;
  onClose: () => void;
  orgName: string;
  employeeView?: boolean;
}) {
  if (!payslip) return null;
  const ded = payslip.pf + payslip.esic + payslip.pt + payslip.tds + payslip.otherDeductions;

  return (
    <Dialog open={!!payslip} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader className="no-print">
          <DialogTitle className="flex items-center gap-2">
            Payslip — {payslip.label ?? "Detail"}
          </DialogTitle>
          <DialogDescription>
            {orgName} · confidential document. Generated from the approved payroll run.
          </DialogDescription>
        </DialogHeader>

        <div className="print-area max-h-[62vh] overflow-y-auto scrollbar-thin rounded-lg border p-5">
          <div className="text-center">
            <p className="text-lg font-bold tracking-tight">{orgName}</p>
            <p className="text-xs text-muted-foreground">Payslip for {payslip.label ?? "the period"}</p>
          </div>
          <Separator className="my-4" />
          <div className="grid grid-cols-2 gap-y-1.5 text-xs">
            <span className="text-muted-foreground">Employee</span><span className="text-right font-medium">{payslip.employeeName}</span>
            <span className="text-muted-foreground">Employee code</span><span className="text-right font-medium">{payslip.employeeCode}</span>
            <span className="text-muted-foreground">Designation</span><span className="text-right font-medium">{payslip.designation}</span>
            <span className="text-muted-foreground">Department</span><span className="text-right font-medium">{payslip.department}</span>
            <span className="text-muted-foreground">Days paid</span><span className="text-right font-medium">{payslip.daysPaid} ({payslip.lopDays} LOP)</span>
          </div>
          <Separator className="my-4" />
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Earnings</p>
              <div className="space-y-1.5 text-xs">
                <Row label="Basic" value={inr(payslip.basic)} />
                <Row label="HRA" value={inr(payslip.hra)} />
                <Row label="Special allowance" value={inr(payslip.specialAllowance)} />
                <Separator className="my-2" />
                <Row label="Gross earnings" value={inr(payslip.gross)} bold />
              </div>
            </div>
            <div>
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Deductions</p>
              <div className="space-y-1.5 text-xs">
                <Row label="Provident Fund (EPF)" value={inr(payslip.pf)} />
                <Row label="ESIC" value={payslip.esic > 0 ? inr(payslip.esic) : "—"} />
                <Row label="Professional Tax" value={inr(payslip.pt)} />
                <Row label="TDS (indicative)" value={inr(payslip.tds)} />
                {payslip.otherDeductions > 0 && <Row label="Other deductions" value={inr(payslip.otherDeductions)} />}
                <Separator className="my-2" />
                <Row label="Total deductions" value={inr(ded)} bold />
              </div>
            </div>
          </div>
          <Separator className="my-4" />
          <div className="flex items-center justify-between rounded-lg bg-primary/10 px-4 py-3">
            <span className="text-sm font-semibold">Net pay</span>
            <span className="text-lg font-bold text-primary">{inr(payslip.net)}</span>
          </div>
          <p className="mt-4 text-[10px] leading-relaxed text-muted-foreground">
            Statutory deductions are computed from the organisation&apos;s effective-dated payroll configuration.
            This is a system-generated document. {employeeView ? "" : "Verify against current statutory rules before disbursement."}
          </p>
        </div>

        <div className="no-print flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button onClick={() => window.print()}>
            <Printer className="mr-1.5 h-4 w-4" /> Print / Save PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className={cn("text-muted-foreground", bold && "font-semibold text-foreground")}>{label}</span>
      <span className={cn(bold && "font-bold")}>{value}</span>
    </div>
  );
}

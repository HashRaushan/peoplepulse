"use client";

/**
 * PeoplePulse HR — Leave module.
 * Approvals queue + team calendar (owner/admin/hr/manager) and personal leave
 * self-service with balances, applications and history.
 */

import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Ban, CalendarDays, ChevronLeft, ChevronRight, Inbox, Plus } from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { STATUS_LABELS } from "@/lib/constants";
import { ago, cn, fmtDate, initials, monthLabel, statusBadgeClasses, todayIso, workingDaysInclusive } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { HR_ROLES } from "@/lib/types";
import type {
  LeaveBalanceDto,
  LeaveCalendarDay,
  LeaveRequestDto,
  LeaveRequestStatus,
  LeaveTypeDto,
} from "@/lib/types";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local helpers =====================

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface LeaveRequestsResponse {
  items: LeaveRequestDto[];
  total: number;
  page: number;
  pageSize: number;
}

function statusBadgeVariant(status: LeaveRequestStatus): "destructive" | "outline" {
  switch (status) {
    case "approved":
    case "pending":
      // Coloured via shared statusBadgeClasses to match expenses/training.
      return "outline";
    case "rejected":
      return "destructive";
    default:
      return "outline";
  }
}

function Avatar({ name, color, className }: { name: string; color: string; className?: string }) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function currentMonthStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function shiftMonth(month: string, delta: number): string {
  const [y, m] = month.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthTitle(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return monthLabel(m, y);
}

// ===================== Module =====================

export function LeaveModule() {
  const { user } = useAppStore();
  const isAdmin = !!user && HR_ROLES.includes(user.role);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Leave</h1>
        <p className="text-sm text-muted-foreground">
          {isAdmin
            ? "Approve requests, plan coverage with the team calendar and manage your own leave."
            : "Apply for leave, track balances and see who else is off."}
        </p>
      </div>

      {isAdmin ? (
        <Tabs defaultValue="approvals">
          <TabsList>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
            <TabsTrigger value="calendar">Team calendar</TabsTrigger>
            <TabsTrigger value="mine">My leave</TabsTrigger>
          </TabsList>
          <TabsContent value="approvals" className="mt-4">
            <ApprovalsView />
          </TabsContent>
          <TabsContent value="calendar" className="mt-4">
            <CalendarView />
          </TabsContent>
          <TabsContent value="mine" className="mt-4">
            <MyLeaveView />
          </TabsContent>
        </Tabs>
      ) : (
        <Tabs defaultValue="mine">
          <TabsList>
            <TabsTrigger value="mine">My leave</TabsTrigger>
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
          </TabsList>
          <TabsContent value="mine" className="mt-4">
            <MyLeaveView />
          </TabsContent>
          <TabsContent value="calendar" className="mt-4">
            <CalendarView />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

// ===================== Approvals (admin/manager) =====================

function ApprovalsView() {
  const qc = useQueryClient();

  const pendingQuery = useQuery({
    queryKey: qk.leaveRequests({ scope: "all", status: "pending" }),
    queryFn: () => api.get<LeaveRequestsResponse>("/api/leave/requests?scope=all&status=pending"),
  });

  const allQuery = useQuery({
    queryKey: qk.leaveRequests({ scope: "all" }),
    queryFn: () => api.get<LeaveRequestsResponse>("/api/leave/requests?scope=all"),
  });

  const decided = useMemo(
    () =>
      (allQuery.data?.items ?? [])
        .filter((r) => r.status !== "pending")
        .sort((a, b) => (b.decidedAt ?? b.createdAt).localeCompare(a.decidedAt ?? a.createdAt))
        .slice(0, 10),
    [allQuery.data]
  );

  const [decision, setDecision] = useState<{
    request: LeaveRequestDto;
    action: "approve" | "reject";
  } | null>(null);
  const [comment, setComment] = useState("");

  const decide = useMutation({
    mutationFn: (v: { id: string; action: "approve" | "reject"; comment?: string }) =>
      api.patch<{ request: LeaveRequestDto }>(`/api/leave/requests/${v.id}`, {
        action: v.action,
        ...(v.comment ? { comment: v.comment } : {}),
      }),
    onSuccess: (_data, v) => {
      qc.invalidateQueries({ queryKey: ["leave-requests"] });
      qc.invalidateQueries({ queryKey: ["leave-balances"] });
      qc.invalidateQueries({ queryKey: ["leave-calendar"] });
      // Approvals write attendance leave rows + update balances shown on the
      // dashboard and in the employee detail sheet — keep those fresh too.
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["attendance"] });
      qc.invalidateQueries({ queryKey: ["my-attendance"] });
      qc.invalidateQueries({ queryKey: ["employee"] });
      toast.success(v.action === "approve" ? "Leave request approved" : "Leave request rejected");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const pending = pendingQuery.data?.items ?? [];

  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="text-base font-semibold">
          Pending approvals
          {pending.length > 0 ? (
            <Badge variant="secondary" className="ml-2 tabular-nums">
              {pending.length}
            </Badge>
          ) : null}
        </h2>

        {pendingQuery.isPending ? (
          <div className="grid gap-4 md:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-48 rounded-xl" />
            ))}
          </div>
        ) : pendingQuery.isError ? (
          <LoadError
            message={pendingQuery.error instanceof Error ? pendingQuery.error.message : undefined}
            onRetry={() => pendingQuery.refetch()}
          />
        ) : pending.length === 0 ? (
          <EmptyState
            icon={<Inbox className="h-8 w-8 text-muted-foreground/50" />}
            title="No pending requests"
            description="You are all caught up — new requests will appear here for approval."
          />
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {pending.map((r) => (
              <Card key={r.id} className="gap-3 py-4">
                <CardHeader className="px-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Avatar name={r.employeeName} color={r.avatarColor} />
                      <div>
                        <CardTitle className="text-sm">{r.employeeName}</CardTitle>
                        <CardDescription className="text-xs">
                          {r.department} · {r.employeeCode}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant="secondary">{r.typeName}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="px-4">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                    <span className="font-medium">
                      {fmtDate(r.startDate)} – {fmtDate(r.endDate)}
                    </span>
                    <span className="text-muted-foreground">
                      {r.days} day{r.days === 1 ? "" : "s"}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      Applied {ago(r.createdAt)}
                    </span>
                  </div>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{r.reason}</p>
                </CardContent>
                <CardFooter className="gap-2 px-4">
                  <Button
                    size="sm"
                    disabled={decide.isPending}
                    onClick={() => {
                      setDecision({ request: r, action: "approve" });
                      setComment("");
                    }}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                    disabled={decide.isPending}
                    onClick={() => {
                      setDecision({ request: r, action: "reject" });
                      setComment("");
                    }}
                  >
                    Reject
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="text-base font-semibold">Recently decided</h2>
        {allQuery.isPending ? (
          <Skeleton className="h-40 rounded-xl" />
        ) : allQuery.isError ? (
          <LoadError
            message={allQuery.error instanceof Error ? allQuery.error.message : undefined}
            onRetry={() => allQuery.refetch()}
          />
        ) : decided.length === 0 ? (
          <EmptyState title="Nothing decided yet" description="Approved and rejected requests will be listed here." />
        ) : (
          <div className="overflow-hidden rounded-xl border bg-card">
            <ul className="divide-y">
              {decided.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-3 text-sm">
                  <Avatar name={r.employeeName} color={r.avatarColor} className="h-7 w-7" />
                  <span className="font-medium">{r.employeeName}</span>
                  <Badge variant={statusBadgeVariant(r.status)} className={statusBadgeClasses(r.status)}>
                    {STATUS_LABELS[r.status]}
                  </Badge>
                  <span className="text-muted-foreground">
                    {r.typeName} · {r.days} day{r.days === 1 ? "" : "s"}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    by {r.approverName ?? "—"}
                    {r.decidedAt ? ` · ${ago(r.decidedAt)}` : ""}
                    {r.comment ? ` — "${r.comment}"` : ""}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      {/* Approve / reject dialog */}
      <Dialog open={!!decision} onOpenChange={(open) => !open && setDecision(null)}>
        {decision ? (
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>
                {decision.action === "approve" ? "Approve leave request" : "Reject leave request"}
              </DialogTitle>
              <DialogDescription>
                {decision.request.employeeName} · {decision.request.typeName} ·{" "}
                {decision.request.days} day{decision.request.days === 1 ? "" : "s"} (
                {fmtDate(decision.request.startDate)} to {fmtDate(decision.request.endDate)})
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <Label htmlFor="decision-comment">Comment (optional)</Label>
              <Textarea
                id="decision-comment"
                placeholder="Message shared with the employee"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDecision(null)}>
                Cancel
              </Button>
              <Button
                variant={decision.action === "reject" ? "destructive" : "default"}
                disabled={decide.isPending}
                onClick={() => {
                  decide.mutate({
                    id: decision.request.id,
                    action: decision.action,
                    comment,
                  });
                  setDecision(null);
                }}
              >
                {decision.action === "approve" ? "Approve" : "Reject"}
              </Button>
            </DialogFooter>
          </DialogContent>
        ) : null}
      </Dialog>
    </div>
  );
}

// ===================== My leave =====================

function MyLeaveView() {
  const qc = useQueryClient();

  const balancesQuery = useQuery({
    queryKey: qk.leaveBalances(),
    queryFn: () => api.get<{ items: LeaveBalanceDto[] }>("/api/leave/balances"),
  });
  const typesQuery = useQuery({
    queryKey: qk.leaveTypes,
    queryFn: () => api.get<{ items: LeaveTypeDto[] }>("/api/leave/types"),
  });
  const mineQuery = useQuery({
    queryKey: qk.leaveRequests({ scope: "mine" }),
    queryFn: () => api.get<LeaveRequestsResponse>("/api/leave/requests?scope=mine"),
  });

  const balances = balancesQuery.data?.items ?? [];
  const types = typesQuery.data?.items ?? [];
  const myRequests = useMemo(
    () => (mineQuery.data?.items ?? []).sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    [mineQuery.data]
  );

  // ---- apply dialog state ----
  const [applyOpen, setApplyOpen] = useState(false);
  const [leaveTypeId, setLeaveTypeId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [reason, setReason] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  const selectedBalance = balances.find((b) => b.leaveTypeId === leaveTypeId);
  const previewDays = startDate && endDate ? workingDaysInclusive(startDate, endDate) : 0;

  function resetApplyForm() {
    setLeaveTypeId("");
    setStartDate("");
    setEndDate("");
    setReason("");
    setFormError(null);
  }

  const apply = useMutation({
    mutationFn: (v: { leaveTypeId: string; startDate: string; endDate: string; reason: string }) =>
      api.post<{ request: LeaveRequestDto }>("/api/leave/requests", v),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leave-requests"] });
      qc.invalidateQueries({ queryKey: ["leave-balances"] });
      qc.invalidateQueries({ queryKey: ["leave-calendar"] });
      // Applications can move pending counts on the dashboard; keep it fresh.
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["attendance"] });
      qc.invalidateQueries({ queryKey: ["my-attendance"] });
      qc.invalidateQueries({ queryKey: ["employee"] });
      toast.success("Leave request submitted for approval");
      setApplyOpen(false);
      resetApplyForm();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const cancel = useMutation({
    mutationFn: (id: string) =>
      api.patch<{ request: LeaveRequestDto }>(`/api/leave/requests/${id}`, { action: "cancel" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leave-requests"] });
      qc.invalidateQueries({ queryKey: ["leave-balances"] });
      qc.invalidateQueries({ queryKey: ["leave-calendar"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["attendance"] });
      qc.invalidateQueries({ queryKey: ["my-attendance"] });
      qc.invalidateQueries({ queryKey: ["employee"] });
      toast.success("Leave request cancelled");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitApply() {
    setFormError(null);
    if (!leaveTypeId) {
      setFormError("Select a leave type.");
      return;
    }
    if (!startDate || !endDate) {
      setFormError("Pick both a start and an end date.");
      return;
    }
    if (endDate < startDate) {
      setFormError("The end date cannot be before the start date.");
      return;
    }
    const days = workingDaysInclusive(startDate, endDate);
    if (days <= 0) {
      setFormError("The selected range has no working days — Sundays are weekly offs.");
      return;
    }
    if (selectedBalance && days > selectedBalance.available) {
      setFormError(
        `Insufficient balance — ${selectedBalance.available} day(s) of ${selectedBalance.name} available, ${days} requested.`
      );
      return;
    }
    if (!reason.trim()) {
      setFormError("Add a short reason for your leave.");
      return;
    }
    apply.mutate({ leaveTypeId, startDate, endDate, reason: reason.trim() });
  }

  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Leave balances</h2>
          <Button
            size="sm"
            onClick={() => {
              resetApplyForm();
              setApplyOpen(true);
            }}
          >
            <Plus /> Apply for leave
          </Button>
        </div>

        {balancesQuery.isPending ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-44 rounded-xl" />
            ))}
          </div>
        ) : balancesQuery.isError ? (
          <LoadError
            message={balancesQuery.error instanceof Error ? balancesQuery.error.message : undefined}
            onRetry={() => balancesQuery.refetch()}
          />
        ) : balances.length === 0 ? (
          <EmptyState title="No leave types assigned" description="Your HR team has not assigned leave balances yet." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {balances.map((b) => (
              <Card key={b.leaveTypeId} className="gap-2 py-4">
                <CardHeader className="px-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">{b.name}</CardTitle>
                    <Badge variant="outline">{b.code}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="px-4">
                  <div className="text-3xl font-bold tabular-nums">{b.available}</div>
                  <div className="text-xs text-muted-foreground">day(s) available</div>
                  <Progress
                    className="mt-3 h-1.5"
                    value={b.entitled > 0 ? Math.min(100, Math.round((b.used / b.entitled) * 100)) : 0}
                  />
                  <div className="mt-1.5 flex justify-between text-xs text-muted-foreground">
                    <span>{b.used} used</span>
                    <span>{b.pending} pending</span>
                    <span>{b.entitled} entitled</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="text-base font-semibold">My requests</h2>
        {mineQuery.isPending ? (
          <Skeleton className="h-56 rounded-xl" />
        ) : mineQuery.isError ? (
          <LoadError
            message={mineQuery.error instanceof Error ? mineQuery.error.message : undefined}
            onRetry={() => mineQuery.refetch()}
          />
        ) : myRequests.length === 0 ? (
          <EmptyState
            icon={<CalendarDays className="h-8 w-8 text-muted-foreground/50" />}
            title="No leave requests yet"
            description="Apply for leave and your requests will be tracked here."
          />
        ) : (
          <div className="overflow-hidden rounded-xl border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Dates</TableHead>
                  <TableHead>Days</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Approver</TableHead>
                  <TableHead>Comment</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myRequests.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.typeName}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {fmtDate(r.startDate)} – {fmtDate(r.endDate)}
                    </TableCell>
                    <TableCell className="tabular-nums">{r.days}</TableCell>
                    <TableCell>
                      <Badge
                        variant={statusBadgeVariant(r.status)}
                        className={statusBadgeClasses(r.status)}
                      >
                        {STATUS_LABELS[r.status] ?? r.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{r.approverName ?? "—"}</TableCell>
                    <TableCell
                      className="max-w-48 truncate text-muted-foreground"
                      title={r.comment ?? undefined}
                    >
                      {r.comment ?? "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      {r.status === "pending" ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                          disabled={cancel.isPending}
                          onClick={() => cancel.mutate(r.id)}
                        >
                          <Ban className="h-3.5 w-3.5" /> Cancel
                        </Button>
                      ) : null}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </section>

      {/* Apply for leave dialog */}
      <Dialog open={applyOpen} onOpenChange={setApplyOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Apply for leave</DialogTitle>
            <DialogDescription>
              Sundays are weekly offs and are not counted towards your leave days.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Leave type</Label>
              <Select value={leaveTypeId} onValueChange={setLeaveTypeId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a leave type" />
                </SelectTrigger>
                <SelectContent>
                  {types.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} ({t.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedBalance ? (
                <p className="text-xs text-muted-foreground">
                  {selectedBalance.available} day(s) available of {selectedBalance.entitled} entitled
                </p>
              ) : null}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="leave-start">Start date</Label>
                <Input
                  id="leave-start"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="leave-end">End date</Label>
                <Input
                  id="leave-end"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
            {startDate && endDate ? (
              <p className="rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
                {previewDays > 0
                  ? `${previewDays} working day${previewDays === 1 ? "" : "s"} of leave will be requested.`
                  : "No working days in the selected range."}
              </p>
            ) : null}
            <div className="space-y-2">
              <Label htmlFor="leave-reason">Reason</Label>
              <Textarea
                id="leave-reason"
                className="min-h-20"
                placeholder="Brief reason for your leave"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
            </div>
            {formError ? <p className="text-sm text-destructive">{formError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApplyOpen(false)}>
              Cancel
            </Button>
            <Button disabled={apply.isPending} onClick={submitApply}>
              Submit request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ===================== Team calendar =====================

function CalendarView() {
  const [month, setMonth] = useState(currentMonthStr());

  const query = useQuery({
    queryKey: qk.leaveCalendar(month),
    queryFn: () => api.get<{ month: string; days: LeaveCalendarDay[] }>(`/api/leave/calendar?month=${month}`),
  });

  const days = query.data?.days ?? [];
  const [y, m] = month.split("-").map(Number);
  const leading = new Date(y, m - 1, 1).getDay();
  const today = todayIso();

  const leaveDays = useMemo(() => days.filter((d) => d.leaves.length > 0), [days]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          aria-label="Previous month"
          onClick={() => setMonth((v) => shiftMonth(v, -1))}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="min-w-36 text-center text-sm font-semibold">{monthTitle(month)}</div>
        <Button
          variant="outline"
          size="icon"
          aria-label="Next month"
          onClick={() => setMonth((v) => shiftMonth(v, 1))}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
        {month !== currentMonthStr() ? (
          <Button variant="ghost" size="sm" onClick={() => setMonth(currentMonthStr())}>
            This month
          </Button>
        ) : null}
      </div>

      {query.isPending ? (
        <Skeleton className="h-96 rounded-xl" />
      ) : query.isError ? (
        <LoadError
          message={query.error instanceof Error ? query.error.message : undefined}
          onRetry={() => query.refetch()}
        />
      ) : (
        <div className="space-y-6">
          <div className="overflow-x-auto scrollbar-thin">
            <div className="min-w-[34rem]">
              <div className="grid grid-cols-7 gap-1">
                {WEEKDAYS.map((w) => (
                  <div
                    key={w}
                    className="pb-1 text-center text-[11px] font-medium text-muted-foreground"
                  >
                    {w}
                  </div>
                ))}
                {Array.from({ length: leading }).map((_, i) => (
                  <div key={`blank-${i}`} />
                ))}
                {days.map((day) => {
                  const isToday = day.date === today;
                  const dayNum = Number(day.date.slice(8, 10));
                  return (
                    <div
                      key={day.date}
                      title={
                        day.holiday
                          ? `${day.holiday.name} (${day.holiday.type})`
                          : day.leaves.length > 0
                            ? day.leaves.map((l) => `${l.employeeName} — ${l.typeName}`).join("\n")
                            : undefined
                      }
                      className={cn(
                        "min-h-16 rounded-md border p-1.5 text-left sm:min-h-20",
                        day.isWeekend && "bg-muted/60",
                        isToday && "ring-2 ring-primary ring-offset-1 ring-offset-background"
                      )}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span
                          className={cn(
                            "text-xs font-medium tabular-nums",
                            isToday && "text-primary"
                          )}
                        >
                          {dayNum}
                        </span>
                      </div>
                      {day.holiday ? (
                        <div
                          className="mt-0.5 truncate text-[10px] leading-tight text-amber-600"
                          title={day.holiday.name}
                        >
                          {day.holiday.name}
                        </div>
                      ) : null}
                      <div className="mt-1 flex flex-wrap gap-1">
                        {day.leaves.slice(0, 3).map((l, i) => (
                          <span
                            key={i}
                            title={`${l.employeeName} — ${l.typeName}`}
                            className="size-2 rounded-full"
                            style={{ backgroundColor: l.avatarColor }}
                          />
                        ))}
                        {day.leaves.length > 3 ? (
                          <span className="text-[9px] leading-none text-muted-foreground">
                            +{day.leaves.length - 3}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-sm bg-muted" /> Weekend
            </span>
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-sm bg-amber-500" /> Holiday
            </span>
            <span className="flex items-center gap-1.5">
              <span className="size-2.5 rounded-full bg-primary" /> On leave
            </span>
            <span className="flex items-center gap-1.5">Today is highlighted with a ring</span>
          </div>

          <section className="space-y-3">
            <h2 className="text-base font-semibold">On leave this month</h2>
            {leaveDays.length === 0 ? (
              <EmptyState
                title="Nobody on leave"
                description={`No approved leave in ${monthTitle(month)} so far.`}
              />
            ) : (
              <div className="overflow-hidden rounded-xl border bg-card">
                <ul className="divide-y">
                  {leaveDays.map((d) => (
                    <li
                      key={d.date}
                      className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-3 text-sm"
                    >
                      <span className="w-28 font-medium">{fmtDate(d.date)}</span>
                      <span className="text-muted-foreground">
                        {d.leaves.map((l) => l.employeeName).join(", ")}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

"use client";

/**
 * PeoplePulse HR — Performance module.
 * Review cycles overview (admin) + review table with self/manager/complete flows.
 */

import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Star, Target } from "lucide-react";

import { api, qk } from "@/lib/api-client";
import { STATUS_LABELS } from "@/lib/constants";
import { cn, fmtDate, initials, statusBadgeClasses, todayIso } from "@/lib/hr-utils";
import { useAppStore } from "@/lib/store";
import { HR_ROLES } from "@/lib/types";
import type {
  EmployeeListResponse,
  PerformanceSummary,
  ReviewDto,
  ReviewStatus,
} from "@/lib/types";

import { GoalsSection } from "./goals";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ===================== Local helpers =====================

const HR_ONLY_ROLES = ["owner", "admin", "hr"];

/** Current review half-year, e.g. "H2 2026" (H1 = Jan–Jun, H2 = Jul–Dec). */
function currentHalf(): string {
  const d = new Date();
  return `H${d.getMonth() >= 6 ? 2 : 1} ${d.getFullYear()}`;
}

/** Default period label matching the current half: H1 → "Jan – Jun YYYY", H2 → "Jul – Dec YYYY". */
function currentPeriodLabel(): string {
  const d = new Date();
  return d.getMonth() >= 6 ? `Jul – Dec ${d.getFullYear()}` : `Jan – Jun ${d.getFullYear()}`;
}

function ReviewStatusBadge({ status }: { status: ReviewStatus }) {
  if (status === "draft") {
    return <Badge className="border-transparent bg-muted text-muted-foreground">Draft</Badge>;
  }
  if (status === "self_review") return <Badge variant="secondary">Self Review</Badge>;
  if (status === "manager_review") return <Badge variant="outline">Manager Review</Badge>;
  return (
    <Badge variant="outline" className={statusBadgeClasses(status)}>
      Completed
    </Badge>
  );
}

function Avatar({ name, color, className }: { name: string; color: string; className?: string }) {
  return (
    <div
      style={{ backgroundColor: `${color}22`, color }}
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
        className
      )}
    >
      {initials(name)}
    </div>
  );
}

function RatingStars({
  value,
  onChange,
}: {
  value: number;
  onChange?: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          aria-label={`Rate ${i} out of 5`}
          disabled={!onChange}
          onClick={() => onChange?.(i)}
          className={cn(
            "rounded-sm disabled:cursor-default",
            onChange && "cursor-pointer transition-transform hover:scale-110"
          )}
        >
          <Star
            className={cn(
              "h-4 w-4",
              i <= value ? "fill-current text-amber-500" : "text-muted-foreground/40"
            )}
          />
        </button>
      ))}
    </div>
  );
}

function ratingText(v: number | null): string {
  return v != null ? `${v}/5` : "—";
}

function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed bg-card px-6 py-12 text-center">
      {icon}
      <p className="text-sm font-medium">{title}</p>
      {description ? <p className="max-w-md text-sm text-muted-foreground">{description}</p> : null}
    </div>
  );
}

function LoadError({ message, onRetry }: { message?: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border bg-card px-6 py-12 text-center">
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="max-w-md text-sm text-muted-foreground">
        {message ?? "We could not load this data. Please try again."}
      </p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

// ===================== Module =====================

export function PerformanceModule() {
  const { user } = useAppStore();
  // Non-managerial employees only get the Goals (OKR) self-service view.
  const isEmployee = !!user && !HR_ROLES.includes(user.role);
  const isAdmin = !!user && HR_ROLES.includes(user.role);
  const isHrOnly = !!user && HR_ONLY_ROLES.includes(user.role);
  const qc = useQueryClient();
  const [perfTab, setPerfTab] = useState("reviews");

  const reviewsQuery = useQuery({
    queryKey: qk.reviews(),
    queryFn: () => api.get<{ items: ReviewDto[] }>("/api/performance/reviews"),
    enabled: isAdmin,
  });
  const summaryQuery = useQuery({
    queryKey: qk.performanceSummary,
    queryFn: () => api.get<PerformanceSummary>("/api/performance/summary"),
    enabled: isAdmin,
  });
  const employeesQuery = useQuery({
    queryKey: qk.employees({ pageSize: 100, status: "active" }),
    queryFn: () => api.get<EmployeeListResponse>("/api/employees?pageSize=100&status=active"),
    enabled: isAdmin,
  });

  const reviews = useMemo(
    () => (reviewsQuery.data?.items ?? []).sort((a, b) => b.dueDate.localeCompare(a.dueDate)),
    [reviewsQuery.data]
  );
  const summary = summaryQuery.data;
  const maxDist = Math.max(1, ...(summary?.distribution ?? []).map((d) => d.count));
  const today = todayIso();

  // ---- review detail dialog ----
  const [selected, setSelected] = useState<ReviewDto | null>(null);
  const [selfRating, setSelfRating] = useState(0);
  const [managerRating, setManagerRating] = useState(0);
  const [summaryText, setSummaryText] = useState("");
  const [strengthsText, setStrengthsText] = useState("");
  const [improvementsText, setImprovementsText] = useState("");
  const [confirmComplete, setConfirmComplete] = useState(false);

  function openReview(r: ReviewDto) {
    setSelected(r);
    setSelfRating(r.selfRating ?? 0);
    setManagerRating(r.managerRating ?? 0);
    setSummaryText(r.summary ?? "");
    setStrengthsText(r.strengths ?? "");
    setImprovementsText(r.improvements ?? "");
    setConfirmComplete(false);
  }

  const isOwnReview = !!user?.employeeId && selected?.employeeId === user.employeeId;
  const canSelfAssess = !!selected && isOwnReview && selected.status === "self_review";
  const canManagerAssess = !!selected && isAdmin && selected.status === "manager_review";
  const canComplete =
    !!selected &&
    isHrOnly &&
    selected.status !== "completed" &&
    (selected.managerRating != null || managerRating > 0);

  const reviewMutation = useMutation({
    mutationFn: (v: { id: string; patch: Record<string, unknown>; message: string }) =>
      api.patch<{ item: ReviewDto }>(`/api/performance/reviews/${v.id}`, v.patch),
    onSuccess: (_data, v) => {
      qc.invalidateQueries({ queryKey: ["reviews"] });
      qc.invalidateQueries({ queryKey: ["performance-summary"] });
      toast.success(v.message);
      setSelected(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitSelfAssessment() {
    if (!selected) return;
    if (selfRating < 1) {
      toast.error("Select a rating before submitting your self assessment.");
      return;
    }
    reviewMutation.mutate({
      id: selected.id,
      patch: { action: "self_submit", selfRating },
      message: "Self assessment submitted",
    });
  }

  function submitManagerEvaluation() {
    if (!selected) return;
    if (managerRating < 1) {
      toast.error("Select a manager rating before submitting.");
      return;
    }
    reviewMutation.mutate({
      id: selected.id,
      patch: {
        action: "manager_submit",
        managerRating,
        summary: summaryText,
        strengths: strengthsText,
        improvements: improvementsText,
      },
      message: "Manager evaluation submitted",
    });
  }

  function completeReview() {
    if (!selected) return;
    const finalRating = selected.managerRating ?? managerRating;
    reviewMutation.mutate({
      id: selected.id,
      patch: { action: "complete", finalRating },
      message: "Review completed and shared with the employee",
    });
  }

  // ---- assign review dialog (admin) ----
  const [assignOpen, setAssignOpen] = useState(false);
  const [assignEmployeeId, setAssignEmployeeId] = useState("");
  const [assignCycle, setAssignCycle] = useState(currentHalf());
  const [assignPeriod, setAssignPeriod] = useState("");
  const [assignDue, setAssignDue] = useState("");
  const [assignError, setAssignError] = useState<string | null>(null);

  const assignMutation = useMutation({
    mutationFn: (v: { employeeId: string; cycle: string; periodLabel?: string; dueDate?: string }) =>
      api.post<{ item: ReviewDto }>("/api/performance/reviews", v),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reviews"] });
      qc.invalidateQueries({ queryKey: ["performance-summary"] });
      toast.success("Review assigned");
      setAssignOpen(false);
      setAssignEmployeeId("");
      setAssignPeriod("");
      setAssignDue("");
      setAssignError(null);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  function submitAssign() {
    setAssignError(null);
    if (!assignEmployeeId) {
      setAssignError("Select an employee.");
      return;
    }
    if (!assignCycle.trim()) {
      setAssignError(`Enter a review cycle, e.g. ${currentHalf()}.`);
      return;
    }
    assignMutation.mutate({
      employeeId: assignEmployeeId,
      cycle: assignCycle.trim(),
      ...(assignPeriod.trim() ? { periodLabel: assignPeriod.trim() } : {}),
      ...(assignDue ? { dueDate: assignDue } : {}),
    });
  }

  // Review tab content: overview strip (admin) + reviews table.
  const reviewsTab = (
    <>
      {/* Overview strip (admin only) */}
      {isAdmin ? (
        summaryQuery.isPending ? (
          <div className="grid gap-4 lg:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-56 rounded-xl" />
            ))}
          </div>
        ) : summaryQuery.isError ? (
          <LoadError
            message={summaryQuery.error instanceof Error ? summaryQuery.error.message : undefined}
            onRetry={() => summaryQuery.refetch()}
          />
        ) : summary ? (
          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="gap-3 py-4">
              <CardHeader className="px-4">
                <CardTitle className="text-sm">Rating overview</CardTitle>
              </CardHeader>
              <CardContent className="px-4">
                <div className="flex items-baseline gap-1.5">
                  <span className="text-3xl font-bold tabular-nums">
                    {summary.avgRating != null ? summary.avgRating.toFixed(1) : "—"}
                  </span>
                  <span className="text-sm text-muted-foreground">/ 5 average</span>
                </div>
                <div className="mt-4 space-y-1.5">
                  {[5, 4, 3, 2, 1].map((r) => {
                    const count =
                      summary.distribution.find((d) => Number(d.rating) === r)?.count ?? 0;
                    return (
                      <div key={r} className="flex items-center gap-2">
                        <span className="flex w-8 items-center gap-1 text-xs text-muted-foreground">
                          {r}
                          <Star className="h-3 w-3 fill-current text-amber-500" />
                        </span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-primary"
                            style={{ width: `${Math.round((count / maxDist) * 100)}%` }}
                          />
                        </div>
                        <span className="w-6 text-right text-xs tabular-nums text-muted-foreground">
                          {count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card className="gap-3 py-4">
              <CardHeader className="px-4">
                <CardTitle className="text-sm">Cycle progress</CardTitle>
              </CardHeader>
              <CardContent className="px-4">
                {summary.cycleProgress.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No reviews in this cycle yet.</p>
                ) : (
                  <div className="space-y-2.5">
                    {summary.cycleProgress.map((s) => {
                      const total =
                        summary.cycleProgress.reduce((acc, x) => acc + x.count, 0) || 1;
                      return (
                        <div key={s.status} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">
                              {STATUS_LABELS[s.status] ?? s.status}
                            </span>
                            <span className="font-medium tabular-nums">{s.count}</span>
                          </div>
                          <div className="h-2 overflow-hidden rounded-full bg-muted">
                            <div
                              className="h-full rounded-full bg-primary/70"
                              style={{ width: `${Math.round((s.count / total) * 100)}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="gap-3 py-4">
              <CardHeader className="px-4">
                <CardTitle className="text-sm">By department</CardTitle>
              </CardHeader>
              <CardContent className="px-4">
                {summary.byDepartment.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No completed reviews yet.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Department</TableHead>
                        <TableHead className="text-right">Reviews</TableHead>
                        <TableHead className="text-right">Avg</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {summary.byDepartment.map((d) => (
                        <TableRow key={d.name}>
                          <TableCell>{d.name}</TableCell>
                          <TableCell className="text-right tabular-nums">{d.count}</TableCell>
                          <TableCell className="text-right tabular-nums">
                            {d.avg != null ? d.avg.toFixed(1) : "—"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        ) : null
      ) : null}

      {/* Reviews table */}
      {reviewsQuery.isPending ? (
        <Skeleton className="h-72 rounded-xl" />
      ) : reviewsQuery.isError ? (
        <LoadError
          message={reviewsQuery.error instanceof Error ? reviewsQuery.error.message : undefined}
          onRetry={() => reviewsQuery.refetch()}
        />
      ) : reviews.length === 0 ? (
        <EmptyState
          icon={<Target className="h-8 w-8 text-muted-foreground/50" />}
          title="No performance reviews"
          description={
            isAdmin
              ? "Assign a review to an employee to kick off a cycle."
              : "You have no reviews assigned yet. Your manager will kick off the next cycle."
          }
        />
      ) : (
        <div className="overflow-hidden rounded-xl border bg-card">
          <div className="flex items-center justify-between border-b px-4 py-3">
            <h3 className="text-sm font-semibold">{isAdmin ? "All reviews" : "My reviews"}</h3>
            <span className="text-xs text-muted-foreground">{reviews.length} total</span>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Cycle</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Self</TableHead>
                <TableHead>Manager</TableHead>
                <TableHead>Final</TableHead>
                <TableHead>Reviewer</TableHead>
                <TableHead>Due</TableHead>
                <TableHead>Completed</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reviews.map((r) => {
                const overdue = r.status !== "completed" && r.dueDate < today;
                return (
                  <TableRow
                    key={r.id}
                    className="cursor-pointer ring-ring outline-none focus-visible:ring-1"
                    tabIndex={0}
                    onClick={() => openReview(r)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        openReview(r);
                      }
                    }}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <Avatar name={r.employeeName} color={r.avatarColor} />
                        <div>
                          <div className="font-medium">{r.employeeName}</div>
                          <div className="text-xs text-muted-foreground">{r.employeeCode}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{r.cycle}</div>
                      {r.periodLabel ? (
                        <div className="text-xs text-muted-foreground">{r.periodLabel}</div>
                      ) : null}
                    </TableCell>
                    <TableCell>
                      <ReviewStatusBadge status={r.status} />
                    </TableCell>
                    <TableCell className="tabular-nums">{ratingText(r.selfRating)}</TableCell>
                    <TableCell className="tabular-nums">{ratingText(r.managerRating)}</TableCell>
                    <TableCell className="tabular-nums font-medium">
                      {ratingText(r.finalRating)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{r.reviewerName ?? "—"}</TableCell>
                    <TableCell className={cn("text-muted-foreground", overdue && "text-destructive")}>
                      {fmtDate(r.dueDate)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {r.completedAt ? fmtDate(r.completedAt.slice(0, 10)) : "—"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </>
  );

  // Non-managerial employees: goals only — no review tooling.
  if (isEmployee) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Performance — Goals</h1>
          <p className="text-sm text-muted-foreground">
            Set quarterly OKR goals and track your progress.
          </p>
        </div>
        <GoalsSection />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Performance</h1>
          <p className="text-sm text-muted-foreground">
            Run review cycles and track goals (OKRs) across teams.
          </p>
        </div>
        {perfTab === "reviews" ? (
          <Button size="sm" onClick={() => setAssignOpen(true)}>
            <Plus /> Assign review
          </Button>
        ) : null}
      </div>

      <Tabs value={perfTab} onValueChange={setPerfTab}>
        <TabsList>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>

        <TabsContent value="reviews" className="mt-4 space-y-6">
          {reviewsTab}
        </TabsContent>

        <TabsContent value="goals" className="mt-4">
          <GoalsSection />
        </TabsContent>
      </Tabs>

      {/* Review detail dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        {selected ? (
          <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-thin sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <Avatar name={selected.employeeName} color={selected.avatarColor} />
                <span>{selected.employeeName}</span>
              </DialogTitle>
              <DialogDescription>
                {selected.cycle}
                {selected.periodLabel ? ` · ${selected.periodLabel}` : ""} ·{" "}
                {selected.designation}, {selected.department} · Due {fmtDate(selected.dueDate)}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-5">
              {/* Goals */}
              <section className="space-y-3">
                <h4 className="text-sm font-semibold">Goals</h4>
                {selected.goals.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No goals set for this cycle.</p>
                ) : (
                  <div className="space-y-3">
                    {selected.goals.map((g, i) => (
                      <div key={i} className="space-y-1.5">
                        <div className="flex items-center justify-between gap-2 text-sm">
                          <span>{g.title}</span>
                          <span className="text-xs tabular-nums text-muted-foreground">
                            {g.progress}%
                          </span>
                        </div>
                        <Progress value={g.progress} className="h-1.5" />
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* Self assessment */}
              <section className="space-y-3 rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold">Self assessment</h4>
                  <ReviewStatusBadge status={selected.status} />
                </div>
                {canSelfAssess ? (
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">Your rating</span>
                      <RatingStars value={selfRating} onChange={setSelfRating} />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Submitting will lock your self assessment and move the review to your manager.
                    </p>
                    <Button
                      size="sm"
                      disabled={reviewMutation.isPending}
                      onClick={submitSelfAssessment}
                    >
                      Submit self assessment
                    </Button>
                  </div>
                ) : selected.selfRating != null ? (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">Submitted rating:</span>
                    <RatingStars value={selected.selfRating} />
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Awaiting self assessment.</p>
                )}
              </section>

              {/* Manager evaluation */}
              <section className="space-y-3 rounded-lg border p-4">
                <h4 className="text-sm font-semibold">Manager evaluation</h4>
                {canManagerAssess ? (
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">Rating</span>
                      <RatingStars value={managerRating} onChange={setManagerRating} />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="review-summary">Summary</Label>
                      <Textarea
                        id="review-summary"
                        className="min-h-16"
                        placeholder="Overall assessment of the period"
                        value={summaryText}
                        onChange={(e) => setSummaryText(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="review-strengths">Strengths</Label>
                      <Textarea
                        id="review-strengths"
                        className="min-h-16"
                        placeholder="What went well"
                        value={strengthsText}
                        onChange={(e) => setStrengthsText(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="review-improvements">Improvements</Label>
                      <Textarea
                        id="review-improvements"
                        className="min-h-16"
                        placeholder="Areas to grow"
                        value={improvementsText}
                        onChange={(e) => setImprovementsText(e.target.value)}
                      />
                    </div>
                    <Button
                      size="sm"
                      disabled={reviewMutation.isPending}
                      onClick={submitManagerEvaluation}
                    >
                      Submit evaluation
                    </Button>
                  </div>
                ) : selected.managerRating != null ? (
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Rating:</span>
                      <RatingStars value={selected.managerRating} />
                    </div>
                    {selected.summary ? (
                      <p>
                        <span className="text-muted-foreground">Summary — </span>
                        {selected.summary}
                      </p>
                    ) : null}
                    {selected.strengths ? (
                      <p>
                        <span className="text-muted-foreground">Strengths — </span>
                        {selected.strengths}
                      </p>
                    ) : null}
                    {selected.improvements ? (
                      <p>
                        <span className="text-muted-foreground">Improvements — </span>
                        {selected.improvements}
                      </p>
                    ) : null}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Awaiting manager evaluation.</p>
                )}

                {canComplete ? (
                  <AlertDialog open={confirmComplete} onOpenChange={setConfirmComplete}>
                    <AlertDialogTrigger asChild>
                      <Button size="sm" variant="outline" className="mt-1">
                        Complete review
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Complete this review?</AlertDialogTitle>
                        <AlertDialogDescription>
                          The final rating will be set to{" "}
                          {selected.managerRating ?? managerRating}/5 (manager rating) and the
                          review will be shared with the employee.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={completeReview}>
                          Complete review
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                ) : null}
              </section>
            </div>
          </DialogContent>
        ) : null}
      </Dialog>

      {/* Assign review dialog (admin) */}
      <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Assign review</DialogTitle>
            <DialogDescription>
              Kick off a review cycle for an employee. They will be asked to complete a self
              assessment first.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Employee</Label>
              <Select value={assignEmployeeId} onValueChange={setAssignEmployeeId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select an employee" />
                </SelectTrigger>
                <SelectContent>
                  {(employeesQuery.data?.items ?? []).map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.firstName} {e.lastName} · {e.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="assign-cycle">Cycle</Label>
              <Input
                id="assign-cycle"
                placeholder={currentHalf()}
                value={assignCycle}
                onChange={(e) => setAssignCycle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assign-period">Period label (optional)</Label>
              <Input
                id="assign-period"
                placeholder={currentPeriodLabel()}
                value={assignPeriod}
                onChange={(e) => setAssignPeriod(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assign-due">Due date</Label>
              <Input
                id="assign-due"
                type="date"
                value={assignDue}
                onChange={(e) => setAssignDue(e.target.value)}
              />
            </div>
            {assignError ? <p className="text-sm text-destructive">{assignError}</p> : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignOpen(false)}>
              Cancel
            </Button>
            <Button disabled={assignMutation.isPending} onClick={submitAssign}>
              Assign review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

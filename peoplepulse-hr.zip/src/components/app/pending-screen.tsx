"use client";

/**
 * PeoplePulse HR — Blocked-workspace screen & buyer payment flow.
 *
 * PendingScreen: full-screen state for workspaces that are not active yet
 * (pending approval, rejected, suspended, expired trial, renewal due).
 *
 * PaymentPanel: the reusable payment component — plan/cycle/seats selection,
 * price breakdown, the platform's bank/UPI details with copy buttons and the
 * UTR submission form. Used by PendingScreen and by Settings → Plan & billing
 * (renewals).
 */
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "@/lib/store";
import { api, qk } from "@/lib/api-client";
import { cn, inr, fmtDate } from "@/lib/hr-utils";
import { computePlanPrice } from "@/lib/billing";
import { PRICING_PLANS, STATUS_LABELS } from "@/lib/constants";
import { isPaidPlan } from "@/lib/plan-state";
import type { BillingOverviewDto, PaymentMethodDto, PaymentProofDto, SessionUser } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Copy, Check, Landmark, Smartphone, Loader2, LogOut, Clock3, ShieldCheck,
  BadgeCheck, AlertTriangle, RefreshCw, Send, Info,
} from "lucide-react";

// ============================== Pending screen ==============================

export function PendingScreen() {
  const { user, signOut } = useAppStore();
  const qc = useQueryClient();

  async function handleSignOut() {
    await api.post("/api/auth/logout").catch(() => {});
    qc.clear();
    signOut();
  }

  if (!user) return null;

  return (
    <div className="flex min-h-screen flex-col bg-muted/40">
      <header className="flex h-16 items-center justify-between border-b bg-background px-4 md:px-6">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-sm font-bold text-primary-foreground">
            P
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold leading-tight">{user.tenantName}</p>
            <p className="text-[10px] text-muted-foreground">PeoplePulse HR</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={handleSignOut} className="gap-1.5">
          <LogOut className="h-3.5 w-3.5" /> Sign out
        </Button>
      </header>

      <main className="flex flex-1 items-start justify-center px-4 py-10 md:py-16">
        <div className="w-full max-w-3xl">
          <BlockedContent user={user} />
        </div>
      </main>

      <footer className="mt-auto border-t bg-background px-6 py-4 text-center text-[11px] text-muted-foreground">
        PeoplePulse HR · Every workspace is reviewed by the platform administrator before activation
      </footer>
    </div>
  );
}

function BlockedContent({ user }: { user: SessionUser }) {
  switch (user.blocked) {
    case "pending":
      // Trial signups simply wait; paid signups get the payment flow.
      return user.plan === "trial" ? (
        <AwaitingApprovalCard />
      ) : (
        <>
          <StatusHeader
            icon={<Clock3 className="h-5 w-5" />}
            title="Almost there — activate your workspace"
            subtitle="Transfer the payment below and submit your transaction reference (UTR). The platform administrator verifies it and activates your workspace, usually within a few hours. You can also switch to the free 14-day trial."
          />
          <PaymentPanel variant="activate" allowTrial />
        </>
      );
    case "trial_expired":
      return (
        <>
          <StatusHeader
            icon={<AlertTriangle className="h-5 w-5" />}
            title="Your free trial has ended"
            subtitle="Pick a plan, transfer the payment and submit your transaction reference (UTR) to continue where you left off. Your data is exactly as you left it."
            tone="warning"
          />
          <PaymentPanel variant="activate" />
        </>
      );
    case "renewal_due":
      return (
        <>
          <StatusHeader
            icon={<AlertTriangle className="h-5 w-5" />}
            title="Subscription renewal due"
            subtitle="Your paid period has ended. Transfer the renewal payment and submit the transaction reference (UTR) to restore full access."
            tone="warning"
          />
          <PaymentPanel variant="renew" />
        </>
      );
    case "rejected":
      return (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10">
              <AlertTriangle className="h-7 w-7 text-destructive" />
            </span>
            <h1 className="text-xl font-bold">Signup declined</h1>
            <p className="max-w-md text-sm text-muted-foreground">
              Your signup request was declined by the platform administrator.
              {user.statusReason ? ` Reason: ${user.statusReason}` : ""}
              {" "}If you believe this is a mistake, please contact support.
            </p>
          </CardContent>
        </Card>
      );
    case "suspended":
      return (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10">
              <AlertTriangle className="h-7 w-7 text-destructive" />
            </span>
            <h1 className="text-xl font-bold">Workspace suspended</h1>
            <p className="max-w-md text-sm text-muted-foreground">
              This workspace has been suspended by the platform administrator.
              {user.statusReason ? ` Reason: ${user.statusReason}` : ""}
              {" "}Your data is safe — contact support to restore access.
            </p>
          </CardContent>
        </Card>
      );
    default:
      return null;
  }
}

function AwaitingApprovalCard() {
  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Clock3 className="h-7 w-7 text-primary" />
        </span>
        <h1 className="text-xl font-bold">Your workspace is under review</h1>
        <p className="max-w-md text-sm text-muted-foreground">
          The platform administrator reviews every new signup. You will receive an
          email as soon as your <strong>14-day free trial</strong> is approved — usually
          within a few hours. You can leave this page; your workspace is already saved.
        </p>
        <div className="mt-2 flex items-center gap-2 rounded-full border bg-muted/50 px-4 py-2 text-xs text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" />
          Approval required · Trial · No payment needed yet
        </div>
      </CardContent>
    </Card>
  );
}

function StatusHeader({
  icon, title, subtitle, tone = "info",
}: {
  icon: React.ReactNode; title: string; subtitle: string; tone?: "info" | "warning";
}) {
  return (
    <div className="mb-6 text-center">
      <span
        className={cn(
          "mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full",
          tone === "warning" ? "bg-amber-500/10 text-amber-600" : "bg-primary/10 text-primary"
        )}
      >
        {icon}
      </span>
      <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
      <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">{subtitle}</p>
    </div>
  );
}

// ============================== Payment panel ==============================

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/**
 * The buyer payment flow.
 * variant="activate" — pending workspace / expired trial
 * variant="renew"    — renewal (blocked renewal_due, or proactive from Settings)
 * allowTrial        — show the free-trial option (only for first-time pending signups)
 */
export function PaymentPanel({ variant = "activate", allowTrial = false }: { variant?: "activate" | "renew"; allowTrial?: boolean }) {
  const { user } = useAppStore();
  const qc = useQueryClient();

  const overviewQuery = useQuery({
    queryKey: qk.billingOverview,
    queryFn: () => api.get<BillingOverviewDto>("/api/billing/overview"),
  });

  const cfg = overviewQuery.data?.config;

  // Selection state is DERIVED from the server config until the user changes
  // something (override pattern — no state-mirroring effects needed).
  const [planOverride, setPlanOverride] = useState<string | null>(null);
  const [cycleOverride, setCycleOverride] = useState<"monthly" | "annual" | null>(null);
  const [seatsOverride, setSeatsOverride] = useState<number | null>(null);
  const [formDraft, setFormDraft] = useState<{
    payerName: string; amount: string; paidAt: string;
    method: "upi" | "bank"; utr: string; note: string;
  } | null>(null);

  const plan = planOverride ?? cfg?.plan ?? "growth";
  const cycle = cycleOverride ?? cfg?.cycle ?? "monthly";
  const seats = seatsOverride ?? cfg?.seats ?? 25;
  const form = formDraft ?? {
    payerName: user?.name ?? "",
    amount: "",
    paidAt: todayISO(),
    method: "bank" as const,
    utr: "",
    note: "",
  };

  const price = useMemo(
    () => (isPaidPlan(plan) ? computePlanPrice(plan, cycle, seats) : null),
    [plan, cycle, seats]
  );

  // Persist the requested plan while blocked (so the admin sees the intent).
  const requestMutation = useMutation({
    mutationFn: (payload: { plan: string; cycle: "monthly" | "annual"; seats: number }) =>
      api.patch("/api/billing/request", payload),
    onError: () => {}, // non-critical — the submit call re-sends the config
  });

  function updatePlan(next: string) {
    setPlanOverride(next);
    requestMutation.mutate({ plan: next, cycle, seats });
  }
  function updateCycle(next: "monthly" | "annual") {
    setCycleOverride(next);
    if (isPaidPlan(plan)) requestMutation.mutate({ plan, cycle: next, seats });
  }
  function updateSeats(next: number) {
    setSeatsOverride(next);
    if (isPaidPlan(plan)) requestMutation.mutate({ plan, cycle, seats: next });
  }

  const submitMutation = useMutation({
    mutationFn: () =>
      api.post<{ proof: PaymentProofDto }>("/api/billing/submit", {
        utr: form?.utr,
        amount: form?.amount ? Number(form.amount) : price?.total,
        payerName: form?.payerName,
        paidAt: form?.paidAt,
        method: form?.method,
        note: form?.note,
        plan,
        cycle,
        seats,
      }),
    onSuccess: () => {
      toast.success("Payment reference submitted", {
        description: "The platform administrator will verify it against their bank statement and activate your workspace. You'll get an email once approved.",
      });
      setFormDraft({ ...form, utr: "", note: "" });
      qc.invalidateQueries({ queryKey: qk.billingOverview });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not submit"),
  });

  if (overviewQuery.isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40" />
        <Skeleton className="h-64" />
      </div>
    );
  }
  const overview = overviewQuery.data;
  if (overviewQuery.isError || !overview || !cfg) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
          <p className="text-sm font-medium">Could not load payment details</p>
          <p className="text-sm text-muted-foreground">
            {overviewQuery.error instanceof Error ? overviewQuery.error.message : "Please try again."}
          </p>
          <Button variant="outline" size="sm" onClick={() => overviewQuery.refetch()}>
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  const proofs = overview.proofs;
  const latest = proofs[0] ?? null;
  const awaitingReview = latest?.status === "submitted";
  const methods = overview.methods;

  return (
    <div className="space-y-5">
      {/* Step 1 — choose plan */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-medium">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">1</span>
            Choose your plan
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {PRICING_PLANS.filter((p) => p.key !== "enterprise" && (allowTrial || p.key !== "trial")).map((p) => (
              <button
                key={p.key}
                type="button"
                onClick={() => updatePlan(p.key)}
                className={cn(
                  "rounded-xl border p-3.5 text-left transition-colors",
                  plan === p.key ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card hover:bg-accent"
                )}
                aria-pressed={plan === p.key}
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold">{p.key === "trial" ? "Free trial" : p.name}</p>
                  {plan === p.key && <Check className="h-4 w-4 text-primary" />}
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {p.key === "trial"
                    ? "14 days, all features — approval required, no payment"
                    : `${inr(cycle === "annual" ? p.annualPerEmployee : p.monthlyPerEmployee)}/employee/mo`}
                </p>
              </button>
            ))}
          </div>

          {plan !== "trial" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="grid gap-1.5">
                  <Label>Billing cycle</Label>
                  <div className="inline-flex rounded-lg border bg-card p-1 text-xs font-medium">
                    {(["monthly", "annual"] as const).map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => updateCycle(c)}
                        className={cn(
                          "rounded-md px-3.5 py-1.5 capitalize transition-colors",
                          cycle === c ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                        )}
                      >
                        {c}
                        {c === "annual" && <span className="ml-1.5 rounded-full bg-primary-foreground/20 px-1.5 py-0.5 text-[9px]">Save 20%</span>}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="pay-seats">Employees (seats)</Label>
                  <Input
                    id="pay-seats"
                    type="number"
                    min={1}
                    max={10000}
                    value={seats}
                    onChange={(e) => updateSeats(Math.max(1, Math.min(10000, Number(e.target.value) || 1)))}
                    className="max-w-40"
                  />
                </div>
              </div>

              {price && (
                <div className="rounded-xl border bg-muted/40 p-4">
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between text-muted-foreground">
                      <span>{inr(price.rate)} × {seats} {seats === 1 ? "employee" : "employees"} × {price.months} {price.months === 1 ? "month" : "months"}</span>
                      <span>{inr(price.amount)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>GST (18%)</span>
                      <span>{inr(price.tax)}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex items-center justify-between text-base font-bold">
                      <span>Total to transfer</span>
                      <span className="text-primary">{inr(price.total)}</span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {plan === "trial" ? (
        <Card>
          <CardContent className="flex items-start gap-3 p-5">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <p className="text-sm text-muted-foreground">
              Trial signups are reviewed by the platform administrator — no payment is needed.
              Once approved you get 14 days of full access. You can switch to a paid plan any time
              from Settings → Plan &amp; billing.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Step 2 — payment methods */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm font-medium">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">2</span>
                Transfer {price ? inr(price.total) : "the amount"} to
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {methods.length === 0 && (
                <p className="rounded-lg border border-dashed p-4 text-center text-xs text-muted-foreground">
                  Payment channels are being configured. Please check back shortly or contact support.
                </p>
              )}
              {methods.map((m) => (
                <MethodCard key={m.id} method={m} />
              ))}
              <p className="text-[11px] text-muted-foreground">
                After transferring, keep the transaction reference (UTR) handy — you will need it in step 3.
                NEFT/IMPS/RTGS and UPI references appear in your bank statement or UPI app.
              </p>
            </CardContent>
          </Card>

          {/* Step 3 — submit UTR */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm font-medium">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">3</span>
                Submit your payment reference (UTR)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {awaitingReview && latest && (
                <div className="flex items-start gap-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
                  <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">Reference {latest.utr} is awaiting verification</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Submitted {fmtDate(latest.createdAt)} for {inr(latest.amount)} ({latest.plan}, {latest.cycle}).
                      The platform administrator verifies it against their bank statement — you&apos;ll be emailed the moment your workspace is activated.
                    </p>
                  </div>
                </div>
              )}

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!form?.utr.trim()) {
                    toast.error("Enter the transaction reference (UTR) from your bank statement or UPI app.");
                    return;
                  }
                  submitMutation.mutate();
                }}
                className="grid gap-4"
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="grid gap-1.5">
                    <Label htmlFor="utr">Transaction reference (UTR / Ref no.)</Label>
                    <Input
                      id="utr"
                      placeholder="e.g. 405212345678"
                      className="font-mono"
                      value={form?.utr ?? ""}
                      onChange={(e) => setFormDraft({ ...form, utr: e.target.value.toUpperCase() })}
                      autoComplete="off"
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <Label>Paid via</Label>
                    <Select
                      value={form?.method ?? "bank"}
                      onValueChange={(v) => setFormDraft({ ...form, method: v as "upi" | "bank" })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank">Bank transfer (NEFT / IMPS / RTGS)</SelectItem>
                        <SelectItem value="upi">UPI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="grid gap-1.5">
                    <Label htmlFor="payer">Paid from (name)</Label>
                    <Input
                      id="payer"
                      value={form?.payerName ?? ""}
                      onChange={(e) => setFormDraft({ ...form, payerName: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <Label htmlFor="amt">Amount paid (₹)</Label>
                    <Input
                      id="amt"
                      type="number"
                      min={1}
                      placeholder={String(price?.total ?? "")}
                      value={form?.amount ?? ""}
                      onChange={(e) => setFormDraft({ ...form, amount: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <Label htmlFor="paidat">Paid on</Label>
                    <Input
                      id="paidat"
                      type="date"
                      max={todayISO()}
                      value={form?.paidAt ?? todayISO()}
                      onChange={(e) => setFormDraft({ ...form, paidAt: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="note">Note (optional)</Label>
                  <Textarea
                    id="note"
                    className="min-h-16"
                    placeholder="Anything the administrator should know about this payment…"
                    value={form?.note ?? ""}
                    onChange={(e) => setFormDraft({ ...form, note: e.target.value })}
                  />
                </div>
                <Button type="submit" disabled={submitMutation.isPending} className="w-full sm:w-auto">
                  {submitMutation.isPending
                    ? <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    : <Send className="mr-2 h-4 w-4" />}
                  Submit for verification
                </Button>
              </form>
            </CardContent>
          </Card>
        </>
      )}

      {/* Submission history */}
      {proofs.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Your submissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-64 space-y-2 overflow-y-auto scrollbar-thin">
              {proofs.map((p) => (
                <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border px-3.5 py-2.5 text-xs">
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="font-mono font-medium">{p.utr}</span>
                    <span className="text-muted-foreground">{inr(p.amount)}</span>
                    <span className="hidden text-muted-foreground sm:inline">{fmtDate(p.paidAt)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground capitalize">{p.plan} · {p.cycle}</span>
                    <ProofStatusBadge status={p.status} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export function ProofStatusBadge({ status }: { status: PaymentProofDto["status"] }) {
  const variant =
    status === "verified" ? "default" :
    status === "submitted" ? "secondary" :
    status === "superseded" ? "outline" :
    "destructive";
  return (
    <Badge variant={variant} className="text-[10px]">
      {STATUS_LABELS[status] ?? status}
    </Badge>
  );
}

function MethodCard({ method }: { method: PaymentMethodDto }) {
  const [copied, setCopied] = useState<string | null>(null);

  async function copy(value: string, key: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(null), 1600);
    } catch {
      toast.error("Could not copy — please select and copy manually.");
    }
  }

  const isUpi = method.type === "upi";

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-3 flex items-center gap-2">
        {isUpi
          ? <Smartphone className="h-4 w-4 text-primary" />
          : <Landmark className="h-4 w-4 text-primary" />}
        <p className="text-sm font-semibold">{method.label}</p>
      </div>

      <div className="space-y-2.5">
        {isUpi ? (
          <>
            <DetailRow label="UPI ID" value={method.upiId ?? "—"} mono copyKey="upi" copied={copied} onCopy={copy} />
            {method.accountHolder && <DetailRow label="Pay to" value={method.accountHolder} />}
          </>
        ) : (
          <>
            {method.accountHolder && <DetailRow label="Account holder" value={method.accountHolder} />}
            <DetailRow label="Account number" value={method.accountNumber ?? "—"} mono copyKey="acc" copied={copied} onCopy={copy} />
            <DetailRow label="IFSC code" value={method.ifsc ?? "—"} mono copyKey="ifsc" copied={copied} onCopy={copy} />
            {method.bankName && <DetailRow label="Bank" value={`${method.bankName}${method.accountType ? ` · ${method.accountType}` : ""}`} />}
          </>
        )}
      </div>

      {method.instructions && (
        <p className="mt-3 rounded-lg bg-muted/60 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
          {method.instructions}
        </p>
      )}
    </div>
  );
}

function DetailRow({
  label, value, mono, copyKey, copied, onCopy,
}: {
  label: string; value: string; mono?: boolean;
  copyKey?: string; copied?: string | null;
  onCopy?: (value: string, key: string) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className={cn("truncate text-sm font-medium", mono && "font-mono tracking-wide")}>{value}</p>
      </div>
      {copyKey && onCopy && (
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-7 w-7 shrink-0"
          aria-label={`Copy ${label}`}
          onClick={() => onCopy(value, copyKey)}
        >
          {copied === copyKey
            ? <Check className="h-3.5 w-3.5 text-primary" />
            : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
        </Button>
      )}
    </div>
  );
}

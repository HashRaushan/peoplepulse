"use client";

import { useEffect } from "react";

/**
 * Registers the PeoplePulse HR service worker for offline app-shell support
 * and PWA installability. Only registered in production to avoid caching
 * conflicts during local development (where the build hash changes constantly).
 */
export function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    // Skip in dev — SW caching fights with Turbopack HMR.
    if (process.env.NODE_ENV !== "production") return;

    const register = () => {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .catch((err) => {
          // Don't surface as a user-visible error — SW is a progressive enhancement.
          console.warn("[sw] registration failed", err);
        });
    };

    if (document.readyState === "complete") {
      register();
    } else {
      window.addEventListener("load", register, { once: true });
    }
  }, []);

  return null;
}

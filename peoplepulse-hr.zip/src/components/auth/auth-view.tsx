"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { api } from "@/lib/api-client";
import { PRICING_PLANS } from "@/lib/constants";
import { computePlanPrice } from "@/lib/billing";
import { isPaidPlan } from "@/lib/plan-state";
import { cn, inr } from "@/lib/hr-utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft, Loader2, LogIn, Sparkles, Building2, Users, Check, Clock3,
  Info, Landmark, ShieldCheck,
} from "lucide-react";
import type { PlanKey, SessionUser } from "@/lib/types";

/** Response of POST /api/auth/register — approval-aware signup result. */
interface RegisterResult {
  tenant: { name: string; slug: string };
  needsApproval: boolean;
  isTrial: boolean;
  platformAdmin: boolean;
}

/** Seats pre-filled for a plan (paid plans use their included seats, others default to 25). */
function seatsForPlan(plan: PlanKey): number {
  return PRICING_PLANS.find((p) => p.key === plan)?.seatsIncluded || 25;
}

export function AuthView() {
  const { authTab, setAuthTab, setView, setUser, regPlan, setRegPlan } = useAppStore();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  // login
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // register wizard
  const [regStep, setRegStep] = useState(1);
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regCompany, setRegCompany] = useState("");
  const [regSize, setRegSize] = useState("11-50");
  const [regCycle, setRegCycle] = useState<"monthly" | "annual">("monthly");
  const [regSeats, setRegSeats] = useState<number>(() => seatsForPlan(regPlan));
  const [regResult, setRegResult] = useState<RegisterResult | null>(null);

  // Price breakdown for the selected paid plan (null for the free trial).
  const regPrice = isPaidPlan(regPlan) ? computePlanPrice(regPlan, regCycle, regSeats) : null;

  // The four selectable cards — the free trial plus paid plans (enterprise excluded).
  const planCards: { key: PlanKey; title: string; subtitle: string; popular?: boolean }[] = [
    { key: "trial", title: "Free trial", subtitle: "14 days, all features, no payment" },
    ...PRICING_PLANS.filter((p) => p.key !== "enterprise").map((p) => ({
      key: p.key,
      title: p.name,
      subtitle: `${inr(regCycle === "annual" ? p.annualPerEmployee : p.monthlyPerEmployee)}/employee/mo`,
      popular: p.highlight,
    })),
  ];

  async function login(e?: React.FormEvent) {
    e?.preventDefault();
    setError("");
    if (!email.trim() || !password) {
      setError("Enter your email and password.");
      return;
    }
    setBusy(true);
    try {
      const res = await api.post<{ user: SessionUser }>("/api/auth/login", { email, password });
      setUser(res.user);
      toast.success(`Welcome back, ${res.user.name.split(" ")[0]}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed");
    } finally {
      setBusy(false);
    }
  }

  async function register(e?: React.FormEvent) {
    e?.preventDefault();
    setError("");
    if (regStep === 1) {
      if (!regName.trim() || !regEmail.trim() || regPassword.length < 8) {
        setError("Enter your name, work email and a password of at least 8 characters.");
        return;
      }
      setRegStep(2);
      return;
    }
    if (regStep === 2) {
      if (!regCompany.trim()) {
        setError("Enter your organisation name.");
        return;
      }
      setRegStep(3);
      return;
    }
    if (regStep === 3) {
      if (isPaidPlan(regPlan) && (!Number.isFinite(regSeats) || regSeats < 1 || regSeats > 10000)) {
        setError("Seats must be a number between 1 and 10,000.");
        return;
      }
      setBusy(true);
      try {
        const res = await api.post<RegisterResult>("/api/auth/register", {
          name: regName,
          email: regEmail,
          password: regPassword,
          company: regCompany,
          companySize: regSize,
          plan: regPlan,
          cycle: regCycle,
          seats: isPaidPlan(regPlan) ? regSeats : 25,
        });
        setRegResult(res);
        setRegStep(4);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Registration failed");
      } finally {
        setBusy(false);
      }
    }
  }

  function selectRegPlan(plan: PlanKey) {
    if (plan !== regPlan) setRegSeats(seatsForPlan(plan));
    setRegPlan(plan);
  }

  async function enterWorkspace() {
    setBusy(true);
    try {
      const res = await api.post<{ user: SessionUser }>("/api/auth/login", { email: regEmail, password: regPassword });
      setUser(res.user);
      toast.success(`Welcome to PeoplePulse HR, ${res.user.name.split(" ")[0]}!`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not sign in");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-muted/30">
      <div className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <button
            onClick={() => setView("site")}
            className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Back to website
          </button>

          <div className="mb-6 flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-sm font-bold text-primary-foreground">P</span>
            <div>
              <div className="font-bold tracking-tight">PeoplePulse HR</div>
              <div className="text-xs text-muted-foreground">
                {authTab === "login" ? "Sign in to your workspace" : "Create your workspace"}
              </div>
            </div>
          </div>

          {authTab === "login" ? (
            <form onSubmit={login} className="rounded-2xl border bg-card p-6 shadow-sm">
              <h1 className="text-xl font-bold">Welcome back</h1>
              <p className="mt-1 text-sm text-muted-foreground">Sign in to continue to your HR workspace.</p>

              <div className="mt-5 grid gap-4">
                <div className="grid gap-1.5">
                  <Label htmlFor="email">Work email</Label>
                  <Input
                    id="email" type="email" autoComplete="email" placeholder="you@company.com"
                    value={email} onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password" type="password" autoComplete="current-password" placeholder="••••••••"
                    value={password} onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</p>}
                <Button type="submit" disabled={busy} className="h-10">
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
                  Sign in
                </Button>
                <p className="text-center text-xs text-muted-foreground">
                  New to PeoplePulse?{" "}
                  <button type="button" className="font-medium text-primary hover:underline" onClick={() => { setAuthTab("register"); setError(""); }}>
                    Create your workspace
                  </button>
                </p>
              </div>
            </form>
          ) : (
            <form onSubmit={register} className="rounded-2xl border bg-card p-6 shadow-sm">
              {regStep === 1 && (
                <>
                  <h1 className="text-xl font-bold">Create your workspace</h1>
                  <p className="mt-1 text-sm text-muted-foreground">Set up your organisation's private HR system.</p>
                  <div className="mt-5 grid gap-4">
                    <div className="grid gap-1.5">
                      <Label htmlFor="reg-name">Your full name</Label>
                      <Input id="reg-name" placeholder="Aarav Shah" value={regName} onChange={(e) => setRegName(e.target.value)} />
                    </div>
                    <div className="grid gap-1.5">
                      <Label htmlFor="reg-email">Work email</Label>
                      <Input id="reg-email" type="email" placeholder="aarav@company.com" value={regEmail} onChange={(e) => setRegEmail(e.target.value)} />
                    </div>
                    <div className="grid gap-1.5">
                      <Label htmlFor="reg-password">Password</Label>
                      <Input id="reg-password" type="password" placeholder="At least 8 characters" value={regPassword} onChange={(e) => setRegPassword(e.target.value)} />
                      <p className="text-[11px] text-muted-foreground">Must be at least 8 characters.</p>
                    </div>
                  </div>
                </>
              )}

              {regStep === 2 && (
                <>
                  <h1 className="text-xl font-bold">Set up your organisation</h1>
                  <p className="mt-1 text-sm text-muted-foreground">This creates your isolated, secure workspace.</p>
                  <div className="mt-5 grid gap-4">
                    <div className="grid gap-1.5">
                      <Label htmlFor="reg-company">Organisation name</Label>
                      <Input id="reg-company" placeholder="Acme Technologies Pvt Ltd" value={regCompany} onChange={(e) => setRegCompany(e.target.value)} />
                    </div>
                    <div className="grid gap-1.5">
                      <Label>Company size</Label>
                      <Select value={regSize} onValueChange={setRegSize}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {["1-10", "11-50", "51-200", "201-500", "501-2000", "2000+"].map((s) => (
                            <SelectItem key={s} value={s}>{s} employees</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </>
              )}

              {regStep === 3 && (
                <>
                  <h1 className="text-xl font-bold">Choose your plan</h1>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Pick how you&apos;d like to start — you can switch plans later.
                  </p>
                  <div className="mt-5 grid gap-4">
                    <div className="grid gap-3 sm:grid-cols-2">
                      {planCards.map((p) => (
                        <button
                          key={p.key}
                          type="button"
                          onClick={() => selectRegPlan(p.key)}
                          className={cn(
                            "rounded-xl border p-3.5 text-left transition-colors",
                            regPlan === p.key ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card hover:bg-accent"
                          )}
                          aria-pressed={regPlan === p.key}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold">
                              {p.title}
                              {p.popular && (
                                <span className="rounded-full bg-primary/10 px-1.5 py-0.5 text-[9px] font-semibold text-primary">
                                  Most popular
                                </span>
                              )}
                            </p>
                            {regPlan === p.key && <Check className="h-4 w-4 shrink-0 text-primary" />}
                          </div>
                          <p className="mt-1 text-[11px] text-muted-foreground">{p.subtitle}</p>
                        </button>
                      ))}
                    </div>

                    {regPrice ? (
                      <>
                        <div className="grid gap-4 sm:grid-cols-2">
                          <div className="grid gap-1.5">
                            <Label>Billing cycle</Label>
                            <div className="inline-flex w-fit rounded-lg border bg-card p-1 text-xs font-medium">
                              {(["monthly", "annual"] as const).map((c) => (
                                <button
                                  key={c}
                                  type="button"
                                  onClick={() => setRegCycle(c)}
                                  className={cn(
                                    "rounded-md px-3.5 py-1.5 capitalize transition-colors",
                                    regCycle === c ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                                  )}
                                >
                                  {c}
                                  {c === "annual" && (
                                    <span className="ml-1.5 rounded-full bg-primary-foreground/20 px-1.5 py-0.5 text-[9px]">
                                      Save 20%
                                    </span>
                                  )}
                                </button>
                              ))}
                            </div>
                          </div>
                          <div className="grid gap-1.5">
                            <Label htmlFor="reg-seats">Employees (seats)</Label>
                            <Input
                              id="reg-seats"
                              type="number"
                              min={1}
                              max={10000}
                              value={regSeats}
                              onChange={(e) => setRegSeats(Math.max(1, Math.min(10000, Number(e.target.value) || 1)))}
                            />
                          </div>
                        </div>

                        <div className="rounded-xl border bg-muted/40 p-4">
                          <div className="space-y-1.5 text-sm">
                            <div className="flex justify-between gap-3 text-muted-foreground">
                              <span>
                                {inr(regPrice.rate)} × {regSeats} {regSeats === 1 ? "employee" : "employees"} ×{" "}
                                {regPrice.months} {regPrice.months === 1 ? "month" : "months"}
                              </span>
                              <span>{inr(regPrice.amount)}</span>
                            </div>
                            <div className="flex justify-between text-muted-foreground">
                              <span>GST (18%)</span>
                              <span>{inr(regPrice.tax)}</span>
                            </div>
                            <Separator className="my-2" />
                            <div className="flex items-center justify-between text-base font-bold">
                              <span>Total</span>
                              <span className="text-primary">{inr(regPrice.total)}</span>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="flex items-start gap-3 rounded-xl border bg-muted/40 p-4">
                        <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          Trial signups are reviewed by the platform administrator — no payment required.
                          Full access for 14 days once approved.
                        </p>
                      </div>
                    )}

                    <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <ShieldCheck className="h-3 w-3 shrink-0 text-primary" />
                      Every workspace is reviewed by the platform administrator before activation.
                    </p>
                  </div>
                </>
              )}

              {regStep === 4 && regResult && (
                <div className="text-center">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                    {regResult.platformAdmin ? (
                      <ShieldCheck className="h-7 w-7 text-primary" />
                    ) : regResult.isTrial ? (
                      <Clock3 className="h-7 w-7 text-primary" />
                    ) : (
                      <Landmark className="h-7 w-7 text-primary" />
                    )}
                  </div>

                  {regResult.platformAdmin ? (
                    <>
                      <h1 className="mt-4 text-xl font-bold">You are the platform administrator</h1>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        <span className="font-medium text-foreground">{regResult.tenant.name}</span> is the
                        platform owner&apos;s own workspace and is active immediately — no approval needed.
                        Every future signup will await your approval in Platform Admin.
                      </p>
                    </>
                  ) : regResult.isTrial ? (
                    <>
                      <h1 className="mt-4 text-xl font-bold">Workspace created — awaiting approval</h1>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        <span className="font-medium text-foreground">{regResult.tenant.name}</span> has been
                        created. The platform administrator has been notified and will approve your 14-day
                        free trial shortly. You&apos;ll receive an email once approved.
                      </p>
                      <div className="mt-5 space-y-2 rounded-xl border bg-muted/40 p-4 text-left text-xs text-muted-foreground">
                        <p className="flex items-center gap-2">
                          <Users className="h-3.5 w-3.5 shrink-0 text-primary" />
                          Add your employees and grant them login access from the Employees module
                        </p>
                        <p className="flex items-center gap-2">
                          <Building2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                          Holidays, policies and workflows are pre-configured — customise them in Settings
                        </p>
                        <p className="flex items-center gap-2">
                          <Sparkles className="h-3.5 w-3.5 shrink-0 text-primary" />
                          Publish a welcome announcement so your team knows where to find everything
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <h1 className="mt-4 text-xl font-bold">Workspace created — one step to go</h1>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        <span className="font-medium text-foreground">{regResult.tenant.name}</span> has been
                        created. Sign in to see the payment details (bank transfer/UPI). After transferring,
                        submit your transaction reference (UTR). The administrator verifies it and activates
                        your workspace.
                      </p>
                    </>
                  )}

                  <Button type="button" onClick={enterWorkspace} disabled={busy} className="mt-6 w-full">
                    {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Enter your workspace
                  </Button>
                </div>
              )}

              {error && regStep < 4 && (
                <p className="mt-4 rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</p>
              )}

              {regStep < 4 && (
                <div className="mt-5 flex items-center justify-between">
                  {regStep > 1 ? (
                    <button type="button" onClick={() => { setRegStep(regStep - 1); setError(""); }} className="text-xs text-muted-foreground hover:text-foreground">
                      Back
                    </button>
                  ) : (
                    <button type="button" onClick={() => setView("site")} className="text-xs text-muted-foreground hover:text-foreground">
                      Cancel
                    </button>
                  )}
                  <Button type="submit" disabled={busy}>
                    {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {regStep < 3 ? "Continue" : "Create workspace"}
                  </Button>
                </div>
              )}

              {regStep < 4 && (
                <p className="mt-4 text-center text-xs text-muted-foreground">
                  Already have an account?{" "}
                  <button type="button" className="font-medium text-primary hover:underline" onClick={() => { setAuthTab("login"); setError(""); }}>
                    Sign in
                  </button>
                </p>
              )}
            </form>
          )}

          <p className="mt-6 text-center text-[11px] leading-relaxed text-muted-foreground">
            Your data is isolated per organisation. Passwords are hashed with scrypt.
          </p>
        </div>
      </div>

      <footer className="mt-auto border-t bg-background pb-[env(safe-area-inset-bottom)]">
        <p className="px-4 py-4 text-center text-xs text-muted-foreground">
          PeoplePulse HR — your company's private HR workspace.{" "}
          <button type="button" onClick={() => setView("site")} className="font-medium text-primary hover:underline">
            About PeoplePulse HR
          </button>
        </p>
      </footer>
    </div>
  );
}

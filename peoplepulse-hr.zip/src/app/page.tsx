"use client";

/**
 * PeoplePulse HR — Marketing Website.
 * Premium single-page commercial site: hero, modules, AI, security, pricing, FAQ, demo.
 */
import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { MarketingSite } from "@/components/marketing/marketing-site";
import { AuthView } from "@/components/auth/auth-view";
import { AppView } from "@/components/app/app-view";
import { ADMIN_MODULES, type ModuleKey } from "@/lib/types";

export default function Home() {
  const { view, user, setView, setUser, setModule, setBooted, booted } = useAppStore();
  const [checking, setChecking] = useState(true);

  // Boot: restore session (if any)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/auth/me");
        if (res.ok) {
          const data = await res.json();
          if (!cancelled && data?.user) {
            setUser(data.user);
          }
        }
      } catch {
        /* not signed in */
      } finally {
        if (!cancelled) {
          setBooted(true);
          setChecking(false);
          // Logged-out visitors land on the marketing site; signed-in users were
          // already routed to "app" by setUser above.
          if (!useAppStore.getState().user) setView("site");
          // PWA shortcuts pass ?module= — deep-link signed-in users straight to it.
          const params = new URLSearchParams(window.location.search);
          const mod = params.get("module");
          if (mod && (ADMIN_MODULES as string[]).includes(mod)) setModule(mod as ModuleKey);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [setUser, setBooted, setView, setModule]);

  // Signed-in users always land in the app
  useEffect(() => {
    if (user && booted) setView("app");
  }, [user, booted, setView]);

  if (checking && !booted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">P</span>
          </div>
          <div className="h-1 w-24 overflow-hidden rounded-full bg-muted">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-primary" />
          </div>
          <p className="text-xs text-muted-foreground">Loading PeoplePulse HR…</p>
        </div>
      </div>
    );
  }

  if (view === "app" && user) return <AppView />;
  if (view === "auth") return <AuthView />;
  return <MarketingSite />;
}

import type { Metadata, Viewport } from "next";
// Self-hosted Geist (bundled font files — no network fetch at build time, so
// offline/restricted build environments cannot fail the deployment).
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "PeoplePulse HR — The Intelligent HR Platform for Modern Teams",
  description:
    "PeoplePulse HR is a multi-tenant HRMS platform for Indian and global teams: core HR, attendance, leave, payroll, recruitment, performance, engagement, workflows and an AI HR copilot — in one secure workspace.",
  applicationName: "PeoplePulse HR",
  keywords: [
    "HRMS",
    "HR software India",
    "payroll software",
    "attendance management",
    "leave management",
    "recruitment ATS",
    "performance management",
    "HR AI assistant",
    "SaaS HR platform",
  ],
  authors: [{ name: "PeoplePulse HR" }],
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "PeoplePulse HR",
  },
  formatDetection: { telephone: false },
  openGraph: {
    title: "PeoplePulse HR",
    description:
      "The intelligent HR platform for modern teams. Core HR, payroll, attendance, leave, recruitment, performance and AI — unified.",
    siteName: "PeoplePulse HR",
    type: "website",
  },
  robots: { index: true, follow: true },
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "32x32" },
      { url: "/icons/icon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/icons/icon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512x512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: ["/favicon.ico"],
  },
};

export const viewport: Viewport = {
  themeColor: "#059669",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${GeistSans.variable} ${GeistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

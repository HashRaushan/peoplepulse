/**
 * Company document library API (Document Center).
 *
 * GET /api/documents — any signed-in user (the library is company-shared).
 *   Query: category (exact match), q (case-insensitive match on title and
 *   content). Ordered by updatedAt (newest first). Each item carries a
 *   single-line 160-char excerpt of the content.
 *
 * POST /api/documents — owner | admin | hr. Body:
 *   { title, category, content, audience?, tags?: string[] }
 * Titles are unique per tenant. Every write is recorded in the audit trail.
 */
import { NextRequest } from "next/server";
import type { CompanyDocument, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { DOCUMENT_CATEGORIES } from "@/lib/constants";
import { parseJson } from "@/app/api/_lib/mappers";
import type { DocumentDto } from "@/lib/types";

const DEFAULT_AUDIENCE = "All Employees";
const MAX_TAGS = 10;
const MAX_TAG_LENGTH = 40;

/** CompanyDocument row -> DocumentDto (shared shape declared in types.ts). */
function toDocumentDto(d: CompanyDocument): DocumentDto {
  return {
    id: d.id,
    title: d.title,
    category: d.category,
    content: d.content,
    excerpt: d.content.replace(/\s+/g, " ").trim().slice(0, 160),
    version: d.version,
    audience: d.audience,
    tags: parseJson<string[]>(d.tags, []),
    updatedBy: d.updatedBy,
    updatedAt: d.updatedAt.toISOString(),
  };
}

/**
 * Normalize a raw `tags` body value into a clean string[]:
 * trims, drops empties, dedupes and caps at 10 tags of 40 chars each.
 * Returns null when the value is present but not an array.
 */
function normalizeTags(raw: unknown): string[] | null {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) return null;
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const item of raw) {
    const tag = String(item).trim().slice(0, MAX_TAG_LENGTH);
    if (!tag || seen.has(tag)) continue;
    seen.add(tag);
    tags.push(tag);
    if (tags.length >= MAX_TAGS) break;
  }
  return tags;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const category = (sp.get("category") ?? "").trim();
    const q = (sp.get("q") ?? "").trim().toLowerCase();

    const where: Prisma.CompanyDocumentWhereInput = { tenantId: session.tenantId };
    if (category) where.category = category;

    let rows = await db.companyDocument.findMany({
      where,
      orderBy: { updatedAt: "desc" },
    });

    // SQLite has no case-insensitive `contains` mode, so filter in memory
    // (document libraries are small) to honour the case-insensitive contract.
    if (q) {
      rows = rows.filter(
        (d) => d.title.toLowerCase().includes(q) || d.content.toLowerCase().includes(q)
      );
    }

    return ok({ documents: rows.map(toDocumentDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const category = String(body.category ?? "").trim();
    const content = String(body.content ?? "").trim();
    const audience = String(body.audience ?? "").trim() || DEFAULT_AUDIENCE;
    const tags = normalizeTags(body.tags);

    if (!title) return fail("Please enter a document title.", 400);
    if (!DOCUMENT_CATEGORIES.includes(category)) {
      return fail(`Category must be one of: ${DOCUMENT_CATEGORIES.join(", ")}.`, 400);
    }
    if (!content) return fail("Please enter the document content.", 400);
    if (tags === null) {
      return fail("Tags must be an array of strings.", 400);
    }

    const clash = await db.companyDocument.findFirst({
      where: { tenantId: session.tenantId, title },
      select: { id: true },
    });
    if (clash) {
      return fail("A document with this title already exists.", 409);
    }

    const document = await db.companyDocument.create({
      data: {
        tenantId: session.tenantId,
        title,
        category,
        content,
        version: 1,
        audience,
        tags: JSON.stringify(tags),
        updatedBy: session.name,
      },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "document.created",
      entity: "CompanyDocument",
      entityId: document.id,
      summary: `Published the document "${document.title}" (${document.category}).`,
    });

    return ok({ document: toDocumentDto(document) }, { status: 201 });
  });
}

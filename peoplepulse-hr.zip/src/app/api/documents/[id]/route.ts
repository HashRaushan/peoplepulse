/**
 * Single company document API (Document Center).
 *
 * PATCH /api/documents/{id} — owner | admin | hr. Body:
 *   { title?, category?, content?, audience?, tags? }
 * Only the provided fields change; every successful save bumps the version
 * (+1) and stamps updatedBy with the acting user. Titles stay unique per
 * tenant (409 on collision), 404 when the id does not exist in the caller's
 * tenant.
 *
 * DELETE /api/documents/{id} — owner | admin | hr. Permanently removes the
 * document (audited with "warning" severity).
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { DOCUMENT_CATEGORIES } from "@/lib/constants";
import { parseJson } from "@/app/api/_lib/mappers";
import type { DocumentDto } from "@/lib/types";

const DEFAULT_AUDIENCE = "All Employees";
const MAX_TAGS = 10;
const MAX_TAG_LENGTH = 40;

type Ctx = { params: Promise<{ id: string }> };

/** CompanyDocument row -> DocumentDto (shared shape declared in types.ts). */
function toDocumentDto(d: {
  id: string;
  title: string;
  category: string;
  content: string;
  version: number;
  audience: string;
  tags: string;
  updatedBy: string;
  updatedAt: Date;
}): DocumentDto {
  return {
    id: d.id,
    title: d.title,
    category: d.category,
    content: d.content,
    excerpt: d.content.replace(/\s+/g, " ").trim().slice(0, 160),
    version: d.version,
    audience: d.audience,
    tags: parseJson<string[]>(d.tags, []),
    updatedBy: d.updatedBy,
    updatedAt: d.updatedAt.toISOString(),
  };
}

/**
 * Normalize a raw `tags` body value into a clean string[]:
 * trims, drops empties, dedupes and caps at 10 tags of 40 chars each.
 * Returns null when the value is present but not an array.
 */
function normalizeTags(raw: unknown): string[] | null {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) return null;
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const item of raw) {
    const tag = String(item).trim().slice(0, MAX_TAG_LENGTH);
    if (!tag || seen.has(tag)) continue;
    seen.add(tag);
    tags.push(tag);
    if (tags.length >= MAX_TAGS) break;
  }
  return tags;
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const document = await db.companyDocument.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!document) return fail("Document not found.", 404);

    const data: {
      title?: string;
      category?: string;
      content?: string;
      audience?: string;
      tags?: string;
      version: number;
      updatedBy: string;
    } = { version: document.version + 1, updatedBy: session.name };

    if (body.title !== undefined) {
      const title = String(body.title).trim();
      if (!title) return fail("Title cannot be empty.", 400);
      if (title !== document.title) {
        const clash = await db.companyDocument.findFirst({
          where: { tenantId: session.tenantId, title, NOT: { id: document.id } },
          select: { id: true },
        });
        if (clash) return fail("A document with this title already exists.", 409);
      }
      data.title = title;
    }

    if (body.category !== undefined) {
      const category = String(body.category).trim();
      if (!DOCUMENT_CATEGORIES.includes(category)) {
        return fail(`Category must be one of: ${DOCUMENT_CATEGORIES.join(", ")}.`, 400);
      }
      data.category = category;
    }

    if (body.content !== undefined) {
      const content = String(body.content).trim();
      if (!content) return fail("Content cannot be empty.", 400);
      data.content = content;
    }

    if (body.audience !== undefined) {
      data.audience = String(body.audience).trim() || DEFAULT_AUDIENCE;
    }

    if (body.tags !== undefined) {
      const tags = normalizeTags(body.tags);
      if (tags === null) return fail("Tags must be an array of strings.", 400);
      data.tags = JSON.stringify(tags);
    }

    const updated = await db.companyDocument.update({
      where: { id: document.id },
      data,
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "document.updated",
      entity: "CompanyDocument",
      entityId: document.id,
      summary: `Updated the document "${updated.title}" (now v${updated.version}).`,
    });

    return ok({ document: toDocumentDto(updated) });
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const document = await db.companyDocument.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!document) return fail("Document not found.", 404);

    await db.companyDocument.delete({ where: { id: document.id } });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "document.deleted",
      entity: "CompanyDocument",
      entityId: document.id,
      summary: `Deleted the document "${document.title}" (was v${document.version}).`,
      severity: "warning",
    });

    return ok({ success: true });
  });
}

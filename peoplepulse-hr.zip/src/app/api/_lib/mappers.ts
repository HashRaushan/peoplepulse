/**
 * PeoplePulse HR — shared DTO mappers and domain helpers for API route handlers.
 *
 * This module lives under `src/app/api/_lib/` — folders prefixed with an
 * underscore are private in the Next.js App Router and are never exposed as
 * routes. Import these mappers in API routes to guarantee that every response
 * matches the DTO shapes declared in `src/lib/types.ts` exactly:
 *   - Date-only fields (joinDate, dob, startDate, ...) -> "YYYY-MM-DD" via dateOnly()
 *   - All other DateTime fields -> ISO strings via toISOString()
 */
import type {
  Announcement,
  AttendanceRecord,
  AuditLog,
  Candidate,
  Department,
  Employee,
  Holiday,
  HrTicket,
  Invoice,
  JobOpening,
  LeaveBalance,
  LeaveRequest,
  LeaveType,
  Notification,
  PaymentMethod,
  PaymentProof,
  PerformanceReview,
  PolicyDocument,
  Tenant,
  Workflow,
  WorkflowExecution,
} from "@prisma/client";
import { db } from "@/lib/db";
import { dateOnly } from "@/lib/api-helpers";
import type {
  AnnouncementDto,
  AttendanceDto,
  AuditLogDto,
  CandidateDto,
  DepartmentDto,
  EmployeeListItem,
  HolidayDto,
  InvoiceDto,
  JobOpeningDto,
  LeaveBalanceDto,
  LeaveRequestDto,
  LeaveTypeDto,
  NotificationDto,
  OnboardingTaskDto,
  OrgProfileDto,
  PaymentMethodDto,
  PaymentProofDto,
  PolicyDto,
  ReviewDto,
  ReviewGoal,
  TicketDto,
  TicketMessage,
  WorkflowDto,
  WorkflowExecutionDto,
  WorkflowExecutionStep,
} from "@/lib/types";

// ============================== Small shared helpers ==============================

/** Parse a JSON string column with a type-safe fallback. */
export function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    const parsed = JSON.parse(raw);
    return (parsed === null || parsed === undefined ? fallback : parsed) as T;
  } catch {
    return fallback;
  }
}

/** Build a local-midnight Date from a "YYYY-MM-DD" string (matches the seed convention). */
export function localDate(iso: string): Date {
  return new Date(`${iso}T00:00:00`);
}

/** True when the value is a well-formed, real "YYYY-MM-DD" calendar date. */
export function isValidDateOnly(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00`);
  return !Number.isNaN(d.getTime()) && dateOnly(d) === value;
}

/** Add N days to a Date (keeps the local-midnight convention). */
export function addDays(base: Date, days: number): Date {
  const d = new Date(base);
  d.setDate(d.getDate() + days);
  return d;
}

/** Employee full display name, e.g. "Ananya Rao". */
export function fullName(e: { firstName: string; lastName: string }): string {
  return `${e.firstName} ${e.lastName}`.trim();
}

/** Short tenant code prefix: first 3 alphanumeric characters of the tenant name, uppercased. */
export function tenantCodePrefix(tenantName: string): string {
  const prefix = tenantName.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 3);
  return prefix || "EMP";
}

/**
 * Generate the next unique employee code for a tenant: `{PREFIX}-{NNN}` where
 * the sequence starts at (existing employee count + 1), is zero-padded to three
 * digits and is incremented until a free code is found.
 */
export async function nextEmployeeCode(tenantId: string, tenantName: string): Promise<string> {
  const prefix = tenantCodePrefix(tenantName);
  const existing = await db.employee.count({ where: { tenantId } });
  let seq = existing + 1;
  for (;;) {
    const code = `${prefix}-${String(seq).padStart(3, "0")}`;
    const clash = await db.employee.findFirst({ where: { tenantId, code }, select: { id: true } });
    if (!clash) return code;
    seq += 1;
  }
}

/** Current "HH:MM" in server local time. */
export function hhmmNow(): string {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

/** Resolve the User id linked to an employee record (for targeted notifications), if any. */
export async function userIdForEmployee(tenantId: string, employeeId: string): Promise<string | null> {
  const user = await db.user.findFirst({ where: { tenantId, employeeId }, select: { id: true } });
  return user?.id ?? null;
}

/** Coerce an unknown body value to a non-negative integer, or a fallback. */
export function toNonNegativeInt(value: unknown, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? Math.round(n) : fallback;
}

/**
 * Read an integer query parameter with a fallback. Unlike the shared `num()`
 * helper, absent/empty/invalid values fall back instead of coercing to 0
 * (Number(null) === 0 would otherwise shrink default page sizes to 1).
 */
export function intParam(value: string | null | undefined, fallback: number): number {
  if (value == null || value.trim() === "") return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? Math.floor(n) : fallback;
}

// ============================== DTO mappers ==============================

type EmployeeWithManager = Employee & {
  manager?: Employee | null;
  users?: { id: string }[];
};

export function toEmployeeListItem(emp: EmployeeWithManager): EmployeeListItem {
  return {
    id: emp.id,
    code: emp.code,
    firstName: emp.firstName,
    lastName: emp.lastName,
    email: emp.email,
    phone: emp.phone,
    department: emp.department,
    designation: emp.designation,
    location: emp.location,
    managerName: emp.manager ? fullName(emp.manager) : null,
    joinDate: dateOnly(emp.joinDate),
    employmentType: emp.employmentType as EmployeeListItem["employmentType"],
    status: emp.status as EmployeeListItem["status"],
    ctc: emp.ctc,
    avatarColor: emp.avatarColor,
    hasLogin: (emp.users?.length ?? 0) > 0,
  };
}

export function toLeaveTypeDto(lt: LeaveType): LeaveTypeDto {
  return {
    id: lt.id,
    name: lt.name,
    code: lt.code,
    annualQuota: lt.annualQuota,
    paid: lt.paid,
    carryForward: lt.carryForward,
  };
}

type BalanceWithType = LeaveBalance & { leaveType: LeaveType };

export function toLeaveBalanceDto(b: BalanceWithType): LeaveBalanceDto {
  return {
    leaveTypeId: b.leaveTypeId,
    name: b.leaveType.name,
    code: b.leaveType.code,
    entitled: b.entitled,
    used: b.used,
    pending: b.pending,
    available: b.entitled - b.used - b.pending,
  };
}

type LeaveRequestWithRelations = LeaveRequest & { employee: Employee; leaveType: LeaveType };

export function toLeaveRequestDto(r: LeaveRequestWithRelations): LeaveRequestDto {
  return {
    id: r.id,
    employeeId: r.employeeId,
    employeeName: fullName(r.employee),
    employeeCode: r.employee.code,
    department: r.employee.department,
    avatarColor: r.employee.avatarColor,
    leaveTypeId: r.leaveTypeId,
    typeName: r.leaveType.name,
    startDate: dateOnly(r.startDate),
    endDate: dateOnly(r.endDate),
    days: r.days,
    reason: r.reason,
    status: r.status as LeaveRequestDto["status"],
    approverName: r.approverName,
    comment: r.comment,
    decidedAt: r.decidedAt?.toISOString() ?? null,
    createdAt: r.createdAt.toISOString(),
  };
}

type AttendanceWithEmployee = AttendanceRecord & { employee: Employee };

export function toAttendanceDto(rec: AttendanceWithEmployee): AttendanceDto {
  return {
    id: rec.id,
    employeeId: rec.employeeId,
    employeeName: fullName(rec.employee),
    employeeCode: rec.employee.code,
    department: rec.employee.department,
    avatarColor: rec.employee.avatarColor,
    date: dateOnly(rec.date),
    checkIn: rec.checkIn,
    checkOut: rec.checkOut,
    status: rec.status as AttendanceDto["status"],
    hours: rec.hours,
    note: rec.note,
    latitude: rec.latitude,
    longitude: rec.longitude,
    accuracy: rec.accuracy,
    distanceMeters: rec.distanceMeters,
    geoStatus: rec.geoStatus,
  };
}

export function toOnboardingTaskDto(t: {
  id: string;
  title: string;
  category: string;
  assignee: string;
  dueDate: Date;
  status: string;
  order: number;
}): OnboardingTaskDto {
  return {
    id: t.id,
    title: t.title,
    category: t.category,
    assignee: t.assignee,
    dueDate: dateOnly(t.dueDate),
    status: t.status as OnboardingTaskDto["status"],
    order: t.order,
  };
}

export function toDepartmentDto(
  d: Department,
  employeeCount: number,
  headName: string | null
): DepartmentDto {
  return {
    id: d.id,
    name: d.name,
    description: d.description,
    headName,
    employeeCount,
  };
}

export function toOpeningDto(o: JobOpening, candidateCount: number): JobOpeningDto {
  return {
    id: o.id,
    title: o.title,
    department: o.department,
    location: o.location,
    employmentType: o.employmentType as JobOpeningDto["employmentType"],
    openings: o.openings,
    status: o.status as JobOpeningDto["status"],
    hiringManager: o.hiringManager,
    minExpYears: o.minExpYears,
    maxSalary: o.maxSalary,
    skills: parseJson<string[]>(o.skills, []),
    description: o.description,
    candidateCount,
    createdAt: o.createdAt.toISOString(),
  };
}

type CandidateWithOpening = Candidate & { opening: JobOpening };

export function toCandidateDto(c: CandidateWithOpening): CandidateDto {
  return {
    id: c.id,
    openingId: c.openingId,
    openingTitle: c.opening.title,
    name: c.name,
    email: c.email,
    phone: c.phone,
    source: c.source,
    stage: c.stage as CandidateDto["stage"],
    rating: c.rating,
    expectedSalary: c.expectedSalary,
    noticePeriod: c.noticePeriod,
    resumeSummary: c.resumeSummary,
    notes: c.notes,
    appliedAt: c.appliedAt.toISOString(),
    updatedAt: c.updatedAt.toISOString(),
  };
}

type ReviewWithEmployee = PerformanceReview & { employee: Employee };

export function toReviewDto(r: ReviewWithEmployee): ReviewDto {
  return {
    id: r.id,
    employeeId: r.employeeId,
    employeeName: fullName(r.employee),
    employeeCode: r.employee.code,
    department: r.employee.department,
    designation: r.employee.designation,
    avatarColor: r.employee.avatarColor,
    cycle: r.cycle,
    periodLabel: r.periodLabel,
    status: r.status as ReviewDto["status"],
    selfRating: r.selfRating,
    managerRating: r.managerRating,
    finalRating: r.finalRating,
    goals: parseJson<ReviewGoal[]>(r.goals, []),
    reviewerName: r.reviewerName,
    dueDate: dateOnly(r.dueDate),
    summary: r.summary,
    strengths: r.strengths,
    improvements: r.improvements,
    completedAt: r.completedAt?.toISOString() ?? null,
  };
}

export function toTicketDto(t: HrTicket): TicketDto {
  const ageHours = Math.round(((Date.now() - t.createdAt.getTime()) / 3_600_000) * 10) / 10;
  return {
    id: t.id,
    ticketNo: t.ticketNo,
    subject: t.subject,
    category: t.category,
    priority: t.priority as TicketDto["priority"],
    status: t.status as TicketDto["status"],
    requesterName: t.requesterName,
    requesterEmail: t.requesterEmail,
    assignedTo: t.assignedTo,
    slaHours: t.slaHours,
    createdAt: t.createdAt.toISOString(),
    resolvedAt: t.resolvedAt?.toISOString() ?? null,
    ageHours,
    messages: parseJson<TicketMessage[]>(t.messages, []),
  };
}

export function toAnnouncementDto(a: Announcement): AnnouncementDto {
  return {
    id: a.id,
    title: a.title,
    body: a.body,
    category: a.category,
    authorName: a.authorName,
    pinned: a.pinned,
    acknowledgedCount: a.acknowledgedCount,
    createdAt: a.createdAt.toISOString(),
  };
}

export function toWorkflowDto(w: Workflow): WorkflowDto {
  return {
    id: w.id,
    name: w.name,
    description: w.description,
    category: w.category,
    triggerCode: w.triggerCode,
    triggerLabel: w.triggerLabel,
    active: w.active,
    lastRunAt: w.lastRunAt?.toISOString() ?? null,
    executionCount: w.executionCount,
  };
}

type ExecutionWithWorkflow = WorkflowExecution & { workflow?: Workflow | null };

export function toWorkflowExecutionDto(e: ExecutionWithWorkflow): WorkflowExecutionDto {
  return {
    id: e.id,
    workflowId: e.workflowId,
    workflowName: e.workflow?.name ?? "",
    status: e.status as WorkflowExecutionDto["status"],
    trigger: e.trigger,
    summary: e.summary,
    startedAt: e.startedAt.toISOString(),
    finishedAt: e.finishedAt?.toISOString() ?? null,
    steps: parseJson<WorkflowExecutionStep[]>(e.steps, []),
  };
}

export function toAuditDto(l: AuditLog): AuditLogDto {
  return {
    id: l.id,
    actorName: l.actorName,
    actorRole: l.actorRole,
    action: l.action,
    entity: l.entity,
    entityId: l.entityId,
    summary: l.summary,
    severity: l.severity as AuditLogDto["severity"],
    createdAt: l.createdAt.toISOString(),
  };
}

export function toPolicyDto(p: PolicyDocument): PolicyDto {
  return {
    id: p.id,
    title: p.title,
    category: p.category,
    version: p.version,
    audience: p.audience,
    content: p.content,
    updatedBy: p.updatedBy,
    updatedAt: p.updatedAt.toISOString(),
  };
}

export function toHolidayDto(h: Holiday): HolidayDto {
  return {
    id: h.id,
    name: h.name,
    date: dateOnly(h.date),
    type: h.type as HolidayDto["type"],
  };
}

export function toNotificationDto(n: Notification): NotificationDto {
  return {
    id: n.id,
    title: n.title,
    body: n.body,
    type: n.type,
    read: n.read,
    createdAt: n.createdAt.toISOString(),
  };
}

export function toInvoiceDto(i: Invoice): InvoiceDto {
  return {
    id: i.id,
    number: i.number,
    plan: i.plan,
    periodLabel: i.periodLabel,
    seats: i.seats,
    amount: i.amount,
    tax: i.tax,
    total: i.total,
    status: i.status as InvoiceDto["status"],
    issuedAt: i.issuedAt.toISOString(),
    paidAt: i.paidAt?.toISOString() ?? null,
    method: i.method,
  };
}

export function toPaymentMethodDto(m: PaymentMethod): PaymentMethodDto {
  return {
    id: m.id,
    label: m.label,
    type: m.type === "upi" ? "upi" : "bank",
    upiId: m.upiId,
    accountHolder: m.accountHolder,
    accountNumber: m.accountNumber,
    ifsc: m.ifsc,
    bankName: m.bankName,
    accountType: m.accountType,
    instructions: m.instructions,
    active: m.active,
    sortOrder: m.sortOrder,
  };
}

export function toPaymentProofDto(p: PaymentProof): PaymentProofDto {
  return {
    id: p.id,
    tenantId: p.tenantId,
    utr: p.utr,
    amount: p.amount,
    payerName: p.payerName,
    paidAt: p.paidAt.toISOString(),
    method: p.method === "upi" ? "upi" : "bank",
    note: p.note,
    plan: p.plan,
    cycle: p.cycle === "annual" ? "annual" : "monthly",
    seats: p.seats,
    status: p.status as PaymentProofDto["status"],
    reviewNote: p.reviewNote,
    reviewedAt: p.reviewedAt?.toISOString() ?? null,
    createdAt: p.createdAt.toISOString(),
  };
}

export function toOrgProfileDto(t: Tenant, employeeCount: number): OrgProfileDto {
  return {
    id: t.id,
    name: t.name,
    slug: t.slug,
    plan: t.plan as OrgProfileDto["plan"],
    planStatus: t.planStatus,
    trialEndsAt: t.trialEndsAt?.toISOString() ?? null,
    seats: t.seats,
    employeeCount,
    brandColor: t.brandColor,
    logoText: t.logoText,
    country: t.country,
    currency: t.currency,
    timezone: t.timezone,
    createdAt: t.createdAt.toISOString(),
    onboardingStep: t.onboardingStep,
  };
}

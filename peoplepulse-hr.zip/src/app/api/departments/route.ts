/**
 * Departments API.
 *
 * GET  /api/departments — list departments with live (non-exited) employee
 *   counts and resolved department head names. Any signed-in user.
 *
 * POST /api/departments — create a department (owner | admin | hr). Department
 *   names are unique per tenant; duplicates fail with 409.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { fullName, toDepartmentDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();

    const [departments, counts, employees] = await Promise.all([
      db.department.findMany({ where: { tenantId: session.tenantId }, orderBy: { name: "asc" } }),
      db.employee.groupBy({
        by: ["department"],
        where: { tenantId: session.tenantId, status: { not: "exited" } },
        _count: { _all: true },
      }),
      db.employee.findMany({
        where: { tenantId: session.tenantId },
        select: { id: true, firstName: true, lastName: true },
      }),
    ]);

    const countByDept = new Map(counts.map((c) => [c.department, c._count._all]));
    const nameById = new Map(employees.map((e) => [e.id, fullName(e)]));

    const items = departments.map((d) =>
      toDepartmentDto(d, countByDept.get(d.name) ?? 0, d.headEmployeeId ? nameById.get(d.headEmployeeId) ?? null : null)
    );
    return ok({ items });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const name = String(body.name ?? "").trim();
    if (!name) return fail("Department name is required.", 400);

    const existing = await db.department.findFirst({
      where: { tenantId: session.tenantId, name },
      select: { id: true },
    });
    if (existing) return fail("Department already exists.", 409);

    const department = await db.department.create({
      data: {
        tenantId: session.tenantId,
        name,
        description: body.description != null && body.description !== "" ? String(body.description) : null,
      },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "department.created",
      entity: "Department",
      entityId: department.id,
      summary: `Created department ${name}.`,
    });

    return ok({ item: toDepartmentDto(department, 0, null) }, { status: 201 });
  });
}

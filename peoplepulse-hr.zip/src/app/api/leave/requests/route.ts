/**
 * Leave request API.
 *
 * GET /api/leave/requests — any signed-in user. Query: scope ("mine" | "team"
 * | "all"), status, page, pageSize. The default scope depends on the caller's
 * role (employee -> mine, manager -> team, hr/owner/admin -> all). Employees
 * are always limited to "mine"; managers never see the whole tenant ("all" is
 * clamped to "team").
 *
 * POST /api/leave/requests — any signed-in user with a linked employee record.
 * Validates the date range (no overlaps with open requests, no spans over a
 * year, reason capped at 500 chars), counts working days (Mon-Sat, Sundays
 * excluded), checks the current-year balance, reserves the days as pending and
 * fires the `leave.submitted` workflow plus a notification and audit entry.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify, triggerWorkflow } from "@/lib/api-helpers";
import { workingDaysInclusive } from "@/lib/hr-utils";
import {
  addDays,
  fullName,
  intParam,
  isValidDateOnly,
  localDate,
  toLeaveRequestDto,
} from "@/app/api/_lib/mappers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const scopeParam = (sp.get("scope") ?? "").trim();
    const status = (sp.get("status") ?? "").trim();
    const page = Math.max(1, intParam(sp.get("page"), 1));
    const pageSize = Math.min(100, Math.max(1, intParam(sp.get("pageSize"), 50)));

    // Role-aware scope resolution: employees only ever see their own requests.
    let scope: "mine" | "team" | "all";
    if (session.role === "employee") scope = "mine";
    else if (session.role === "manager") scope = scopeParam === "mine" ? "mine" : "team";
    else scope = scopeParam === "mine" || scopeParam === "team" ? scopeParam : "all";

    const where: Prisma.LeaveRequestWhereInput = { tenantId: session.tenantId };
    if (status) where.status = status;

    if (scope === "mine") {
      if (!session.employeeId) {
        return ok({ items: [], total: 0, page, pageSize });
      }
      where.employeeId = session.employeeId;
    } else if (scope === "team") {
      if (!session.employeeId) {
        return ok({ items: [], total: 0, page, pageSize });
      }
      where.OR = [
        { employeeId: session.employeeId },
        { employee: { managerId: session.employeeId } },
      ];
    }

    const [rows, total] = await Promise.all([
      db.leaveRequest.findMany({
        where,
        include: { employee: true, leaveType: true },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.leaveRequest.count({ where }),
    ]);

    return ok({ items: rows.map(toLeaveRequestDto), total, page, pageSize });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail("Your account is not linked to an employee record.", 400);
    }

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const leaveTypeId = String(body.leaveTypeId ?? "").trim();
    const startDate = String(body.startDate ?? "").trim();
    const endDate = String(body.endDate ?? "").trim();
    const reason = String(body.reason ?? "").trim();

    if (!leaveTypeId) return fail("Please select a leave type.", 400);
    if (!isValidDateOnly(startDate) || !isValidDateOnly(endDate)) {
      return fail("Start and end dates must be valid dates (YYYY-MM-DD).", 400);
    }
    if (endDate < startDate) return fail("End date cannot be before the start date.", 400);
    if (reason.length < 3) return fail("Please enter a reason (at least 3 characters).", 400);
    if (reason.length > 500) return fail("Reason must be 500 characters or fewer.", 400);

    // Span limit: a request cannot cover more than a year.
    const rangeStart = localDate(startDate);
    const rangeEnd = localDate(endDate);
    if (rangeEnd.getTime() - rangeStart.getTime() > 366 * 86400000) {
      return fail("Leave requests cannot span more than a year.", 400);
    }

    // Overlap guard: reject when an open (pending/approved) request for the
    // same employee already covers any of these days. The end boundary is
    // widened to the full calendar day so stored rows with a time-of-day
    // component are still caught.
    const overlap = await db.leaveRequest.findFirst({
      where: {
        tenantId: session.tenantId,
        employeeId: session.employeeId,
        status: { in: ["pending", "approved"] },
        startDate: { lt: addDays(rangeEnd, 1) },
        endDate: { gte: rangeStart },
      },
      select: { id: true },
    });
    if (overlap) {
      return fail("You already have a leave request overlapping these dates.", 409);
    }

    const leaveType = await db.leaveType.findFirst({
      where: { tenantId: session.tenantId, id: leaveTypeId },
    });
    if (!leaveType) return fail("The selected leave type was not found.", 400);

    // Working days = Mon-Sat inclusive (Sundays excluded), same as the UI.
    const days = workingDaysInclusive(startDate, endDate);
    if (days <= 0) return fail("The selected dates include no working days.", 400);

    const year = new Date().getFullYear();
    const balance = await db.leaveBalance.findFirst({
      where: {
        tenantId: session.tenantId,
        employeeId: session.employeeId,
        leaveTypeId: leaveType.id,
        year,
      },
    });
    const available = balance ? balance.entitled - balance.used - balance.pending : 0;
    if (available < days) return fail("Insufficient leave balance.", 400);

    const request = await db.leaveRequest.create({
      data: {
        tenantId: session.tenantId,
        employeeId: session.employeeId,
        leaveTypeId: leaveType.id,
        startDate: rangeStart,
        endDate: rangeEnd,
        days,
        reason,
        status: "pending",
      },
      include: { employee: true, leaveType: true },
    });

    if (balance) {
      await db.leaveBalance.update({
        where: { id: balance.id },
        data: { pending: { increment: days } },
      });
    }

    await notify(session.tenantId, {
      userId: session.id,
      title: "Leave request submitted",
      body: `Your ${days}-day ${leaveType.name} request (${startDate} to ${endDate}) is pending approval.`,
      type: "leave",
    });

    await triggerWorkflow(session.tenantId, "leave.submitted", {
      trigger: "Employee self-service",
      summary: `${fullName(request.employee)} submitted a ${days}-day ${leaveType.name} request.`,
      steps: [
        {
          name: "Balance check",
          detail: `${available} day(s) available, ${days} requested.`,
          ok: true,
        },
        {
          name: "Pending approval",
          detail: "Request routed to the reporting manager for approval.",
          ok: true,
        },
      ],
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "leave.requested",
      entity: "LeaveRequest",
      entityId: request.id,
      summary: `${fullName(request.employee)} requested ${days} day(s) of ${leaveType.name} (${startDate} to ${endDate}).`,
    });

    return ok({ request: toLeaveRequestDto(request) }, { status: 201 });
  });
}

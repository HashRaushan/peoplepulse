/**
 * Leave request decision API.
 *
 * PATCH /api/leave/requests/{id} — body { action: "approve" | "reject" |
 * "cancel", comment? }.
 *   - cancel: requester only, pending requests only. Releases the reserved
 *     pending days.
 *   - approve / reject: allowed for owner/admin/hr always, and for a manager
 *     only when the request belongs to their direct report. Approving moves
 *     the reserved days from pending to used and marks attendance as "leave"
 *     for every working day in the range.
 * All outcomes notify the employee and write an audit entry.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit, notify, triggerWorkflow } from "@/lib/api-helpers";
import { addDays, fullName, localDate, toLeaveRequestDto, userIdForEmployee } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

/** Clamp the pending counter so it never drifts below zero. Uses the year the
 *  request STARTS in, so balances are released into the same year they were
 *  reserved from (requests may span a year boundary). */
async function adjustPending(
  tenantId: string,
  employeeId: string,
  leaveTypeId: string,
  delta: number,
  year: number
) {
  const balance = await db.leaveBalance.findFirst({
    where: { tenantId, employeeId, leaveTypeId, year },
  });
  if (!balance) return null;
  const updated = await db.leaveBalance.update({
    where: { id: balance.id },
    data: { pending: Math.max(0, balance.pending + delta) },
  });
  return updated;
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const action = String(body.action ?? "");
    const comment =
      body.comment != null && String(body.comment).trim() !== "" ? String(body.comment).slice(0, 300) : null;

    const request = await db.leaveRequest.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { employee: true, leaveType: true },
    });
    if (!request) return fail("Leave request not found.", 404);

    const rangeLabel = `${dateOnly(request.startDate)} to ${dateOnly(request.endDate)}`;
    const employeeUserId = await userIdForEmployee(session.tenantId, request.employeeId);

    if (action === "cancel") {
      if (session.employeeId !== request.employeeId) {
        return fail("Only the requester can cancel this leave request.", 403);
      }
      if (request.status !== "pending") {
        return fail("Only pending requests can be cancelled.", 400);
      }

      const updated = await db.leaveRequest.update({
        where: { id: request.id },
        data: {
          status: "cancelled",
          approverName: session.name,
          comment,
          decidedAt: new Date(),
        },
        include: { employee: true, leaveType: true },
      });
      await adjustPending(
        session.tenantId,
        request.employeeId,
        request.leaveTypeId,
        -request.days,
        request.startDate.getFullYear()
      );

      await notify(session.tenantId, {
        userId: employeeUserId,
        title: "Leave request cancelled",
        body: `Your ${request.days}-day ${request.leaveType.name} request (${rangeLabel}) was cancelled.`,
        type: "leave",
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "leave.cancelled",
        entity: "LeaveRequest",
        entityId: request.id,
        summary: `Cancelled a ${request.days}-day ${request.leaveType.name} request for ${fullName(request.employee)}.`,
      });
      return ok({ request: toLeaveRequestDto(updated) });
    }

    if (action === "approve" || action === "reject") {
      const isHrRole = ["owner", "admin", "hr"].includes(session.role);
      const isOwnManager =
        session.role === "manager" &&
        !!session.employeeId &&
        request.employee.managerId === session.employeeId;
      if (!isHrRole && !isOwnManager) {
        return fail("You do not have permission to decide this leave request.", 403);
      }
      if (request.status !== "pending") {
        return fail("This request has already been processed.", 400);
      }

      if (action === "approve") {
        // Move the reserved days from pending to used. The balance year is the
        // year the request starts in, not necessarily the current year.
        const year = request.startDate.getFullYear();
        const balance = await db.leaveBalance.findFirst({
          where: {
            tenantId: session.tenantId,
            employeeId: request.employeeId,
            leaveTypeId: request.leaveTypeId,
            year,
          },
        });
        // Re-check the balance at decision time — it may have shrunk since the
        // request was submitted (e.g. another request was approved meanwhile).
        if (balance && balance.used + request.days > balance.entitled) {
          return fail("Insufficient balance — this request can no longer be approved in full.", 409);
        }
        if (balance) {
          await db.leaveBalance.update({
            where: { id: balance.id },
            data: {
              used: { increment: request.days },
              pending: Math.max(0, balance.pending - request.days),
            },
          });
        }

        // Mark attendance as "leave" for each working day (Mon-Sat) in the range.
        const cursor = localDate(dateOnly(request.startDate));
        const end = localDate(dateOnly(request.endDate));
        let markedDays = 0;
        while (cursor.getTime() <= end.getTime()) {
          if (cursor.getDay() !== 0) {
            const day = new Date(cursor);
            const existing = await db.attendanceRecord.findFirst({
              where: {
                tenantId: session.tenantId,
                employeeId: request.employeeId,
                date: { gte: day, lt: addDays(day, 1) },
              },
            });
            if (existing) {
              await db.attendanceRecord.update({
                where: { id: existing.id },
                data: { status: "leave" },
              });
            } else {
              await db.attendanceRecord.create({
                data: {
                  tenantId: session.tenantId,
                  employeeId: request.employeeId,
                  date: day,
                  status: "leave",
                  note: `${request.leaveType.name} approved`,
                },
              });
            }
            markedDays += 1;
          }
          cursor.setDate(cursor.getDate() + 1);
        }

        const updated = await db.leaveRequest.update({
          where: { id: request.id },
          data: {
            status: "approved",
            approverName: session.name,
            comment,
            decidedAt: new Date(),
          },
          include: { employee: true, leaveType: true },
        });

        await notify(session.tenantId, {
          userId: employeeUserId,
          title: "Leave request approved",
          body: `Your ${request.days}-day ${request.leaveType.name} request (${rangeLabel}) was approved by ${session.name}.`,
          type: "leave",
        });

        await triggerWorkflow(session.tenantId, "leave.approved", {
          trigger: "Manager approval",
          summary: `${session.name} approved ${request.days} day(s) of ${request.leaveType.name} for ${fullName(request.employee)}.`,
          steps: [
            { name: "Balance updated", detail: `${request.days} day(s) moved from pending to used.`, ok: true },
            { name: "Attendance marked", detail: `${markedDays} working day(s) marked as leave.`, ok: true },
            { name: "Employee notified", detail: `Approval confirmation sent to ${fullName(request.employee)}.`, ok: true },
          ],
        });

        await audit(session.tenantId, {
          actorName: session.name,
          actorRole: session.role,
          action: "leave.approved",
          entity: "LeaveRequest",
          entityId: request.id,
          summary: `Approved ${request.days}-day ${request.leaveType.name} for ${fullName(request.employee)} (${rangeLabel}).`,
        });
        return ok({ request: toLeaveRequestDto(updated) });
      }

      // reject: release the reserved pending days.
      await adjustPending(
        session.tenantId,
        request.employeeId,
        request.leaveTypeId,
        -request.days,
        request.startDate.getFullYear()
      );
      const updated = await db.leaveRequest.update({
        where: { id: request.id },
        data: {
          status: "rejected",
          approverName: session.name,
          comment,
          decidedAt: new Date(),
        },
        include: { employee: true, leaveType: true },
      });

      await notify(session.tenantId, {
        userId: employeeUserId,
        title: "Leave request rejected",
        body: `Your ${request.days}-day ${request.leaveType.name} request (${rangeLabel}) was rejected by ${session.name}.${comment ? ` Note: ${comment}` : ""}`,
        type: "leave",
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "leave.rejected",
        entity: "LeaveRequest",
        entityId: request.id,
        summary: `Rejected ${request.days}-day ${request.leaveType.name} for ${fullName(request.employee)} (${rangeLabel}).`,
      });
      return ok({ request: toLeaveRequestDto(updated) });
    }

    return fail("Unknown action. Use approve, reject or cancel.", 400);
  });
}

/**
 * Leave type catalogue API.
 *
 * GET /api/leave/types — any signed-in user. Returns the tenant's configured
 * leave types ({ items: LeaveTypeDto[] }) sorted by name.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { toLeaveTypeDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const rows = await db.leaveType.findMany({
      where: { tenantId: session.tenantId },
      orderBy: { name: "asc" },
    });
    return ok({ items: rows.map(toLeaveTypeDto) });
  });
}

/**
 * Team leave calendar API.
 *
 * GET /api/leave/calendar — any signed-in user. Query: month (YYYY-MM,
 * defaults to the current month). Builds a LeaveCalendarDay for every day of
 * the month with weekend flags, tenant holidays and the list of approved
 * leave overlapping each day.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly } from "@/lib/api-helpers";
import { fullName, localDate } from "@/app/api/_lib/mappers";
import type { LeaveCalendarDay } from "@/lib/types";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;

    const monthParam = sp.get("month") ?? "";
    const match = /^(\d{4})-(\d{2})$/.exec(monthParam);
    const now = new Date();
    const year = match ? Number(match[1]) : now.getFullYear();
    const month = match ? Number(match[2]) : now.getMonth() + 1;
    if (year < 2000 || month < 1 || month > 12) {
      return fail("Month must be in YYYY-MM format.", 400);
    }

    const monthStart = new Date(year, month - 1, 1);
    const monthEnd = new Date(year, month, 1);
    const daysInMonth = new Date(year, month, 0).getDate();

    const [holidays, leaves] = await Promise.all([
      db.holiday.findMany({
        where: { tenantId: session.tenantId, date: { gte: monthStart, lt: monthEnd } },
      }),
      db.leaveRequest.findMany({
        where: {
          tenantId: session.tenantId,
          status: "approved",
          startDate: { lt: monthEnd },
          endDate: { gte: monthStart },
        },
        include: { employee: true, leaveType: true },
      }),
    ]);

    const holidayByDate = new Map(holidays.map((h) => [dateOnly(h.date), { name: h.name, type: h.type }]));
    // Normalise to date-only keys: stored datetimes may carry a time-of-day
    // component (e.g. seed data), so raw timestamp comparison would drop days.
    const rangeOf = (l: { startDate: Date; endDate: Date }) => ({
      start: dateOnly(l.startDate),
      end: dateOnly(l.endDate),
    });

    const days: LeaveCalendarDay[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const day = localDate(iso);
      const dayLeaves = leaves
        .map((l) => ({ l, range: rangeOf(l) }))
        .filter(({ range }) => range.start <= iso && range.end >= iso)
        .map(({ l }) => ({
          employeeName: fullName(l.employee),
          typeName: l.leaveType.name,
          avatarColor: l.employee.avatarColor,
        }));
      const holiday = holidayByDate.get(iso);
      days.push({
        date: iso,
        isWeekend: day.getDay() === 0,
        ...(holiday ? { holiday } : {}),
        leaves: dayLeaves,
      });
    }

    return ok({ month: `${year}-${String(month).padStart(2, "0")}`, days });
  });
}

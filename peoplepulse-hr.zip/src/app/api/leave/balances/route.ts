/**
 * Leave balance API.
 *
 * GET /api/leave/balances — current-year leave balances joined with the leave
 * type. Any signed-in user; query employeeId defaults to the caller's own
 * employee record. Viewing another employee's balances requires the
 * owner/admin/hr/manager role. Users without an employee record get an empty
 * list rather than an error.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { toLeaveBalanceDto } from "@/app/api/_lib/mappers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const requested = (sp.get("employeeId") ?? "").trim();

    let employeeId = session.employeeId;
    if (requested && requested !== session.employeeId) {
      if (!["owner", "admin", "hr", "manager"].includes(session.role)) {
        return fail("You do not have permission to view these balances.", 403);
      }
      employeeId = requested;
    }
    if (!employeeId) return ok({ items: [] });

    const rows = await db.leaveBalance.findMany({
      where: {
        tenantId: session.tenantId,
        employeeId,
        year: new Date().getFullYear(),
      },
      include: { leaveType: true },
    });
    return ok({ items: rows.map(toLeaveBalanceDto) });
  });
}

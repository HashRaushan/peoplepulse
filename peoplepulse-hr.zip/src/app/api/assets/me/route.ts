/**
 * My assets API.
 *
 * GET /api/assets/me — any signed-in user with a linked employee record
 * (400 when the account has no employeeId). Returns the user's open asset
 * allocations (returnedAt = null) with the asset details, newest first.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import type { MyAssetDto } from "@/lib/types";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail("Your account is not linked to an employee record.", 400);
    }

    const rows = await db.assetAllocation.findMany({
      where: {
        tenantId: session.tenantId,
        employeeId: session.employeeId,
        returnedAt: null,
      },
      include: { asset: true },
      orderBy: { allocatedAt: "desc" },
    });

    const items: MyAssetDto[] = rows.map((row) => ({
      id: row.id,
      assetId: row.assetId,
      name: row.asset.name,
      category: row.asset.category,
      assetTag: row.asset.assetTag,
      serialNumber: row.asset.serialNumber,
      value: row.asset.value,
      allocatedAt: row.allocatedAt.toISOString(),
    }));

    return ok({ items });
  });
}

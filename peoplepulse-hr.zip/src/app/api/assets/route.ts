/**
 * Asset inventory API.
 *
 * GET /api/assets — full asset inventory with stats. Owner/admin/hr only
 * (403 otherwise). Includes the currently open allocation (with the employee
 * name) per asset and returns inventory stats. Ordered by createdAt desc.
 *
 * POST /api/assets — register a new asset (owner/admin/hr). Auto-generates the
 * next "AST-###" tag for the tenant (max numeric suffix + 1, zero-padded to
 * three digits), validates name/category and writes an audit entry.
 * Responds with 201 { asset }.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { ASSET_CATEGORIES } from "@/lib/constants";
import { fullName, isValidDateOnly, localDate } from "@/app/api/_lib/mappers";
import type { AssetDto, AssetStatus } from "@/lib/types";

type AssetWithOpenAllocation = Prisma.AssetGetPayload<{
  include: { allocations: { include: { employee: true } } };
}>;

/** Map a Prisma asset (with its open allocation) to the API DTO. */
function toAssetDto(a: AssetWithOpenAllocation): AssetDto {
  const open = a.allocations.find((al) => al.returnedAt === null) ?? null;
  return {
    id: a.id,
    name: a.name,
    category: a.category,
    assetTag: a.assetTag,
    serialNumber: a.serialNumber,
    value: a.value,
    purchaseDate: a.purchaseDate ? dateOnly(a.purchaseDate) : null,
    status: a.status as AssetStatus,
    notes: a.notes,
    currentAllocation: open
      ? {
          employeeId: open.employeeId,
          employeeName: fullName(open.employee),
          allocatedAt: open.allocatedAt.toISOString(),
        }
      : null,
    createdAt: a.createdAt.toISOString(),
  };
}

/** Prisma include that fetches only the open allocation with its employee. */
const OPEN_ALLOCATION_INCLUDE = {
  allocations: { where: { returnedAt: null }, include: { employee: true } },
} satisfies Prisma.AssetInclude;

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const rows = await db.asset.findMany({
      where: { tenantId: session.tenantId },
      include: OPEN_ALLOCATION_INCLUDE,
      orderBy: { createdAt: "desc" },
    });

    const stats = {
      total: rows.length,
      allocated: rows.filter((a) => a.status === "allocated").length,
      available: rows.filter((a) => a.status === "available").length,
      totalValue: rows.reduce((sum, a) => sum + a.value, 0),
    };

    return ok({ assets: rows.map(toAssetDto), stats });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const name = String(body.name ?? "").trim();
    const category = String(body.category ?? "").trim();
    const serialNumber =
      body.serialNumber != null && String(body.serialNumber).trim() !== ""
        ? String(body.serialNumber).trim().slice(0, 100)
        : null;
    const notes =
      body.notes != null && String(body.notes).trim() !== ""
        ? String(body.notes).trim().slice(0, 500)
        : null;

    if (!name) return fail("Please enter an asset name.", 400);
    if (name.length > 120) return fail("Asset name must be 120 characters or fewer.", 400);
    if (!category) return fail("Please select a category.", 400);
    if (!ASSET_CATEGORIES.includes(category)) {
      return fail("Please select a valid asset category.", 400);
    }

    // Value (INR) — optional, non-negative.
    let value = 0;
    if (body.value != null && String(body.value).trim() !== "") {
      const n = Number(body.value);
      if (!Number.isFinite(n) || n < 0) {
        return fail("Value must be a non-negative amount in INR.", 400);
      }
      value = Math.round(n);
    }

    // Purchase date — optional YYYY-MM-DD.
    let purchaseDate: Date | null = null;
    if (body.purchaseDate != null && String(body.purchaseDate).trim() !== "") {
      const pd = String(body.purchaseDate).trim();
      if (!isValidDateOnly(pd)) {
        return fail("Purchase date must be a valid date (YYYY-MM-DD).", 400);
      }
      purchaseDate = localDate(pd);
    }

    // Next tag: AST-### based on the tenant's highest existing suffix.
    const existing = await db.asset.findMany({
      where: { tenantId: session.tenantId, assetTag: { startsWith: "AST-" } },
      select: { assetTag: true },
    });
    let maxSuffix = 0;
    for (const row of existing) {
      const n = Number.parseInt(row.assetTag.slice(4), 10);
      if (Number.isFinite(n) && n > maxSuffix) maxSuffix = n;
    }
    const assetTag = `AST-${String(maxSuffix + 1).padStart(3, "0")}`;

    const asset = await db.asset.create({
      data: {
        tenantId: session.tenantId,
        name,
        category,
        assetTag,
        serialNumber,
        value,
        purchaseDate,
        status: "available",
        notes,
      },
      include: OPEN_ALLOCATION_INCLUDE,
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "asset.created",
      entity: "Asset",
      entityId: asset.id,
      summary: `Added asset ${asset.name} (${asset.assetTag}, ${asset.category}).`,
    });

    return ok({ asset: toAssetDto(asset) }, { status: 201 });
  });
}

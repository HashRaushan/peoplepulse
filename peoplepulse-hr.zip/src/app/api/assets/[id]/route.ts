/**
 * Asset lifecycle API.
 *
 * PATCH /api/assets/{id} — owner/admin/hr only. Body { action, ... }:
 *   - allocate:   { employeeId, notes? } — asset must be "available" (409
 *     otherwise). Creates an AssetAllocation, marks the asset "allocated",
 *     notifies the employee's linked user and audits.
 *   - return:     { condition?, notes? } — asset must be "allocated" (409
 *     otherwise). Closes the open allocation (returnedAt, condition, notes)
 *     and marks the asset "available".
 *   - retire:     asset must not be currently allocated (409 when allocated).
 *     Marks the asset "retired"; audited with warning severity.
 *   - maintenance_on:  only from "available" — marks the asset "maintenance".
 *   - maintenance_off: only from "maintenance" — back to "available".
 *   - update:     { name?, category?, value?, serialNumber?, notes? } —
 *     partial update of asset details.
 * Responds with { asset } and 404 when the asset is not found in the tenant.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit, notify } from "@/lib/api-helpers";
import { ASSET_CATEGORIES } from "@/lib/constants";
import { fullName, userIdForEmployee } from "@/app/api/_lib/mappers";
import type { AssetDto, AssetStatus } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

type AssetWithOpenAllocation = Prisma.AssetGetPayload<{
  include: { allocations: { include: { employee: true } } };
}>;

const RETURN_CONDITIONS = ["Excellent", "Good", "Fair", "Damaged"];

/** Map a Prisma asset (with its open allocation) to the API DTO. */
function toAssetDto(a: AssetWithOpenAllocation): AssetDto {
  const open = a.allocations.find((al) => al.returnedAt === null) ?? null;
  return {
    id: a.id,
    name: a.name,
    category: a.category,
    assetTag: a.assetTag,
    serialNumber: a.serialNumber,
    value: a.value,
    purchaseDate: a.purchaseDate ? dateOnly(a.purchaseDate) : null,
    status: a.status as AssetStatus,
    notes: a.notes,
    currentAllocation: open
      ? {
          employeeId: open.employeeId,
          employeeName: fullName(open.employee),
          allocatedAt: open.allocatedAt.toISOString(),
        }
      : null,
    createdAt: a.createdAt.toISOString(),
  };
}

/** Prisma include that fetches only the open allocation with its employee. */
const OPEN_ALLOCATION_INCLUDE = {
  allocations: { where: { returnedAt: null }, include: { employee: true } },
} satisfies Prisma.AssetInclude;

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;
    const action = String(body.action ?? "");

    const asset = await db.asset.findFirst({
      where: { tenantId: session.tenantId, id },
      include: OPEN_ALLOCATION_INCLUDE,
    });
    if (!asset) return fail("Asset not found.", 404);

    const openAllocation = asset.allocations.find((al) => al.returnedAt === null) ?? null;

    // ---------- allocate ----------
    if (action === "allocate") {
      if (asset.status !== "available") {
        return fail("Asset is not available", 409);
      }
      const employeeId = String(body.employeeId ?? "").trim();
      if (!employeeId) return fail("Please select an employee to allocate the asset to.", 400);

      const employee = await db.employee.findFirst({
        where: { tenantId: session.tenantId, id: employeeId, status: "active" },
      });
      if (!employee) {
        return fail("Employee not found or not active.", 400);
      }

      const notes =
        body.notes != null && String(body.notes).trim() !== ""
          ? String(body.notes).trim().slice(0, 500)
          : null;

      await db.assetAllocation.create({
        data: {
          tenantId: session.tenantId,
          assetId: asset.id,
          employeeId: employee.id,
          notes,
        },
      });
      const updated = await db.asset.update({
        where: { id: asset.id },
        data: { status: "allocated" },
        include: OPEN_ALLOCATION_INCLUDE,
      });

      const employeeUserId = await userIdForEmployee(session.tenantId, employee.id);
      await notify(session.tenantId, {
        userId: employeeUserId,
        title: "Asset allocated to you",
        body: `${asset.name} (${asset.assetTag}) has been allocated to you${notes ? ` — ${notes}` : ""}.`,
        type: "asset",
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.allocated",
        entity: "Asset",
        entityId: asset.id,
        summary: `Allocated ${asset.name} (${asset.assetTag}) to ${fullName(employee)}.`,
      });

      return ok({ asset: toAssetDto(updated) });
    }

    // ---------- return ----------
    if (action === "return") {
      if (asset.status !== "allocated" || !openAllocation) {
        return fail("Asset is not allocated", 409);
      }
      const holderName = fullName(openAllocation.employee);

      let condition: string | null = null;
      if (body.condition != null && String(body.condition).trim() !== "") {
        condition = String(body.condition).trim();
        if (!RETURN_CONDITIONS.includes(condition)) {
          return fail("Condition must be Excellent, Good, Fair or Damaged.", 400);
        }
      }
      const notes =
        body.notes != null && String(body.notes).trim() !== ""
          ? String(body.notes).trim().slice(0, 500)
          : null;

      await db.assetAllocation.update({
        where: { id: openAllocation.id },
        data: {
          returnedAt: new Date(),
          ...(condition ? { condition } : {}),
          ...(notes ? { notes } : {}),
        },
      });
      const updated = await db.asset.update({
        where: { id: asset.id },
        data: { status: "available" },
        include: OPEN_ALLOCATION_INCLUDE,
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.returned",
        entity: "Asset",
        entityId: asset.id,
        summary: `${asset.name} (${asset.assetTag}) returned by ${holderName}${condition ? ` in ${condition} condition` : ""}.`,
      });

      return ok({ asset: toAssetDto(updated) });
    }

    // ---------- retire ----------
    if (action === "retire") {
      if (asset.status === "allocated") {
        return fail("Asset is currently allocated — return it before retiring it.", 409);
      }
      const updated = await db.asset.update({
        where: { id: asset.id },
        data: { status: "retired" },
        include: OPEN_ALLOCATION_INCLUDE,
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.retired",
        entity: "Asset",
        entityId: asset.id,
        summary: `Retired ${asset.name} (${asset.assetTag}).`,
        severity: "warning",
      });

      return ok({ asset: toAssetDto(updated) });
    }

    // ---------- maintenance ----------
    if (action === "maintenance_on") {
      if (asset.status !== "available") {
        return fail("Only available assets can be sent for maintenance.", 409);
      }
      const updated = await db.asset.update({
        where: { id: asset.id },
        data: { status: "maintenance" },
        include: OPEN_ALLOCATION_INCLUDE,
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.maintenance_on",
        entity: "Asset",
        entityId: asset.id,
        summary: `Sent ${asset.name} (${asset.assetTag}) for maintenance.`,
      });

      return ok({ asset: toAssetDto(updated) });
    }

    if (action === "maintenance_off") {
      if (asset.status !== "maintenance") {
        return fail("Asset is not under maintenance.", 409);
      }
      const updated = await db.asset.update({
        where: { id: asset.id },
        data: { status: "available" },
        include: OPEN_ALLOCATION_INCLUDE,
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.maintenance_off",
        entity: "Asset",
        entityId: asset.id,
        summary: `Returned ${asset.name} (${asset.assetTag}) to service after maintenance.`,
      });

      return ok({ asset: toAssetDto(updated) });
    }

    // ---------- update details ----------
    if (action === "update") {
      const data: Prisma.AssetUpdateInput = {};

      if (body.name != null) {
        const name = String(body.name).trim();
        if (!name) return fail("Asset name cannot be empty.", 400);
        if (name.length > 120) return fail("Asset name must be 120 characters or fewer.", 400);
        data.name = name;
      }

      if (body.category != null) {
        const category = String(body.category).trim();
        if (!ASSET_CATEGORIES.includes(category)) {
          return fail("Please select a valid asset category.", 400);
        }
        data.category = category;
      }

      if (body.value != null && String(body.value).trim() !== "") {
        const n = Number(body.value);
        if (!Number.isFinite(n) || n < 0) {
          return fail("Value must be a non-negative amount in INR.", 400);
        }
        data.value = Math.round(n);
      }

      if (body.serialNumber != null) {
        const serial = String(body.serialNumber).trim();
        data.serialNumber = serial === "" ? null : serial.slice(0, 100);
      }

      if (body.notes != null) {
        const notes = String(body.notes).trim();
        data.notes = notes === "" ? null : notes.slice(0, 500);
      }

      const updated = await db.asset.update({
        where: { id: asset.id },
        data,
        include: OPEN_ALLOCATION_INCLUDE,
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "asset.updated",
        entity: "Asset",
        entityId: asset.id,
        summary: `Updated details of ${updated.name} (${updated.assetTag}).`,
      });

      return ok({ asset: toAssetDto(updated) });
    }

    return fail(
      "Unknown action. Use allocate, return, retire, maintenance_on, maintenance_off or update.",
      400
    );
  });
}

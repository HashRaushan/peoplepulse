/**
 * Announcements API.
 *
 * GET  /api/announcements — any signed-in user. Company-wide feed sorted by
 *   pinned first, then newest. Each item carries `hasAcked` for the current
 *   user (from their AnnouncementAck rows).
 *
 * POST /api/announcements (owner | admin | hr) — publish an announcement
 *   (title <= 200 chars, body <= 5000 chars) and broadcast a notification to
 *   the whole tenant.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify } from "@/lib/api-helpers";
import { toAnnouncementDto } from "@/app/api/_lib/mappers";

const CATEGORIES = ["company", "department", "policy", "event", "celebration"];

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const rows = await db.announcement.findMany({
      where: { tenantId: session.tenantId },
      orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
    });

    // Per-announcement acknowledgement state for the current user.
    const acks = await db.announcementAck.findMany({
      where: {
        tenantId: session.tenantId,
        userId: session.id,
        announcementId: { in: rows.map((a) => a.id) },
      },
      select: { announcementId: true },
    });
    const ackedIds = new Set(acks.map((a) => a.announcementId));

    return ok({
      items: rows.map((a) => ({ ...toAnnouncementDto(a), hasAcked: ackedIds.has(a.id) })),
    });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const text = String(body.body ?? "").trim();
    if (!title) return fail("Announcement title is required.", 400);
    if (title.length > 200) {
      return fail("Announcement title must be 200 characters or fewer.", 400);
    }
    if (!text) return fail("Announcement body is required.", 400);
    if (text.length > 5000) {
      return fail("Announcement body must be 5000 characters or fewer.", 400);
    }

    const category = CATEGORIES.includes(String(body.category)) ? String(body.category) : "company";

    const announcement = await db.announcement.create({
      data: {
        tenantId: session.tenantId,
        title,
        body: text,
        category,
        authorName: session.name,
        pinned: body.pinned === true,
      },
    });

    // Broadcast to everyone in the tenant (userId null reaches all users).
    await notify(session.tenantId, {
      title: "New announcement",
      body: `${title} — by ${session.name}`,
      type: "announcement",
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "announcement.created",
      entity: "Announcement",
      entityId: announcement.id,
      summary: `Published announcement "${title}".`,
    });

    return ok({ item: { ...toAnnouncementDto(announcement), hasAcked: false } }, { status: 201 });
  });
}

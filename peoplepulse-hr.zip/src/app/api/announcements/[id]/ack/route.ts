/**
 * Announcement acknowledgement API.
 *
 * POST /api/announcements/{id}/ack — any signed-in user. Idempotent: the first
 * call records an AnnouncementAck row for (announcement, user) and increments
 * acknowledgedCount; repeated calls (including a unique-constraint race) return
 * the current announcement DTO with hasAcked: true WITHOUT incrementing again.
 */
import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { toAnnouncementDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const announcement = await db.announcement.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!announcement) return fail("Announcement not found.", 404);

    // Already acknowledged? Return the current state without incrementing.
    const existing = await db.announcementAck.findFirst({
      where: { announcementId: announcement.id, userId: session.id },
      select: { id: true },
    });
    if (existing) {
      return ok({ item: { ...toAnnouncementDto(announcement), hasAcked: true } });
    }

    try {
      await db.announcementAck.create({
        data: {
          tenantId: session.tenantId,
          announcementId: announcement.id,
          userId: session.id,
        },
      });
    } catch (e) {
      // Lost a race against a concurrent ack for the same user — same outcome.
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
        return ok({ item: { ...toAnnouncementDto(announcement), hasAcked: true } });
      }
      throw e;
    }

    // A NEW ack was recorded — only now does the counter move.
    const updated = await db.announcement.update({
      where: { id: announcement.id },
      data: { acknowledgedCount: { increment: 1 } },
    });

    return ok({ item: { ...toAnnouncementDto(updated), hasAcked: true } });
  });
}

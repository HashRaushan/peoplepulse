/**
 * Team attendance API.
 *
 * GET /api/attendance (owner | admin | hr | manager) — the attendance board
 * for a single day. Query: date (YYYY-MM-DD, defaults to today), department.
 * Excludes exited employees, computes a status summary and returns records
 * sorted by employee name.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok, dateOnly } from "@/lib/api-helpers";
import { addDays, fullName, isValidDateOnly, localDate, toAttendanceDto } from "@/app/api/_lib/mappers";
import type { AttendanceSummary } from "@/lib/types";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);
    const sp = req.nextUrl.searchParams;

    const dateParam = sp.get("date") ?? "";
    const date = isValidDateOnly(dateParam) ? dateParam : dateOnly(new Date());
    const department = (sp.get("department") ?? "").trim();

    const dayStart = localDate(date);
    const dayEnd = addDays(dayStart, 1);

    const employeeFilter: Prisma.EmployeeWhereInput = { status: { not: "exited" } };
    if (department) employeeFilter.department = department;

    const records = await db.attendanceRecord.findMany({
      where: {
        tenantId: session.tenantId,
        date: { gte: dayStart, lt: dayEnd },
        employee: employeeFilter,
      },
      include: { employee: true },
    });
    records.sort((a, b) => fullName(a.employee).localeCompare(fullName(b.employee)));

    const summary: AttendanceSummary = {
      present: 0,
      wfh: 0,
      late: 0,
      absent: 0,
      leave: 0,
      holiday: 0,
      total: records.length,
    };
    const statusKeys = ["present", "wfh", "late", "absent", "leave", "holiday"] as const;
    for (const r of records) {
      if ((statusKeys as readonly string[]).includes(r.status)) {
        summary[r.status as (typeof statusKeys)[number]] += 1;
      }
    }

    return ok({ date, summary, records: records.map(toAttendanceDto) });
  });
}

/**
 * Self-service attendance API (punch clock and regularisation).
 *
 * GET  /api/attendance/me — any signed-in user with a linked employee record.
 *   Query: month (YYYY-MM, defaults to the current month). Returns the month's
 *   records, a status summary and the average worked hours.
 *
 * POST /api/attendance/me — actions:
 *   - check_in: stamps the check-in time for today only (a date in the past
 *     or future is rejected — use regularise for past dates); late after
 *     10:15; Sundays are rejected as weekly off.
 *   - check_out: stamps the check-out time for today only and computes worked
 *     hours (overnight differences count as 0).
 *   - regularize: corrects a past date within the last 7 days to
 *     present/wfh with an optional note. Audited with warning severity.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { addDays, hhmmNow, isValidDateOnly, localDate, toAttendanceDto } from "@/app/api/_lib/mappers";
import { haversineMeters } from "@/lib/geo";
import type { AttendanceSummary, MyAttendanceResponse } from "@/lib/types";
import type { Prisma } from "@prisma/client";

const LATE_AFTER = "10:15";

function hhmmToMinutes(hhmm: string): number {
  const hh = Number(hhmm.slice(0, 2));
  const mm = Number(hhmm.slice(3, 5));
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return 0;
  return hh * 60 + mm;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail("Your account is not linked to an employee record.", 400);
    }

    const sp = req.nextUrl.searchParams;
    const monthParam = sp.get("month") ?? "";
    const match = /^(\d{4})-(\d{2})$/.exec(monthParam);
    const now = new Date();
    const year = match ? Number(match[1]) : now.getFullYear();
    const month = match ? Number(match[2]) : now.getMonth() + 1;
    if (year < 2000 || month < 1 || month > 12) {
      return fail("Month must be in YYYY-MM format.", 400);
    }

    const monthStart = new Date(year, month - 1, 1);
    const monthEnd = new Date(year, month, 1);

    const [employee, records] = await Promise.all([
      db.employee.findFirst({ where: { tenantId: session.tenantId, id: session.employeeId } }),
      db.attendanceRecord.findMany({
        where: {
          tenantId: session.tenantId,
          employeeId: session.employeeId,
          date: { gte: monthStart, lt: monthEnd },
        },
        orderBy: { date: "desc" },
      }),
    ]);
    if (!employee) return fail("Your account is not linked to an employee record.", 400);

    const summary: AttendanceSummary = {
      present: 0,
      wfh: 0,
      late: 0,
      absent: 0,
      leave: 0,
      holiday: 0,
      total: records.length,
    };
    const statusKeys = ["present", "wfh", "late", "absent", "leave", "holiday"] as const;
    for (const r of records) {
      if ((statusKeys as readonly string[]).includes(r.status)) {
        summary[r.status as (typeof statusKeys)[number]] += 1;
      }
    }

    const withHours = records.filter((r) => r.hours != null);
    const avgHours =
      withHours.length > 0
        ? Math.round((withHours.reduce((sum, r) => sum + (r.hours ?? 0), 0) / withHours.length) * 10) / 10
        : 0;

    const response: MyAttendanceResponse = {
      month: `${year}-${String(month).padStart(2, "0")}`,
      summary,
      records: records.map((r) => toAttendanceDto({ ...r, employee })),
      avgHours,
    };
    return ok(response);
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail("Your account is not linked to an employee record.", 400);
    }

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const action = String(body.action ?? "");
    const date = isValidDateOnly(body.date) ? body.date : dateOnly(new Date());
    const tenantId = session.tenantId;
    const employeeId = session.employeeId;

    const [employee, dayStart, today] = await Promise.all([
      db.employee.findFirst({ where: { tenantId, id: employeeId } }),
      Promise.resolve(localDate(date)),
      Promise.resolve(localDate(dateOnly(new Date()))),
    ]);
    if (!employee) return fail("Your account is not linked to an employee record.", 400);

    const findDayRecord = () =>
      db.attendanceRecord.findFirst({
        where: { tenantId, employeeId, date: { gte: dayStart, lt: addDays(dayStart, 1) } },
      });

    if (action === "check_in") {
      if (date !== dateOnly(new Date())) {
        return fail("Check-in and check-out are only allowed for today. Use regularise for past dates.", 400);
      }
      if (dayStart.getDay() === 0) return fail("Today is a weekly off.", 400);
      const existing = await findDayRecord();
      if (existing?.checkIn) return fail("Already checked in today.", 400);

      // ---- Geo-fence validation (server-authoritative) ----
      const tenant = await db.tenant.findUnique({
        where: { id: tenantId },
        select: {
          geoFenceEnabled: true,
          officeLatitude: true,
          officeLongitude: true,
          officeRadiusMeters: true,
          officeLabel: true,
        },
      });

      const lat = body.latitude != null ? Number(body.latitude) : null;
      const lng = body.longitude != null ? Number(body.longitude) : null;
      const acc = body.accuracy != null ? Number(body.accuracy) : null;
      const hasCoords = lat != null && lng != null && Number.isFinite(lat) && Number.isFinite(lng);

      let distanceMeters: number | null = null;
      let geoStatus: string | null = null;

      if (tenant?.geoFenceEnabled) {
        if (!hasCoords) {
          return fail("Location is required for check-in. Please enable location access and try again.", 400);
        }
        if (tenant.officeLatitude == null || tenant.officeLongitude == null) {
          return fail("Office location is not configured. Ask an admin to set it under Settings → Attendance.", 400);
        }
        distanceMeters = haversineMeters(lat, lng, tenant.officeLatitude, tenant.officeLongitude);
        if (distanceMeters == null) {
          return fail("Could not compute distance to office. Please try again.", 400);
        }
        if (distanceMeters > tenant.officeRadiusMeters) {
          const label = tenant.officeLabel ?? "the office";
          return fail(`You are ${distanceMeters} m away from ${label}. Check-in is only allowed within ${tenant.officeRadiusMeters} m of the office.`, 400);
        }
        geoStatus = "inside";
      } else if (hasCoords && tenant?.officeLatitude != null && tenant?.officeLongitude != null) {
        // Fence disabled but office configured — still record + classify for visibility.
        distanceMeters = haversineMeters(lat, lng, tenant.officeLatitude, tenant.officeLongitude);
        geoStatus = distanceMeters != null && distanceMeters <= tenant.officeRadiusMeters ? "inside" : "outside";
      } else if (hasCoords) {
        geoStatus = "unverified";
      }

      const time = hhmmNow();
      const status = time > LATE_AFTER ? "late" : "present";
      const createData: Prisma.AttendanceRecordCreateInput = {
        tenant: { connect: { id: tenantId } },
        employee: { connect: { id: employeeId } },
        date: dayStart,
        checkIn: time,
        status,
        latitude: lat,
        longitude: lng,
        accuracy: acc != null && Number.isFinite(acc) ? acc : null,
        distanceMeters,
        geoStatus,
      };
      const updateData: Prisma.AttendanceRecordUpdateInput = {
        checkIn: time,
        status,
        latitude: lat,
        longitude: lng,
        accuracy: acc != null && Number.isFinite(acc) ? acc : null,
        distanceMeters,
        geoStatus,
      };
      const record = existing
        ? await db.attendanceRecord.update({ where: { id: existing.id }, data: updateData })
        : await db.attendanceRecord.create({ data: createData });

      const geoNote = distanceMeters != null ? ` at ${distanceMeters} m from ${tenant?.officeLabel ?? "office"}` : "";
      await audit(tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "attendance.check_in",
        entity: "AttendanceRecord",
        entityId: record.id,
        summary: `Checked in at ${time} (${status})${geoNote}.`,
      });
      return ok({ record: toAttendanceDto({ ...record, employee }) });
    }

    if (action === "check_out") {
      if (date !== dateOnly(new Date())) {
        return fail("Check-in and check-out are only allowed for today. Use regularise for past dates.", 400);
      }
      const existing = await findDayRecord();
      if (!existing || !existing.checkIn) return fail("You have not checked in yet today.", 400);
      if (existing.checkOut) return fail("Already checked out today.", 400);

      const time = hhmmNow();
      const diffMinutes = hhmmToMinutes(time) - hhmmToMinutes(existing.checkIn);
      const hours = diffMinutes <= 0 ? 0 : Math.round((diffMinutes / 60) * 10) / 10;
      const record = await db.attendanceRecord.update({
        where: { id: existing.id },
        data: { checkOut: time, hours },
      });

      await audit(tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "attendance.check_out",
        entity: "AttendanceRecord",
        entityId: record.id,
        summary: `Checked out at ${time} (${hours}h worked).`,
      });
      return ok({ record: toAttendanceDto({ ...record, employee }) });
    }

    if (action === "regularize") {
      if (dayStart.getTime() >= today.getTime()) {
        return fail("Regularisation is only allowed for past dates.", 400);
      }
      if (addDays(today, -7).getTime() > dayStart.getTime()) {
        return fail("Regularisation is only allowed within the last 7 days.", 400);
      }
      const status = String(body.status ?? "");
      if (!["present", "wfh"].includes(status)) {
        return fail("Regularisation status must be 'present' or 'wfh'.", 400);
      }
      const note = body.note != null && body.note !== "" ? String(body.note).slice(0, 300) : null;

      const existing = await findDayRecord();
      const record = existing
        ? await db.attendanceRecord.update({
            where: { id: existing.id },
            data: { status, note },
          })
        : await db.attendanceRecord.create({
            data: { tenantId, employeeId, date: dayStart, status, note },
          });

      await audit(tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "attendance.regularize",
        entity: "AttendanceRecord",
        entityId: record.id,
        summary: `Attendance regularised for ${date}.`,
        severity: "warning",
      });
      return ok({ record: toAttendanceDto({ ...record, employee }) });
    }

    return fail("Unknown action. Use check_in, check_out or regularize.", 400);
  });
}

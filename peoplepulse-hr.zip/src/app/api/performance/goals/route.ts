/**
 * Goals / OKR API.
 *
 * GET /api/performance/goals?scope=&cycle= (any signed-in user)
 *   - scope "mine": the caller's own goals (requires a linked employee record).
 *   - scope "team": manager sees own + direct reports' goals (Employee.managerId);
 *     owner/admin/hr see every goal in the tenant.
 *   - scope "all": owner/admin/hr only — everyone else silently falls back to
 *     their team scope (manager) or own goals (employee).
 *   - Default scope by role: employee -> mine, manager -> team, owner/admin/hr -> all.
 *   - Optional `cycle` exact-match filter. Response also carries the distinct
 *     cycles available in scope (desc) and a status summary of the listed goals.
 *
 * POST /api/performance/goals (any role with a linked employee record)
 *   - { title, description?, metric?, targetValue, unit?, cycle?, dueDate? }
 *   - Defaults: cycle = current Indian fiscal quarter (FY starts April,
 *     e.g. FY26-Q1 = Apr-Jun 2025), currentValue 0, status "on_track".
 */
import { NextRequest } from "next/server";
import type { Prisma, Employee, Goal } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { fullName, isValidDateOnly, localDate } from "@/app/api/_lib/mappers";
import type { GoalDto, GoalStatus } from "@/lib/types";

const HR_ONLY_ROLES = ["owner", "admin", "hr"];

type GoalWithEmployee = Goal & { employee: Employee };

/** Map a Goal row (with employee) to the GoalDto contract (progress computed). */
function toGoalDto(g: GoalWithEmployee): GoalDto {
  const progress =
    g.targetValue > 0 ? Math.min(100, Math.round((g.currentValue / g.targetValue) * 100)) : 0;
  return {
    id: g.id,
    employeeId: g.employeeId,
    employeeName: fullName(g.employee),
    employeeCode: g.employee.code,
    department: g.employee.department,
    avatarColor: g.employee.avatarColor,
    cycle: g.cycle,
    title: g.title,
    description: g.description,
    metric: g.metric,
    targetValue: g.targetValue,
    currentValue: g.currentValue,
    unit: g.unit,
    progress,
    status: g.status as GoalStatus,
    dueDate: g.dueDate ? dateOnly(g.dueDate) : null,
    createdAt: g.createdAt.toISOString(),
    updatedAt: g.updatedAt.toISOString(),
  };
}

/**
 * Indian fiscal quarter label for a date: the fiscal year starts in April, so
 * Apr-Jun 2025 = FY26-Q1, Jul-Sep 2025 = FY26-Q2, Jan-Mar 2026 = FY26-Q4 and
 * Apr-Jun 2026 = FY27-Q1.
 */
function currentFiscalQuarter(now = new Date()): string {
  const year = now.getFullYear();
  const month = now.getMonth() + 1; // 1-12
  const fy = month >= 4 ? year + 1 : year;
  const quarter = month >= 4 ? Math.ceil((month - 3) / 3) : 4;
  return `FY${String(fy).slice(2)}-Q${quarter}`;
}

const EMPTY_SUMMARY = { total: 0, completed: 0, onTrack: 0, atRisk: 0, behind: 0 };

function summarize(goals: GoalWithEmployee[]) {
  return {
    total: goals.length,
    completed: goals.filter((g) => g.status === "completed").length,
    onTrack: goals.filter((g) => g.status === "on_track").length,
    atRisk: goals.filter((g) => g.status === "at_risk").length,
    behind: goals.filter((g) => g.status === "behind").length,
  };
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const isHrOnly = HR_ONLY_ROLES.includes(session.role);

    // Resolve the requested scope (with role-based fallbacks).
    let scope = (sp.get("scope") ?? "").trim();
    if (!["mine", "team", "all"].includes(scope)) {
      scope = session.role === "employee" ? "mine" : session.role === "manager" ? "team" : "all";
    } else if (scope === "all" && !isHrOnly) {
      scope = session.role === "manager" ? "team" : "mine";
    }

    // Resolve the employee ids visible in the scope (null = whole tenant).
    let employeeIds: string[] | null = null;
    if (scope === "mine") {
      if (!session.employeeId) {
        return ok({ goals: [], cycles: [], summary: EMPTY_SUMMARY });
      }
      employeeIds = [session.employeeId];
    } else if (scope === "team" && !isHrOnly) {
      if (!session.employeeId) {
        return ok({ goals: [], cycles: [], summary: EMPTY_SUMMARY });
      }
      const directs = await db.employee.findMany({
        where: { tenantId: session.tenantId, managerId: session.employeeId },
        select: { id: true },
      });
      employeeIds = [session.employeeId, ...directs.map((d) => d.id)];
    }

    const where: Prisma.GoalWhereInput = { tenantId: session.tenantId };
    if (employeeIds) where.employeeId = { in: employeeIds };

    const rows = await db.goal.findMany({ where, include: { employee: true } });
    rows.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());

    const cycles = [...new Set(rows.map((r) => r.cycle))].sort().reverse();
    const cycleFilter = (sp.get("cycle") ?? "").trim();
    const visible = cycleFilter ? rows.filter((r) => r.cycle === cycleFilter) : rows;

    return ok({ goals: visible.map(toGoalDto), cycles, summary: summarize(visible) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail(
        "Your account is not linked to an employee profile, so a goal cannot be created for you.",
        400
      );
    }

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    if (!title) return fail("Goal title is required.", 400);
    if (title.length > 160) return fail("Goal title must be 160 characters or fewer.", 400);

    const targetValue = Number(body.targetValue);
    if (!Number.isFinite(targetValue) || targetValue <= 0) {
      return fail("Target value must be a number greater than zero.", 400);
    }

    let dueDate: Date | null = null;
    if (body.dueDate != null && body.dueDate !== "") {
      if (!isValidDateOnly(body.dueDate)) {
        return fail("Due date must be a valid date (YYYY-MM-DD).", 400);
      }
      dueDate = localDate(body.dueDate);
    }

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id: session.employeeId },
    });
    if (!employee) return fail("Linked employee profile not found.", 404);

    const description = String(body.description ?? "").trim();
    const metric = String(body.metric ?? "").trim();
    const unit = String(body.unit ?? "").trim();
    const cycle = String(body.cycle ?? "").trim() || currentFiscalQuarter();

    const goal = await db.goal.create({
      data: {
        tenantId: session.tenantId,
        employeeId: employee.id,
        cycle,
        title,
        description,
        metric: metric || null,
        targetValue,
        currentValue: 0,
        unit: unit || null,
        status: "on_track",
        dueDate,
      },
      include: { employee: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "goal.created",
      entity: "Goal",
      entityId: goal.id,
      summary: `Created goal "${title}" for ${fullName(employee)} (${cycle}, target ${targetValue}${unit ? ` ${unit}` : ""}).`,
    });

    return ok({ goal: toGoalDto(goal) }, { status: 201 });
  });
}

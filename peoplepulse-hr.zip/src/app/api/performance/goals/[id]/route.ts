/**
 * Goal lifecycle API (single goal).
 *
 * PATCH /api/performance/goals/{id} — body { action, ... }:
 *   - progress: log a new currentValue (clamped >= 0). Allowed for the goal
 *     owner, their manager (Employee.managerId) or owner/admin/hr. When the
 *     computed progress reaches 100% the status auto-flips to "completed".
 *   - status: set status to one of on_track | at_risk | behind | completed.
 *     Same permission as progress.
 *   - update: edit goal fields (title, description, metric, targetValue,
 *     currentValue, unit, cycle, dueDate). Goal owner or owner/admin/hr only
 *     (NOT the manager).
 *
 * DELETE /api/performance/goals/{id} — goal owner or owner/admin/hr.
 * Audit severity "warning".
 *
 * All lookups are tenant-scoped: goals from another tenant 404.
 */
import { NextRequest } from "next/server";
import type { Prisma, Employee, Goal } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { fullName, isValidDateOnly, localDate } from "@/app/api/_lib/mappers";
import type { GoalDto, GoalStatus } from "@/lib/types";

const HR_ONLY_ROLES = ["owner", "admin", "hr"];
const GOAL_STATUSES: GoalStatus[] = ["on_track", "at_risk", "behind", "completed"];

type GoalWithEmployee = Goal & { employee: Employee };

/** Map a Goal row (with employee) to the GoalDto contract (progress computed). */
function toGoalDto(g: GoalWithEmployee): GoalDto {
  const progress =
    g.targetValue > 0 ? Math.min(100, Math.round((g.currentValue / g.targetValue) * 100)) : 0;
  return {
    id: g.id,
    employeeId: g.employeeId,
    employeeName: fullName(g.employee),
    employeeCode: g.employee.code,
    department: g.employee.department,
    avatarColor: g.employee.avatarColor,
    cycle: g.cycle,
    title: g.title,
    description: g.description,
    metric: g.metric,
    targetValue: g.targetValue,
    currentValue: g.currentValue,
    unit: g.unit,
    progress,
    status: g.status as GoalStatus,
    dueDate: g.dueDate ? dateOnly(g.dueDate) : null,
    createdAt: g.createdAt.toISOString(),
    updatedAt: g.updatedAt.toISOString(),
  };
}

function goalProgress(currentValue: number, targetValue: number): number {
  return targetValue > 0 ? Math.min(100, Math.round((currentValue / targetValue) * 100)) : 0;
}

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;
    const action = String(body.action ?? "");

    const goal = await db.goal.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { employee: true },
    });
    if (!goal) return fail("Goal not found.", 404);

    const isHrOnly = HR_ONLY_ROLES.includes(session.role);
    const isOwner = session.employeeId != null && session.employeeId === goal.employeeId;
    const isGoalManager =
      session.employeeId != null && session.employeeId === goal.employee.managerId;
    // Owner, their manager or HR can log progress / change the status.
    const canContribute = isOwner || isGoalManager || isHrOnly;
    // Only the owner or HR can restructure or delete the goal.
    const canManage = isOwner || isHrOnly;

    if (action === "progress") {
      if (!canContribute) {
        return fail("Only the goal owner, their manager, or HR can update progress.", 403);
      }
      const currentValue = Number(body.currentValue);
      if (!Number.isFinite(currentValue)) {
        return fail("Current value must be a number.", 400);
      }
      const clamped = Math.max(0, currentValue);
      const progress = goalProgress(clamped, goal.targetValue);
      const status: string = progress >= 100 ? "completed" : goal.status;

      const updated = await db.goal.update({
        where: { id: goal.id },
        data: { currentValue: clamped, status },
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "goal.progress_updated",
        entity: "Goal",
        entityId: goal.id,
        summary: `Logged ${clamped}/${goal.targetValue}${goal.unit ? ` ${goal.unit}` : ""} (${progress}%) on "${goal.title}" for ${fullName(goal.employee)}.`,
      });
      return ok({ goal: toGoalDto(updated) });
    }

    if (action === "status") {
      if (!canContribute) {
        return fail("Only the goal owner, their manager, or HR can change the status.", 403);
      }
      const status = String(body.status ?? "");
      if (!GOAL_STATUSES.includes(status as GoalStatus)) {
        return fail("Status must be one of: on_track, at_risk, behind, completed.", 400);
      }

      const updated = await db.goal.update({
        where: { id: goal.id },
        data: { status },
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "goal.status_changed",
        entity: "Goal",
        entityId: goal.id,
        summary: `Changed status of "${goal.title}" (${fullName(goal.employee)}) from ${goal.status} to ${status}.`,
      });
      return ok({ goal: toGoalDto(updated) });
    }

    if (action === "update") {
      if (!canManage) {
        return fail("Only the goal owner or HR can edit this goal.", 403);
      }

      const data: Prisma.GoalUncheckedUpdateInput = {};
      if (body.title != null) {
        const title = String(body.title).trim();
        if (!title) return fail("Goal title cannot be empty.", 400);
        if (title.length > 160) return fail("Goal title must be 160 characters or fewer.", 400);
        data.title = title;
      }
      if (body.description != null) data.description = String(body.description).trim();
      if (body.metric != null) data.metric = String(body.metric).trim() || null;
      if (body.unit != null) data.unit = String(body.unit).trim() || null;
      if (body.cycle != null) {
        const cycle = String(body.cycle).trim();
        if (!cycle) return fail("Cycle cannot be empty.", 400);
        data.cycle = cycle;
      }
      if (body.targetValue != null) {
        const targetValue = Number(body.targetValue);
        if (!Number.isFinite(targetValue) || targetValue <= 0) {
          return fail("Target value must be a number greater than zero.", 400);
        }
        data.targetValue = targetValue;
      }
      if (body.currentValue != null) {
        const currentValue = Number(body.currentValue);
        if (!Number.isFinite(currentValue)) {
          return fail("Current value must be a number.", 400);
        }
        data.currentValue = Math.max(0, currentValue);
      }
      if (body.dueDate != null) {
        if (body.dueDate === "") {
          data.dueDate = null;
        } else if (isValidDateOnly(body.dueDate)) {
          data.dueDate = localDate(body.dueDate);
        } else {
          return fail("Due date must be a valid date (YYYY-MM-DD).", 400);
        }
      }

      const updated = await db.goal.update({
        where: { id: goal.id },
        data,
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "goal.updated",
        entity: "Goal",
        entityId: goal.id,
        summary: `Updated goal "${updated.title}" for ${fullName(goal.employee)} (${Object.keys(data).join(", ") || "no fields"}).`,
      });
      return ok({ goal: toGoalDto(updated) });
    }

    return fail("Unknown action. Use progress, status or update.", 400);
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const goal = await db.goal.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { employee: true },
    });
    if (!goal) return fail("Goal not found.", 404);

    const isHrOnly = HR_ONLY_ROLES.includes(session.role);
    const isOwner = session.employeeId != null && session.employeeId === goal.employeeId;
    if (!isOwner && !isHrOnly) {
      return fail("Only the goal owner or HR can delete this goal.", 403);
    }

    await db.goal.delete({ where: { id: goal.id } });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "goal.deleted",
      entity: "Goal",
      entityId: goal.id,
      summary: `Deleted goal "${goal.title}" for ${fullName(goal.employee)} (${goal.cycle}).`,
      severity: "warning",
    });

    return ok({ ok: true });
  });
}

/**
 * Performance summary API.
 *
 * GET /api/performance/summary (owner | admin | hr | manager) — analytics for
 * the reviews module: rating distribution (buckets 1-5), average final rating,
 * per-department averages for completed reviews and cycle progress counts.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import type { PerformanceSummary } from "@/lib/types";

const CYCLE_STATUSES = ["self_review", "manager_review", "completed", "draft"];

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);

    const reviews = await db.performanceReview.findMany({
      where: { tenantId: session.tenantId },
      include: { employee: true },
    });
    const completed = reviews.filter((r) => r.status === "completed" && r.finalRating != null);

    const distribution = [1, 2, 3, 4, 5].map((bucket) => ({
      rating: String(bucket),
      count: completed.filter((r) => r.finalRating === bucket).length,
    }));

    const avgRating =
      completed.length > 0
        ? Math.round(
            (completed.reduce((sum, r) => sum + (r.finalRating ?? 0), 0) / completed.length) * 10
          ) / 10
        : null;

    const byDept = new Map<string, { total: number; count: number }>();
    for (const r of completed) {
      const entry = byDept.get(r.employee.department) ?? { total: 0, count: 0 };
      entry.total += r.finalRating ?? 0;
      entry.count += 1;
      byDept.set(r.employee.department, entry);
    }
    const byDepartment = [...byDept.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([name, v]) => ({
        name,
        avg: v.count > 0 ? Math.round((v.total / v.count) * 10) / 10 : null,
        count: v.count,
      }));

    const cycleProgress = CYCLE_STATUSES.map((status) => ({
      status,
      count: reviews.filter((r) => r.status === status).length,
    }));

    const summary: PerformanceSummary = { distribution, avgRating, byDepartment, cycleProgress };
    return ok(summary);
  });
}

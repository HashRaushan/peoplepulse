/**
 * Performance reviews API.
 *
 * GET  /api/performance/reviews (owner | admin | hr | manager) — query status,
 *   employeeId. Sorted by stage priority (self review first, then manager
 *   review, completed, draft) and due date. (If an employee-role caller ever
 *   reaches this endpoint they are pinned to their own reviews.)
 *
 * POST /api/performance/reviews (owner | admin | hr) — start a review for an
 *   employee. Defaults: cycle = the current half-year (e.g. "H2 2026"),
 *   periodLabel derived from the cycle, due date 14 days out. One review per
 *   employee per cycle (409 on conflict).
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { addDays, fullName, isValidDateOnly, localDate, toReviewDto } from "@/app/api/_lib/mappers";

const STATUS_ORDER: Record<string, number> = {
  self_review: 0,
  manager_review: 1,
  completed: 2,
  draft: 3,
};

/** Derive a human period label from cycles like "H1 2025" / "H2 2025". */
function derivePeriodLabel(cycle: string): string {
  const match = /^H([12])\s+(\d{4})$/.exec(cycle.trim());
  if (!match) return cycle;
  return match[1] === "1" ? `Jan - Jun ${match[2]}` : `Jul - Dec ${match[2]}`;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);
    const sp = req.nextUrl.searchParams;
    const status = (sp.get("status") ?? "").trim();
    const employeeIdParam = (sp.get("employeeId") ?? "").trim();

    const where: Prisma.PerformanceReviewWhereInput = { tenantId: session.tenantId };
    if (status) where.status = status;
    // Defensive clamp: employee-role callers only ever see their own reviews.
    const employeeId = session.role === "employee" ? session.employeeId : employeeIdParam || null;
    if (employeeId) where.employeeId = employeeId;

    const rows = await db.performanceReview.findMany({
      where,
      include: { employee: true },
    });
    rows.sort(
      (a, b) =>
        (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9) ||
        a.dueDate.getTime() - b.dueDate.getTime()
    );

    return ok({ items: rows.map(toReviewDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const employeeId = String(body.employeeId ?? "").trim();
    if (!employeeId) return fail("Please select an employee.", 400);

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id: employeeId },
    });
    if (!employee) return fail("Employee not found.", 404);

    const now = new Date();
    const cycle = String(body.cycle ?? "").trim() || `H${now.getMonth() + 1 > 6 ? 2 : 1} ${now.getFullYear()}`;
    const periodLabel = String(body.periodLabel ?? "").trim() || derivePeriodLabel(cycle);
    const dueDate = isValidDateOnly(body.dueDate)
      ? localDate(body.dueDate)
      : addDays(localDate(dateOnly(new Date())), 14);

    const existing = await db.performanceReview.findFirst({
      where: { tenantId: session.tenantId, employeeId, cycle },
      select: { id: true },
    });
    if (existing) return fail("A review for this employee and cycle already exists.", 409);

    const review = await db.performanceReview.create({
      data: {
        tenantId: session.tenantId,
        employeeId,
        cycle,
        periodLabel,
        status: "self_review",
        dueDate,
        goals: "[]",
      },
      include: { employee: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "review.created",
      entity: "PerformanceReview",
      entityId: review.id,
      summary: `Created ${cycle} review for ${fullName(employee)}.`,
    });

    return ok({ item: toReviewDto(review) }, { status: 201 });
  });
}

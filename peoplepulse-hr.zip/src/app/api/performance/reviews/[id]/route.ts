/**
 * Performance review lifecycle API.
 *
 * PATCH /api/performance/reviews/{id} — body { action, ... }:
 *   - self_submit: the reviewed employee submits a 1-5 self rating; the review
 *     moves to "manager_review".
 *   - manager_submit: owner/admin/hr, or the employee's DIRECT manager —
 *     records the manager rating and feedback; the review stays in
 *     "manager_review".
 *   - complete: owner/admin/hr finalises the review (requires a manager
 *     rating), sets the final rating and stamps completedAt.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { fullName, toReviewDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

function parseRating(value: unknown): number | null {
  if (value == null || value === "") return null;
  const rating = Math.round(Number(value));
  return Number.isFinite(rating) && rating >= 1 && rating <= 5 ? rating : null;
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const action = String(body.action ?? "");
    const review = await db.performanceReview.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { employee: true },
    });
    if (!review) return fail("Review not found.", 404);

    if (action === "self_submit") {
      if (session.employeeId !== review.employeeId) {
        return fail("Only the reviewed employee can submit the self review.", 403);
      }
      if (review.status !== "self_review") {
        return fail("The self review has already been submitted.", 400);
      }
      const selfRating = parseRating(body.selfRating);
      if (selfRating == null) return fail("Self rating must be between 1 and 5.", 400);

      const updated = await db.performanceReview.update({
        where: { id: review.id },
        data: { selfRating, status: "manager_review" },
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "review.self_submitted",
        entity: "PerformanceReview",
        entityId: review.id,
        summary: `${fullName(review.employee)} submitted a self rating of ${selfRating}/5 (${review.cycle}).`,
      });
      return ok({ item: toReviewDto(updated) });
    }

    if (action === "manager_submit") {
      const isHrRole = ["owner", "admin", "hr"].includes(session.role);
      const isOwnManager =
        session.role === "manager" &&
        !!session.employeeId &&
        review.employee.managerId === session.employeeId;
      if (!isHrRole && !isOwnManager) {
        return fail("You do not have permission to submit the manager review.", 403);
      }
      if (review.status === "completed") {
        return fail("This review is already completed.", 400);
      }
      const managerRating = parseRating(body.managerRating);
      if (managerRating == null) return fail("Manager rating must be between 1 and 5.", 400);

      const data: Prisma.PerformanceReviewUncheckedUpdateInput = {
        managerRating,
        status: "manager_review",
        reviewerName: session.name,
      };
      if (body.summary != null) data.summary = String(body.summary);
      if (body.strengths != null) data.strengths = String(body.strengths);
      if (body.improvements != null) data.improvements = String(body.improvements);

      const updated = await db.performanceReview.update({
        where: { id: review.id },
        data,
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "review.manager_submitted",
        entity: "PerformanceReview",
        entityId: review.id,
        summary: `${session.name} rated ${fullName(review.employee)} ${managerRating}/5 (${review.cycle}).`,
      });
      return ok({ item: toReviewDto(updated) });
    }

    if (action === "complete") {
      if (!["owner", "admin", "hr"].includes(session.role)) {
        return fail("You do not have permission to complete this review.", 403);
      }
      const managerRating = parseRating(body.managerRating) ?? review.managerRating;
      if (managerRating == null) {
        return fail("A manager rating must be submitted before completing the review.", 400);
      }
      const finalRating = parseRating(body.finalRating) ?? managerRating;

      const data: Prisma.PerformanceReviewUncheckedUpdateInput = {
        managerRating,
        finalRating,
        status: "completed",
        completedAt: new Date(),
        reviewerName: review.reviewerName ?? session.name,
      };
      if (body.summary != null) data.summary = String(body.summary);
      if (body.strengths != null) data.strengths = String(body.strengths);
      if (body.improvements != null) data.improvements = String(body.improvements);

      const updated = await db.performanceReview.update({
        where: { id: review.id },
        data,
        include: { employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "review.completed",
        entity: "PerformanceReview",
        entityId: review.id,
        summary: `Completed ${review.cycle} review for ${fullName(review.employee)} with a final rating of ${finalRating}/5.`,
      });
      return ok({ item: toReviewDto(updated) });
    }

    return fail("Unknown action. Use self_submit, manager_submit or complete.", 400);
  });
}

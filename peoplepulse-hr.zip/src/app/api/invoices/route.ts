/** Billing invoices API. GET /api/invoices — owner | admin. */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { toInvoiceDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"]);
    const rows = await db.invoice.findMany({
      where: { tenantId: session.tenantId },
      orderBy: { issuedAt: "desc" },
    });
    return ok({ items: rows.map(toInvoiceDto) });
  });
}

/**
 * Bulk employee import API.
 *
 * POST /api/employees/import (owner | admin | hr) — accepts up to 200 rows of
 * { name, email, department, designation, ctc?, joinDate?, phone?, location? }.
 * Each row is validated independently (name/email present, email format,
 * duplicates within the tenant and within the payload). Valid rows are created
 * with the same defaults and side effects as POST /api/employees (code
 * generation, current-year leave balances, onboarding checklist for joiners).
 * Returns a BulkImportResponse with per-row outcomes.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { hashPassword, generatePassword } from "@/lib/crypto";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { AVATAR_COLORS } from "@/lib/constants";
import {
  addDays,
  isValidDateOnly,
  localDate,
  nextEmployeeCode,
  toNonNegativeInt,
} from "@/app/api/_lib/mappers";
import type { BulkImportResponse, BulkImportRow } from "@/lib/types";

const ONBOARDING_TASKS = [
  { title: "Document submission", category: "documentation", assignee: "New Joiner", offset: 2, order: 1 },
  { title: "ID proofs", category: "documentation", assignee: "New Joiner", offset: 2, order: 2 },
  { title: "Bank details", category: "documentation", assignee: "New Joiner", offset: 3, order: 3 },
  { title: "IT access", category: "it", assignee: "IT Admin", offset: 1, order: 4 },
  { title: "Team introduction", category: "hr", assignee: "People Team", offset: 1, order: 5 },
  { title: "First-month goals", category: "hr", assignee: "New Joiner", offset: 30, order: 6 },
];

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const rows = Array.isArray(body.rows) ? (body.rows as Record<string, unknown>[]) : null;
    if (!rows) return fail("An array of rows is required.", 400);
    if (rows.length === 0) return fail("No rows to import.", 400);
    if (rows.length > 200) return fail("Import is limited to 200 rows at a time.", 400);

    const tenantId = session.tenantId;
    const year = new Date().getFullYear();
    const today = localDate(dateOnly(new Date()));
    const leaveTypes = await db.leaveType.findMany({ where: { tenantId } });
    const baseCount = await db.employee.count({ where: { tenantId } });

    // Optional bulk login creation (role: employee) with one shared initial password.
    const createLogins = body.createLogins === true;
    const suppliedPassword =
      typeof body.defaultPassword === "string" && body.defaultPassword.length > 0
        ? body.defaultPassword
        : null;
    if (createLogins && suppliedPassword !== null && suppliedPassword.length < 8) {
      return fail("The default password must be at least 8 characters.", 400);
    }
    const loginPassword: string | undefined = createLogins
      ? suppliedPassword ?? generatePassword()
      : undefined;
    let loginsCreated = 0;

    let created = 0;
    let failed = 0;
    const results: BulkImportRow[] = [];
    const seenEmails = new Set<string>();

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i] ?? {};
      const rowNo = i + 1;
      const name = String(row.name ?? "").trim();
      const email = String(row.email ?? "").trim().toLowerCase();

      const error = (message: string) => {
        failed += 1;
        results.push({
          row: rowNo,
          name: name || "(missing name)",
          email: email || "(missing email)",
          status: "error",
          message,
        });
      };

      if (!name || !email) {
        error("Name and email are required.");
        continue;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        error("Invalid email address.");
        continue;
      }
      if (seenEmails.has(email)) {
        error("Duplicate email within this import.");
        continue;
      }
      seenEmails.add(email);

      const existing = await db.employee.findFirst({ where: { tenantId, email }, select: { id: true } });
      if (existing) {
        error("An employee with this email already exists.");
        continue;
      }

      try {
        const parts = name.split(/\s+/);
        const firstName = parts[0];
        const lastName = parts.slice(1).join(" ");
        const joinDate = isValidDateOnly(row.joinDate) ? localDate(row.joinDate) : today;
        const code = await nextEmployeeCode(tenantId, session.tenantName);

        const employee = await db.employee.create({
          data: {
            tenantId,
            code,
            firstName,
            lastName,
            email,
            phone: String(row.phone ?? "").trim(),
            department: String(row.department ?? "").trim() || "General",
            designation: String(row.designation ?? "").trim() || "Team Member",
            location: String(row.location ?? "").trim() || "Bengaluru",
            joinDate,
            employmentType: "full_time",
            status: "active",
            ctc: toNonNegativeInt(row.ctc, 0),
            avatarColor: AVATAR_COLORS[(baseCount + created) % AVATAR_COLORS.length],
          },
        });

        await Promise.all(
          leaveTypes.map((lt) =>
            db.leaveBalance.create({
              data: {
                tenantId,
                employeeId: employee.id,
                leaveTypeId: lt.id,
                year,
                entitled: lt.annualQuota,
              },
            })
          )
        );

        if (joinDate.getTime() >= addDays(today, -30).getTime()) {
          await Promise.all(
            ONBOARDING_TASKS.map((t) =>
              db.onboardingTask.create({
                data: {
                  tenantId,
                  employeeId: employee.id,
                  title: t.title,
                  category: t.category,
                  assignee: t.assignee,
                  dueDate: addDays(joinDate, t.offset),
                  status: "pending",
                  order: t.order,
                },
              })
            )
          );
        }

        if (createLogins && loginPassword) {
          const globalUser = await db.user.findFirst({ where: { email }, select: { id: true } });
          if (!globalUser) {
            await db.user.create({
              data: {
                tenantId,
                email,
                name: name,
                password: hashPassword(loginPassword),
                role: "employee",
                employeeId: employee.id,
              },
            });
            loginsCreated += 1;
          }
        }

        created += 1;
        results.push({ row: rowNo, name, email, status: "ok" });
      } catch (e) {
        error(e instanceof Error ? `Could not create employee: ${e.message}` : "Could not create employee.");
      }
    }

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "employee.imported",
      entity: "Employee",
      summary: `Bulk imported ${created} employees, ${failed} failed${loginsCreated ? `, ${loginsCreated} logins created` : ""}.`,
    });

    const response: BulkImportResponse = {
      created,
      failed,
      rows: results,
      ...(createLogins ? { loginsCreated, loginPassword } : {}),
    };
    return ok(response);
  });
}

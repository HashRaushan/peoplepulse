/**
 * Employee login-access management.
 *
 * POST /api/employees/{id}/access — owner | admin | hr.
 *   { action: "grant",  role?: "employee"|"manager"|"hr"|"admin", password? }
 *       Create a login for an employee who does not have one. Returns the
 *       password ONCE (generated server-side when omitted).
 *   { action: "reset",  password? }
 *       Set a new password for an existing login (generated when omitted).
 *   { action: "role",   role: "..." }
 *       Change the login's role.
 *   { action: "revoke" }
 *       Remove the login entirely; the employee record is kept.
 *
 * Guardrails: the owner's own account cannot be modified here; hr/admin
 * roles may only be granted by owners/admins; emails are globally unique
 * across logins.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { hashPassword, generatePassword } from "@/lib/crypto";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { fullName } from "@/app/api/_lib/mappers";

const LOGIN_ROLES = ["employee", "manager", "hr", "admin"];

type Ctx = { params: Promise<{ id: string }> };

function parseRole(value: unknown, fallback = "employee"): string {
  return typeof value === "string" && LOGIN_ROLES.includes(value) ? value : fallback;
}

function accessBody(hasLogin: boolean, email: string | null, role: string | null, password?: string) {
  return { access: { hasLogin, email, role, password: password ?? null } };
}

export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;
    const action = String(body.action ?? "");

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { users: { select: { id: true, email: true, role: true } } },
    });
    if (!employee) return fail("Employee not found.", 404);

    const existing = employee.users[0] ?? null;

    // Password helpers (validate or generate).
    const suppliedPassword =
      typeof body.password === "string" && body.password.length > 0 ? body.password : null;
    if (suppliedPassword !== null && suppliedPassword.length < 8) {
      return fail("Password must be at least 8 characters.", 400);
    }
    const password = suppliedPassword ?? generatePassword();

    if (action === "grant") {
      if (existing) return fail("This employee already has login access.", 409);
      const role = parseRole(body.role);
      if ((role === "hr" || role === "admin") && !["owner", "admin"].includes(session.role)) {
        return fail("Only owners and admins can grant HR or admin access.", 403);
      }
      const globalUser = await db.user.findFirst({
        where: { email: employee.email },
        select: { id: true },
      });
      if (globalUser) {
        return fail("A user account with this email already exists. The email must be unique across all organisations.", 409);
      }
      await db.user.create({
        data: {
          tenantId: session.tenantId,
          email: employee.email,
          name: fullName(employee),
          password: hashPassword(password),
          role,
          employeeId: employee.id,
        },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "user.login_created",
        entity: "User",
        entityId: employee.id,
        summary: `Created ${role} login for ${fullName(employee)} (${employee.email}).`,
      });
      return ok(accessBody(true, employee.email, role, password), { status: 201 });
    }

    if (action === "reset") {
      if (!existing) return fail("This employee has no login access to reset.", 404);
      if (existing.id === session.id) {
        return fail("Use Settings \u2192 Security to change your own password.", 400);
      }
      await db.user.update({
        where: { id: existing.id },
        data: { password: hashPassword(password) },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "user.password_reset",
        entity: "User",
        entityId: existing.id,
        severity: "warning",
        summary: `Reset the password for ${fullName(employee)} (${employee.email}).`,
      });
      return ok(accessBody(true, existing.email, existing.role, password));
    }

    if (action === "role") {
      if (!existing) return fail("This employee has no login access.", 404);
      const role = parseRole(body.role, existing.role);
      if (role === existing.role) return ok(accessBody(true, existing.email, role));
      if ((role === "hr" || role === "admin") && !["owner", "admin"].includes(session.role)) {
        return fail("Only owners and admins can assign HR or admin roles.", 403);
      }
      if (existing.role === "owner") {
        return fail("The organisation owner's role cannot be changed.", 403);
      }
      await db.user.update({ where: { id: existing.id }, data: { role } });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "user.role_changed",
        entity: "User",
        entityId: existing.id,
        summary: `Changed ${fullName(employee)}'s access role from ${existing.role} to ${role}.`,
      });
      return ok(accessBody(true, existing.email, role));
    }

    if (action === "revoke") {
      if (!existing) return fail("This employee has no login access.", 404);
      if (existing.role === "owner") {
        return fail("The organisation owner's login cannot be revoked.", 403);
      }
      if (existing.id === session.id) {
        return fail("You cannot revoke your own access.", 400);
      }
      await db.user.delete({ where: { id: existing.id } });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "user.login_revoked",
        entity: "User",
        entityId: existing.id,
        severity: "warning",
        summary: `Revoked login access for ${fullName(employee)} (${employee.email}). The employee record was kept.`,
      });
      return ok(accessBody(false, null, null));
    }

    return fail("Unknown action. Use grant, reset, role or revoke.", 400);
  });
}

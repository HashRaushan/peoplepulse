/**
 * Single employee API.
 *
 * GET /api/employees/{id} — full employee profile (EmployeeDetail). Any
 *   signed-in user may call this, but users with the "employee" role may only
 *   view their own record (managers and HR roles can view anyone, which
 *   includes their direct and indirect reports). Compensation data (ctc,
 *   lastPayslipNet) is hidden from managers for non-direct-reports and from
 *   employee-role users entirely; loginEmail is also hidden from employees.
 *
 * PATCH /api/employees/{id} — partial profile update (owner | admin | hr).
 *   Setting status to "exited" automatically stamps the exit date.
 *
 * DELETE /api/employees/{id} — soft exit (owner | admin | hr): marks the
 *   employee as exited with reason "Administrative exit".
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit } from "@/lib/api-helpers";
import { STATUS_LABELS } from "@/lib/constants";
import {
  addDays,
  fullName,
  isValidDateOnly,
  localDate,
  toEmployeeListItem,
  toLeaveBalanceDto,
  toOnboardingTaskDto,
} from "@/app/api/_lib/mappers";
import type { EmployeeDetail } from "@/lib/types";

const EMPLOYMENT_TYPES = ["full_time", "part_time", "contract", "intern"];
const EMPLOYMENT_STATUSES = ["active", "probation", "notice", "exited"];

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    // Self-service users may only open their own profile.
    if (session.role === "employee" && session.employeeId !== id) {
      return fail("You do not have permission to view this employee.", 403);
    }

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id },
      include: {
        manager: true,
        users: { select: { id: true, email: true, role: true } },
        leaveBalances: {
          where: { year: new Date().getFullYear() },
          include: { leaveType: true },
        },
        onboardingTasks: { orderBy: { order: "asc" } },
      },
    });
    if (!employee) return fail("Employee not found.", 404);

    const today = localDate(dateOnly(new Date()));
    const [attendance, payslipCount, lastPayslip, latestReview] = await Promise.all([
      db.attendanceRecord.findMany({
        where: {
          tenantId: session.tenantId,
          employeeId: employee.id,
          date: { gte: addDays(today, -29), lt: addDays(today, 1) },
        },
        orderBy: { date: "desc" },
      }),
      db.payslip.count({
        where: {
          tenantId: session.tenantId,
          employeeId: employee.id,
          run: { status: { in: ["approved", "paid"] } },
        },
      }),
      db.payslip.findFirst({
        where: {
          tenantId: session.tenantId,
          employeeId: employee.id,
          run: { status: { in: ["approved", "paid"] } },
        },
        orderBy: [{ run: { year: "desc" } }, { run: { month: "desc" } }],
      }),
      db.performanceReview.findFirst({
        where: { tenantId: session.tenantId, employeeId: employee.id },
        orderBy: { createdAt: "desc" },
      }),
    ]);

    const detail: EmployeeDetail = {
      ...toEmployeeListItem(employee),
      loginEmail: employee.users[0]?.email ?? null,
      loginRole: employee.users[0]?.role ?? null,
      dob: employee.dob ? dateOnly(employee.dob) : null,
      gender: employee.gender,
      emergencyContact: employee.emergencyContact,
      managerId: employee.managerId,
      exitDate: employee.exitDate ? dateOnly(employee.exitDate) : null,
      createdAt: employee.createdAt.toISOString(),
      balances: employee.leaveBalances.map(toLeaveBalanceDto),
      attendance30d: attendance.map((r) => ({
        date: dateOnly(r.date),
        status: r.status,
        checkIn: r.checkIn,
        checkOut: r.checkOut,
      })),
      payslipCount,
      lastPayslipNet: lastPayslip?.net ?? null,
      reviewStatus: latestReview
        ? `${STATUS_LABELS[latestReview.status] ?? latestReview.status} · ${latestReview.cycle}`
        : null,
      onboardingTasks: employee.onboardingTasks.map(toOnboardingTaskDto),
    };

    // Compensation privacy: managers only see pay data for their direct
    // reports; employee-role users never see it (even on their own record).
    if (session.role === "manager" && employee.managerId !== session.employeeId) {
      detail.ctc = 0;
      detail.lastPayslipNet = null;
    } else if (session.role === "employee") {
      detail.ctc = 0;
      detail.lastPayslipNet = null;
      detail.loginEmail = null;
    }
    return ok(detail);
  });
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!employee) return fail("Employee not found.", 404);

    const data: Prisma.EmployeeUncheckedUpdateInput = {};

    if (body.firstName !== undefined) {
      const firstName = String(body.firstName).trim();
      if (!firstName) return fail("First name cannot be empty.", 400);
      data.firstName = firstName;
    }
    if (body.lastName !== undefined) {
      const lastName = String(body.lastName).trim();
      if (!lastName) return fail("Last name cannot be empty.", 400);
      data.lastName = lastName;
    }
    if (body.phone !== undefined) data.phone = String(body.phone).trim();
    if (body.department !== undefined) {
      const department = String(body.department).trim();
      if (!department) return fail("Department cannot be empty.", 400);
      data.department = department;
    }
    if (body.designation !== undefined) {
      const designation = String(body.designation).trim();
      if (!designation) return fail("Designation cannot be empty.", 400);
      data.designation = designation;
    }
    if (body.location !== undefined) {
      const location = String(body.location).trim();
      if (!location) return fail("Location cannot be empty.", 400);
      data.location = location;
    }
    if (body.ctc !== undefined) {
      const ctc = Number(body.ctc);
      if (!Number.isFinite(ctc) || ctc < 0) return fail("CTC must be a non-negative amount.", 400);
      data.ctc = Math.round(ctc);
    }
    if (body.employmentType !== undefined) {
      const employmentType = String(body.employmentType);
      if (!EMPLOYMENT_TYPES.includes(employmentType)) {
        return fail("Employment type must be full_time, part_time, contract or intern.", 400);
      }
      data.employmentType = employmentType;
    }
    if (body.status !== undefined) {
      const status = String(body.status);
      if (!EMPLOYMENT_STATUSES.includes(status)) {
        return fail("Status must be active, probation, notice or exited.", 400);
      }
      data.status = status;
      const today = localDate(dateOnly(new Date()));
      if (status === "exited" && employee.status !== "exited") {
        data.exitDate = today;
      } else if (status !== "exited" && employee.status === "exited") {
        // Re-activating an exited employee clears the stale exit stamp.
        data.exitDate = null;
        data.exitReason = null;
      }
    }
    if (body.managerId !== undefined) {
      if (body.managerId === null || String(body.managerId) === "") {
        data.managerId = null;
      } else {
        const mid = String(body.managerId);
        if (mid === employee.id) return fail("An employee cannot report to themselves.", 400);
        const manager = await db.employee.findFirst({
          where: { tenantId: session.tenantId, id: mid },
          select: { id: true },
        });
        if (!manager) return fail("The selected reporting manager was not found.", 400);
        data.managerId = mid;
      }
    }
    if (body.gender !== undefined) {
      data.gender = body.gender === null || body.gender === "" ? null : String(body.gender);
    }
    if (body.emergencyContact !== undefined) {
      data.emergencyContact =
        body.emergencyContact === null || body.emergencyContact === "" ? null : String(body.emergencyContact);
    }
    if (body.dob !== undefined) {
      if (body.dob === null || body.dob === "") {
        data.dob = null;
      } else if (isValidDateOnly(body.dob)) {
        data.dob = localDate(body.dob);
      } else {
        return fail("Date of birth must be a valid date (YYYY-MM-DD).", 400);
      }
    }

    await db.employee.update({ where: { id: employee.id }, data });
    const updated = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id: employee.id },
      include: { manager: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "employee.updated",
      entity: "Employee",
      entityId: employee.id,
      summary: `Updated profile of ${fullName(updated ?? employee)}.`,
    });

    return ok({ employee: toEmployeeListItem(updated ?? employee) });
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const employee = await db.employee.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!employee) return fail("Employee not found.", 404);

    await db.employee.update({
      where: { id: employee.id },
      data: {
        status: "exited",
        exitDate: localDate(dateOnly(new Date())),
        exitReason: "Administrative exit",
      },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "employee.deleted",
      entity: "Employee",
      entityId: employee.id,
      summary: `Exited ${fullName(employee)} (${employee.code}) — administrative exit.`,
      severity: "warning",
    });

    return ok({ success: true });
  });
}

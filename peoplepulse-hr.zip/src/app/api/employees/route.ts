/**
 * Employee directory API.
 *
 * GET  /api/employees — paginated, filterable employee list for the tenant.
 *   Available to any signed-in user (filters power the directory page).
 *   Sensitive fields (ctc, hasLogin) are stripped for users below manager
 *   level: only owner/admin/hr/manager see compensation data.
 *   Query: search, department, location, status, employmentType, page, pageSize.
 *
 * POST /api/employees — create an employee (owner | admin | hr). Generates a
 *   unique employee code, allocates current-year leave balances for every
 *   tenant leave type, seeds the default onboarding checklist for probationers
 *   and new joiners, fires the `employee.joined` workflow and writes an audit
 *   entry. Responds with { employee: EmployeeListItem }.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { hashPassword, generatePassword } from "@/lib/crypto";
import { handle, fail, ok, dateOnly, audit, notify, triggerWorkflow } from "@/lib/api-helpers";
import { AVATAR_COLORS } from "@/lib/constants";
import {
  addDays,
  fullName,
  intParam,
  isValidDateOnly,
  localDate,
  nextEmployeeCode,
  toEmployeeListItem,
  toNonNegativeInt,
  userIdForEmployee,
} from "@/app/api/_lib/mappers";
import type { EmployeeListResponse } from "@/lib/types";

const EMPLOYMENT_TYPES = ["full_time", "part_time", "contract", "intern"];
const EMPLOYMENT_STATUSES = ["active", "probation", "notice", "exited"];
const LOGIN_ROLES = ["employee", "manager", "hr", "admin"] as const;

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const search = (sp.get("search") ?? "").trim();
    const department = (sp.get("department") ?? "").trim();
    const location = (sp.get("location") ?? "").trim();
    const status = (sp.get("status") ?? "").trim();
    const employmentType = (sp.get("employmentType") ?? "").trim();
    const page = Math.max(1, intParam(sp.get("page"), 1));
    const pageSize = Math.min(100, Math.max(1, intParam(sp.get("pageSize"), 12)));

    const where: Prisma.EmployeeWhereInput = { tenantId: session.tenantId };
    if (search) {
      // SQLite `contains` is already case-insensitive for ASCII text.
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { email: { contains: search } },
        { code: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (location) where.location = location;
    if (status) where.status = status;
    if (employmentType) where.employmentType = employmentType;

    const [rows, total, deptRows, locRows] = await Promise.all([
      db.employee.findMany({
        where,
        include: { manager: true, users: { select: { id: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.employee.count({ where }),
      db.employee.findMany({
        where: { tenantId: session.tenantId },
        distinct: ["department"],
        select: { department: true },
      }),
      db.employee.findMany({
        where: { tenantId: session.tenantId },
        distinct: ["location"],
        select: { location: true },
      }),
    ]);

    const canSeeCtc = ["owner", "admin", "hr", "manager"].includes(session.role);

    const body: EmployeeListResponse = {
      items: rows.map((r) => {
        const item = toEmployeeListItem(r);
        return canSeeCtc ? item : { ...item, ctc: 0, hasLogin: false };
      }),
      total,
      page,
      pageSize,
      departments: deptRows.map((d) => d.department).filter(Boolean).sort(),
      locations: locRows.map((l) => l.location).filter(Boolean).sort(),
    };
    return ok(body);
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const firstName = String(body.firstName ?? "").trim();
    const lastName = String(body.lastName ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const department = String(body.department ?? "").trim();
    const designation = String(body.designation ?? "").trim();
    const joinDateStr = String(body.joinDate ?? "").trim();

    if (!firstName || !lastName) return fail("First name and last name are required.", 400);
    if (firstName.length > 60 || lastName.length > 60) {
      return fail("Names must be 60 characters or fewer.", 400);
    }
    const phone = String(body.phone ?? "").trim();
    if (phone.length > 20) return fail("Phone must be 20 characters or fewer.", 400);
    if (!email) return fail("Email is required.", 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Please enter a valid email address.", 400);
    if (!department) return fail("Department is required.", 400);
    if (!designation) return fail("Designation is required.", 400);
    if (!isValidDateOnly(joinDateStr)) return fail("Join date must be a valid date (YYYY-MM-DD).", 400);

    // Login grant — parsed and authorised BEFORE any DB writes so a forbidden
    // request can never leave a half-provisioned employee behind.
    const createLogin = body.createLogin === true;
    const loginRole =
      typeof body.loginRole === "string" && (LOGIN_ROLES as readonly string[]).includes(body.loginRole)
        ? body.loginRole
        : "employee";
    if (createLogin && (loginRole === "hr" || loginRole === "admin") && !["owner", "admin"].includes(session.role)) {
      return fail("Only owners and admins can grant HR or admin access.", 403);
    }

    const employmentType = EMPLOYMENT_TYPES.includes(String(body.employmentType))
      ? String(body.employmentType)
      : "full_time";
    const employmentStatus = EMPLOYMENT_STATUSES.includes(String(body.employmentStatus))
      ? String(body.employmentStatus)
      : "active";

    const duplicate = await db.employee.findFirst({
      where: { tenantId: session.tenantId, email },
      select: { id: true },
    });
    if (duplicate) return fail("An employee with this email already exists.", 409);

    let managerId: string | null = null;
    if (body.managerId != null && String(body.managerId) !== "") {
      const mid = String(body.managerId);
      const manager = await db.employee.findFirst({
        where: { tenantId: session.tenantId, id: mid },
        select: { id: true },
      });
      if (!manager) return fail("The selected reporting manager was not found.", 400);
      managerId = mid;
    }

    const ctc = toNonNegativeInt(body.ctc, 0);
    const joinDate = localDate(joinDateStr);
    const code = await nextEmployeeCode(session.tenantId, session.tenantName);
    const tenantCount = await db.employee.count({ where: { tenantId: session.tenantId } });
    const avatarColor = AVATAR_COLORS[tenantCount % AVATAR_COLORS.length];

    const employee = await db.employee.create({
      data: {
        tenantId: session.tenantId,
        code,
        firstName,
        lastName,
        email,
        phone,
        department,
        designation,
        location: String(body.location ?? "").trim() || "Bengaluru",
        managerId,
        joinDate,
        employmentType,
        status: employmentStatus,
        ctc,
        dob: isValidDateOnly(body.dob) ? localDate(body.dob) : null,
        gender: body.gender != null && body.gender !== "" ? String(body.gender) : null,
        emergencyContact:
          body.emergencyContact != null && body.emergencyContact !== "" ? String(body.emergencyContact) : null,
        avatarColor,
      },
      include: { manager: true, users: { select: { id: true } } },
    });

    // Allocate current-year leave balances for every leave type in the tenant.
    const year = new Date().getFullYear();
    const leaveTypes = await db.leaveType.findMany({ where: { tenantId: session.tenantId } });
    await Promise.all(
      leaveTypes.map((lt) =>
        db.leaveBalance.create({
          data: {
            tenantId: session.tenantId,
            employeeId: employee.id,
            leaveTypeId: lt.id,
            year,
            entitled: lt.annualQuota,
          },
        })
      )
    );

    // Default onboarding checklist for probationers and joiners from the last 30 days onward.
    const today = localDate(dateOnly(new Date()));
    const isRecentJoiner = joinDate.getTime() >= addDays(today, -30).getTime();
    const tasks = [
      { title: "Document submission", category: "documentation", assignee: "New Joiner", offset: 2, order: 1 },
      { title: "ID proofs", category: "documentation", assignee: "New Joiner", offset: 2, order: 2 },
      { title: "Bank details", category: "documentation", assignee: "New Joiner", offset: 3, order: 3 },
      { title: "IT access", category: "it", assignee: "IT Admin", offset: 1, order: 4 },
      { title: "Team introduction", category: "hr", assignee: "People Team", offset: 1, order: 5 },
      { title: "First-month goals", category: "hr", assignee: "New Joiner", offset: 30, order: 6 },
    ];
    if (employmentStatus === "probation" || isRecentJoiner) {
      await Promise.all(
        tasks.map((t) =>
          db.onboardingTask.create({
            data: {
              tenantId: session.tenantId,
              employeeId: employee.id,
              title: t.title,
              category: t.category,
              assignee: t.assignee,
              dueDate: addDays(joinDate, t.offset),
              status: "pending",
              order: t.order,
            },
          })
        )
      );
    }

    await triggerWorkflow(session.tenantId, "employee.joined", {
      trigger: "Employee added",
      summary: `Onboarding automation ran for ${fullName(employee)}.`,
      steps: [
        { name: "Employee record", detail: `${code} created in ${department}.`, ok: true },
        {
          name: "Leave balances",
          detail: `${leaveTypes.length} leave type(s) allocated for ${year}.`,
          ok: true,
        },
        {
          name: "Onboarding checklist",
          detail:
            employmentStatus === "probation" || isRecentJoiner
              ? `${tasks.length} default tasks created.`
              : "Skipped (not a new joiner).",
          ok: true,
        },
      ],
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "employee.created",
      entity: "Employee",
      entityId: employee.id,
      summary: `Added ${fullName(employee)} (${code}).`,
    });

    // Optional: create the employee's login account so they can sign in.
    // (Role authorisation already happened before the DB writes above.)
    let login: { email: string; password: string; role: string } | undefined;
    if (createLogin) {
      const globalUser = await db.user.findFirst({ where: { email }, select: { id: true } });
      if (globalUser) {
        return fail(
          "Employee saved, but a user account with this email already exists. Grant access from the employee profile instead.",
          409
        );
      }
      const password =
        typeof body.loginPassword === "string" && body.loginPassword.length >= 8
          ? body.loginPassword
          : generatePassword();
      await db.user.create({
        data: {
          tenantId: session.tenantId,
          email,
          name: fullName(employee),
          password: hashPassword(password),
          role: loginRole,
          employeeId: employee.id,
        },
      });
      login = { email, password, role: loginRole };
      employee.users = [{ id: "created" }];
      await notify(session.tenantId, {
        userId: await userIdForEmployee(session.tenantId, employee.id),
        title: "Welcome to PeoplePulse HR",
        body: "Your login has been created. Sign in and start exploring your HR workspace.",
        type: "success",
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "user.login_created",
        entity: "User",
        entityId: employee.id,
        summary: `Created ${loginRole} login for ${fullName(employee)} (${email}).`,
      });
    }

    return ok({ employee: toEmployeeListItem(employee), ...(login ? { login } : {}) }, { status: 201 });
  });
}

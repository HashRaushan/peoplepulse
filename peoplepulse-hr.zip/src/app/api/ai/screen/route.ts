import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, dateOnly } from "@/lib/api-helpers";
import { openrouterChat } from "@/lib/openrouter";
import type { AiScreenResultDto } from "@/lib/types";

/**
 * POST /api/ai/screen — AI candidate screening (owner | admin | hr | manager).
 *
 * Loads the candidate plus its job opening (tenant-scoped), asks the AI to
 * assess fit, validates the JSON response, appends a screening note to the
 * candidate record (preserving existing notes) and audits the action.
 * Any AI/parse failure returns 502 with a friendly message.
 */

const VERDICTS = ["strong", "moderate", "weak"] as const;

/** Robustly parse and validate the model's JSON response. Returns null on failure. */
function parseScreenResult(raw: string): AiScreenResultDto | null {
  let text = raw.trim();
  // Strip markdown code fences if present.
  text = text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "").trim();

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    // Best effort: extract the outermost {...} block.
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start === -1 || end <= start) return null;
    try {
      parsed = JSON.parse(text.slice(start, end + 1));
    } catch {
      return null;
    }
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  const obj = parsed as Record<string, unknown>;

  const verdict = String(obj.verdict ?? "").toLowerCase();
  if (!VERDICTS.includes(verdict as (typeof VERDICTS)[number])) return null;

  const scoreNum = Math.round(Number(obj.score));
  if (!Number.isFinite(scoreNum)) return null;
  const score = Math.min(100, Math.max(0, scoreNum));

  const summary = typeof obj.summary === "string" ? obj.summary.trim() : "";
  if (!summary) return null;

  const toList = (v: unknown): string[] =>
    Array.isArray(v)
      ? v
          .filter((x): x is string => typeof x === "string")
          .map((s) => s.trim())
          .filter(Boolean)
          .slice(0, 4)
      : [];

  return {
    verdict: verdict as AiScreenResultDto["verdict"],
    score,
    summary,
    strengths: toList(obj.strengths),
    concerns: toList(obj.concerns),
  };
}

function parseSkills(json: string): string[] {
  try {
    const arr = JSON.parse(json);
    if (!Array.isArray(arr)) return [];
    return arr.filter((s): s is string => typeof s === "string").slice(0, 12);
  } catch {
    return [];
  }
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);
    const body = await req.json().catch(() => ({}));
    const candidateId = String(body.candidateId ?? "").trim();
    if (!candidateId) return fail("candidateId is required.", 400);

    const candidate = await db.candidate.findFirst({
      where: { tenantId: session.tenantId, id: candidateId },
      include: { opening: true },
    });
    if (!candidate || !candidate.opening) return fail("Candidate not found.", 404);

    const opening = candidate.opening;
    const skills = parseSkills(opening.skills);

    const systemPrompt =
      "You are an expert technical recruiter. Respond with ONLY valid JSON, no markdown fences.";
    const userPrompt = `Screen a candidate against a job opening and assess their fit.

OPENING:
- Title: ${opening.title}
- Department: ${opening.department}
- Location: ${opening.location}
- Required skills: ${skills.join(", ") || "not specified"}
- Description: ${opening.description || "not provided"}
- Minimum experience: ${opening.minExpYears} years
- Max salary budget: ${opening.maxSalary != null ? `₹${opening.maxSalary} annually` : "not specified"}

CANDIDATE:
- Name: ${candidate.name}
- Resume summary: ${candidate.resumeSummary ?? "not provided"}
- Notes so far: ${candidate.notes ?? "none"}
- Expected salary: ${candidate.expectedSalary != null ? `₹${candidate.expectedSalary} annually` : "not specified"}
- Notice period: ${candidate.noticePeriod ?? "not specified"}
- Source: ${candidate.source}
- Current team rating: ${candidate.rating != null ? `${candidate.rating}/5` : "not rated"}

Respond with ONLY a JSON object of exactly this shape:
{ "verdict": "strong" | "moderate" | "weak", "score": <0-100 integer>, "summary": "<2 sentences>", "strengths": ["<3 short strings>"], "concerns": ["<3 short strings>"] }`;

    let result: AiScreenResultDto | null = null;
    try {
      const raw = await openrouterChat({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        maxTokens: 800,
        temperature: 0.2,
      });
      result = parseScreenResult(raw);
    } catch (e) {
      console.error(
        "[ai/screen] OpenRouter failed:",
        e instanceof Error ? e.message : e
      );
    }

    if (!result) {
      return fail("AI screening is unavailable right now. Please try again.", 502);
    }

    // Append the screening summary to the candidate's notes (preserve existing).
    const note = `--- AI screening (${dateOnly(new Date())}) ---\n${result.summary} [Fit score: ${result.score}/100]`;
    await db.candidate.update({
      where: { id: candidate.id },
      data: { notes: candidate.notes ? `${candidate.notes}\n\n${note}` : note },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "ai.screen",
      entity: "Candidate",
      entityId: candidate.id,
      summary: `AI screening for ${candidate.name} (${opening.title}): ${result.verdict} fit, score ${result.score}/100.`,
    });

    return ok(result);
  });
}

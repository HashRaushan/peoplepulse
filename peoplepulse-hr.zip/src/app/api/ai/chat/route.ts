import { NextRequest } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, dateOnly } from "@/lib/api-helpers";
import { openrouterChat, openrouterConfigured } from "@/lib/openrouter";
import type { SessionUser } from "@/lib/types";

/**
 * AI HR copilot (OpenRouter-powered, with graceful fallback).
 *
 * Primary path  : OpenRouter (OPENROUTER_MODEL + OPENROUTER_FALLBACK_MODELS chain,
 *                 e.g. DeepSeek v3 → Llama 3.3 70B) using a rich, tenant-scoped
 *                 data snapshot so answers stay grounded in live org data.
 * Fallback path : the original z-ai-web-dev-sdk completion with the legacy
 *                 permission-aware context — used when the key is missing or
 *                 every OpenRouter model fails, so the chat endpoint never
 *                 hard-fails while the old path exists.
 *
 * Compatibility (unchanged): POST { message } → { reply }; both the user and
 * assistant turns are persisted to AiChatMessage (read by /api/ai/history);
 * every query is audited.
 */

interface HistoryMessage {
  role: "user" | "assistant";
  content: string;
}

// ---------- Rich context snapshot (OpenRouter path) ----------

/**
 * Build a grounded DATA block for the system prompt. All queries are
 * tenant-scoped; employees only ever see their own data plus org aggregates.
 */
async function buildRichContext(session: SessionUser): Promise<string> {
  const now = new Date();
  const year = now.getFullYear();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const isHr = ["owner", "admin", "hr"].includes(session.role);

  const [employeeRows, pendingLeaves, holidays, policies, courses, employee] = await Promise.all([
    db.employee.findMany({
      where: { tenantId: session.tenantId, status: { not: "exited" } },
      select: { department: true },
    }),
    db.leaveRequest.count({ where: { tenantId: session.tenantId, status: "pending" } }),
    db.holiday.findMany({
      where: { tenantId: session.tenantId, date: { gte: now } },
      orderBy: { date: "asc" },
      take: 3,
    }),
    db.policyDocument.findMany({ where: { tenantId: session.tenantId } }),
    db.trainingCourse.findMany({
      where: { tenantId: session.tenantId, published: true },
      select: { title: true },
      take: 5,
      orderBy: { createdAt: "asc" },
    }),
    session.employeeId
      ? db.employee.findUnique({ where: { id: session.employeeId } })
      : Promise.resolve(null),
  ]);

  const deptCounts = new Map<string, number>();
  for (const e of employeeRows) deptCounts.set(e.department, (deptCounts.get(e.department) ?? 0) + 1);

  const parts: string[] = [
    `Today: ${dateOnly(now)}. Currency: INR.`,
    `Organisation: ${session.tenantName}.`,
    `Total active employees (excluding exited): ${employeeRows.length}. Department counts: ${
      [...deptCounts.entries()].map(([d, c]) => `${d} ${c}`).join(", ") || "none"
    }.`,
    `Asking user: ${session.name} (role: ${session.role}${
      employee ? `, designation: ${employee.designation}, department: ${employee.department}` : ""
    }).`,
  ];

  if (session.employeeId) {
    const [balances, myExpenseCount] = await Promise.all([
      db.leaveBalance.findMany({
        where: { employeeId: session.employeeId, year },
        include: { leaveType: true },
      }),
      db.expenseClaim.count({
        where: { tenantId: session.tenantId, employeeId: session.employeeId },
      }),
    ]);
    parts.push(
      `Their leave balances (available of entitled): ${
        balances.map((b) => `${b.leaveType.name} ${b.entitled - b.used - b.pending} of ${b.entitled}`).join(", ") || "none"
      }.`,
      `Their submitted expense claims (all time): ${myExpenseCount}.`
    );
  }

  parts.push(`Pending leave requests in the organisation: ${pendingLeaves}.`);

  parts.push(
    `Next 3 upcoming holidays: ${
      holidays.map((h) => `${h.name} on ${dateOnly(h.date)}`).join(", ") || "none"
    }.`
  );

  const policyTitles = policies.slice(0, 5).map((p) => p.title);
  const shortestPolicies = [...policies]
    .sort((a, b) => a.content.length - b.content.length)
    .slice(0, 3);
  parts.push(`Policy titles (up to 5): ${policyTitles.join(", ") || "none"}.`);
  if (shortestPolicies.length) {
    parts.push(
      `Full policy content:\n${shortestPolicies.map((p) => `### ${p.title}\n${p.content}`).join("\n\n")}`
    );
  }

  parts.push(
    `Published training course titles (up to 5): ${
      courses.map((c) => c.title).join(", ") || "none"
    }.`
  );

  // Org-wide expense aggregate only for hr/admin/owner.
  if (isHr) {
    const orgExpenses = await db.expenseClaim.aggregate({
      where: {
        tenantId: session.tenantId,
        status: { in: ["approved", "paid"] },
        expenseDate: { gte: monthStart },
      },
      _sum: { amount: true },
    });
    parts.push(`Organisation expense total approved this month: ₹${orgExpenses._sum.amount ?? 0}.`);
  }

  return parts.join("\n");
}

// ---------- Legacy context + provider (fallback path, preserved) ----------

/** Permission-aware context snapshot — the original buildContext, unchanged. */
async function buildLegacyContext(session: SessionUser): Promise<string> {
  const now = new Date();
  const today = dateOnly(now);
  const year = now.getFullYear();
  const isHr = ["owner", "admin", "hr"].includes(session.role);
  const isManager = session.role === "manager" || isHr;

  const parts: string[] = [
    `Organisation: ${session.tenantName} (plan: ${session.plan}). Today: ${today}. Currency: INR.`,
    `Current user: ${session.name}, role: ${session.role}.`,
  ];

  if (isManager) {
    const [employees, pendingLeaves, openTickets, currentRun, openings, reviews, policies, holidays] = await Promise.all([
      db.employee.findMany({ where: { tenantId: session.tenantId, status: { not: "exited" } } }),
      db.leaveRequest.findMany({ where: { tenantId: session.tenantId, status: "pending" }, include: { employee: true, leaveType: true } }),
      db.hrTicket.findMany({ where: { tenantId: session.tenantId, status: { in: ["open", "in_progress"] } } }),
      db.payrollRun.findFirst({ where: { tenantId: session.tenantId }, orderBy: [{ year: "desc" }, { month: "desc" }] }),
      db.jobOpening.findMany({ where: { tenantId: session.tenantId, status: "open" } }),
      db.performanceReview.findMany({ where: { tenantId: session.tenantId }, include: { employee: true } }),
      db.policyDocument.findMany({ where: { tenantId: session.tenantId } }),
      db.holiday.findMany({ where: { tenantId: session.tenantId, date: { gte: now } }, orderBy: { date: "asc" }, take: 5 }),
    ]);

    const deptCounts = new Map<string, number>();
    for (const e of employees) deptCounts.set(e.department, (deptCounts.get(e.department) ?? 0) + 1);

    parts.push(
      `Headcount: ${employees.length} active. By department: ${[...deptCounts.entries()].map(([d, c]) => `${d} ${c}`).join(", ")}.`,
      `Pending leave approvals: ${pendingLeaves.length}${pendingLeaves.length ? " — " + pendingLeaves.slice(0, 6).map((l) => `${l.employee.firstName} ${l.employee.lastName} (${l.leaveType.code}, ${l.days}d from ${today.slice(0, 7)}-...)`).join("; ") : ""}.`,
      `Open HR tickets: ${openTickets.length}.`,
      `Latest payroll run: ${currentRun ? `${currentRun.month}/${currentRun.year}, status ${currentRun.status}, ${currentRun.employeeCount} employees, gross ₹${currentRun.grossTotal}` : "none"}.`,
      `Open job openings: ${openings.map((o) => o.title).join(", ") || "none"}.`,
      `Performance cycle statuses: ${["self_review", "manager_review", "completed"].map((s) => `${s} ${reviews.filter((r) => r.status === s).length}`).join(", ")}.`,
      `Upcoming holidays: ${holidays.map((h) => `${h.name} (${today.slice(0, 4)}-${String(h.date.getMonth() + 1).padStart(2, "0")}-${String(h.date.getDate()).padStart(2, "0")})`).join(", ") || "none"}.`,
      `Policies available: ${policies.map((p) => p.title).join(", ") || "none"}.`,
      `Policy summaries: ${policies.slice(0, 3).map((p) => `[${p.title}] ${p.content.replace(/[#*\n]/g, " ").slice(0, 500)}`).join(" || ")}`,
    );
  } else if (session.employeeId) {
    const [employee, balances, requests, payslips, policies, holidays] = await Promise.all([
      db.employee.findUnique({ where: { id: session.employeeId } }),
      db.leaveBalance.findMany({ where: { employeeId: session.employeeId, year }, include: { leaveType: true } }),
      db.leaveRequest.findMany({ where: { employeeId: session.employeeId }, include: { leaveType: true }, orderBy: { createdAt: "desc" }, take: 5 }),
      db.payslip.findMany({ where: { employeeId: session.employeeId }, include: { run: true }, orderBy: [{ run: { year: "desc" } }, { run: { month: "desc" } }], take: 3 }),
      db.policyDocument.findMany({ where: { tenantId: session.tenantId } }),
      db.holiday.findMany({ where: { tenantId: session.tenantId, date: { gte: now } }, orderBy: { date: "asc" }, take: 5 }),
    ]);

    if (employee) {
      parts.push(
        `Employee: ${employee.firstName} ${employee.lastName}, ${employee.designation}, ${employee.department}. Joined ${employee.joinDate.toISOString().slice(0, 10)}. Status: ${employee.status}.`,
        `Leave balances: ${balances.map((b) => `${b.leaveType.name} ${b.entitled - b.used - b.pending} of ${b.entitled} available`).join(", ")}.`,
        `Recent leave requests: ${requests.map((r) => `${r.leaveType.name} ${r.startDate.toISOString().slice(0, 10)} (${r.status})`).join("; ") || "none"}.`,
        `Recent payslips: ${payslips.map((p) => `${p.run.month}/${p.run.year} net ₹${p.net} (${p.run.status})`).join("; ") || "none"}. Payslips are downloadable from the Payroll section.`,
        `Upcoming holidays: ${holidays.map((h) => h.name).join(", ") || "none"}.`,
        `Policies available: ${policies.map((p) => p.title).join(", ") || "none"}.`,
        `Policy summaries: ${policies.slice(0, 3).map((p) => `[${p.title}] ${p.content.replace(/[#*\n]/g, " ").slice(0, 500)}`).join(" || ")}`,
      );
    }
  }

  return parts.filter(Boolean).join("\n");
}

/** Original z-ai-web-dev-sdk completion — kept verbatim as the fallback provider. */
async function legacyCompletion(
  systemPrompt: string,
  recent: HistoryMessage[],
  message: string
): Promise<string> {
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: systemPrompt },
      ...recent,
      { role: "user", content: message },
    ],
    thinking: { type: "disabled" },
  });
  const reply = completion.choices[0]?.message?.content?.trim() ?? "";
  if (!reply) throw new Error("Empty response");
  return reply;
}

const LEGACY_SYSTEM_PREAMBLE = (isHr: boolean) =>
  `You are Pulse, the AI HR assistant inside PeoplePulse HR — an HR management platform. You help ${
    isHr ? "HR administrators and managers" : "employees"
  } with their HR questions.

RULES:
- Answer ONLY from the live context provided. If information is not in the context, say so honestly and suggest where to find it in the app.
- Never invent numbers, names, policies or statutory rates.
- Be concise and warm. Use short paragraphs or bullets. Use ₹ for money (Indian format).
- For consequential actions (approvals, payroll, exits), remind the user to perform them in the app — you cannot take actions.
- For employees: only discuss their own data. Never speculate about colleagues or salaries.
- For statutory/tax topics: note that figures are configurable in the payroll settings and must be verified against current rules.
- If asked something outside HR topics, politely redirect to HR matters.

LIVE ORGANISATION CONTEXT (authorised for this user):`;

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const body = await req.json().catch(() => ({}));
    const message = String(body.message ?? "").trim();
    if (!message) return fail("Message is required.", 400);
    if (message.length > 2000) return fail("Message is too long (max 2000 characters).", 400);

    const isHr = ["owner", "admin", "hr"].includes(session.role);

    // Conversation history (last 8 messages for continuity)
    const history = await db.aiChatMessage.findMany({
      where: { tenantId: session.tenantId, userId: session.id },
      orderBy: { createdAt: "asc" },
      take: 20,
    });
    const recent: HistoryMessage[] = history.slice(-8).map((m) => ({
      role: m.role === "user" ? ("user" as const) : ("assistant" as const),
      content: m.content,
    }));

    let reply = "";

    // ---- Primary path: OpenRouter (DeepSeek v3 → fallback model chain) ----
    if (openrouterConfigured()) {
      try {
        const context = await buildRichContext(session);
        const systemPrompt = `You are Pulse, the HR copilot for ${session.tenantName}. Use ONLY the DATA below to answer. Never invent numbers — if the data doesn't cover it, say you don't have that information. Be concise and warm (under 180 words unless asked to draft something). Use ₹ for money (Indian format). You cannot take actions — approvals and changes happen in the app.

DATA:
${context}`;

        const content = await openrouterChat({
          messages: [
            { role: "system", content: systemPrompt },
            ...recent,
            { role: "user", content: message },
          ],
        });
        reply = content.trim();
      } catch (e) {
        console.error(
          "[ai] OpenRouter failed, falling back to legacy provider:",
          e instanceof Error ? e.message : e
        );
      }
    }

    // ---- Fallback path: original z-ai implementation (never hard-fail) ----
    if (!reply) {
      try {
        const context = await buildLegacyContext(session);
        const systemPrompt = `${LEGACY_SYSTEM_PREAMBLE(isHr)}
${context}`;
        reply = await legacyCompletion(systemPrompt, recent, message);
      } catch (e) {
        console.error("[ai] completion failed", e);
        return fail("The AI assistant is temporarily unavailable. Please try again in a moment.", 503);
      }
    }

    await db.aiChatMessage.createMany({
      data: [
        { tenantId: session.tenantId, userId: session.id, role: "user", content: message },
        { tenantId: session.tenantId, userId: session.id, role: "assistant", content: reply },
      ],
    });

    await audit(session.tenantId, {
      actorName: session.name, actorRole: session.role, action: "ai.query",
      entity: "AiChat", entityId: null,
      summary: `AI assistant query: "${message.slice(0, 120)}"`,
    });

    return ok({ reply });
  });
}

import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const messages = await db.aiChatMessage.findMany({
      where: { tenantId: session.tenantId, userId: session.id },
      orderBy: { createdAt: "asc" },
      take: 40,
    });
    return ok({
      items: messages.map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant",
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  });
}

export async function DELETE() {
  return handle(async () => {
    const session = await requireAuth();
    await db.aiChatMessage.deleteMany({
      where: { tenantId: session.tenantId, userId: session.id },
    });
    return ok({ success: true });
  });
}

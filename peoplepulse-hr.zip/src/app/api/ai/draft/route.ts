import { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { openrouterChat } from "@/lib/openrouter";

/**
 * POST /api/ai/draft — AI drafting helper for HR communications.
 *
 * Body: { kind: "announcement" | "email" | "policy", topic: string, tone?: string }
 * - announcement | email : any signed-in role
 * - policy              : owner | admin | hr only (403 otherwise)
 * Returns { text }. Any AI failure returns 502 with a friendly message.
 */

const KINDS = ["announcement", "email", "policy"] as const;
type DraftKind = (typeof KINDS)[number];

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const body = await req.json().catch(() => ({}));
    const kind = String(body.kind ?? "") as DraftKind;
    const topic = String(body.topic ?? "").trim();
    const tone = typeof body.tone === "string" ? body.tone.trim() : "";

    if (!KINDS.includes(kind)) {
      return fail("kind must be one of: announcement, email, policy.", 400);
    }
    if (!topic) return fail("topic is required.", 400);
    if (kind === "policy" && !["owner", "admin", "hr"].includes(session.role)) {
      return fail("Only owners, admins and HR can draft policy documents.", 403);
    }

    const systemPrompt = `You are Pulse, an HR communications assistant for ${session.tenantName}. Write in a warm, professional tone.`;

    let userPrompt: string;
    if (kind === "announcement") {
      userPrompt = `Draft a company announcement about: ${topic}. Format: a bold-worthy title line, then 2 short paragraphs, then a warm sign-off from the People Team.`;
    } else if (kind === "email") {
      userPrompt = `Draft a professional email about: ${topic}. Start with "Subject: ..." then the body.`;
    } else {
      userPrompt = `Draft an HR policy document about: ${topic} for ${session.tenantName}. Use sections: Purpose, Scope, Policy, Compliance. Plain text with clear headings.`;
    }
    if (tone) userPrompt += ` Desired tone: ${tone}.`;

    try {
      const text = await openrouterChat({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        maxTokens: 1200,
        temperature: 0.6,
      });
      const trimmed = text.trim();
      if (!trimmed) throw new Error("Empty draft");
      return ok({ text: trimmed });
    } catch (e) {
      console.error(
        "[ai/draft] failed:",
        e instanceof Error ? e.message : e
      );
      return fail("AI drafting is unavailable right now.", 502);
    }
  });
}

/** AI configuration label API. GET /api/ai/config — any signed-in user. */
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { openrouterConfigured, primaryModelLabel } from "@/lib/openrouter";

export async function GET() {
  return handle(async () => {
    await requireAuth();
    return ok({ configured: openrouterConfigured(), modelLabel: primaryModelLabel() });
  });
}

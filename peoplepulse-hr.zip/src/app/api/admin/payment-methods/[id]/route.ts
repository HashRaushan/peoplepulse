/**
 * Platform Admin — update / delete a payment method.
 * PATCH  /api/admin/payment-methods/[id] — partial update (label, details,
 *         instructions, active, sortOrder).
 * DELETE /api/admin/payment-methods/[id] — remove the channel entirely.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { handle, fail, ok } from "@/lib/api-helpers";
import { requirePlatformAdmin, platformAudit } from "@/lib/approval";
import { toPaymentMethodDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const admin = await requirePlatformAdmin();
    const { id } = await ctx.params;
    const raw = await req.json().catch(() => ({}));
    const body = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;

    const existing = await db.paymentMethod.findUnique({ where: { id } });
    if (!existing) return fail("Payment method not found.", 404);

    const data: Record<string, unknown> = {};
    if (body.label != null) data.label = String(body.label).trim();
    if (body.upiId != null) {
      // Strip accidental wrapping quotes (copy-paste artifact), then validate
      // the same way POST does — an invalid UPI ID must never reach buyers.
      const upiId = String(body.upiId)
        .trim()
        .replace(/^["']+|["']+$/g, "")
        .trim();
      if (upiId && !/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(upiId)) {
        return fail("Invalid UPI ID. Expected format: name@bank (e.g. yourname@okhdfcbank).", 400);
      }
      data.upiId = upiId || null;
    }
    if (body.accountHolder != null) {
      data.accountHolder =
        String(body.accountHolder).trim().replace(/^["']+|["']+$/g, "").trim() || null;
    }
    if (body.accountNumber != null) {
      data.accountNumber =
        String(body.accountNumber).trim().replace(/^["']+|["']+$/g, "").trim() || null;
    }
    if (body.ifsc != null) {
      data.ifsc =
        String(body.ifsc).trim().replace(/^["']+|["']+$/g, "").trim().toUpperCase() || null;
    }
    if (body.bankName != null) {
      data.bankName =
        String(body.bankName).trim().replace(/^["']+|["']+$/g, "").trim() || null;
    }
    if (body.accountType != null) {
      data.accountType =
        String(body.accountType).trim().replace(/^["']+|["']+$/g, "").trim() || null;
    }
    if (body.instructions != null) data.instructions = String(body.instructions).trim() || null;
    if (body.active != null) data.active = body.active === true;
    if (body.sortOrder != null && Number.isFinite(Number(body.sortOrder))) {
      data.sortOrder = Math.floor(Number(body.sortOrder));
    }
    if (Object.keys(data).length === 0) return fail("Nothing to update.", 400);

    const updated = await db.paymentMethod.update({ where: { id }, data });

    await platformAudit({
      actorName: admin.name,
      action: "payment_method.updated",
      entity: "PaymentMethod",
      entityId: id,
      summary: `Updated payment channel "${updated.label}"${updated.active ? "" : " (disabled)"}.`,
    });

    return ok({ method: toPaymentMethodDto(updated) });
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const admin = await requirePlatformAdmin();
    const { id } = await ctx.params;
    const existing = await db.paymentMethod.findUnique({ where: { id } });
    if (!existing) return fail("Payment method not found.", 404);

    await db.paymentMethod.delete({ where: { id } });
    await platformAudit({
      actorName: admin.name,
      action: "payment_method.deleted",
      entity: "PaymentMethod",
      entityId: id,
      summary: `Deleted payment channel "${existing.label}".`,
      severity: "warning",
    });
    return ok({ ok: true });
  });
}

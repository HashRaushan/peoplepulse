/**
 * Platform Admin — payment method management.
 * GET  /api/admin/payment-methods — list all channels (including inactive).
 * POST /api/admin/payment-methods — create a channel.
 *      Body: { label, type: "upi"|"bank", upiId?, accountHolder?, accountNumber?,
 *              ifsc?, bankName?, accountType?, instructions?, active?, sortOrder? }
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { handle, fail, ok } from "@/lib/api-helpers";
import { requirePlatformAdmin, ensureDefaultPaymentMethods, platformAudit } from "@/lib/approval";
import { toPaymentMethodDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    await requirePlatformAdmin();
    await ensureDefaultPaymentMethods();
    const rows = await db.paymentMethod.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });
    return ok({ items: rows.map(toPaymentMethodDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const admin = await requirePlatformAdmin();
    const raw = await req.json().catch(() => ({}));
    const body = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;

    const type = body.type === "upi" ? "upi" : "bank";
    /** Strip accidental wrapping quotes (copy-paste artifact), then trim. */
    const clean = (v: unknown) => String(v ?? "").trim().replace(/^["']+|["']+$/g, "").trim();
    const label = clean(body.label);
    const upiId = clean(body.upiId);
    const accountNumber = clean(body.accountNumber);
    const ifsc = clean(body.ifsc).toUpperCase();

    if (!label) return fail("Label is required.", 400);
    if (type === "upi" && !/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(upiId)) {
      return fail("Enter a valid UPI ID (e.g. name@bank).", 400);
    }
    if (type === "bank") {
      if (!/^[0-9]{5,20}$/.test(accountNumber)) return fail("Enter a valid account number.", 400);
      if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) return fail("Enter a valid IFSC code (e.g. BARB0PHAGWA).", 400);
    }

    const created = await db.paymentMethod.create({
      data: {
        label,
        type,
        upiId: type === "upi" ? upiId : null,
        accountHolder: clean(body.accountHolder) || null,
        accountNumber: type === "bank" ? accountNumber : null,
        ifsc: type === "bank" ? ifsc : null,
        bankName: clean(body.bankName) || null,
        accountType: clean(body.accountType) || null,
        instructions: String(body.instructions ?? "").trim() || null,
        active: body.active !== false,
        sortOrder: Number.isFinite(Number(body.sortOrder)) ? Math.floor(Number(body.sortOrder)) : 20,
      },
    });

    await platformAudit({
      actorName: admin.name,
      action: "payment_method.created",
      entity: "PaymentMethod",
      entityId: created.id,
      summary: `Added ${type === "upi" ? "UPI" : "bank"} payment channel "${label}".`,
    });

    return ok({ method: toPaymentMethodDto(created) }, { status: 201 });
  });
}

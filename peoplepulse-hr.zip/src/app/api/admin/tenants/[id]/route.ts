/**
 * Platform Admin — tenant decisions.
 * POST /api/admin/tenants/[id] — platform super admin only.
 *
 * Body: { action, reason?, proofId?, months? }
 *   action = "approve"      → activate the workspace (trial → trialing +14d,
 *                             paid → active with paidUntil; creates a PAID
 *                             invoice and verifies the submitted UTR)
 *   action = "reject"       → decline the signup (reason stored & emailed)
 *   action = "suspend"      → suspend an active workspace (reason emailed)
 *   action = "verify"       → verify a renewal UTR for an already-active
 *                             workspace (extends paidUntil, creates invoice)
 *   action = "reject-proof" → mark a submitted UTR as unverifiable (reason
 *                             emailed; buyer can resubmit)
 *   action = "extend"       → manually grant N months (months required)
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { handle, fail, ok } from "@/lib/api-helpers";
import { requirePlatformAdmin, createPaidInvoice, platformAudit } from "@/lib/approval";
import {
  emailBuyerApproved,
  emailBuyerRejected,
  emailBuyerSuspended,
  emailBuyerPaymentVerified,
  emailBuyerProofRejected,
} from "@/lib/mailer";
import { isPaidPlan, cycleMonths } from "@/lib/plan-state";

type Ctx = { params: Promise<{ id: string }> };

const DAY_MS = 24 * 60 * 60 * 1000;

function fmtDate(d: Date): string {
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}

function addMonths(base: Date, months: number): Date {
  const d = new Date(base);
  d.setMonth(d.getMonth() + months);
  return d;
}

export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const admin = await requirePlatformAdmin();
    const { id } = await ctx.params;
    const raw = await req.json().catch(() => ({}));
    const body = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
    const action = String(body.action ?? "");
    const reason = String(body.reason ?? "").trim();

    const tenant = await db.tenant.findUnique({
      where: { id },
      include: { users: { where: { role: "owner" }, orderBy: { createdAt: "asc" }, take: 1 } },
    });
    if (!tenant) return fail("Tenant not found.", 404);
    const owner = tenant.users[0];
    const now = new Date();

    switch (action) {
      // ---------------- Approve a pending workspace ----------------
      case "approve": {
        if (tenant.planStatus !== "pending") {
          return fail(`This workspace is already ${tenant.planStatus}. Use suspend/extend instead.`, 400);
        }

        // Verify the latest submitted UTR (if any) so it cannot be reused.
        const latestSubmitted = await db.paymentProof.findFirst({
          where: { tenantId: tenant.id, status: "submitted" },
          orderBy: { createdAt: "desc" },
        });
        if (latestSubmitted) {
          await db.paymentProof.update({
            where: { id: latestSubmitted.id },
            data: { status: "verified", reviewedAt: now, reviewNote: "Verified on approval" },
          });
        }

        if (isPaidPlan(tenant.plan)) {
          // Paid plan — activate with a paid-through date + invoice.
          const months = cycleMonths(tenant.billingCycle);
          const invoice = await createPaidInvoice(
            tenant,
            latestSubmitted
              ? {
                  amount: latestSubmitted.amount,
                  plan: latestSubmitted.plan,
                  cycle: latestSubmitted.cycle,
                  seats: latestSubmitted.seats,
                  method: latestSubmitted.method,
                }
              : null
          );
          await db.tenant.update({
            where: { id: tenant.id },
            data: {
              planStatus: "active",
              paidUntil: addMonths(now, months),
              approvedAt: now,
              approvedBy: admin.name,
              statusReason: null,
            },
          });
          await platformAudit({
            actorName: admin.name,
            action: "tenant.approved",
            entity: "Tenant",
            entityId: tenant.id,
            summary: `Approved ${tenant.name} — ${tenant.plan} (${tenant.billingCycle}), invoice ${invoice.number}.`,
          });
          if (owner) {
            await emailBuyerApproved({
              to: owner.email,
              companyName: tenant.name,
              plan: tenant.plan,
              cycle: tenant.billingCycle === "annual" ? "annual" : "monthly",
              seats: tenant.seats,
              validUntilLabel: fmtDate(addMonths(now, months)),
            });
          }
        } else {
          // Trial — activate a 14-day trial.
          const trialEnds = new Date(now.getTime() + 14 * DAY_MS);
          await db.tenant.update({
            where: { id: tenant.id },
            data: {
              planStatus: "trialing",
              plan: "trial",
              trialEndsAt: trialEnds,
              approvedAt: now,
              approvedBy: admin.name,
              statusReason: null,
            },
          });
          await platformAudit({
            actorName: admin.name,
            action: "tenant.approved",
            entity: "Tenant",
            entityId: tenant.id,
            summary: `Approved ${tenant.name} — 14-day trial until ${fmtDate(trialEnds)}.`,
          });
          if (owner) {
            await emailBuyerApproved({
              to: owner.email,
              companyName: tenant.name,
              plan: "trial",
              validUntilLabel: fmtDate(trialEnds),
            });
          }
        }
        return ok({ ok: true });
      }

      // ---------------- Decline a signup ----------------
      case "reject": {
        await db.tenant.update({
          where: { id: tenant.id },
          data: { planStatus: "rejected", statusReason: reason || null, approvedBy: admin.name },
        });
        await platformAudit({
          actorName: admin.name,
          action: "tenant.rejected",
          entity: "Tenant",
          entityId: tenant.id,
          summary: `Rejected ${tenant.name}.${reason ? ` Reason: ${reason}` : ""}`,
          severity: "warning",
        });
        if (owner) {
          await emailBuyerRejected({ to: owner.email, companyName: tenant.name, reason: reason || "" });
        }
        return ok({ ok: true });
      }

      // ---------------- Suspend an active workspace ----------------
      case "suspend": {
        if (tenant.planStatus === "pending") {
          return fail("Use reject for pending signups.", 400);
        }
        await db.tenant.update({
          where: { id: tenant.id },
          data: { planStatus: "cancelled", statusReason: reason || null },
        });
        await platformAudit({
          actorName: admin.name,
          action: "tenant.suspended",
          entity: "Tenant",
          entityId: tenant.id,
          summary: `Suspended ${tenant.name}.${reason ? ` Reason: ${reason}` : ""}`,
          severity: "warning",
        });
        if (owner) {
          await emailBuyerSuspended({ to: owner.email, companyName: tenant.name, reason: reason || "" });
        }
        return ok({ ok: true });
      }

      // ---------------- Verify a renewal UTR (active tenant) ----------------
      case "verify": {
        const proofId = String(body.proofId ?? "");
        if (!proofId) return fail("proofId is required.", 400);
        const proof = await db.paymentProof.findFirst({ where: { id: proofId, tenantId: tenant.id } });
        if (!proof) return fail("Payment submission not found.", 404);
        if (proof.status !== "submitted") return fail("This submission was already reviewed.", 400);

        const months = cycleMonths(proof.cycle);
        const base = tenant.paidUntil && tenant.paidUntil.getTime() > now.getTime() ? tenant.paidUntil : now;
        const newPaidUntil = addMonths(base, months);
        const invoice = await createPaidInvoice(tenant, {
          amount: proof.amount,
          plan: proof.plan,
          cycle: proof.cycle,
          seats: proof.seats,
          method: proof.method,
        });

        await db.paymentProof.update({
          where: { id: proof.id },
          data: { status: "verified", reviewedAt: now, reviewNote: "Verified by platform admin" },
        });
        // Activate the plan the payment was for (handles plan changes on renewal).
        await db.tenant.update({
          where: { id: tenant.id },
          data: {
            planStatus: "active",
            plan: isPaidPlan(proof.plan) ? proof.plan : tenant.plan,
            billingCycle: proof.cycle === "annual" ? "annual" : "monthly",
            seats: proof.seats,
            paidUntil: newPaidUntil,
            statusReason: null,
          },
        });
        await platformAudit({
          actorName: admin.name,
          action: "payment.verified",
          entity: "PaymentProof",
          entityId: proof.id,
          summary: `Verified UTR ${proof.utr} from ${tenant.name} — extended to ${fmtDate(newPaidUntil)}, invoice ${invoice.number}.`,
        });
        if (owner) {
          await emailBuyerPaymentVerified({
            to: owner.email,
            companyName: tenant.name,
            utr: proof.utr,
            amount: proof.amount,
            paidUntilLabel: fmtDate(newPaidUntil),
            invoiceNumber: invoice.number,
          });
        }
        return ok({ ok: true, paidUntil: newPaidUntil.toISOString() });
      }

      // ---------------- Mark a UTR as unverifiable ----------------
      case "reject-proof": {
        const proofId = String(body.proofId ?? "");
        if (!proofId) return fail("proofId is required.", 400);
        const proof = await db.paymentProof.findFirst({ where: { id: proofId, tenantId: tenant.id } });
        if (!proof) return fail("Payment submission not found.", 404);
        if (proof.status !== "submitted") return fail("This submission was already reviewed.", 400);

        await db.paymentProof.update({
          where: { id: proof.id },
          data: { status: "rejected", reviewedAt: now, reviewNote: reason || "Could not be verified" },
        });
        await platformAudit({
          actorName: admin.name,
          action: "payment.rejected",
          entity: "PaymentProof",
          entityId: proof.id,
          summary: `Could not verify UTR ${proof.utr} from ${tenant.name}.${reason ? ` Reason: ${reason}` : ""}`,
          severity: "warning",
        });
        if (owner) {
          await emailBuyerProofRejected({
            to: owner.email,
            companyName: tenant.name,
            utr: proof.utr,
            reason: reason || "",
          });
        }
        return ok({ ok: true });
      }

      // ---------------- Manually grant months ----------------
      case "extend": {
        const months = Number(body.months ?? 0);
        if (!Number.isFinite(months) || months < 1 || months > 36) {
          return fail("Months must be between 1 and 36.", 400);
        }
        const base = tenant.paidUntil && tenant.paidUntil.getTime() > now.getTime() ? tenant.paidUntil : now;
        const newPaidUntil = addMonths(base, Math.floor(months));
        await db.tenant.update({
          where: { id: tenant.id },
          data: { planStatus: "active", paidUntil: newPaidUntil, statusReason: null },
        });
        await platformAudit({
          actorName: admin.name,
          action: "tenant.extended",
          entity: "Tenant",
          entityId: tenant.id,
          summary: `Granted ${tenant.name} ${months} extra month(s) — paid until ${fmtDate(newPaidUntil)}.`,
        });
        return ok({ ok: true, paidUntil: newPaidUntil.toISOString() });
      }

      default:
        return fail("Unknown action.", 400);
    }
  });
}

/**
 * Platform Admin — tenant list & platform stats.
 * GET /api/admin/tenants — platform super admin only.
 */
import { db } from "@/lib/db";
import { handle, ok } from "@/lib/api-helpers";
import { requirePlatformAdmin } from "@/lib/approval";
import { computePlanPrice } from "@/lib/billing";
import { blockState, isPaidPlan } from "@/lib/plan-state";
import { toPaymentProofDto } from "@/app/api/_lib/mappers";
import type { AdminStatsDto, AdminTenantDto } from "@/lib/types";

export async function GET() {
  return handle(async () => {
    await requirePlatformAdmin();

    const [tenants, proofs] = await Promise.all([
      db.tenant.findMany({
        include: {
          users: { where: { role: "owner" }, orderBy: { createdAt: "asc" }, take: 1 },
          _count: { select: { employees: true } },
        },
        orderBy: { createdAt: "desc" },
      }),
      db.paymentProof.findMany({ orderBy: { createdAt: "desc" } }),
    ]);

    const latestProofByTenant = new Map<string, (typeof proofs)[number]>();
    for (const p of proofs) {
      if (!latestProofByTenant.has(p.tenantId)) latestProofByTenant.set(p.tenantId, p);
    }

    const items: AdminTenantDto[] = tenants.map((t) => {
      const owner = t.users[0];
      const proof = latestProofByTenant.get(t.id) ?? null;
      const cycle = t.billingCycle === "annual" ? "annual" : "monthly";
      return {
        id: t.id,
        name: t.name,
        slug: t.slug,
        plan: t.plan,
        cycle,
        seats: t.seats,
        planStatus: t.planStatus,
        blocked: blockState(t),
        statusReason: t.statusReason,
        trialEndsAt: t.trialEndsAt ? t.trialEndsAt.toISOString() : null,
        paidUntil: t.paidUntil ? t.paidUntil.toISOString() : null,
        approvedAt: t.approvedAt ? t.approvedAt.toISOString() : null,
        ownerName: owner?.name ?? "—",
        ownerEmail: owner?.email ?? "—",
        employeeCount: t._count.employees,
        createdAt: t.createdAt.toISOString(),
        latestProof: proof ? toPaymentProofDto(proof) : null,
        price: isPaidPlan(t.plan) ? computePlanPrice(t.plan, cycle, t.seats) : null,
      };
    });

    const stats: AdminStatsDto = {
      total: items.length,
      pending: items.filter((t) => t.planStatus === "pending").length,
      active: items.filter((t) => t.planStatus === "active" && !t.blocked).length,
      trialing: items.filter((t) => t.planStatus === "trialing" && !t.blocked).length,
      rejected: items.filter((t) => t.planStatus === "rejected").length,
      cancelled: items.filter((t) => t.planStatus === "cancelled" || t.planStatus === "past_due").length,
      pendingProofs: proofs.filter((p) => p.status === "submitted").length,
      mrr: items
        .filter((t) => t.planStatus === "active" && !t.blocked && t.price)
        .reduce((sum, t) => sum + (t.price ? Math.round(t.price.total / t.price.months) : 0), 0),
    };

    return ok({ items, stats });
  });
}

/**
 * Policy documents API.
 *
 * GET  /api/policies — any signed-in user. Policy handbook sorted by title.
 *
 * POST /api/policies (owner | admin | hr) — create or update a policy.
 *   Upserts by tenant + title: republishing an existing policy bumps its
 *   version by 0.1 and refreshes the content and updatedBy fields.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toPolicyDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const rows = await db.policyDocument.findMany({
      where: { tenantId: session.tenantId },
      orderBy: { title: "asc" },
    });
    return ok({ items: rows.map(toPolicyDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const content = String(body.content ?? "").trim();
    if (!title) return fail("Policy title is required.", 400);
    if (!content) return fail("Policy content is required.", 400);

    const existing = await db.policyDocument.findFirst({
      where: { tenantId: session.tenantId, title },
    });

    if (existing) {
      // Bump the version by 0.1 (1.0 -> 1.1 -> ... -> 1.9 -> 2.0).
      const current = Number(existing.version);
      const base = Number.isFinite(current) ? Math.round(current * 10) : 10;
      const nextVersion = ((base + 1) / 10).toFixed(1);

      const updated = await db.policyDocument.update({
        where: { id: existing.id },
        data: {
          category: body.category != null && body.category !== "" ? String(body.category) : existing.category,
          content,
          version: nextVersion,
          updatedBy: session.name,
        },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "policy.updated",
        entity: "PolicyDocument",
        entityId: updated.id,
        summary: `Updated policy "${title}" to version ${nextVersion}.`,
      });

      return ok({ item: toPolicyDto(updated) });
    }

    const created = await db.policyDocument.create({
      data: {
        tenantId: session.tenantId,
        title,
        category: body.category != null && body.category !== "" ? String(body.category) : "HR Policy",
        content,
        version: body.version != null && body.version !== "" ? String(body.version) : "1.0",
        audience: "All Employees",
        updatedBy: session.name,
      },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "policy.created",
      entity: "PolicyDocument",
      entityId: created.id,
      summary: `Published policy "${title}" (v${created.version}).`,
    });

    return ok({ item: toPolicyDto(created) }, { status: 201 });
  });
}

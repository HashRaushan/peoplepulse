/**
 * Holiday calendar API.
 *
 * GET  /api/holidays — any signed-in user. Tenant holidays sorted by date.
 *
 * POST /api/holidays (owner | admin | hr) — add a holiday (name, date
 * YYYY-MM-DD, optional type public|optional). A second holiday on the same
 * date is rejected with 409.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { isValidDateOnly, localDate, toHolidayDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const rows = await db.holiday.findMany({
      where: { tenantId: session.tenantId },
      orderBy: { date: "asc" },
    });
    return ok({ items: rows.map(toHolidayDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const name = String(body.name ?? "").trim();
    const date = String(body.date ?? "").trim();
    if (!name) return fail("Holiday name is required.", 400);
    if (!isValidDateOnly(date)) return fail("Holiday date must be a valid date (YYYY-MM-DD).", 400);
    const type = ["public", "optional"].includes(String(body.type)) ? String(body.type) : "public";

    const duplicate = await db.holiday.findFirst({
      where: { tenantId: session.tenantId, date: localDate(date) },
      select: { id: true },
    });
    if (duplicate) return fail("A holiday already exists on this date.", 409);

    const holiday = await db.holiday.create({
      data: { tenantId: session.tenantId, name, date: localDate(date), type },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "holiday.created",
      entity: "Holiday",
      entityId: holiday.id,
      summary: `Added holiday "${name}" on ${date}.`,
    });

    return ok({ item: toHolidayDto(holiday) }, { status: 201 });
  });
}

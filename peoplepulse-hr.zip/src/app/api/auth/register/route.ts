import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/crypto";
import { setSessionCookie } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { provisionTenant, slugify } from "@/lib/provision";
import { notifyPlatformAdmin } from "@/lib/approval";
import { emailAdminNewSignup } from "@/lib/mailer";
import { isPaidPlan, isBillingCycle } from "@/lib/plan-state";

/**
 * Registration creates the workspace in PENDING state. A platform admin
 * approves every signup (trial and paid) from Platform Admin → Tenants.
 *
 * The very first user on a fresh deployment becomes the platform super admin
 * and their workspace is approved automatically (unless PLATFORM_ADMIN_EMAIL
 * is set, in which case only that email can claim the platform admin role).
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const company = String(body.company ?? "").trim();
    const companySize = String(body.companySize ?? "11-50");
    const plan = String(body.plan ?? "trial");
    const cycle = String(body.cycle ?? "monthly");
    const seats = Number(body.seats ?? 0);

    if (!name || !email || !company) return fail("Name, email and organisation name are required.", 400);
    if (password.length < 8) return fail("Password must be at least 8 characters.", 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Please enter a valid email address.", 400);

    const isTrial = plan === "trial";
    if (!isTrial && !isPaidPlan(plan)) {
      return fail("Please choose a valid plan.", 400);
    }
    const billingCycle: "monthly" | "annual" = isBillingCycle(cycle) ? cycle : "monthly";

    // Seats: paid plans choose 1-10000 (default = plan's included seats); trial defaults to 25.
    const PRICING_SEATS: Record<string, number> = { starter: 25, growth: 100, professional: 500 };
    let seatCount: number;
    if (isTrial) {
      seatCount = 25;
    } else {
      if (!Number.isFinite(seats) || seats < 1 || seats > 10000) {
        seatCount = PRICING_SEATS[plan] ?? 25;
      } else {
        seatCount = Math.floor(seats);
      }
    }

    const existing = await db.user.findFirst({ where: { email } });
    if (existing) return fail("An account with this email already exists. Please sign in instead.", 409);

    // Platform admin bootstrap:
    //  - If PLATFORM_ADMIN_EMAIL is set, only that email can claim the role.
    //  - Otherwise the first user ever to register becomes the platform admin.
    const adminEmail = (process.env.PLATFORM_ADMIN_EMAIL ?? "").trim().toLowerCase();
    const anyAdmin = await db.user.findFirst({ where: { superAdmin: true }, select: { id: true } });
    const becomesPlatformAdmin = adminEmail ? email === adminEmail : !anyAdmin;

    // Unique slug (append -2, -3… when two companies share a name).
    let slug = slugify(company);
    for (let i = 2; ; i += 1) {
      const clash = await db.tenant.findFirst({ where: { slug }, select: { id: true } });
      if (!clash) break;
      slug = `${slugify(company)}-${i}`;
    }

    const now = new Date();
    const tenant = await db.tenant.create({
      data: {
        name: company,
        slug,
        // The platform admin's own workspace is a lifetime Professional account.
        plan: becomesPlatformAdmin ? "professional" : isTrial ? "trial" : plan,
        planStatus: becomesPlatformAdmin ? "active" : "pending",
        trialEndsAt: null,
        seats: becomesPlatformAdmin ? 500 : seatCount,
        billingCycle,
        approvedAt: becomesPlatformAdmin ? now : null,
        approvedBy: becomesPlatformAdmin ? "system (platform bootstrap)" : null,
        onboardingStep: 1,
      },
    });

    // Everything after the tenant row is created is compensatable: on any
    // failure the half-built workspace is deleted (cascades clean users,
    // leave types, etc.) so the caller can simply retry registration.
    try {
      const user = await db.user.create({
        data: {
          tenantId: tenant.id,
          email,
          name,
          password: hashPassword(password),
          role: "owner",
          superAdmin: becomesPlatformAdmin,
        },
      });

      await provisionTenant({
        tenantId: tenant.id,
        ownerUserId: user.id,
        ownerName: name,
        ownerEmail: email,
        companyName: company,
      });

      await setSessionCookie(user.id);

      if (!becomesPlatformAdmin) {
        // Tell the platform admin about the new signup (email + in-app).
        await emailAdminNewSignup({
          companyName: company,
          ownerName: name,
          ownerEmail: email,
          companySize,
          plan,
          cycle: billingCycle,
          seats: seatCount,
        });
        await notifyPlatformAdmin(
          `New ${isTrial ? "trial" : "paid"} signup: ${company}`,
          `${name} (${email}) registered ${isTrial ? "for a 14-day trial" : `for the ${plan} plan (${billingCycle}, ${seatCount} seats)`}. Approve or decline in Platform Admin → Tenants.`
        );
      }

      return ok(
        {
          tenant: { name: tenant.name, slug: tenant.slug },
          needsApproval: !becomesPlatformAdmin,
          isTrial,
          platformAdmin: becomesPlatformAdmin,
        },
        { status: 201 }
      );
    } catch (e) {
      await db.tenant.delete({ where: { id: tenant.id } }).catch(() => {});
      throw e;
    }
  });
}

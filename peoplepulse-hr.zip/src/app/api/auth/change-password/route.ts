/**
 * POST /api/auth/change-password — any signed-in user changes their own password.
 * Body: { currentPassword, newPassword }. newPassword must be >= 8 chars.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { verifyPassword, hashPassword } from "@/lib/crypto";
import { handle, fail, ok, audit } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const body = await req.json().catch(() => ({}));
    const currentPassword = String(body.currentPassword ?? "");
    const newPassword = String(body.newPassword ?? "");

    if (newPassword.length < 8) {
      return fail("New password must be at least 8 characters.", 400);
    }
    if (newPassword === currentPassword) {
      return fail("The new password must be different from the current one.", 400);
    }

    const user = await db.user.findUnique({ where: { id: session.id } });
    if (!user || !verifyPassword(currentPassword, user.password)) {
      return fail("Current password is incorrect.", 400);
    }

    await db.user.update({
      where: { id: session.id },
      data: { password: hashPassword(newPassword) },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "auth.password_changed",
      entity: "User",
      entityId: session.id,
      severity: "warning",
      summary: `${session.name} changed their password.`,
    });

    return ok({ ok: true });
  });
}

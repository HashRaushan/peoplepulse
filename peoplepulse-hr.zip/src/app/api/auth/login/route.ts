import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/crypto";
import { setSessionCookie, getSessionUser } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";

/** Shaped like a real scrypt hash so the unknown-user branch burns the same
 *  KDF work as the real branch — response times cannot reveal whether an
 *  email exists. */
const DUMMY_HASH = "scrypt:" + "0".repeat(32) + ":" + "0".repeat(128);

export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await req.json().catch(() => ({}));
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!email || !password) return fail("Email and password are required.", 400);

    // User.email is globally unique — deterministic lookup via findUnique.
    const user = await db.user.findUnique({
      where: { email },
      include: { tenant: true, employee: true },
    });
    // Always run one scrypt verification (real or dummy) to equalise timing.
    const passwordOk = verifyPassword(password, user?.password ?? DUMMY_HASH);
    if (!user || !passwordOk) {
      return fail("Invalid email or password.", 401);
    }

    await setSessionCookie(user.id);
    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    await audit(user.tenantId, {
      actorName: user.name,
      actorRole: user.role,
      action: "auth.login",
      entity: "User",
      entityId: user.id,
      summary: `${user.name} signed in.`,
    });

    // Single source of truth: build the session payload via getSessionUser so
    // the login response always matches /api/auth/me (incl. superAdmin, blocked
    // state, billing cycle, paidUntil…).
    const sessionUser = await getSessionUser();
    if (!sessionUser) return fail("Could not create session. Please try again.", 500);
    return ok({ user: sessionUser });
  });
}

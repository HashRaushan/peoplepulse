/**
 * Audit trail API.
 *
 * GET /api/audit (owner | admin | hr) — paginated audit log for the tenant.
 * Query: action, entity, page (default 1), pageSize (default 30).
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { intParam, toAuditDto } from "@/app/api/_lib/mappers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const sp = req.nextUrl.searchParams;
    const action = (sp.get("action") ?? "").trim();
    const entity = (sp.get("entity") ?? "").trim();
    const page = Math.max(1, intParam(sp.get("page"), 1));
    const pageSize = Math.min(100, Math.max(1, intParam(sp.get("pageSize"), 30)));

    const where: Prisma.AuditLogWhereInput = { tenantId: session.tenantId };
    if (action) where.action = action;
    if (entity) where.entity = entity;

    const [rows, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.auditLog.count({ where }),
    ]);

    return ok({ items: rows.map(toAuditDto), total, page, pageSize });
  });
}

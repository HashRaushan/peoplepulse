/**
 * Surveys API.
 *
 * GET /api/surveys — any signed-in user. Returns every survey in the tenant
 * with question/response counts and whether the current user has already
 * responded (false when the account has no linked employee record).
 * Ordered: active surveys first, then closed, newest first within each group.
 *
 * POST /api/surveys — owner/admin/hr. Creates a survey (status "active") with
 * its questions. Validates title, type (enps|pulse|custom), at least one
 * question, per-question text/type and the >=2 non-empty options rule for
 * choice questions. Writes an audit entry.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { isValidDateOnly, localDate } from "@/app/api/_lib/mappers";
import type { Survey } from "@prisma/client";
import type { SurveyListItemDto } from "@/lib/types";

const SURVEY_TYPES: readonly string[] = ["enps", "pulse", "custom"];
const QUESTION_TYPES: readonly string[] = ["rating_10", "choice", "text"];

type SurveyWithCounts = Survey & {
  _count: { questions: number; responses: number };
};

/** Map a survey row (with counts) to the list DTO. */
function toListItem(s: SurveyWithCounts, hasResponded: boolean): SurveyListItemDto {
  return {
    id: s.id,
    title: s.title,
    description: s.description,
    type: s.type,
    status: s.status,
    anonymous: s.anonymous,
    questionCount: s._count.questions,
    responseCount: s._count.responses,
    hasResponded,
    createdAt: s.createdAt.toISOString(),
    closesAt: s.closesAt ? s.closesAt.toISOString() : null,
  };
}

/** Sort rank: active surveys first, closed last (drafts in between). */
function statusRank(status: string): number {
  if (status === "active") return 0;
  if (status === "closed") return 2;
  return 1;
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();

    const [surveys, myResponses] = await Promise.all([
      db.survey.findMany({
        where: { tenantId: session.tenantId },
        include: { _count: { select: { questions: true, responses: true } } },
      }),
      session.employeeId
        ? db.surveyResponse.findMany({
            where: { tenantId: session.tenantId, employeeId: session.employeeId },
            select: { surveyId: true },
          })
        : Promise.resolve([] as { surveyId: string }[]),
    ]);

    const respondedSurveyIds = new Set(myResponses.map((r) => r.surveyId));

    const items = surveys
      .map((s) => toListItem(s, respondedSurveyIds.has(s.id)))
      .sort(
        (a, b) =>
          statusRank(a.status) - statusRank(b.status) ||
          b.createdAt.localeCompare(a.createdAt)
      );

    return ok({ surveys: items });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const description = String(body.description ?? "").trim().slice(0, 1000);
    const type = String(body.type ?? "").trim();
    const anonymous = body.anonymous === true || body.anonymous === "true";

    if (!title) return fail("Please enter a survey title.", 400);
    if (title.length > 200) return fail("Survey title must be at most 200 characters.", 400);
    if (!SURVEY_TYPES.includes(type)) return fail("Survey type must be enps, pulse or custom.", 400);

    // Optional close date: accepts "YYYY-MM-DD" or a full ISO timestamp.
    let closesAt: Date | null = null;
    if (typeof body.closesAt === "string" && body.closesAt.trim() !== "") {
      const value = body.closesAt.trim();
      if (isValidDateOnly(value)) {
        closesAt = localDate(value);
      } else {
        const parsed = new Date(value);
        if (Number.isNaN(parsed.getTime())) {
          return fail("Close date must be a valid date (YYYY-MM-DD).", 400);
        }
        closesAt = parsed;
      }
    }

    // Questions validation.
    const rawQuestions = Array.isArray(body.questions) ? body.questions : [];
    if (rawQuestions.length === 0) return fail("Add at least one question.", 400);
    if (rawQuestions.length > 30) return fail("A survey can have at most 30 questions.", 400);

    const questions: { text: string; type: string; options: string[] }[] = [];
    for (let i = 0; i < rawQuestions.length; i++) {
      const rq = rawQuestions[i];
      if (!rq || typeof rq !== "object" || Array.isArray(rq)) {
        return fail(`Question ${i + 1} is invalid.`, 400);
      }
      const q = rq as Record<string, unknown>;
      const text = String(q.text ?? "").trim();
      const qType = String(q.type ?? "").trim();
      const label = `Question ${i + 1}`;

      if (!text) return fail(`${label} needs question text.`, 400);
      if (text.length > 500) return fail(`${label} text must be at most 500 characters.`, 400);
      if (!QUESTION_TYPES.includes(qType)) {
        return fail(`${label} type must be rating_10, choice or text.`, 400);
      }

      let options: string[] = [];
      if (qType === "choice") {
        const rawOptions = Array.isArray(q.options) ? q.options : [];
        options = [...new Set(rawOptions.map((o) => String(o ?? "").trim()))].filter(Boolean);
        if (options.length < 2) {
          return fail(`${label} (choice) needs at least 2 non-empty options.`, 400);
        }
      }

      questions.push({ text, type: qType, options });
    }

    const survey = await db.survey.create({
      data: {
        tenantId: session.tenantId,
        title,
        description,
        type,
        status: "active",
        anonymous,
        createdBy: session.name,
        closesAt,
        questions: {
          create: questions.map((q, i) => ({
            tenantId: session.tenantId,
            text: q.text,
            type: q.type,
            options: JSON.stringify(q.options),
            order: i,
          })),
        },
      },
      include: { _count: { select: { questions: true, responses: true } } },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "survey.created",
      entity: "Survey",
      entityId: survey.id,
      summary: `Created ${questions.length}-question ${type} survey "${title}"${anonymous ? " (anonymous)" : ""}.`,
    });

    return ok({ survey: toListItem(survey, false) }, { status: 201 });
  });
}

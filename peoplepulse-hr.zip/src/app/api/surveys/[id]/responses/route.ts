/**
 * Survey response API.
 *
 * POST /api/surveys/{id}/responses — any signed-in user with a linked employee
 * record. One response per employee per survey. Closed surveys (status !=
 * "active" or a past closesAt deadline) are rejected with 409. Every
 * rating/choice question must be answered (text questions may be skipped);
 * ratings must be "1".."10" and choice values must match one of the
 * question's options. The response and its answers are created atomically
 * via a nested write.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { parseJson } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const survey = await db.survey.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { questions: true },
    });
    if (!survey) return fail("Survey not found.", 404);
    if (survey.status !== "active") {
      return fail("This survey is closed for responses.", 409);
    }
    if (survey.closesAt && survey.closesAt.getTime() < Date.now()) {
      return fail("This survey is closed for responses.", 409);
    }
    if (!session.employeeId) {
      return fail("Your account is not linked to an employee record.", 400);
    }

    const existing = await db.surveyResponse.findFirst({
      where: { surveyId: survey.id, employeeId: session.employeeId },
      select: { id: true },
    });
    if (existing) return fail("You have already responded", 409);

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw) || !Array.isArray(raw.answers)) {
      return fail("Invalid request body.", 400);
    }

    const questions = [...survey.questions].sort((a, b) => a.order - b.order);
    const questionById = new Map(questions.map((q) => [q.id, q]));

    // Collect the first value per question; reject unknown question ids.
    const valueByQuestion = new Map<string, string>();
    for (const entry of raw.answers) {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
        return fail("Invalid answer payload.", 400);
      }
      const a = entry as Record<string, unknown>;
      const questionId = String(a.questionId ?? "");
      const question = questionById.get(questionId);
      if (!question) return fail("Answers reference an unknown question.", 400);
      if (!valueByQuestion.has(questionId)) {
        valueByQuestion.set(questionId, String(a.value ?? ""));
      }
    }

    // Required-answer + value validation per question type.
    const answerRows: { questionId: string; value: string }[] = [];
    for (const q of questions) {
      const value = (valueByQuestion.get(q.id) ?? "").trim();

      if (q.type === "rating_10") {
        if (!/^(10|[1-9])$/.test(value)) {
          return fail("All questions are required", 400);
        }
        answerRows.push({ questionId: q.id, value });
      } else if (q.type === "choice") {
        const options = parseJson<string[]>(q.options, []);
        if (!value || !options.includes(value)) {
          return fail("All questions are required", 400);
        }
        answerRows.push({ questionId: q.id, value });
      } else {
        // Free-text questions are optional; skip empty submissions.
        if (value !== "") {
          answerRows.push({ questionId: q.id, value: value.slice(0, 2000) });
        }
      }
    }

    // Atomic: response row + all its answers in one nested create.
    await db.surveyResponse.create({
      data: {
        tenantId: session.tenantId,
        surveyId: survey.id,
        employeeId: session.employeeId,
        answers: {
          create: answerRows.map((r) => ({
            tenantId: session.tenantId,
            questionId: r.questionId,
            value: r.value,
          })),
        },
      },
    });

    return ok({ ok: true }, { status: 201 });
  });
}

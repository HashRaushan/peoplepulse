/**
 * Survey detail API.
 *
 * GET /api/surveys/{id} — any signed-in user. Returns the survey, its ordered
 * questions (options parsed) and the current user's own answers. Aggregated
 * results (participation, per-question averages/distributions/text answers)
 * are included ONLY for owner/admin/hr and NEVER contain employee identity.
 *
 * PATCH /api/surveys/{id} — owner/admin/hr. Body { action: "close" | "reopen" }.
 * Reopening clears a past closesAt date so the survey stays open.
 *
 * DELETE /api/surveys/{id} — owner/admin/hr. Refused with 409 when the survey
 * already has responses (close it instead); otherwise deletes it.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { parseJson } from "@/app/api/_lib/mappers";
import type { Survey, SurveyQuestion, SurveyResponse, SurveyAnswer } from "@prisma/client";
import type { SurveyDetailDto, SurveyListItemDto, SurveyResultsDto } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

const MGR_ROLES = ["owner", "admin", "hr"];

type SurveyWithDetail = Survey & {
  questions: SurveyQuestion[];
  _count: { responses: number };
};

function toListItem(s: SurveyWithDetail, hasResponded: boolean): SurveyListItemDto {
  return {
    id: s.id,
    title: s.title,
    description: s.description,
    type: s.type,
    status: s.status,
    anonymous: s.anonymous,
    questionCount: s.questions.length,
    responseCount: s._count.responses,
    hasResponded,
    createdAt: s.createdAt.toISOString(),
    closesAt: s.closesAt ? s.closesAt.toISOString() : null,
  };
}

/**
 * Aggregate responses into the results DTO. Deliberately works only on the
 * answer values — employee identity is never read or exposed here.
 */
function buildResults(
  survey: SurveyWithDetail,
  responses: (SurveyResponse & { answers: SurveyAnswer[] })[],
  totalEmployees: number
): SurveyResultsDto {
  const participation =
    totalEmployees > 0 ? Math.round((responses.length / totalEmployees) * 100) : 0;

  const perQuestion = [...survey.questions]
    .sort((a, b) => a.order - b.order)
    .map((q) => {
      const answers = responses
        .flatMap((r) => r.answers)
        .filter((a) => a.questionId === q.id);

      if (q.type === "rating_10") {
        const nums = answers
          .map((a) => Number(a.value))
          .filter((n) => Number.isInteger(n) && n >= 1 && n <= 10);
        const average =
          nums.length > 0
            ? Math.round((nums.reduce((sum, n) => sum + n, 0) / nums.length) * 10) / 10
            : null;
        const distribution = Array.from({ length: 10 }, (_, i) => ({
          label: String(i + 1),
          count: nums.filter((n) => n === i + 1).length,
        }));
        return { questionId: q.id, type: q.type, average, distribution, textAnswers: [] };
      }

      if (q.type === "choice") {
        const options = parseJson<string[]>(q.options, []);
        const distribution = options.map((label) => ({
          label,
          count: answers.filter((a) => a.value === label).length,
        }));
        return { questionId: q.id, type: q.type, average: null, distribution, textAnswers: [] };
      }

      return {
        questionId: q.id,
        type: q.type,
        average: null,
        distribution: [] as { label: string; count: number }[],
        textAnswers: answers.map((a) => a.value).filter((v) => v.trim() !== ""),
      };
    });

  return { participation, totalEmployees, perQuestion };
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const survey = await db.survey.findFirst({
      where: { tenantId: session.tenantId, id },
      include: {
        questions: true,
        _count: { select: { responses: true } },
      },
    });
    if (!survey) return fail("Survey not found.", 404);

    // Current user's own response (hasResponded + myAnswers).
    let hasResponded = false;
    let myAnswers: { questionId: string; value: string }[] | null = null;
    if (session.employeeId) {
      const myResponse = await db.surveyResponse.findFirst({
        where: { surveyId: survey.id, employeeId: session.employeeId },
        include: { answers: true },
      });
      if (myResponse) {
        hasResponded = true;
        myAnswers = myResponse.answers.map((a) => ({
          questionId: a.questionId,
          value: a.value,
        }));
      }
    }

    // Aggregated results — owner/admin/hr only, always identity-free.
    let results: SurveyResultsDto | null = null;
    if (MGR_ROLES.includes(session.role)) {
      const [totalEmployees, responses] = await Promise.all([
        db.employee.count({
          where: { tenantId: session.tenantId, status: { not: "exited" } },
        }),
        db.surveyResponse.findMany({
          where: { surveyId: survey.id },
          include: { answers: true },
        }),
      ]);
      results = buildResults(survey, responses, totalEmployees);
    }

    const dto: SurveyDetailDto = {
      survey: toListItem(survey, hasResponded),
      questions: [...survey.questions]
        .sort((a, b) => a.order - b.order)
        .map((q) => ({
          id: q.id,
          text: q.text,
          type: q.type as "rating_10" | "choice" | "text",
          options: parseJson<string[]>(q.options, []),
          order: q.order,
        })),
      results,
      myAnswers,
    };
    return ok(dto);
  });
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const action = String((raw as Record<string, unknown>).action ?? "");

    const survey = await db.survey.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { questions: true, _count: { select: { responses: true } } },
    });
    if (!survey) return fail("Survey not found.", 404);

    if (action === "close") {
      if (survey.status !== "active") {
        return fail("Only active surveys can be closed.", 400);
      }
      await db.survey.update({ where: { id: survey.id }, data: { status: "closed" } });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "survey.closed",
        entity: "Survey",
        entityId: survey.id,
        summary: `Closed survey "${survey.title}" with ${survey._count.responses} response(s).`,
      });
      return ok({
        survey: toListItem({ ...survey, status: "closed" }, false),
      });
    }

    if (action === "reopen") {
      if (survey.status !== "closed") {
        return fail("Only closed surveys can be reopened.", 400);
      }
      // A past close date would immediately re-close the survey — clear it.
      const clearClosesAt = !!survey.closesAt && survey.closesAt.getTime() < Date.now();
      await db.survey.update({
        where: { id: survey.id },
        data: { status: "active", ...(clearClosesAt ? { closesAt: null } : {}) },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "survey.reopened",
        entity: "Survey",
        entityId: survey.id,
        summary: `Reopened survey "${survey.title}"${clearClosesAt ? " and cleared its past close date" : ""}.`,
      });
      return ok({
        survey: toListItem(
          { ...survey, status: "active", ...(clearClosesAt ? { closesAt: null } : {}) },
          false
        ),
      });
    }

    return fail("Unknown action. Use close or reopen.", 400);
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const survey = await db.survey.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { _count: { select: { responses: true } } },
    });
    if (!survey) return fail("Survey not found.", 404);

    if (survey._count.responses > 0) {
      return fail("Survey has responses — close it instead", 409);
    }

    await db.survey.delete({ where: { id: survey.id } });
    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "survey.deleted",
      entity: "Survey",
      entityId: survey.id,
      summary: `Deleted survey "${survey.title}".`,
    });
    return ok({ ok: true });
  });
}

/**
 * Organisation chart API.
 *
 * GET /api/org-chart (owner | admin | hr | manager) — returns the reporting
 * tree for the tenant as { root: OrgChartNode }. Exited employees are excluded.
 * The tree is rooted at employees without a manager; employees whose manager is
 * missing (e.g. an exited manager) are promoted to the top level so nobody is
 * lost. When there is more than one top-level node, everything is wrapped in a
 * virtual node named after the tenant with designation "Organisation".
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { tenantCodePrefix } from "@/app/api/_lib/mappers";
import type { OrgChartNode } from "@/lib/types";

/** Internal build node — carries managerId for wiring, stripped on output. */
type BuildNode = {
  id: string;
  code: string;
  name: string;
  designation: string;
  department: string;
  avatarColor: string;
  managerId: string | null;
  children: BuildNode[];
};

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);

    const employees = await db.employee.findMany({
      where: { tenantId: session.tenantId, status: { not: "exited" } },
      select: {
        id: true,
        code: true,
        firstName: true,
        lastName: true,
        designation: true,
        department: true,
        avatarColor: true,
        managerId: true,
      },
    });

    const nodes = new Map<string, BuildNode>();
    for (const e of employees) {
      nodes.set(e.id, {
        id: e.id,
        code: e.code,
        name: `${e.firstName} ${e.lastName}`.trim(),
        designation: e.designation,
        department: e.department,
        avatarColor: e.avatarColor,
        managerId: e.managerId,
        children: [],
      });
    }

    const roots: BuildNode[] = [];
    for (const node of nodes.values()) {
      const parent = node.managerId ? nodes.get(node.managerId) : undefined;
      if (parent && parent !== node) parent.children.push(node);
      else roots.push(node); // no manager, or manager not in the active tree
    }

    // Safety net for malformed manager cycles: attach unreachable nodes at the top.
    const reachable = new Set<BuildNode>();
    const visit = (n: BuildNode) => {
      if (reachable.has(n)) return;
      reachable.add(n);
      n.children.forEach(visit);
    };
    roots.forEach(visit);
    for (const node of nodes.values()) {
      if (!reachable.has(node)) roots.push(node);
    }

    const byName = (a: BuildNode, b: BuildNode) => a.name.localeCompare(b.name);
    roots.sort(byName);

    /** Strip the internal managerId field and sort each level by name. */
    const toNode = (n: BuildNode): OrgChartNode => ({
      id: n.id,
      code: n.code,
      name: n.name,
      designation: n.designation,
      department: n.department,
      avatarColor: n.avatarColor,
      children: n.children.sort(byName).map(toNode),
    });

    let root: OrgChartNode;
    if (roots.length === 1) {
      root = toNode(roots[0]);
    } else {
      root = {
        id: `org-${session.tenantId}`,
        code: tenantCodePrefix(session.tenantName),
        name: session.tenantName,
        designation: "Organisation",
        department: "",
        avatarColor: session.brandColor,
        children: roots.map(toNode),
      };
    }

    return ok({ root });
  });
}

/**
 * HR helpdesk tickets API.
 *
 * GET  /api/tickets — any signed-in user. Query: scope ("mine" | "all"),
 *   status, category, priority. Employee- and manager-role callers are
 *   pinned to "mine" (their own tickets, matched by requester email);
 *   owner/admin/hr default to "all".
 *
 * POST /api/tickets — any signed-in user. Creates a ticket with a
 *   tenant-sequential number ({PREFIX}-HR-1001...), an SLA by priority
 *   (urgent 8h, high 24h, medium 48h, low 72h), the first conversation
 *   message, an HR notification and an audit entry.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify } from "@/lib/api-helpers";
import { tenantCodePrefix, toTicketDto } from "@/app/api/_lib/mappers";
import type { TicketMessage } from "@/lib/types";

const PRIORITIES = ["low", "medium", "high", "urgent"];
const SLA_HOURS: Record<string, number> = { urgent: 8, high: 24, medium: 48, low: 72 };

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const sp = req.nextUrl.searchParams;
    const scopeParam = (sp.get("scope") ?? "").trim();
    const status = (sp.get("status") ?? "").trim();
    const category = (sp.get("category") ?? "").trim();
    const priority = (sp.get("priority") ?? "").trim();

    const scope =
      session.role === "employee" || session.role === "manager"
        ? "mine"
        : scopeParam === "mine"
          ? "mine"
          : "all";

    const where: Prisma.HrTicketWhereInput = { tenantId: session.tenantId };
    if (scope === "mine") {
      // Emails are unique per requester; names are not.
      where.requesterEmail = session.email;
    }
    if (status) where.status = status;
    if (category) where.category = category;
    if (priority) where.priority = priority;

    const rows = await db.hrTicket.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });
    return ok({ items: rows.map(toTicketDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const subject = String(body.subject ?? "").trim();
    const category = String(body.category ?? "").trim();
    const message = String(body.message ?? "").trim();
    const priority = PRIORITIES.includes(String(body.priority)) ? String(body.priority) : "medium";

    if (!subject) return fail("Subject is required.", 400);
    if (!category) return fail("Category is required.", 400);
    if (!message) return fail("Please describe your issue in the message field.", 400);

    // Sequential ticket number: {TENANT}-HR-1001, incremented until unique.
    const prefix = tenantCodePrefix(session.tenantName);
    const existingCount = await db.hrTicket.count({ where: { tenantId: session.tenantId } });
    let seq = existingCount + 1;
    let ticketNo = "";
    for (;;) {
      const candidate = `${prefix}-HR-${1000 + seq}`;
      const clash = await db.hrTicket.findFirst({
        where: { tenantId: session.tenantId, ticketNo: candidate },
        select: { id: true },
      });
      if (!clash) {
        ticketNo = candidate;
        break;
      }
      seq += 1;
    }

    const now = new Date();
    const messages: TicketMessage[] = [
      { author: session.name, role: "requester", content: message, at: now.toISOString() },
    ];

    const ticket = await db.hrTicket.create({
      data: {
        tenantId: session.tenantId,
        ticketNo,
        subject,
        category,
        priority,
        status: "open",
        requesterName: session.name,
        requesterEmail: session.email,
        slaHours: SLA_HOURS[priority],
        messages: JSON.stringify(messages),
      },
    });

    // Notify every HR-side user (owner/admin/hr) in the tenant.
    const hrUsers = await db.user.findMany({
      where: { tenantId: session.tenantId, role: { in: ["owner", "admin", "hr"] } },
      select: { id: true },
    });
    await Promise.all(
      hrUsers.map((u) =>
        notify(session.tenantId, {
          userId: u.id,
          title: "New HR ticket",
          body: `${ticketNo}: "${subject}" raised by ${session.name} (${category}).`,
          type: "ticket",
        })
      )
    );

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "ticket.created",
      entity: "HrTicket",
      entityId: ticket.id,
      summary: `Ticket ${ticketNo} created: "${subject}".`,
    });

    return ok({ item: toTicketDto(ticket) }, { status: 201 });
  });
}

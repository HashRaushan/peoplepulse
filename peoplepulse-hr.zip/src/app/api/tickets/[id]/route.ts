/**
 * HR helpdesk ticket actions API.
 *
 * PATCH /api/tickets/{id} — body { action, ... }:
 *   - reply: append a conversation message (capped at 2000 characters).
 *     Allowed for the requester (matched by requester email — emails are
 *     unique) or owner/admin/hr (HR roles post with role "hr"). Audits
 *     "ticket.replied".
 *   - status: owner/admin/hr only; moving to "resolved" stamps resolvedAt.
 *   - assign: owner/admin/hr only; set or clear the assignee.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { parseJson, toTicketDto } from "@/app/api/_lib/mappers";
import type { TicketMessage } from "@/lib/types";

const TICKET_STATUSES = ["open", "in_progress", "resolved", "closed"];

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const action = String(body.action ?? "");
    const ticket = await db.hrTicket.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!ticket) return fail("Ticket not found.", 404);

    const isHrRole = ["owner", "admin", "hr"].includes(session.role);
    // Emails are unique per requester; matching by name would let same-named
    // users open each other's tickets.
    const isRequester = ticket.requesterEmail === session.email;

    if (action === "reply") {
      if (!isRequester && !isHrRole) {
        return fail("You do not have permission to reply to this ticket.", 403);
      }
      const message = String(body.message ?? "").trim().slice(0, 2000);
      if (!message) return fail("Message is required.", 400);

      const messages = parseJson<TicketMessage[]>(ticket.messages, []);
      messages.push({
        author: session.name,
        role: isHrRole ? "hr" : "requester",
        content: message,
        at: new Date().toISOString(),
      });

      const updated = await db.hrTicket.update({
        where: { id: ticket.id },
        data: { messages: JSON.stringify(messages) },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "ticket.replied",
        entity: "HrTicket",
        entityId: ticket.id,
        summary: `${session.name} replied to ticket ${ticket.ticketNo}.`,
        severity: "info",
      });
      return ok({ item: toTicketDto(updated) });
    }

    if (action === "status") {
      if (!isHrRole) return fail("You do not have permission to update the ticket status.", 403);
      const status = String(body.status ?? "");
      if (!TICKET_STATUSES.includes(status)) {
        return fail("Status must be open, in_progress, resolved or closed.", 400);
      }
      const updated = await db.hrTicket.update({
        where: { id: ticket.id },
        data: { status, ...(status === "resolved" ? { resolvedAt: new Date() } : {}) },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "ticket.status",
        entity: "HrTicket",
        entityId: ticket.id,
        summary: `Ticket ${ticket.ticketNo} marked ${status}.`,
      });
      return ok({ item: toTicketDto(updated) });
    }

    if (action === "assign") {
      if (!isHrRole) return fail("You do not have permission to assign this ticket.", 403);
      const assignedTo =
        body.assignedTo == null ? null : String(body.assignedTo).trim() || null;
      const updated = await db.hrTicket.update({
        where: { id: ticket.id },
        data: { assignedTo },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "ticket.assigned",
        entity: "HrTicket",
        entityId: ticket.id,
        summary: `Ticket ${ticket.ticketNo} assigned to ${assignedTo ?? "unassigned"}.`,
      });
      return ok({ item: toTicketDto(updated) });
    }

    return fail("Unknown action. Use reply, status or assign.", 400);
  });
}

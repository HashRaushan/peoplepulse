/**
 * Expense claims API.
 *
 * GET /api/expenses — any signed-in user. Returns every claim the caller may
 * see plus a role-aware summary:
 *   - employee: own claims only
 *   - manager: own claims + claims of direct reports
 *   - owner/admin/hr: the whole tenant
 * Summary: mySubmitted (my open claims), myApprovedMonthTotal (INR approved or
 * paid with an expense date in the current calendar month), pendingApprovalCount
 * (submitted claims the caller can decide — 0 for plain employees) and
 * orgMonthTotal (org-wide approved+paid this month — 0 unless owner/admin/hr).
 *
 * POST /api/expenses — any signed-in user with a linked employee record.
 * Validates title/category/amount/expenseDate, stores the claim as "submitted"
 * and writes an audit entry.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify, dateOnly } from "@/lib/api-helpers";
import { EXPENSE_CATEGORIES } from "@/lib/constants";
import { fullName, isValidDateOnly, localDate, userIdForEmployee } from "@/app/api/_lib/mappers";
import type { ExpenseClaimDto, ExpensesSummaryDto } from "@/lib/types";

type ClaimWithEmployee = Prisma.ExpenseClaimGetPayload<{ include: { employee: true } }>;

function toClaimDto(c: ClaimWithEmployee): ExpenseClaimDto {
  return {
    id: c.id,
    employeeId: c.employeeId,
    employeeName: fullName(c.employee),
    employeeCode: c.employee.code,
    department: c.employee.department,
    avatarColor: c.employee.avatarColor,
    title: c.title,
    category: c.category,
    amount: c.amount,
    expenseDate: dateOnly(c.expenseDate),
    description: c.description,
    status: c.status as ExpenseClaimDto["status"],
    approverName: c.approverName,
    comment: c.comment,
    decidedAt: c.decidedAt?.toISOString() ?? null,
    paidAt: c.paidAt?.toISOString() ?? null,
    createdAt: c.createdAt.toISOString(),
  };
}

/** [monthStart, monthEnd) window for the current calendar month. */
function currentMonthWindow(): { start: Date; end: Date } {
  const now = new Date();
  return {
    start: new Date(now.getFullYear(), now.getMonth(), 1),
    end: new Date(now.getFullYear(), now.getMonth() + 1, 1),
  };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const isHrRole = ["owner", "admin", "hr"].includes(session.role);

    // Visibility: employees see their own claims, managers also see their direct
    // reports, and owner/admin/hr see the entire tenant.
    const where: Prisma.ExpenseClaimWhereInput = { tenantId: session.tenantId };
    if (session.role === "employee") {
      where.employeeId = session.employeeId ?? "__none__";
    } else if (session.role === "manager") {
      if (!session.employeeId) {
        where.employeeId = "__none__";
      } else {
        where.OR = [
          { employeeId: session.employeeId },
          { employee: { managerId: session.employeeId } },
        ];
      }
    }

    const claims = await db.expenseClaim.findMany({
      where,
      include: { employee: true },
      orderBy: { createdAt: "desc" },
    });

    // ---- Role-aware summary ----
    const month = currentMonthWindow();
    const myId = session.employeeId;
    const myClaims = myId ? claims.filter((c) => c.employeeId === myId) : [];

    const mySubmitted = myClaims.filter((c) => c.status === "submitted").length;
    const myApprovedMonthTotal = myClaims
      .filter(
        (c) =>
          (c.status === "approved" || c.status === "paid") &&
          c.expenseDate >= month.start &&
          c.expenseDate < month.end
      )
      .reduce((sum, c) => sum + c.amount, 0);

    // Claims awaiting a decision by this user: managers decide their direct
    // reports' claims, owner/admin/hr decide everything, employees nothing.
    let pendingApprovalCount = 0;
    if (isHrRole) {
      pendingApprovalCount = claims.filter((c) => c.status === "submitted").length;
    } else if (session.role === "manager" && myId) {
      pendingApprovalCount = claims.filter(
        (c) => c.status === "submitted" && c.employeeId !== myId
      ).length;
    }

    let orgMonthTotal = 0;
    if (isHrRole) {
      const agg = await db.expenseClaim.aggregate({
        where: {
          tenantId: session.tenantId,
          status: { in: ["approved", "paid"] },
          expenseDate: { gte: month.start, lt: month.end },
        },
        _sum: { amount: true },
      });
      orgMonthTotal = agg._sum.amount ?? 0;
    }

    const summary: ExpensesSummaryDto = {
      mySubmitted,
      myApprovedMonthTotal,
      pendingApprovalCount,
      orgMonthTotal,
    };

    return ok({ claims: claims.map(toClaimDto), summary });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) {
      return fail("No employee profile linked to your account.", 400);
    }

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const category = String(body.category ?? "").trim();
    const description = String(body.description ?? "").trim().slice(0, 500);
    const expenseDate = String(body.expenseDate ?? "").trim();

    if (!title) return fail("Please enter a claim title.", 400);
    if (title.length > 120) return fail("Claim title must be 120 characters or fewer.", 400);
    if (!EXPENSE_CATEGORIES.includes(category)) {
      return fail("Please select a valid expense category.", 400);
    }
    if (!isValidDateOnly(expenseDate)) {
      return fail("Expense date must be a valid date (YYYY-MM-DD).", 400);
    }

    const amountNum = Number(body.amount);
    if (!Number.isFinite(amountNum) || !Number.isInteger(amountNum) || amountNum <= 0) {
      return fail("Amount must be a positive whole number (INR).", 400);
    }
    if (amountNum > 99_99_99_999) return fail("Amount exceeds the maximum claim value.", 400);

    const claim = await db.expenseClaim.create({
      data: {
        tenantId: session.tenantId,
        employeeId: session.employeeId,
        title,
        category,
        amount: amountNum,
        expenseDate: localDate(expenseDate),
        description,
        status: "submitted",
      },
      include: { employee: true },
    });

    const employeeUserId = await userIdForEmployee(session.tenantId, claim.employeeId);
    await notify(session.tenantId, {
      userId: employeeUserId,
      title: "Expense claim submitted",
      body: `Your ${category} claim of ₹${amountNum.toLocaleString("en-IN")} ("${title}") has been submitted for approval.`,
      type: "expense",
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "expense.submitted",
      entity: "ExpenseClaim",
      entityId: claim.id,
      summary: `${fullName(claim.employee)} submitted a ${category} claim of ₹${amountNum.toLocaleString("en-IN")} dated ${expenseDate} ("${title}").`,
    });

    return ok({ claim: toClaimDto(claim) }, { status: 201 });
  });
}

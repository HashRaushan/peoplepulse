/**
 * Expense claim decision API.
 *
 * PATCH /api/expenses/{id} — body { action, comment? }:
 *   - approve / reject: allowed for owner/admin/hr always, and for a manager
 *     only when the claim belongs to one of their direct reports. Only
 *     submitted claims can be decided (409 otherwise).
 *   - mark_paid: owner/admin/hr only. Only approved claims can be paid
 *     (409 otherwise).
 *   - cancel: the claim owner only, submitted claims only (409 otherwise).
 * Every outcome notifies the claimant's linked user; approve/reject/mark_paid
 * also write an audit entry (severity "warning" on reject).
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, dateOnly, audit, notify } from "@/lib/api-helpers";
import { fullName, userIdForEmployee } from "@/app/api/_lib/mappers";
import type { ExpenseClaimDto } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

type ClaimWithEmployee = Prisma.ExpenseClaimGetPayload<{ include: { employee: true } }>;

function toClaimDto(c: ClaimWithEmployee): ExpenseClaimDto {
  return {
    id: c.id,
    employeeId: c.employeeId,
    employeeName: fullName(c.employee),
    employeeCode: c.employee.code,
    department: c.employee.department,
    avatarColor: c.employee.avatarColor,
    title: c.title,
    category: c.category,
    amount: c.amount,
    expenseDate: dateOnly(c.expenseDate),
    description: c.description,
    status: c.status as ExpenseClaimDto["status"],
    approverName: c.approverName,
    comment: c.comment,
    decidedAt: c.decidedAt?.toISOString() ?? null,
    paidAt: c.paidAt?.toISOString() ?? null,
    createdAt: c.createdAt.toISOString(),
  };
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const action = String(body.action ?? "");
    const comment =
      body.comment != null && String(body.comment).trim() !== "" ? String(body.comment).slice(0, 300) : null;

    const claim = await db.expenseClaim.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { employee: true },
    });
    if (!claim) return fail("Expense claim not found.", 404);

    const isHrRole = ["owner", "admin", "hr"].includes(session.role);
    const isOwnManager =
      session.role === "manager" && !!session.employeeId && claim.employee.managerId === session.employeeId;
    const amountLabel = `₹${claim.amount.toLocaleString("en-IN")}`;
    const claimantUserId = await userIdForEmployee(session.tenantId, claim.employeeId);
    const claimantName = fullName(claim.employee);

    if (action === "approve" || action === "reject") {
      if (!isHrRole && !isOwnManager) {
        return fail("You do not have permission to decide this expense claim.", 403);
      }
      if (claim.status !== "submitted") {
        return fail("This claim has already been processed.", 409);
      }

      const updated = await db.expenseClaim.update({
        where: { id: claim.id },
        data: {
          status: action === "approve" ? "approved" : "rejected",
          approverName: session.name,
          comment,
          decidedAt: new Date(),
        },
        include: { employee: true },
      });

      await notify(session.tenantId, {
        userId: claimantUserId,
        title: action === "approve" ? "Expense claim approved" : "Expense claim rejected",
        body:
          action === "approve"
            ? `Your ${claim.category} claim ${amountLabel} ("${claim.title}") was approved by ${session.name}.`
            : `Your ${claim.category} claim ${amountLabel} ("${claim.title}") was rejected by ${session.name}.${comment ? ` Note: ${comment}` : ""}`,
        type: "expense",
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: action === "approve" ? "expense.approved" : "expense.rejected",
        entity: "ExpenseClaim",
        entityId: claim.id,
        summary: `${action === "approve" ? "Approved" : "Rejected"} a ${claim.category} claim of ${amountLabel} for ${claimantName} ("${claim.title}").`,
        ...(action === "reject" ? { severity: "warning" as const } : {}),
      });

      return ok({ claim: toClaimDto(updated) });
    }

    if (action === "mark_paid") {
      if (!isHrRole) {
        return fail("Only owner, admin or HR can mark claims as paid.", 403);
      }
      if (claim.status !== "approved") {
        return fail("Only approved claims can be marked as paid.", 409);
      }

      const updated = await db.expenseClaim.update({
        where: { id: claim.id },
        data: { status: "paid", paidAt: new Date() },
        include: { employee: true },
      });

      await notify(session.tenantId, {
        userId: claimantUserId,
        title: "Expense claim paid",
        body: `Your ${claim.category} claim ${amountLabel} ("${claim.title}") has been paid out.`,
        type: "expense",
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "expense.paid",
        entity: "ExpenseClaim",
        entityId: claim.id,
        summary: `Marked a ${claim.category} claim of ${amountLabel} as paid for ${claimantName} ("${claim.title}").`,
      });

      return ok({ claim: toClaimDto(updated) });
    }

    if (action === "cancel") {
      if (session.employeeId !== claim.employeeId) {
        return fail("Only the claim owner can cancel this expense claim.", 403);
      }
      if (claim.status !== "submitted") {
        return fail("Only submitted claims can be cancelled.", 409);
      }

      const updated = await db.expenseClaim.update({
        where: { id: claim.id },
        data: {
          status: "cancelled",
          approverName: session.name,
          comment,
          decidedAt: new Date(),
        },
        include: { employee: true },
      });

      await notify(session.tenantId, {
        userId: claimantUserId,
        title: "Expense claim cancelled",
        body: `Your ${claim.category} claim ${amountLabel} ("${claim.title}") was cancelled.`,
        type: "expense",
      });

      return ok({ claim: toClaimDto(updated) });
    }

    return fail("Unknown action. Use approve, reject, mark_paid or cancel.", 400);
  });
}

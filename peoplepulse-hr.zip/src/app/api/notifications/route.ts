/**
 * Notifications API.
 *
 * GET   /api/notifications — any signed-in user. The 20 most recent tenant
 *   notifications addressed to the caller (broadcasts with no userId plus
 *   notifications targeted at the caller's user id).
 *
 * PATCH /api/notifications — mark notifications as read. Body: { id } to mark
 *   a single notification, or { all: true } to mark everything visible to the
 *   caller. An empty body (or a body without `all`/`id`) is accepted as a
 *   no-op and responds with { ok: true, updated: 0 }.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { toNotificationDto } from "@/app/api/_lib/mappers";

function visibleToUser(userId: string): Prisma.NotificationWhereInput {
  return { OR: [{ userId: null }, { userId }] };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const rows = await db.notification.findMany({
      where: { tenantId: session.tenantId, ...visibleToUser(session.id) },
      orderBy: { createdAt: "desc" },
      take: 20,
    });
    return ok({ items: rows.map(toNotificationDto) });
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth();
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    if (body.all === true) {
      const result = await db.notification.updateMany({
        where: {
          tenantId: session.tenantId,
          read: false,
          ...visibleToUser(session.id),
        },
        data: { read: true },
      });
      return ok({ ok: true, updated: result.count });
    }

    if (body.id != null && String(body.id) !== "") {
      const notification = await db.notification.findFirst({
        where: {
          tenantId: session.tenantId,
          id: String(body.id),
          ...visibleToUser(session.id),
        },
      });
      if (!notification) return fail("Notification not found.", 404);
      await db.notification.update({
        where: { id: notification.id },
        data: { read: true },
      });
      return ok({ ok: true, updated: 1 });
    }

    // Empty body / no `all` and no `id` — accepted as a no-op success.
    return ok({ ok: true, updated: 0 });
  });
}

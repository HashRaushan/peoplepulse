/**
 * Job opening status API.
 *
 * PATCH /api/recruitment/openings/{id} (owner | admin | hr) — update the
 * opening status (open | on_hold | closed).
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toOpeningDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const status = String(body.status ?? "");
    if (!["open", "on_hold", "closed"].includes(status)) {
      return fail("Status must be open, on_hold or closed.", 400);
    }

    const opening = await db.jobOpening.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!opening) return fail("Job opening not found.", 404);

    const updated = await db.jobOpening.update({
      where: { id: opening.id },
      data: { status },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "opening.updated",
      entity: "JobOpening",
      entityId: opening.id,
      summary: `Set "${opening.title}" status to ${status}.`,
    });

    const candidateCount = await db.candidate.count({
      where: { tenantId: session.tenantId, openingId: opening.id },
    });
    return ok({ item: toOpeningDto(updated, candidateCount) });
  });
}

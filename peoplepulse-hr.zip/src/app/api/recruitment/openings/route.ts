/**
 * Recruitment openings API.
 *
 * GET  /api/recruitment/openings (owner | admin | hr | manager) — all tenant
 *   openings with live candidate counts, newest first.
 *
 * POST /api/recruitment/openings (owner | admin | hr) — create a job opening.
 *   Skills are accepted as string[] (or a comma-separated string) and stored
 *   as a JSON string.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toOpeningDto, toNonNegativeInt } from "@/app/api/_lib/mappers";

const EMPLOYMENT_TYPES = ["full_time", "part_time", "contract", "intern"];
const OPENING_STATUSES = ["open", "on_hold", "closed"];

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);
    const [openings, counts] = await Promise.all([
      db.jobOpening.findMany({ where: { tenantId: session.tenantId }, orderBy: { createdAt: "desc" } }),
      db.candidate.groupBy({
        by: ["openingId"],
        where: { tenantId: session.tenantId },
        _count: { _all: true },
      }),
    ]);
    const countById = new Map(counts.map((c) => [c.openingId, c._count._all]));
    return ok({ items: openings.map((o) => toOpeningDto(o, countById.get(o.id) ?? 0)) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    const department = String(body.department ?? "").trim();
    if (!title) return fail("Job title is required.", 400);
    if (!department) return fail("Department is required.", 400);

    const employmentType = EMPLOYMENT_TYPES.includes(String(body.employmentType))
      ? String(body.employmentType)
      : "full_time";
    const status = OPENING_STATUSES.includes(String(body.status)) ? String(body.status) : "open";

    let skills: string[] = [];
    if (Array.isArray(body.skills)) {
      skills = body.skills.map((s) => String(s).trim()).filter(Boolean);
    } else if (typeof body.skills === "string" && body.skills.trim() !== "") {
      skills = body.skills.split(",").map((s) => s.trim()).filter(Boolean);
    }

    const maxSalaryRaw = body.maxSalary == null || body.maxSalary === "" ? null : Number(body.maxSalary);
    const maxSalary =
      maxSalaryRaw != null && Number.isFinite(maxSalaryRaw) && maxSalaryRaw >= 0 ? Math.round(maxSalaryRaw) : null;

    const opening = await db.jobOpening.create({
      data: {
        tenantId: session.tenantId,
        title,
        department,
        location: String(body.location ?? "").trim() || "Bengaluru",
        employmentType,
        openings: Math.max(1, toNonNegativeInt(body.openings, 1)),
        status,
        hiringManager: String(body.hiringManager ?? "").trim() || session.name,
        minExpYears: toNonNegativeInt(body.minExpYears, 0),
        maxSalary,
        skills: JSON.stringify(skills),
        description: String(body.description ?? ""),
      },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "opening.created",
      entity: "JobOpening",
      entityId: opening.id,
      summary: `Created job opening "${title}" (${department}).`,
    });

    return ok({ item: toOpeningDto(opening, 0) }, { status: 201 });
  });
}

/**
 * Candidate pipeline API.
 *
 * PATCH /api/recruitment/candidates/{id} (owner | admin | hr) — move a
 * candidate through the pipeline (stage), set a 1-5 rating or update notes.
 * Setting the stage to "hired" stamps hiredAt.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toCandidateDto } from "@/app/api/_lib/mappers";

const STAGES = ["applied", "screening", "interview", "offer", "hired", "rejected"];

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const candidate = await db.candidate.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!candidate) return fail("Candidate not found.", 404);

    const data: Prisma.CandidateUncheckedUpdateInput = {};

    if (body.stage !== undefined) {
      const stage = String(body.stage);
      if (!STAGES.includes(stage)) {
        return fail("Stage must be applied, screening, interview, offer, hired or rejected.", 400);
      }
      data.stage = stage;
      if (stage === "hired" && !candidate.hiredAt) data.hiredAt = new Date();
    }
    if (body.rating !== undefined && body.rating !== null && body.rating !== "") {
      const rating = Math.round(Number(body.rating));
      if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
        return fail("Rating must be between 1 and 5.", 400);
      }
      data.rating = rating;
    }
    if (body.notes !== undefined) {
      data.notes = body.notes === null ? null : String(body.notes);
    }

    const updated = await db.candidate.update({
      where: { id: candidate.id },
      data,
      include: { opening: true },
    });

    const detail = data.stage ? ` (stage: ${data.stage})` : "";
    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "candidate.updated",
      entity: "Candidate",
      entityId: candidate.id,
      summary: `Updated candidate ${candidate.name}${detail}.`,
    });

    return ok({ item: toCandidateDto(updated) });
  });
}

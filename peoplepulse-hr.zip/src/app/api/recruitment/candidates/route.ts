/**
 * Recruitment candidates API.
 *
 * GET  /api/recruitment/candidates (owner | admin | hr | manager) — the
 *   candidate pipeline with the parent opening title. Query: openingId, stage.
 *   Sorted by most recent application first.
 *
 * POST /api/recruitment/candidates (owner | admin | hr) — add a candidate to
 *   an opening that belongs to the tenant.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toCandidateDto, toNonNegativeInt } from "@/app/api/_lib/mappers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr", "manager"]);
    const sp = req.nextUrl.searchParams;
    const openingId = (sp.get("openingId") ?? "").trim();
    const stage = (sp.get("stage") ?? "").trim();

    const where: Prisma.CandidateWhereInput = { tenantId: session.tenantId };
    if (openingId) where.openingId = openingId;
    if (stage) where.stage = stage;

    const rows = await db.candidate.findMany({
      where,
      include: { opening: true },
      orderBy: { appliedAt: "desc" },
    });
    return ok({ items: rows.map(toCandidateDto) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const openingId = String(body.openingId ?? "").trim();
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    if (!openingId) return fail("Please select a job opening.", 400);
    if (!name) return fail("Candidate name is required.", 400);
    if (!email) return fail("Candidate email is required.", 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Please enter a valid email address.", 400);

    const opening = await db.jobOpening.findFirst({
      where: { tenantId: session.tenantId, id: openingId },
    });
    if (!opening) return fail("The selected job opening was not found.", 404);

    const expectedSalaryRaw =
      body.expectedSalary == null || body.expectedSalary === "" ? null : Number(body.expectedSalary);

    const candidate = await db.candidate.create({
      data: {
        tenantId: session.tenantId,
        openingId: opening.id,
        name,
        email,
        phone: body.phone != null && body.phone !== "" ? String(body.phone) : null,
        source: String(body.source ?? "").trim() || "Careers Page",
        expectedSalary:
          expectedSalaryRaw != null && Number.isFinite(expectedSalaryRaw) && expectedSalaryRaw >= 0
            ? toNonNegativeInt(expectedSalaryRaw, 0)
            : null,
        noticePeriod: body.noticePeriod != null && body.noticePeriod !== "" ? String(body.noticePeriod) : null,
        resumeSummary: body.resumeSummary != null && body.resumeSummary !== "" ? String(body.resumeSummary) : null,
      },
      include: { opening: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "candidate.created",
      entity: "Candidate",
      entityId: candidate.id,
      summary: `Added candidate ${name} to "${opening.title}".`,
    });

    return ok({ item: toCandidateDto(candidate) }, { status: 201 });
  });
}

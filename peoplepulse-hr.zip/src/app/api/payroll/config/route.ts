/**
 * Payroll statutory configuration API.
 *
 * GET   /api/payroll/config (owner | admin | hr) — returns the tenant's
 *   EFFECTIVE configuration: the stored tenant.payrollConfig deep-merged over
 *   the built-in defaults, so partial/stale stored configs can never surface
 *   NaN values.
 *
 * PATCH /api/payroll/config (owner | admin) — accepts a full PayrollConfigDto,
 *   validates the structure and statutory ranges, persists it as JSON on the
 *   tenant and writes a "payroll.config_updated" audit entry.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { mergePayrollConfig } from "@/lib/payroll";
import type { PayrollConfigDto } from "@/lib/types";

const isFiniteNumber = (v: unknown): v is number =>
  typeof v === "number" && Number.isFinite(v);

/**
 * Validate a full PayrollConfigDto payload. Returns a normalised config or an
 * error message (callers map that to a 400).
 */
function validateConfig(raw: unknown): { config: PayrollConfigDto } | { error: string } {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { error: "Invalid request body." };
  }
  const body = raw as Record<string, unknown>;

  const effectiveFrom = typeof body.effectiveFrom === "string" ? body.effectiveFrom.trim() : "";
  if (!effectiveFrom) return { error: "effectiveFrom is required." };
  const currency = typeof body.currency === "string" ? body.currency.trim() : "";
  if (!currency) return { error: "currency is required." };
  const note = typeof body.note === "string" ? body.note : "";
  if (note.length > 2000) return { error: "note must be 2000 characters or fewer." };

  if (!isFiniteNumber(body.basicPercentOfCtc) || body.basicPercentOfCtc < 0.2 || body.basicPercentOfCtc > 0.6) {
    return { error: "basicPercentOfCtc must be between 0.2 and 0.6." };
  }
  if (!isFiniteNumber(body.hraPercentOfBasic) || body.hraPercentOfBasic < 0 || body.hraPercentOfBasic > 1) {
    return { error: "hraPercentOfBasic must be between 0 and 1." };
  }
  if (!isFiniteNumber(body.paidDaysBasis) || !Number.isInteger(body.paidDaysBasis) || body.paidDaysBasis < 26 || body.paidDaysBasis > 31) {
    return { error: "paidDaysBasis must be an integer between 26 and 31." };
  }

  const epf = body.epf as Record<string, unknown> | undefined;
  if (!epf || typeof epf !== "object") return { error: "epf section is required." };
  if (typeof epf.enabled !== "boolean") return { error: "epf.enabled must be a boolean." };
  if (!isFiniteNumber(epf.employeeRate) || epf.employeeRate < 0 || epf.employeeRate > 1) {
    return { error: "epf.employeeRate must be between 0 and 1." };
  }
  if (!isFiniteNumber(epf.wageCeiling) || epf.wageCeiling < 0) {
    return { error: "epf.wageCeiling must be a non-negative number." };
  }

  const esic = body.esic as Record<string, unknown> | undefined;
  if (!esic || typeof esic !== "object") return { error: "esic section is required." };
  if (typeof esic.enabled !== "boolean") return { error: "esic.enabled must be a boolean." };
  if (!isFiniteNumber(esic.employeeRate) || esic.employeeRate < 0 || esic.employeeRate > 1) {
    return { error: "esic.employeeRate must be between 0 and 1." };
  }
  if (!isFiniteNumber(esic.grossCeiling) || esic.grossCeiling < 0) {
    return { error: "esic.grossCeiling must be a non-negative number." };
  }

  const pt = body.professionalTax as Record<string, unknown> | undefined;
  if (!pt || typeof pt !== "object") return { error: "professionalTax section is required." };
  if (typeof pt.state !== "string" || !pt.state.trim()) {
    return { error: "professionalTax.state is required." };
  }
  if (!Array.isArray(pt.slabs) || pt.slabs.length === 0) {
    return { error: "professionalTax.slabs must be a non-empty array." };
  }
  const ptSlabs: { upto: number | null; monthly: number }[] = [];
  for (const s of pt.slabs) {
    if (!s || typeof s !== "object") return { error: "professionalTax.slabs entries must be objects." };
    const slab = s as Record<string, unknown>;
    if (slab.upto !== null && !isFiniteNumber(slab.upto)) {
      return { error: "professionalTax slab 'upto' must be a number or null." };
    }
    if (!isFiniteNumber(slab.monthly) || slab.monthly < 0) {
      return { error: "professionalTax slab 'monthly' must be a non-negative number." };
    }
    ptSlabs.push({ upto: slab.upto === null ? null : (slab.upto as number), monthly: slab.monthly });
  }

  const tds = body.tds as Record<string, unknown> | undefined;
  if (!tds || typeof tds !== "object") return { error: "tds section is required." };
  if (typeof tds.mode !== "string" || !tds.mode.trim()) {
    return { error: "tds.mode is required." };
  }
  if (!isFiniteNumber(tds.annualStandardDeduction) || tds.annualStandardDeduction < 0) {
    return { error: "tds.annualStandardDeduction must be a non-negative number." };
  }
  if (!Array.isArray(tds.slabs) || tds.slabs.length === 0) {
    return { error: "tds.slabs must be a non-empty array." };
  }
  const tdsSlabs: { upto: number | null; rate: number }[] = [];
  for (const s of tds.slabs) {
    if (!s || typeof s !== "object") return { error: "tds.slabs entries must be objects." };
    const slab = s as Record<string, unknown>;
    if (slab.upto !== null && !isFiniteNumber(slab.upto)) {
      return { error: "tds slab 'upto' must be a number or null." };
    }
    if (!isFiniteNumber(slab.rate) || slab.rate < 0 || slab.rate > 1) {
      return { error: "tds slab 'rate' must be between 0 and 1." };
    }
    tdsSlabs.push({ upto: slab.upto === null ? null : (slab.upto as number), rate: slab.rate });
  }

  return {
    config: {
      effectiveFrom,
      currency,
      note,
      basicPercentOfCtc: body.basicPercentOfCtc,
      hraPercentOfBasic: body.hraPercentOfBasic,
      paidDaysBasis: body.paidDaysBasis,
      epf: {
        enabled: epf.enabled as boolean,
        employeeRate: epf.employeeRate as number,
        wageCeiling: epf.wageCeiling as number,
      },
      esic: {
        enabled: esic.enabled as boolean,
        employeeRate: esic.employeeRate as number,
        grossCeiling: esic.grossCeiling as number,
      },
      professionalTax: { state: (pt.state as string).trim(), slabs: ptSlabs },
      tds: {
        mode: (tds.mode as string).trim(),
        annualStandardDeduction: tds.annualStandardDeduction as number,
        slabs: tdsSlabs,
      },
    },
  };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    // The effective config: stored tenant config deep-merged over defaults.
    const tenant = await db.tenant.findUnique({ where: { id: session.tenantId } });
    return ok(mergePayrollConfig(tenant?.payrollConfig));
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"]);
    const raw = await req.json().catch(() => null);

    const result = validateConfig(raw);
    if ("error" in result) return fail(result.error, 400);

    await db.tenant.update({
      where: { id: session.tenantId },
      data: { payrollConfig: JSON.stringify(result.config) },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "payroll.config_updated",
      entity: "Tenant",
      entityId: session.tenantId,
      summary: `Payroll configuration updated (basic ${Math.round(result.config.basicPercentOfCtc * 100)}% of CTC, EPF ${result.config.epf.enabled ? `${(result.config.epf.employeeRate * 100).toFixed(2)}%` : "off"}, ESIC ${result.config.esic.enabled ? `${(result.config.esic.employeeRate * 100).toFixed(2)}%` : "off"}, PT ${result.config.professionalTax.state}).`,
      severity: "info",
    });

    return ok({ item: result.config });
  });
}

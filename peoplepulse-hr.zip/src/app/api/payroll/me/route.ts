import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

/** Employee self-service: own payslips only. */
export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    if (!session.employeeId) return ok({ items: [] });

    const payslips = await db.payslip.findMany({
      where: { employeeId: session.employeeId },
      include: { run: true },
      orderBy: [{ run: { year: "desc" } }, { run: { month: "desc" } }],
    });

    return ok({
      items: payslips.map((p) => ({
        id: p.id,
        label: `${MONTHS[p.run.month - 1]} ${p.run.year}`,
        month: p.run.month,
        year: p.run.year,
        runStatus: p.run.status,
        daysPaid: p.daysPaid,
        lopDays: p.lopDays,
        basic: p.basic,
        hra: p.hra,
        specialAllowance: p.specialAllowance,
        gross: p.gross,
        pf: p.pf,
        esic: p.esic,
        pt: p.pt,
        tds: p.tds,
        otherDeductions: p.otherDeductions,
        net: p.net,
      })),
    });
  });
}

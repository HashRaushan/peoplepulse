import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, num, dateOnly } from "@/lib/api-helpers";
import { computePayslip, mergePayrollConfig } from "@/lib/payroll";
import { triggerWorkflow } from "@/lib/api-helpers";
import type { PayrollRunSummary } from "@/lib/types";

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function toSummary(r: {
  id: string; month: number; year: number; status: string; employeeCount: number;
  grossTotal: number; netTotal: number; processedAt: Date | null; approvedBy: string | null; approvedAt: Date | null;
}): PayrollRunSummary {
  return {
    id: r.id, month: r.month, year: r.year, label: `${MONTHS[r.month - 1]} ${r.year}`,
    status: r.status as PayrollRunSummary["status"], employeeCount: r.employeeCount,
    grossTotal: r.grossTotal, netTotal: r.netTotal,
    processedAt: r.processedAt?.toISOString() ?? null,
    approvedBy: r.approvedBy, approvedAt: r.approvedAt?.toISOString() ?? null,
  };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const runs = await db.payrollRun.findMany({
      where: { tenantId: session.tenantId },
      orderBy: [{ year: "desc" }, { month: "desc" }],
    });
    return ok({ items: runs.map(toSummary) });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const body = await req.json().catch(() => ({}));
    const now = new Date();
    // Month/year must be whole numbers in range — a fractional month like 1.5
    // is rejected rather than silently coerced to a different month.
    const monthRaw = num(String(body.month ?? now.getMonth() + 1), now.getMonth() + 1);
    const month = Math.round(monthRaw);
    if (!Number.isInteger(monthRaw) || !Number.isInteger(month) || month < 1 || month > 12) {
      return fail("Invalid month.", 400);
    }
    const yearRaw = num(String(body.year ?? now.getFullYear()), now.getFullYear());
    const year = Math.round(yearRaw);
    if (!Number.isInteger(yearRaw) || !Number.isInteger(year) || year < 2000 || year > 2100) {
      return fail("Invalid year.", 400);
    }

    const existing = await db.payrollRun.findFirst({ where: { tenantId: session.tenantId, month, year } });
    if (existing) return fail(`A payroll run for ${MONTHS[month - 1]} ${year} already exists.`, 409);

    const tenant = await db.tenant.findUnique({ where: { id: session.tenantId } });
    // Deep-merge the stored config over the defaults section by section so a
    // partial tenant.payrollConfig can never produce NaN components.
    const config = mergePayrollConfig(tenant?.payrollConfig);

    const employees = await db.employee.findMany({
      where: { tenantId: session.tenantId, status: { in: ["active", "probation", "notice"] } },
    });
    if (employees.length === 0) return fail("No active employees to process payroll for.", 400);

    const run = await db.payrollRun.create({
      data: { tenantId: session.tenantId, month, year, status: "draft" },
    });

    let grossTotal = 0, netTotal = 0, lopTotal = 0;
    for (const emp of employees) {
      // LOP approximation from absent days this month
      const monthStart = new Date(year, month - 1, 1);
      const monthEnd = new Date(year, month, 0);
      const absents = await db.attendanceRecord.count({
        where: { employeeId: emp.id, date: { gte: monthStart, lte: monthEnd }, status: "absent" },
      });
      // lopAmount is reported in the audit summary; the payslip row itself
      // persists lopDays/daysPaid.
      const { lopAmount, ...p } = computePayslip(emp.ctc, absents, config);
      await db.payslip.create({ data: { tenantId: session.tenantId, runId: run.id, employeeId: emp.id, ...p } });
      grossTotal += p.gross; netTotal += p.net; lopTotal += lopAmount;
    }

    const updated = await db.payrollRun.update({
      where: { id: run.id },
      data: {
        employeeCount: employees.length, grossTotal, netTotal,
        processedBy: session.name, processedAt: new Date(),
      },
    });

    await audit(session.tenantId, {
      actorName: session.name, actorRole: session.role, action: "payroll.processed",
      entity: "PayrollRun", entityId: run.id,
      summary: `Processed ${MONTHS[month - 1]} ${year} payroll draft for ${employees.length} employees (gross ₹${grossTotal.toLocaleString("en-IN")}${lopTotal > 0 ? `, incl. ₹${lopTotal.toLocaleString("en-IN")} loss of pay` : ""}).`,
      severity: "warning",
    });

    return ok({ run: toSummary(updated) }, { status: 201 });
  });
}

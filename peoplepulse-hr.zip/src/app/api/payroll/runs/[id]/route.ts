import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify, triggerWorkflow } from "@/lib/api-helpers";
import { userIdForEmployee } from "@/app/api/_lib/mappers";
import type { PayrollRunDto, PayslipDto } from "@/lib/types";

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;
    const run = await db.payrollRun.findFirst({
      where: { id, tenantId: session.tenantId },
      include: { payslips: { include: { employee: true }, orderBy: { employee: { code: "asc" } } } },
    });
    if (!run) return fail("Payroll run not found.", 404);

    const payslips: PayslipDto[] = run.payslips.map((p) => ({
      id: p.id, employeeId: p.employeeId, employeeCode: p.employee.code,
      employeeName: `${p.employee.firstName} ${p.employee.lastName}`,
      department: p.employee.department, designation: p.employee.designation,
      daysPaid: p.daysPaid, lopDays: p.lopDays, basic: p.basic, hra: p.hra,
      specialAllowance: p.specialAllowance, gross: p.gross, pf: p.pf, esic: p.esic,
      pt: p.pt, tds: p.tds, otherDeductions: p.otherDeductions, net: p.net,
    }));

    const dto: PayrollRunDto = {
      id: run.id, month: run.month, year: run.year, label: `${MONTHS[run.month - 1]} ${run.year}`,
      status: run.status as PayrollRunDto["status"], employeeCount: run.employeeCount,
      grossTotal: run.grossTotal, netTotal: run.netTotal,
      processedAt: run.processedAt?.toISOString() ?? null,
      approvedBy: run.approvedBy, approvedAt: run.approvedAt?.toISOString() ?? null,
      payslips,
    };
    return ok(dto);
  });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    const run = await db.payrollRun.findFirst({ where: { id, tenantId: session.tenantId } });
    if (!run) return fail("Payroll run not found.", 404);

    let status = run.status;
    if (action === "submit_review") {
      if (run.status !== "draft") return fail("Only draft runs can be submitted for review.", 400);
      status = "in_review";
      await triggerWorkflow(session.tenantId, "payroll.in_review", {
        trigger: "payroll.run_submitted",
        summary: `Payroll run ${MONTHS[run.month - 1]} ${run.year} submitted for review by ${session.name}`,
        steps: [
          { name: "Validate payslips", detail: `${run.employeeCount} payslips validated without errors`, ok: true },
          { name: "Notify approvers", detail: `Approval request sent to organisation owners`, ok: true },
        ],
      });
    } else if (action === "approve") {
      if (run.status !== "in_review") return fail("Run must be in review before approval.", 400);
      status = "approved";
    } else if (action === "mark_paid") {
      if (run.status !== "approved") return fail("Run must be approved before marking as paid.", 400);
      status = "paid";
    } else {
      return fail("Unknown action. Use submit_review, approve or mark_paid.", 400);
    }

    const updated = await db.payrollRun.update({
      where: { id: run.id },
      data: {
        status,
        approvedBy: action === "approve" ? session.name : run.approvedBy,
        approvedAt: action === "approve" ? new Date() : run.approvedAt,
        paidAt: action === "mark_paid" ? new Date() : run.paidAt,
      },
    });

    // When a run is marked paid, notify every affected employee's linked user
    // (one notification per user, batched).
    if (action === "mark_paid") {
      const payslips = await db.payslip.findMany({
        where: { runId: run.id },
        select: { employeeId: true },
      });
      const userIds = new Set<string>();
      for (const p of payslips) {
        const userId = await userIdForEmployee(session.tenantId, p.employeeId);
        if (userId) userIds.add(userId);
      }
      const label = `${MONTHS[run.month - 1]} ${run.year}`;
      await Promise.all(
        [...userIds].map((userId) =>
          notify(session.tenantId, {
            userId,
            title: "Payslip paid",
            body: `Your ${label} payslip has been paid`,
            type: "payroll",
          })
        )
      );
    }

    await audit(session.tenantId, {
      actorName: session.name, actorRole: session.role, action: `payroll.${action}`,
      entity: "PayrollRun", entityId: run.id,
      summary: `Payroll run ${MONTHS[run.month - 1]} ${run.year} moved to ${status.replace("_", " ")}.`,
      severity: "warning",
    });

    return ok({
      run: {
        id: updated.id, month: updated.month, year: updated.year,
        label: `${MONTHS[updated.month - 1]} ${updated.year}`, status: updated.status,
        employeeCount: updated.employeeCount, grossTotal: updated.grossTotal,
        netTotal: updated.netTotal, processedAt: updated.processedAt?.toISOString() ?? null,
        approvedBy: updated.approvedBy, approvedAt: updated.approvedAt?.toISOString() ?? null,
      },
    });
  });
}

import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok, dateOnly } from "@/lib/api-helpers";
import type {
  AdminDashboard, EmployeeDashboard, LeaveRequestDto, AnnouncementDto, HolidayDto,
  LeaveBalanceDto,
} from "@/lib/types";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const now = new Date();
    const today = dateOnly(now);
    const year = now.getFullYear();

    const isHr = ["owner", "admin", "hr"].includes(session.role);
    const isManager = session.role === "manager" || isHr;

    if (isManager) return adminDashboard(session.tenantId, today, year);
    return employeeDashboard(session, today, year);
  });
}

async function adminDashboard(tenantId: string, today: string, year: number) {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const daysAgo30 = new Date(now); daysAgo30.setDate(daysAgo30.getDate() - 30);
  const daysAgo90 = new Date(now); daysAgo90.setDate(daysAgo90.getDate() - 90);
  const daysAgo365 = new Date(now); daysAgo365.setDate(daysAgo365.getDate() - 365);

  const [
    employees, todayRecords, pendingLeaves, holidays, announcements, payrollRuns,
    tickets, joiners30, exits30, exits365,
  ] = await Promise.all([
    db.employee.findMany({ where: { tenantId }, include: { leaveBalances: true } }),
    db.attendanceRecord.findMany({ where: { tenantId, date: new Date(`${today}T00:00:00`) } }),
    db.leaveRequest.findMany({
      where: { tenantId, status: "pending" },
      include: { employee: true, leaveType: true },
      orderBy: { createdAt: "desc" },
      take: 8,
    }),
    db.holiday.findMany({ where: { tenantId, date: { gte: now } }, orderBy: { date: "asc" }, take: 4 }),
    db.announcement.findMany({ where: { tenantId }, orderBy: [{ pinned: "desc" }, { createdAt: "desc" }], take: 3 }),
    db.payrollRun.findMany({ where: { tenantId }, orderBy: [{ year: "desc" }, { month: "desc" }] }),
    db.hrTicket.count({ where: { tenantId, status: { in: ["open", "in_progress"] } } }),
    db.employee.count({ where: { tenantId, joinDate: { gte: daysAgo30 }, status: { not: "exited" } } }),
    db.employee.count({ where: { tenantId, exitDate: { gte: daysAgo30 } } }),
    db.employee.count({ where: { tenantId, exitDate: { gte: daysAgo365 } } }),
  ]);

  const active = employees.filter((e) => e.status !== "exited");
  const presentToday = todayRecords.filter((r) => ["present", "late", "wfh"].includes(r.status)).length;
  const workingToday = now.getDay() !== 0;
  const onLeaveToday = todayRecords.filter((r) => r.status === "leave").length;

  // Headcount trend (last 12 months)
  const headcountTrend: { month: string; count: number }[] = [];
  for (let m = 11; m >= 0; m--) {
    const d = new Date(now.getFullYear(), now.getMonth() - m, 1);
    const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    const count = employees.filter((e) => e.joinDate <= end && (!e.exitDate || e.exitDate > end)).length;
    headcountTrend.push({ month: d.toLocaleString("en-IN", { month: "short" }), count });
  }

  // Attrition trend (exits per month, last 12 months) + annualised rate
  const attritionTrend: { month: string; exits: number }[] = [];
  for (let m = 11; m >= 0; m--) {
    const d = new Date(now.getFullYear(), now.getMonth() - m, 1);
    const start = new Date(d.getFullYear(), d.getMonth(), 1);
    const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    const exits = employees.filter((e) => e.exitDate && e.exitDate >= start && e.exitDate <= end).length;
    attritionTrend.push({ month: d.toLocaleString("en-IN", { month: "short" }), exits });
  }
  const attritionRate = active.length > 0 ? (exits365 / active.length) * 100 : 0;

  // Department split
  const deptMap = new Map<string, number>();
  for (const e of active) deptMap.set(e.department, (deptMap.get(e.department) ?? 0) + 1);
  const departmentSplit = [...deptMap.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // Attendance trend (present % last 14 working days)
  const allRecent = await db.attendanceRecord.findMany({
    where: { tenantId, date: { gte: new Date(now.getTime() - 27 * 86400000) } },
    select: { date: true, status: true },
  });
  const attendanceTrend: { date: string; presentPct: number }[] = [];
  for (let d = 27; d >= 0; d--) {
    const day = new Date(now); day.setDate(day.getDate() - d);
    if (day.getDay() === 0) continue;
    const key = dateOnly(day);
    const recs = allRecent.filter((r) => dateOnly(r.date) === key);
    if (recs.length === 0) continue;
    const present = recs.filter((r) => ["present", "late", "wfh"].includes(r.status)).length;
    attendanceTrend.push({ date: key.slice(5), presentPct: Math.round((present / recs.length) * 100) });
    if (attendanceTrend.length >= 14) break;
  }

  // Leave utilization (aggregate by type)
  const leaveTypes = await db.leaveType.findMany({ where: { tenantId } });
  const leaveUtilization = leaveTypes.map((lt) => {
    const balances = employees.flatMap((e) => e.leaveBalances).filter((b) => b.leaveTypeId === lt.id && b.year === year);
    const entitled = balances.reduce((s, b) => s + b.entitled, 0);
    const used = balances.reduce((s, b) => s + b.used, 0);
    return { name: lt.name, used, entitled };
  });

  const currentRun = payrollRuns[0];
  const openRoles = await db.jobOpening.count({ where: { tenantId, status: "open" } });

  // Engagement (real numbers): survey participation and average pulse over
  // the last 90 days. pulseScore is the mean of all rating_10 answers in the
  // window scaled to 0-100 (null when nobody answered a rating question);
  // participation is responses / non-exited employees.
  const [surveyResponses90d, ratingAnswers] = await Promise.all([
    db.surveyResponse.count({ where: { tenantId, submittedAt: { gte: daysAgo90 } } }),
    db.surveyAnswer.findMany({
      where: {
        tenantId,
        response: { submittedAt: { gte: daysAgo90 } },
        question: { type: "rating_10" },
      },
      select: { value: true },
    }),
  ]);
  const pulseScore =
    ratingAnswers.length > 0
      ? Math.round(
          (ratingAnswers.reduce((sum, a) => sum + Number(a.value), 0) / ratingAnswers.length) * 10
        )
      : null;
  const participation =
    active.length > 0 ? Math.round((surveyResponses90d / active.length) * 100) : 0;
  const pendingLeaveDtos: LeaveRequestDto[] = pendingLeaves.map((lr) => ({
    id: lr.id,
    employeeId: lr.employeeId,
    employeeName: `${lr.employee.firstName} ${lr.employee.lastName}`,
    employeeCode: lr.employee.code,
    department: lr.employee.department,
    avatarColor: lr.employee.avatarColor,
    leaveTypeId: lr.leaveTypeId,
    typeName: lr.leaveType.name,
    startDate: dateOnly(lr.startDate),
    endDate: dateOnly(lr.endDate),
    days: lr.days,
    reason: lr.reason,
    status: "pending",
    approverName: null,
    comment: null,
    decidedAt: null,
    createdAt: lr.createdAt.toISOString(),
  }));

  const data: AdminDashboard = {
    kpis: {
      totalEmployees: active.length,
      activeToday: presentToday,
      presentPct: workingToday && active.length > 0 ? Math.round((presentToday / active.length) * 100) : 0,
      onLeaveToday,
      pendingApprovals: pendingLeaves.length,
      openTickets: tickets,
      attritionRate: Math.round(attritionRate * 10) / 10,
      headcountChange30d: joiners30 - exits30,
      newJoiners30d: joiners30,
      exits30d: exits30,
      monthlyPayrollCost: currentRun?.grossTotal ?? 0,
      openRoles,
    },
    headcountTrend,
    attritionTrend,
    departmentSplit,
    attendanceTrend,
    leaveUtilization,
    pendingLeaveRequests: pendingLeaveDtos,
    upcomingHolidays: holidays.map((h): HolidayDto => ({ id: h.id, name: h.name, date: dateOnly(h.date), type: h.type as "public" | "optional" })),
    recentAnnouncements: announcements.map((a): AnnouncementDto => ({
      id: a.id, title: a.title, body: a.body, category: a.category,
      authorName: a.authorName, pinned: a.pinned,
      acknowledgedCount: a.acknowledgedCount, createdAt: a.createdAt.toISOString(),
    })),
    payroll: {
      label: currentRun ? `${["January","February","March","April","May","June","July","August","September","October","November","December"][currentRun.month - 1]} ${currentRun.year}` : "—",
      status: (currentRun?.status ?? "draft") as "draft" | "in_review" | "approved" | "paid",
      netTotal: currentRun?.netTotal ?? 0,
      employeeCount: currentRun?.employeeCount ?? 0,
    },
    engagement: { pulseScore, participation },
  };

  return ok(data);
}

async function employeeDashboard(session: { tenantId: string; employeeId: string | null; email: string; name: string }, today: string, year: number) {
  if (!session.employeeId) {
    return ok({
      greeting: { firstName: session.name.split(" ")[0], designation: "—", department: "—" },
      myAttendance: { present: 0, wfh: 0, late: 0, leave: 0, absent: 0, avgHours: 0, todayStatus: null },
      myBalances: [], myPayslips: [], myPendingRequests: [],
      upcomingHolidays: [], announcements: [], onboardingTasks: [],
    } satisfies EmployeeDashboard);
  }

  const empId = session.employeeId;
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const [employee, records, balances, payslips, requests, holidays, announcements, onboarding, todayRec] =
    await Promise.all([
      db.employee.findUnique({ where: { id: empId } }),
      db.attendanceRecord.findMany({
        where: { employeeId: empId, date: { gte: monthStart } },
        orderBy: { date: "desc" },
      }),
      db.leaveBalance.findMany({ where: { employeeId: empId, year }, include: { leaveType: true } }),
      db.payslip.findMany({
        where: { employeeId: empId },
        include: { run: true },
        orderBy: [{ run: { year: "desc" } }, { run: { month: "desc" } }],
        take: 6,
      }),
      db.leaveRequest.findMany({
        where: { employeeId: empId },
        include: { leaveType: true },
        orderBy: { createdAt: "desc" },
        take: 10,
      }),
      db.holiday.findMany({ where: { tenantId: session.tenantId, date: { gte: now } }, orderBy: { date: "asc" }, take: 4 }),
      db.announcement.findMany({ where: { tenantId: session.tenantId }, orderBy: [{ pinned: "desc" }, { createdAt: "desc" }], take: 4 }),
      db.onboardingTask.findMany({ where: { employeeId: empId }, orderBy: { order: "asc" } }),
      db.attendanceRecord.findFirst({ where: { employeeId: empId, date: new Date(`${today}T00:00:00`) } }),
    ]);

  if (!employee) return ok({ error: "Employee record not found" }, { status: 404 });

  const hoursList = records.map((r) => r.hours).filter((h): h is number => h !== null);
  const data: EmployeeDashboard = {
    greeting: {
      firstName: employee.firstName,
      designation: employee.designation,
      department: employee.department,
    },
    myAttendance: {
      present: records.filter((r) => r.status === "present").length,
      wfh: records.filter((r) => r.status === "wfh").length,
      late: records.filter((r) => r.status === "late").length,
      leave: records.filter((r) => r.status === "leave").length,
      absent: records.filter((r) => r.status === "absent").length,
      avgHours: hoursList.length ? Math.round((hoursList.reduce((a, b) => a + b, 0) / hoursList.length) * 10) / 10 : 0,
      todayStatus: todayRec?.status ?? null,
    },
    myBalances: balances.map((b): LeaveBalanceDto => ({
      leaveTypeId: b.leaveTypeId, name: b.leaveType.name, code: b.leaveType.code,
      entitled: b.entitled, used: b.used, pending: b.pending,
      available: b.entitled - b.used - b.pending,
    })),
    myPayslips: payslips.map((p) => ({
      id: p.id,
      label: `${["January","February","March","April","May","June","July","August","September","October","November","December"][p.run.month - 1]} ${p.run.year}`,
      net: p.net,
      status: p.run.status as "draft" | "in_review" | "approved" | "paid",
    })),
    myPendingRequests: requests
      .filter((r) => r.status === "pending")
      .map((r) => ({
        id: r.id, employeeId: r.employeeId, employeeName: `${employee.firstName} ${employee.lastName}`,
        employeeCode: employee.code, department: employee.department, avatarColor: employee.avatarColor,
        leaveTypeId: r.leaveTypeId, typeName: r.leaveType.name,
        startDate: dateOnly(r.startDate), endDate: dateOnly(r.endDate), days: r.days,
        reason: r.reason, status: "pending" as const, approverName: null, comment: null,
        decidedAt: null, createdAt: r.createdAt.toISOString(),
      })),
    upcomingHolidays: holidays.map((h): HolidayDto => ({ id: h.id, name: h.name, date: dateOnly(h.date), type: h.type as "public" | "optional" })),
    announcements: announcements.map((a): AnnouncementDto => ({
      id: a.id, title: a.title, body: a.body, category: a.category, authorName: a.authorName,
      pinned: a.pinned, acknowledgedCount: a.acknowledgedCount, createdAt: a.createdAt.toISOString(),
    })),
    onboardingTasks: onboarding.map((t) => ({
      id: t.id, title: t.title, category: t.category, assignee: t.assignee,
      dueDate: dateOnly(t.dueDate), status: t.status as "pending" | "in_progress" | "done", order: t.order,
    })),
  };

  return ok(data);
}

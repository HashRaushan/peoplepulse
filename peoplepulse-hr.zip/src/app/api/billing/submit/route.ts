/**
 * Payment reference (UTR) submission.
 * POST /api/billing/submit — workspace owner/admin (pending workspaces included).
 *
 * Body: { utr, amount, payerName, paidAt ("YYYY-MM-DD"), method ("upi"|"bank"),
 *         note?, plan?, cycle?, seats? }
 *
 * On success the platform admin is notified by email + in-app notification and
 * must verify the reference against their bank statement before approving.
 * UTRs are globally unique — a reference number can only ever be claimed once.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { notifyPlatformAdmin } from "@/lib/approval";
import { emailAdminPaymentSubmitted } from "@/lib/mailer";
import { computePlanPrice } from "@/lib/billing";
import { isPaidPlan, isBillingCycle } from "@/lib/plan-state";
import { isValidDateOnly, localDate } from "@/app/api/_lib/mappers";
import { toPaymentProofDto } from "@/app/api/_lib/mappers";

const UTR_RE = /^[A-Z0-9]{6,25}$/;

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"], { pendingOk: true });
    const raw = await req.json().catch(() => ({}));
    const body = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;

    const utr = String(body.utr ?? "").trim().toUpperCase();
    const payerName = String(body.payerName ?? "").trim();
    const method = body.method === "upi" ? "upi" : "bank";
    const note = String(body.note ?? "").trim();
    const paidAtRaw = String(body.paidAt ?? "").trim();

    if (!UTR_RE.test(utr)) {
      return fail(
        "Enter a valid transaction reference — 6 to 25 letters/digits, exactly as shown in your bank statement or UPI app.",
        400
      );
    }
    if (!payerName) return fail("Enter the name the payment was made from.", 400);
    if (!isValidDateOnly(paidAtRaw)) return fail("Enter the date you made the payment.", 400);

    const tenant = await db.tenant.findUnique({ where: { id: session.tenantId } });
    if (!tenant) return fail("Workspace not found.", 404);

    // Optional plan change submitted together with the payment.
    let plan = tenant.plan;
    let cycle: "monthly" | "annual" = tenant.billingCycle === "annual" ? "annual" : "monthly";
    let seats = tenant.seats;
    const reqPlan = String(body.plan ?? "");
    if (reqPlan && isPaidPlan(reqPlan)) {
      plan = reqPlan;
      if (isBillingCycle(String(body.cycle ?? ""))) cycle = body.cycle as "monthly" | "annual";
      const reqSeats = Number(body.seats ?? 0);
      if (Number.isFinite(reqSeats) && reqSeats >= 1 && reqSeats <= 10000) seats = Math.floor(reqSeats);
    }
    if (!isPaidPlan(plan)) {
      return fail("Choose a paid plan before submitting your payment reference.", 400);
    }

    const price = computePlanPrice(plan, cycle, seats);
    const amount = Number(body.amount);
    const finalAmount =
      Number.isFinite(amount) && amount > 0 ? Math.round(amount) : price.total;

    // Global UTR uniqueness — one transaction reference can only be claimed once.
    const duplicate = await db.paymentProof.findUnique({ where: { utr } });
    if (duplicate) {
      return fail(
        "This transaction reference has already been submitted. Check your bank statement and use the correct reference number.",
        409
      );
    }

    // Supersede any previous pending submission from this workspace.
    await db.paymentProof.updateMany({
      where: { tenantId: tenant.id, status: "submitted" },
      data: { status: "superseded", reviewNote: "Replaced by a newer submission", reviewedAt: new Date() },
    });

    const proof = await db.paymentProof.create({
      data: {
        tenantId: tenant.id,
        utr,
        amount: finalAmount,
        payerName,
        paidAt: localDate(paidAtRaw),
        method,
        note: note || null,
        plan,
        cycle,
        seats,
        status: "submitted",
      },
    });

    // Persist the requested plan on the tenant so approval activates exactly this.
    await db.tenant.update({
      where: { id: tenant.id },
      data: { plan, billingCycle: cycle, seats },
    });

    await audit(tenant.id, {
      actorName: session.name,
      actorRole: session.role,
      action: "payment.submitted",
      entity: "PaymentProof",
      entityId: proof.id,
      summary: `Payment reference ${utr} (${method === "upi" ? "UPI" : "bank"}) submitted for ${plan} (${cycle}, ${seats} seats).`,
      severity: "info",
    });

    await emailAdminPaymentSubmitted({
      companyName: tenant.name,
      ownerName: session.name,
      ownerEmail: session.email,
      utr,
      amount: finalAmount,
      payerName,
      paidAt: paidAtRaw,
      method,
      plan,
      cycle,
      seats,
      note: note || null,
    });
    await notifyPlatformAdmin(
      `Payment submitted: ${tenant.name}`,
      `${session.name} submitted reference ${utr} for ₹${finalAmount.toLocaleString("en-IN")} (${plan}, ${cycle}, ${seats} seats). Verify it against your bank statement, then approve in Platform Admin → Tenants.`
    );

    return ok({ proof: toPaymentProofDto(proof) }, { status: 201 });
  });
}

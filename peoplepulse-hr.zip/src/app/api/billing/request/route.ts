/**
 * Change the requested plan/cycle/seats before (or while) submitting payment.
 * PATCH /api/billing/request — workspace owner/admin (pending workspaces included).
 *
 * Only allowed while the workspace is blocked (pending approval, expired trial
 * or renewal due) — active tenants contact the platform admin to change plans.
 * "trial" is accepted ONLY for first-time pending signups (not expired trials).
 *
 * Body: { plan: "trial"|"starter"|"growth"|"professional", cycle: "monthly"|"annual", seats: number }
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { computePlanPrice } from "@/lib/billing";
import { blockState, isPaidPlan, isBillingCycle } from "@/lib/plan-state";

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"], { pendingOk: true });
    const raw = await req.json().catch(() => ({}));
    const body = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;

    const plan = String(body.plan ?? "");
    const cycle = String(body.cycle ?? "monthly");
    const seats = Number(body.seats ?? 0);

    const tenant = await db.tenant.findUnique({ where: { id: session.tenantId } });
    if (!tenant) return fail("Workspace not found.", 404);

    // Only while blocked — active workspaces change plans via the platform admin.
    if (!session.superAdmin && !blockState(tenant)) {
      return fail("Your plan can only be changed while your workspace is awaiting activation or renewal.", 400);
    }

    const isTrial = plan === "trial";
    if (!isTrial && !isPaidPlan(plan)) return fail("Choose a valid plan.", 400);
    if (isTrial && tenant.planStatus !== "pending") {
      return fail("The free trial is only available for new signups.", 400);
    }
    if (!isBillingCycle(cycle)) return fail("Choose a valid billing cycle.", 400);
    if (!isTrial && (!Number.isFinite(seats) || seats < 1 || seats > 10000)) {
      return fail("Seats must be between 1 and 10,000.", 400);
    }

    const updated = await db.tenant.update({
      where: { id: tenant.id },
      data: isTrial ? { plan: "trial" } : { plan, billingCycle: cycle, seats: Math.floor(seats) },
    });

    const price = isPaidPlan(updated.plan)
      ? computePlanPrice(updated.plan, updated.billingCycle === "annual" ? "annual" : "monthly", updated.seats)
      : null;
    return ok({
      config: {
        plan: updated.plan,
        cycle: updated.billingCycle === "annual" ? "annual" : "monthly",
        seats: updated.seats,
      },
      price,
    });
  });
}

/**
 * Billing overview for the buyer's payment screen.
 * GET /api/billing/overview — any signed-in user (pending workspaces included).
 *
 * Returns the platform's active payment methods (bank/UPI), this workspace's
 * payment submissions, the current plan configuration and the price breakdown.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok, fail } from "@/lib/api-helpers";
import { ensureDefaultPaymentMethods } from "@/lib/approval";
import { computePlanPrice } from "@/lib/billing";
import { blockState, isPaidPlan } from "@/lib/plan-state";
import { toPaymentMethodDto, toPaymentProofDto } from "@/app/api/_lib/mappers";
import type { BillingOverviewDto } from "@/lib/types";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(undefined, { pendingOk: true });

    await ensureDefaultPaymentMethods();

    const [methods, proofs, tenant] = await Promise.all([
      db.paymentMethod.findMany({ where: { active: true }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] }),
      db.paymentProof.findMany({ where: { tenantId: session.tenantId }, orderBy: { createdAt: "desc" }, take: 10 }),
      db.tenant.findUnique({ where: { id: session.tenantId } }),
    ]);
    if (!tenant) return fail("Workspace not found.", 404);

    const price = isPaidPlan(tenant.plan)
      ? computePlanPrice(tenant.plan, tenant.billingCycle === "annual" ? "annual" : "monthly", tenant.seats)
      : null;

    const payload: BillingOverviewDto = {
      methods: methods.map(toPaymentMethodDto),
      proofs: proofs.map(toPaymentProofDto),
      config: {
        plan: tenant.plan,
        cycle: tenant.billingCycle === "annual" ? "annual" : "monthly",
        seats: tenant.seats,
        planStatus: tenant.planStatus,
        blocked: session.superAdmin ? null : blockState(tenant),
        statusReason: tenant.statusReason,
        trialEndsAt: tenant.trialEndsAt ? tenant.trialEndsAt.toISOString() : null,
        paidUntil: tenant.paidUntil ? tenant.paidUntil.toISOString() : null,
      },
      price,
    };

    return ok(payload);
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, num } from "@/lib/api-helpers";
import type { LeadDto } from "@/lib/types";

export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireAuth(["owner", "admin"]);
    const sp = req.nextUrl.searchParams;
    const page = Math.max(1, num(sp.get("page"), 1));
    const pageSize = Math.min(100, Math.max(1, num(sp.get("pageSize"), 50)));
    const [rows, total] = await Promise.all([
      db.lead.findMany({ orderBy: { createdAt: "desc" }, skip: (page - 1) * pageSize, take: pageSize }),
      db.lead.count(),
    ]);
    const items: LeadDto[] = rows.map((r) => ({
      id: r.id, name: r.name, email: r.email, company: r.company,
      companySize: r.companySize, plan: r.plan, message: r.message,
      status: r.status as LeadDto["status"], createdAt: r.createdAt.toISOString(),
    }));
    return ok({ items, total, page, pageSize });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const company = String(body.company ?? "").trim();
    if (!name || !email || !company) return fail("Name, email and company are required.", 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Please enter a valid email address.", 400);

    await db.lead.create({
      data: {
        name,
        email,
        company,
        companySize: String(body.companySize ?? ""),
        plan: String(body.plan ?? "growth"),
        message: String(body.message ?? "").slice(0, 2000),
        source: String(body.source ?? "website"),
      },
    });
    return ok({ success: true }, { status: 201 });
  });
}

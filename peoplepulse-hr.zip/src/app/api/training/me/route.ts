/**
 * My learning API.
 *
 * GET /api/training/me — any signed-in user. Returns the caller's enrollments
 * (with course info) ordered by enrolledAt desc. Employees without a linked
 * employee record get an empty list.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import type { MyLearningDto } from "@/lib/types";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();

    if (!session.employeeId) return ok({ items: [] });

    const enrollments = await db.trainingEnrollment.findMany({
      where: { tenantId: session.tenantId, employeeId: session.employeeId },
      include: { course: true },
      orderBy: { enrolledAt: "desc" },
    });

    const items: MyLearningDto[] = enrollments.map((e) => ({
      id: e.id,
      courseId: e.courseId,
      title: e.course.title,
      category: e.course.category,
      mode: e.course.mode,
      durationHours: e.course.durationHours,
      mandatory: e.course.mandatory,
      status: e.status,
      progress: e.progress,
      score: e.score,
      enrolledAt: e.enrolledAt.toISOString(),
      completedAt: e.completedAt?.toISOString() ?? null,
    }));

    return ok({ items });
  });
}

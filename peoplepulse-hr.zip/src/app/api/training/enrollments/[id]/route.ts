/**
 * Training enrollment progress API.
 *
 * PATCH /api/training/enrollments/{id} — own enrollment only (owner/admin/hr
 * may update anyone's). Body:
 *   - { progress: number } — clamped to 0-100. Status becomes "in_progress"
 *     when progress is between 1-99, auto "completed" (+ completedAt) at 100,
 *     and "enrolled" at 0.
 *   - { action: "complete", score? } — marks completed, progress 100,
 *     completedAt now. Score must be an integer between 0 and 100.
 * Both paths write an audit entry.
 */
import { NextRequest } from "next/server";
import type { TrainingEnrollment, TrainingCourse } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify } from "@/lib/api-helpers";
import { fullName } from "@/app/api/_lib/mappers";
import type { MyLearningDto } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

type EnrollmentWithCourse = TrainingEnrollment & { course: TrainingCourse };

function toMyLearningDto(e: EnrollmentWithCourse): MyLearningDto {
  return {
    id: e.id,
    courseId: e.courseId,
    title: e.course.title,
    category: e.course.category,
    mode: e.course.mode,
    durationHours: e.course.durationHours,
    mandatory: e.course.mandatory,
    status: e.status,
    progress: e.progress,
    score: e.score,
    enrolledAt: e.enrolledAt.toISOString(),
    completedAt: e.completedAt?.toISOString() ?? null,
  };
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const enrollment = await db.trainingEnrollment.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { course: true, employee: true },
    });
    if (!enrollment) return fail("Enrollment not found.", 404);

    const mgr = ["owner", "admin", "hr"].includes(session.role);
    if (!mgr && enrollment.employeeId !== session.employeeId) {
      return fail("You can only update your own learning progress.", 403);
    }

    if (body.action === "complete") {
      let score: number | null = null;
      if (body.score !== undefined && body.score !== null && String(body.score).trim() !== "") {
        const n = Number(body.score);
        if (!Number.isFinite(n) || !Number.isInteger(n) || n < 0 || n > 100) {
          return fail("Score must be an integer between 0 and 100.", 400);
        }
        score = n;
      }

      const updated = await db.trainingEnrollment.update({
        where: { id: enrollment.id },
        data: {
          status: "completed",
          progress: 100,
          completedAt: new Date(),
          ...(score !== null ? { score } : {}),
        },
        include: { course: true, employee: true },
      });

      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "training.completed",
        entity: "TrainingEnrollment",
        entityId: enrollment.id,
        summary: `${fullName(updated.employee)} completed "${updated.course.title}"${updated.score !== null ? ` with a score of ${updated.score}` : ""}.`,
      });

      return ok({ enrollment: toMyLearningDto(updated) });
    }

    if (body.action !== undefined) {
      return fail("Unknown action. Use complete, or send a progress value.", 400);
    }

    if (body.progress === undefined || body.progress === null) {
      return fail("Provide a progress value between 0 and 100.", 400);
    }

    const n = Number(body.progress);
    if (!Number.isFinite(n)) return fail("Progress must be a number between 0 and 100.", 400);
    const progress = Math.max(0, Math.min(100, Math.round(n)));
    const status = progress >= 100 ? "completed" : progress > 0 ? "in_progress" : "enrolled";
    const completedAt = progress >= 100 ? (enrollment.completedAt ?? new Date()) : null;

    const updated = await db.trainingEnrollment.update({
      where: { id: enrollment.id },
      data: { progress, status, completedAt },
      include: { course: true, employee: true },
    });

    if (status === "completed" && enrollment.status !== "completed") {
      const user = await db.user.findFirst({
        where: { employeeId: enrollment.employeeId },
        select: { id: true },
      });
      await notify(session.tenantId, {
        userId: user?.id ?? null,
        title: "Training completed",
        body: `You completed "${updated.course.title}". Nice work!`,
        type: "training",
      });
    }

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "training.progress_updated",
      entity: "TrainingEnrollment",
      entityId: enrollment.id,
      summary: `${fullName(updated.employee)} is at ${updated.progress}% in "${updated.course.title}" (${updated.status}).`,
    });

    return ok({ enrollment: toMyLearningDto(updated) });
  });
}

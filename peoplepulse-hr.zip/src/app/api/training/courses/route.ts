/**
 * Training course catalog API.
 *
 * GET /api/training/courses — any signed-in user. Returns the course catalog
 * (unpublished courses only for owner/admin/hr) plus roll-up stats: published
 * count, mandatory count, the caller's active/completed enrollments and the
 * tenant-wide completion rate. Each course carries `myEnrollment` when the
 * caller's linked employee record is enrolled in it.
 *
 * POST /api/training/courses — owner/admin/hr. Creates a course (published by
 * default). Validates title, category (TRAINING_CATEGORIES), mode
 * (online|in_person|hybrid) and durationHours > 0. createdBy = session name.
 */
import { NextRequest } from "next/server";
import type { TrainingCourse, TrainingEnrollment } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { TRAINING_CATEGORIES } from "@/lib/constants";
import type { TrainingCourseDto } from "@/lib/types";

const COURSE_MODES = ["online", "in_person", "hybrid"] as const;
type CourseMode = (typeof COURSE_MODES)[number];

function isManagerRole(role: string): boolean {
  return role === "owner" || role === "admin" || role === "hr";
}

type CourseWithEnrollments = TrainingCourse & { enrollments: TrainingEnrollment[] };

function toCourseDto(course: CourseWithEnrollments, employeeId: string | null): TrainingCourseDto {
  const mine = employeeId ? course.enrollments.find((e) => e.employeeId === employeeId) : undefined;
  return {
    id: course.id,
    title: course.title,
    description: course.description,
    category: course.category,
    mode: course.mode,
    durationHours: course.durationHours,
    provider: course.provider,
    mandatory: course.mandatory,
    published: course.published,
    enrolledCount: course.enrollments.length,
    completedCount: course.enrollments.filter((e) => e.status === "completed").length,
    myEnrollment: mine
      ? {
          id: mine.id,
          status: mine.status,
          progress: mine.progress,
          score: mine.score,
          completedAt: mine.completedAt?.toISOString() ?? null,
        }
      : null,
  };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const mgr = isManagerRole(session.role);

    const [courses, publishedCount, mandatoryCount, totalEnrollments, completedEnrollments, myActive, myCompleted] =
      await Promise.all([
        db.trainingCourse.findMany({
          where: { tenantId: session.tenantId, ...(mgr ? {} : { published: true }) },
          include: { enrollments: true },
          orderBy: { createdAt: "desc" },
        }),
        db.trainingCourse.count({ where: { tenantId: session.tenantId, published: true } }),
        db.trainingCourse.count({ where: { tenantId: session.tenantId, mandatory: true } }),
        db.trainingEnrollment.count({ where: { tenantId: session.tenantId } }),
        db.trainingEnrollment.count({ where: { tenantId: session.tenantId, status: "completed" } }),
        session.employeeId
          ? db.trainingEnrollment.count({
              where: {
                tenantId: session.tenantId,
                employeeId: session.employeeId,
                status: { in: ["enrolled", "in_progress"] },
              },
            })
          : Promise.resolve(0),
        session.employeeId
          ? db.trainingEnrollment.count({
              where: { tenantId: session.tenantId, employeeId: session.employeeId, status: "completed" },
            })
          : Promise.resolve(0),
      ]);

    const completionRate =
      totalEnrollments > 0 ? Math.round((completedEnrollments / totalEnrollments) * 100) : 0;

    return ok({
      courses: courses.map((c) => toCourseDto(c, session.employeeId)),
      stats: { published: publishedCount, mandatory: mandatoryCount, myActive, myCompleted, completionRate },
    });
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const title = String(body.title ?? "").trim();
    if (title.length < 3) return fail("Title must be at least 3 characters.", 400);

    const description = String(body.description ?? "").trim();

    const category = String(body.category ?? "").trim();
    if (!TRAINING_CATEGORIES.includes(category)) {
      return fail(`Category must be one of: ${TRAINING_CATEGORIES.join(", ")}.`, 400);
    }

    const mode = String(body.mode ?? "").trim();
    if (!COURSE_MODES.includes(mode as CourseMode)) {
      return fail("Mode must be online, in_person or hybrid.", 400);
    }

    const durationHours = Number(body.durationHours);
    if (!Number.isFinite(durationHours) || durationHours <= 0) {
      return fail("Duration must be greater than 0 hours.", 400);
    }

    const providerRaw = body.provider != null ? String(body.provider).trim() : "";
    const provider = providerRaw || null;

    const mandatory = typeof body.mandatory === "boolean" ? body.mandatory : false;

    const course = await db.trainingCourse.create({
      data: {
        tenantId: session.tenantId,
        title,
        description,
        category,
        mode,
        durationHours,
        provider,
        mandatory,
        published: true,
        createdBy: session.name,
      },
      include: { enrollments: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "training.course.created",
      entity: "TrainingCourse",
      entityId: course.id,
      summary: `Created training course "${course.title}" (${course.category}, ${course.mode}, ${course.durationHours}h).`,
    });

    return ok({ course: toCourseDto(course, session.employeeId) }, { status: 201 });
  });
}

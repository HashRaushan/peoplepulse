/**
 * Training enrollment API.
 *
 * POST /api/training/courses/{id}/enroll — body optional { employeeId? }.
 *   - Without employeeId: self-enrollment using the session's linked employee
 *     record (400 when no employee is linked; 404 when the course is not
 *     published — only HR-side assignment may target unpublished courses).
 *   - With employeeId (owner/admin/hr only): enrolls that employee, who must
 *     exist in the tenant and not be exited.
 * Returns 409 when already enrolled. When someone else is enrolled, a
 * notification is created for their linked user. Always audits.
 */
import { NextRequest } from "next/server";
import type { TrainingEnrollment, TrainingCourse, Employee } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit, notify } from "@/lib/api-helpers";
import { fullName } from "@/app/api/_lib/mappers";
import type { MyLearningDto } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

type EnrollmentWithCourse = TrainingEnrollment & { course: TrainingCourse };

function toMyLearningDto(e: EnrollmentWithCourse): MyLearningDto {
  return {
    id: e.id,
    courseId: e.courseId,
    title: e.course.title,
    category: e.course.category,
    mode: e.course.mode,
    durationHours: e.course.durationHours,
    mandatory: e.course.mandatory,
    status: e.status,
    progress: e.progress,
    score: e.score,
    enrolledAt: e.enrolledAt.toISOString(),
    completedAt: e.completedAt?.toISOString() ?? null,
  };
}

export async function POST(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth();
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    const body =
      raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};

    const course = await db.trainingCourse.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!course) return fail("Course not found.", 404);

    const mgr = ["owner", "admin", "hr"].includes(session.role);
    const requestedEmployeeId = body.employeeId != null ? String(body.employeeId).trim() : "";

    let employee: Employee;
    let enrolledByOther = false;

    if (requestedEmployeeId) {
      if (!mgr) return fail("You do not have permission to enroll others.", 403);
      const emp = await db.employee.findFirst({
        where: { tenantId: session.tenantId, id: requestedEmployeeId, status: { not: "exited" } },
      });
      if (!emp) return fail("Employee not found or inactive in this organisation.", 400);
      employee = emp;
      enrolledByOther = emp.id !== session.employeeId;
    } else {
      // Self-service enrollment is only offered for published courses; HR
      // may still assign an unpublished course to someone explicitly.
      if (!course.published) {
        return fail("This course is not available for enrollment.", 404);
      }
      if (!session.employeeId) {
        return fail("Your account is not linked to an employee record.", 400);
      }
      const emp = await db.employee.findFirst({
        where: { tenantId: session.tenantId, id: session.employeeId },
      });
      if (!emp) return fail("Your account is not linked to an employee record.", 400);
      employee = emp;
    }

    const existing = await db.trainingEnrollment.findFirst({
      where: { courseId: course.id, employeeId: employee.id },
    });
    if (existing) return fail("Already enrolled in this course.", 409);

    const enrollment = await db.trainingEnrollment.create({
      data: {
        tenantId: session.tenantId,
        courseId: course.id,
        employeeId: employee.id,
        status: "enrolled",
        progress: 0,
      },
      include: { course: true },
    });

    if (enrolledByOther) {
      const user = await db.user.findFirst({ where: { employeeId: employee.id }, select: { id: true } });
      await notify(session.tenantId, {
        userId: user?.id ?? null,
        title: "Training course assigned",
        body: `You have been enrolled in "${course.title}" (${course.category}) by ${session.name}.`,
        type: "training",
      });
    }

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "training.enrolled",
      entity: "TrainingEnrollment",
      entityId: enrollment.id,
      summary: `${enrolledByOther ? `${session.name} enrolled ${fullName(employee)}` : `${fullName(employee)} self-enrolled`} in "${course.title}".`,
    });

    return ok({ enrollment: toMyLearningDto(enrollment) }, { status: 201 });
  });
}

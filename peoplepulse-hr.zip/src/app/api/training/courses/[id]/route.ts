/**
 * Training course management API (owner/admin/hr).
 *
 * PATCH /api/training/courses/{id} — body { action: "update", ...fields } for a
 * partial update (validated like create) or { action: "toggle_publish" } to
 * flip the published flag. Both write an audit entry.
 *
 * DELETE /api/training/courses/{id} — refuses with 409 "Course has enrollments"
 * when any enrollment exists, otherwise deletes the course (audit logged).
 */
import { NextRequest } from "next/server";
import type { TrainingCourse, TrainingEnrollment } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { TRAINING_CATEGORIES } from "@/lib/constants";
import type { TrainingCourseDto } from "@/lib/types";

const COURSE_MODES = ["online", "in_person", "hybrid"] as const;
type CourseMode = (typeof COURSE_MODES)[number];

type CourseWithEnrollments = TrainingCourse & { enrollments: TrainingEnrollment[] };

function toCourseDto(course: CourseWithEnrollments, employeeId: string | null): TrainingCourseDto {
  const mine = employeeId ? course.enrollments.find((e) => e.employeeId === employeeId) : undefined;
  return {
    id: course.id,
    title: course.title,
    description: course.description,
    category: course.category,
    mode: course.mode,
    durationHours: course.durationHours,
    provider: course.provider,
    mandatory: course.mandatory,
    published: course.published,
    enrolledCount: course.enrollments.length,
    completedCount: course.enrollments.filter((e) => e.status === "completed").length,
    myEnrollment: mine
      ? {
          id: mine.id,
          status: mine.status,
          progress: mine.progress,
          score: mine.score,
          completedAt: mine.completedAt?.toISOString() ?? null,
        }
      : null,
  };
}

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const course = await db.trainingCourse.findFirst({
      where: { tenantId: session.tenantId, id },
      include: { enrollments: true },
    });
    if (!course) return fail("Course not found.", 404);

    const action = String(body.action ?? "update");

    if (action === "toggle_publish") {
      const updated = await db.trainingCourse.update({
        where: { id: course.id },
        data: { published: !course.published },
        include: { enrollments: true },
      });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "training.course.publish_toggled",
        entity: "TrainingCourse",
        entityId: course.id,
        summary: `${updated.published ? "Published" : "Unpublished"} training course "${updated.title}".`,
      });
      return ok({ course: toCourseDto(updated, session.employeeId) });
    }

    if (action !== "update") {
      return fail("Unknown action. Use update or toggle_publish.", 400);
    }

    const data: {
      title?: string;
      description?: string;
      category?: string;
      mode?: string;
      durationHours?: number;
      provider?: string | null;
      mandatory?: boolean;
    } = {};

    if (body.title !== undefined) {
      const title = String(body.title).trim();
      if (title.length < 3) return fail("Title must be at least 3 characters.", 400);
      data.title = title;
    }
    if (body.description !== undefined) {
      data.description = String(body.description).trim();
    }
    if (body.category !== undefined) {
      const category = String(body.category).trim();
      if (!TRAINING_CATEGORIES.includes(category)) {
        return fail(`Category must be one of: ${TRAINING_CATEGORIES.join(", ")}.`, 400);
      }
      data.category = category;
    }
    if (body.mode !== undefined) {
      const mode = String(body.mode).trim();
      if (!COURSE_MODES.includes(mode as CourseMode)) {
        return fail("Mode must be online, in_person or hybrid.", 400);
      }
      data.mode = mode;
    }
    if (body.durationHours !== undefined) {
      const durationHours = Number(body.durationHours);
      if (!Number.isFinite(durationHours) || durationHours <= 0) {
        return fail("Duration must be greater than 0 hours.", 400);
      }
      data.durationHours = durationHours;
    }
    if (body.provider !== undefined) {
      const provider = body.provider === null ? "" : String(body.provider).trim();
      data.provider = provider || null;
    }
    if (body.mandatory !== undefined) {
      if (typeof body.mandatory !== "boolean") return fail("Mandatory must be a boolean.", 400);
      data.mandatory = body.mandatory;
    }

    if (Object.keys(data).length === 0) {
      return fail("Nothing to update. Provide at least one course field.", 400);
    }

    const updated = await db.trainingCourse.update({
      where: { id: course.id },
      data,
      include: { enrollments: true },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "training.course.updated",
      entity: "TrainingCourse",
      entityId: course.id,
      summary: `Updated training course "${updated.title}" (${Object.keys(data).join(", ")})`,
    });

    return ok({ course: toCourseDto(updated, session.employeeId) });
  });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const course = await db.trainingCourse.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!course) return fail("Course not found.", 404);

    const enrollmentCount = await db.trainingEnrollment.count({
      where: { courseId: course.id },
    });
    if (enrollmentCount > 0) return fail("Course has enrollments", 409);

    await db.trainingCourse.delete({ where: { id: course.id } });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "training.course.deleted",
      entity: "TrainingCourse",
      entityId: course.id,
      summary: `Deleted training course "${course.title}".`,
    });

    return ok({ ok: true });
  });
}

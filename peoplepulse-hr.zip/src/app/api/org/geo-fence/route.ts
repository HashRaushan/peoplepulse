/**
 * Organisation attendance geo-fence config API.
 *
 * GET   /api/org/geo-fence — any signed-in user. Returns the tenant's geo-fence
 *   configuration so the Attendance UI knows whether to request location before
 *   check-in. Exposes no secrets — only the office coordinates, radius and label.
 *
 * PATCH /api/org/geo-fence — owner | admin. Updates the geo-fence configuration.
 *   Body: { enabled?: boolean, officeLabel?: string, officeLatitude?: number|null,
 *           officeLongitude?: number|null, officeRadiusMeters?: number }
 *   When enabling, both officeLatitude and officeLongitude must be set.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import type { GeoFenceConfigDto } from "@/lib/types";

function toDto(t: {
  geoFenceEnabled: boolean;
  officeLabel: string | null;
  officeLatitude: number | null;
  officeLongitude: number | null;
  officeRadiusMeters: number;
}): GeoFenceConfigDto {
  return {
    enabled: t.geoFenceEnabled,
    officeLabel: t.officeLabel,
    officeLatitude: t.officeLatitude,
    officeLongitude: t.officeLongitude,
    officeRadiusMeters: t.officeRadiusMeters,
  };
}

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const tenant = await db.tenant.findUnique({
      where: { id: session.tenantId },
      select: {
        geoFenceEnabled: true,
        officeLabel: true,
        officeLatitude: true,
        officeLongitude: true,
        officeRadiusMeters: true,
      },
    });
    if (!tenant) return fail("Organisation not found.", 404);
    return ok(toDto(tenant));
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const data: Prisma.TenantUpdateInput = {};
    const summary: string[] = [];

    if (body.enabled !== undefined) {
      const enabled = Boolean(body.enabled);
      if (enabled) {
        const tenant = await db.tenant.findUnique({
          where: { id: session.tenantId },
          select: { officeLatitude: true, officeLongitude: true },
        });
        const lat = body.officeLatitude !== undefined ? body.officeLatitude : tenant?.officeLatitude;
        const lng = body.officeLongitude !== undefined ? body.officeLongitude : tenant?.officeLongitude;
        if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
          return fail("Set the office location (latitude and longitude) before enabling geo-fencing.", 400);
        }
      }
      data.geoFenceEnabled = enabled;
      summary.push(enabled ? "enabled geo-fencing" : "disabled geo-fencing");
    }

    if (body.officeLabel !== undefined) {
      const label = String(body.officeLabel).trim();
      data.officeLabel = label ? label.slice(0, 120) : null;
      summary.push(`office label set to "${data.officeLabel ?? ""}"`);
    }

    if (body.officeLatitude !== undefined) {
      if (body.officeLatitude === null) {
        data.officeLatitude = null;
      } else {
        const lat = Number(body.officeLatitude);
        if (!Number.isFinite(lat) || lat < -90 || lat > 90) {
          return fail("Office latitude must be between -90 and 90.", 400);
        }
        data.officeLatitude = lat;
      }
    }
    if (body.officeLongitude !== undefined) {
      if (body.officeLongitude === null) {
        data.officeLongitude = null;
      } else {
        const lng = Number(body.officeLongitude);
        if (!Number.isFinite(lng) || lng < -180 || lng > 180) {
          return fail("Office longitude must be between -180 and 180.", 400);
        }
        data.officeLongitude = lng;
      }
    }

    if (body.officeRadiusMeters !== undefined) {
      const radius = Number(body.officeRadiusMeters);
      if (!Number.isFinite(radius) || radius < 10 || radius > 50000) {
        return fail("Radius must be between 10 m and 50 km.", 400);
      }
      data.officeRadiusMeters = Math.round(radius);
      summary.push(`radius set to ${data.officeRadiusMeters} m`);
    }

    await db.tenant.update({ where: { id: session.tenantId }, data });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "org.geo_fence_updated",
      entity: "Tenant",
      entityId: session.tenantId,
      summary: summary.length ? `Updated attendance geo-fence (${summary.join(", ")}).` : "Updated attendance geo-fence.",
    });

    const updated = await db.tenant.findUnique({
      where: { id: session.tenantId },
      select: {
        geoFenceEnabled: true,
        officeLabel: true,
        officeLatitude: true,
        officeLongitude: true,
        officeRadiusMeters: true,
      },
    });
    return ok(toDto(updated!));
  });
}

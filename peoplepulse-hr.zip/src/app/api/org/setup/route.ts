/**
 * GET /api/org/setup — first-run setup progress for the tenant (owner | admin | hr).
 * Powers the dashboard "Set up your workspace" checklist.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);

    const [employees, withLogins, departments, leaveTypes, announcements] = await Promise.all([
      db.employee.count({ where: { tenantId: session.tenantId, status: { not: "exited" } } }),
      db.employee.count({
        where: {
          tenantId: session.tenantId,
          status: { not: "exited" },
          users: { some: {} },
        },
      }),
      db.department.count({ where: { tenantId: session.tenantId } }),
      db.leaveType.count({ where: { tenantId: session.tenantId } }),
      db.announcement.count({ where: { tenantId: session.tenantId } }),
    ]);

    const complete = employees >= 2 && withLogins >= 2 && leaveTypes >= 1 && announcements >= 1;

    return ok({ employees, withLogins, departments, leaveTypes, announcements, complete });
  });
}

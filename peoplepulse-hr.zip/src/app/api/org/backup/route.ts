/**
 * GET /api/org/backup — owner only, single-organisation deployments only
 * (the dump contains every tenant's records, so it is blocked as soon as a
 * second organisation exists). Streams a consistent snapshot of the entire
 * PeoplePulse SQLite database as a downloadable .db file. Uses SQLite's
 * VACUUM INTO so the snapshot is safe even while the app is running.
 * Every successful download is audited with critical severity.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, audit } from "@/lib/api-helpers";
import { randomBytes } from "node:crypto";
import { mkdir, readFile, rm } from "node:fs/promises";
import path from "node:path";

const DB_URL = process.env.DATABASE_URL ?? "file:./db/custom.db";
const DOWNLOAD_DIR = path.join(process.cwd(), "download");

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner"]);

    // The snapshot contains ALL organisations' data — refuse to hand it to one
    // tenant's owner the moment the deployment hosts more than one org.
    if ((await db.tenant.count()) > 1) {
      return fail("Backup download is only available on single-organisation deployments.", 403);
    }

    const today = new Date().toISOString().slice(0, 10);
    const filename = `peoplepulse-backup-${today}-${randomBytes(3).toString("hex")}.db`;
    const target = path.join(DOWNLOAD_DIR, filename);

    try {
      await mkdir(DOWNLOAD_DIR, { recursive: true });
      // Parameterised paths are not supported by VACUUM INTO; the target is a
      // server-controlled path (date + hex) so injection is not possible.
      await db.$executeRawUnsafe(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
      const buffer = await readFile(target);
      await rm(target, { force: true });
      await audit(session.tenantId, {
        actorName: session.name,
        actorRole: session.role,
        action: "org.backup_downloaded",
        entity: "Tenant",
        entityId: session.tenantId,
        summary: "Full database backup downloaded.",
        severity: "critical",
      });
      return new Response(new Uint8Array(buffer), {
        headers: {
          "Content-Type": "application/octet-stream",
          "Content-Disposition": `attachment; filename="${filename}"`,
          "Content-Length": String(buffer.byteLength),
        },
      });
    } catch (e) {
      await rm(target, { force: true }).catch(() => undefined);
      const message = e instanceof Error ? e.message : "Backup failed";
      console.error("[backup]", message);
      return fail("Could not create the backup. Please try again.", 500);
    }
  });
}

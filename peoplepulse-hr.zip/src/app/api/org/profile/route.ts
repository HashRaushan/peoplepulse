/**
 * Organisation profile API (tenant branding and locale settings).
 *
 * GET   /api/org/profile — any signed-in user. Returns the OrgProfileDto with
 *   a live non-exited employee count.
 *
 * PATCH /api/org/profile — owner | admin. Accepts name, brandColor (hex),
 *   logoText (1-2 characters), country, currency and timezone.
 */
import { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toOrgProfileDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth();
    const [tenant, employeeCount] = await Promise.all([
      db.tenant.findUnique({ where: { id: session.tenantId } }),
      db.employee.count({ where: { tenantId: session.tenantId, status: { not: "exited" } } }),
    ]);
    if (!tenant) return fail("Organisation not found.", 404);
    return ok(toOrgProfileDto(tenant, employeeCount));
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin"]);
    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    const tenant = await db.tenant.findUnique({ where: { id: session.tenantId } });
    if (!tenant) return fail("Organisation not found.", 404);

    const data: Prisma.TenantUpdateInput = {};

    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return fail("Organisation name cannot be empty.", 400);
      data.name = name;
    }
    if (body.brandColor !== undefined) {
      const brandColor = String(body.brandColor).trim();
      if (!/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(brandColor)) {
        return fail("Brand colour must be a hex value like #059669.", 400);
      }
      data.brandColor = brandColor;
    }
    if (body.logoText !== undefined) {
      const logoText = String(body.logoText).trim();
      if (logoText.length < 1 || logoText.length > 2) {
        return fail("Logo text must be 1-2 characters.", 400);
      }
      data.logoText = logoText;
    }
    if (body.country !== undefined) {
      const country = String(body.country).trim();
      if (!country) return fail("Country cannot be empty.", 400);
      data.country = country;
    }
    if (body.currency !== undefined) {
      const currency = String(body.currency).trim();
      if (!currency) return fail("Currency cannot be empty.", 400);
      data.currency = currency;
    }
    if (body.timezone !== undefined) {
      const timezone = String(body.timezone).trim();
      if (!timezone) return fail("Timezone cannot be empty.", 400);
      data.timezone = timezone;
    }

    await db.tenant.update({ where: { id: tenant.id }, data });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "org.updated",
      entity: "Tenant",
      entityId: tenant.id,
      summary: "Updated organisation profile settings.",
    });

    const [updated, employeeCount] = await Promise.all([
      db.tenant.findUnique({ where: { id: tenant.id } }),
      db.employee.count({ where: { tenantId: session.tenantId, status: { not: "exited" } } }),
    ]);
    return ok(toOrgProfileDto(updated ?? tenant, employeeCount));
  });
}

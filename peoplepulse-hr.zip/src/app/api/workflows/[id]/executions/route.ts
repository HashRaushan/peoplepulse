/**
 * Workflow execution history API.
 *
 * GET /api/workflows/{id}/executions (owner | admin | hr) — the 30 most
 * recent executions of a tenant workflow, newest first, with parsed steps.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok } from "@/lib/api-helpers";
import { toWorkflowExecutionDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const workflow = await db.workflow.findFirst({
      where: { tenantId: session.tenantId, id },
      select: { id: true },
    });
    if (!workflow) return fail("Workflow not found.", 404);

    const rows = await db.workflowExecution.findMany({
      where: { tenantId: session.tenantId, workflowId: workflow.id },
      include: { workflow: true },
      orderBy: { startedAt: "desc" },
      take: 30,
    });

    return ok({ items: rows.map(toWorkflowExecutionDto) });
  });
}

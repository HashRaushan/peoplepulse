/**
 * Workflow toggle API.
 *
 * PATCH /api/workflows/{id} (owner | admin | hr) — activate or deactivate a
 * workflow automation. Body: { active: boolean }.
 */
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, fail, ok, audit } from "@/lib/api-helpers";
import { toWorkflowDto } from "@/app/api/_lib/mappers";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const { id } = await ctx.params;

    const raw = await req.json().catch(() => null);
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return fail("Invalid request body.", 400);
    }
    const body = raw as Record<string, unknown>;

    if (typeof body.active !== "boolean") {
      return fail("Active must be true or false.", 400);
    }

    const workflow = await db.workflow.findFirst({
      where: { tenantId: session.tenantId, id },
    });
    if (!workflow) return fail("Workflow not found.", 404);

    const updated = await db.workflow.update({
      where: { id: workflow.id },
      data: { active: body.active },
    });

    await audit(session.tenantId, {
      actorName: session.name,
      actorRole: session.role,
      action: "workflow.updated",
      entity: "Workflow",
      entityId: workflow.id,
      summary: `${body.active ? "Activated" : "Deactivated"} workflow "${workflow.name}".`,
    });

    // Live-count fallback for Prisma clients cached before executionCount existed.
    const executionCount =
      typeof updated.executionCount === "number"
        ? updated.executionCount
        : await db.workflowExecution.count({
            where: { tenantId: session.tenantId, workflowId: updated.id },
          });

    return ok({ item: { ...toWorkflowDto(updated), executionCount } });
  });
}

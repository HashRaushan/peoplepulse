/**
 * Workflow automations API.
 *
 * GET /api/workflows (owner | admin | hr) — all tenant workflows sorted by
 * active first, then name.
 */
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok } from "@/lib/api-helpers";
import { toWorkflowDto } from "@/app/api/_lib/mappers";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const rows = await db.workflow.findMany({
      where: { tenantId: session.tenantId },
      orderBy: [{ active: "desc" }, { name: "asc" }],
    });
    // Fall back to a live count when the running process's Prisma client was
    // loaded before the executionCount column was added (long-lived dev server).
    const items = await Promise.all(
      rows.map(async (w) => ({
        ...toWorkflowDto(w),
        executionCount:
          typeof w.executionCount === "number"
            ? w.executionCount
            : await db.workflowExecution.count({
                where: { tenantId: session.tenantId, workflowId: w.id },
              }),
      }))
    );
    return ok({ items });
  });
}

import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, ok, dateOnly } from "@/lib/api-helpers";
import type { AnalyticsResponse } from "@/lib/types";

export async function GET() {
  return handle(async () => {
    const session = await requireAuth(["owner", "admin", "hr"]);
    const tenantId = session.tenantId;
    const now = new Date();
    const year = now.getFullYear();

    const [employees, leaveTypes, candidates, openings, tickets, reviews, payrollRuns] =
      await Promise.all([
        db.employee.findMany({ where: { tenantId } }),
        db.leaveType.findMany({ where: { tenantId } }),
        db.candidate.findMany({ where: { tenantId }, include: { opening: true } }),
        db.jobOpening.findMany({ where: { tenantId } }),
        db.hrTicket.findMany({ where: { tenantId } }),
        db.performanceReview.findMany({ where: { tenantId } }),
        db.payrollRun.findMany({ where: { tenantId }, orderBy: [{ year: "asc" }, { month: "asc" }] }),
      ]);

    // Headcount trend: hired / exited / total per month (12 months)
    const headcountTrend: { month: string; hired: number; exited: number; total: number }[] = [];
    for (let m = 11; m >= 0; m--) {
      const d = new Date(year, now.getMonth() - m, 1);
      const start = new Date(d.getFullYear(), d.getMonth(), 1);
      const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
      const hired = employees.filter((e) => e.joinDate >= start && e.joinDate <= end).length;
      const exited = employees.filter((e) => e.exitDate && e.exitDate >= start && e.exitDate <= end).length;
      const total = employees.filter((e) => e.joinDate <= end && (!e.exitDate || e.exitDate > end)).length;
      headcountTrend.push({ month: d.toLocaleString("en-IN", { month: "short" }), hired, exited, total });
    }

    // Tenure buckets (active employees)
    const active = employees.filter((e) => e.status !== "exited");
    const tenure = (days: number) => days / 365;
    const buckets = [
      { name: "< 1 yr", test: (y: number) => y < 1 },
      { name: "1–3 yrs", test: (y: number) => y >= 1 && y < 3 },
      { name: "3–5 yrs", test: (y: number) => y >= 3 && y < 5 },
      { name: "5+ yrs", test: (y: number) => y >= 5 },
    ];
    const tenureBuckets = buckets.map((b) => ({
      name: b.name,
      value: active.filter((e) => b.test(tenure((now.getTime() - e.joinDate.getTime()) / 86400000))).length,
    }));

    // Gender split
    const genderCounts = new Map<string, number>();
    for (const e of active) {
      const g = e.gender ?? "undisclosed";
      genderCounts.set(g, (genderCounts.get(g) ?? 0) + 1);
    }
    const genderSplit = [...genderCounts.entries()].map(([name, value]) => ({ name, value }));

    // Department attendance rate (last 30 days)
    const recent = await db.attendanceRecord.findMany({
      where: { tenantId, date: { gte: new Date(now.getTime() - 30 * 86400000) } },
      include: { employee: true },
    });
    const deptAgg = new Map<string, { present: number; total: number }>();
    for (const r of recent) {
      const cur = deptAgg.get(r.employee.department) ?? { present: 0, total: 0 };
      cur.total += 1;
      if (["present", "late", "wfh"].includes(r.status)) cur.present += 1;
      deptAgg.set(r.employee.department, cur);
    }
    const deptAttendance = [...deptAgg.entries()]
      .map(([name, v]) => ({ name, rate: v.total > 0 ? Math.round((v.present / v.total) * 100) : 0 }))
      .sort((a, b) => b.rate - a.rate);

    // Leave utilization by type (org-wide)
    const balances = await db.leaveBalance.findMany({ where: { tenantId, year }, include: { leaveType: true } });
    const leaveUtilizationByType = leaveTypes.map((lt) => {
      const rows = balances.filter((b) => b.leaveTypeId === lt.id);
      return {
        name: lt.name,
        entitled: rows.reduce((s, b) => s + b.entitled, 0),
        used: rows.reduce((s, b) => s + b.used, 0),
      };
    });

    // Hiring funnel + source of hire
    const stageOrder = ["applied", "screening", "interview", "offer", "hired"];
    const hiringFunnel = stageOrder.map((stage) => ({
      stage: stage.charAt(0).toUpperCase() + stage.slice(1),
      count: candidates.filter((c) => c.stage === stage).length,
    }));
    const sourceMap = new Map<string, number>();
    for (const c of candidates) sourceMap.set(c.source, (sourceMap.get(c.source) ?? 0) + 1);
    const sourceOfHire = [...sourceMap.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

    // Payroll cost trend
    const payrollCostTrend = payrollRuns.slice(-6).map((r) => ({
      month: new Date(r.year, r.month - 1).toLocaleString("en-IN", { month: "short" }),
      gross: r.grossTotal,
      net: r.netTotal,
    }));

    // Ticket metrics
    const resolved = tickets.filter((t) => t.resolvedAt);
    const avgResolutionHours = resolved.length
      ? Math.round((resolved.reduce((s, t) => s + (t.resolvedAt!.getTime() - t.createdAt.getTime()) / 3600000, 0) / resolved.length) * 10) / 10
      : null;
    const catMap = new Map<string, number>();
    for (const t of tickets) catMap.set(t.category, (catMap.get(t.category) ?? 0) + 1);

    // Rating distribution
    const completed = reviews.filter((r) => r.finalRating !== null);
    const ratingDistribution = [1, 2, 3, 4, 5].map((rating) => ({
      rating: `${rating} Star${rating > 1 ? "s" : ""}`,
      count: completed.filter((r) => r.finalRating === rating).length,
    }));

    const data: AnalyticsResponse = {
      headcountTrend,
      tenureBuckets,
      genderSplit,
      deptAttendance,
      leaveUtilizationByType,
      hiringFunnel,
      sourceOfHire,
      payrollCostTrend,
      ticketMetrics: {
        avgResolutionHours,
        openCount: tickets.filter((t) => t.status === "open" || t.status === "in_progress").length,
        resolvedCount: resolved.length,
        byCategory: [...catMap.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value),
      },
      ratingDistribution,
    };

    return ok(data);
  });
}

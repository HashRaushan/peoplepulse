/**
 * PeoplePulse HR — configurable payroll engine.
 *
 * IMPORTANT: Statutory values (PF, ESI, PT, TDS) are CONFIGURABLE, effective-dated
 * inputs stored per tenant. Defaults below reflect commonly cited Indian payroll
 * practice, but every run must be reviewed by an authorised payroll administrator
 * and verified against current statutory rules before disbursement/filing.
 */
import type { PayrollConfigDto } from "./types";

export const DEFAULT_PAYROLL_CONFIG: PayrollConfigDto = {
  effectiveFrom: "2025-04-01",
  currency: "INR",
  note:
    "Statutory values are configurable and effective-dated. Figures are indicative — review and verify against current statutory rules before disbursement. TDS uses the configured new-regime slab approximation.",
  basicPercentOfCtc: 0.4,
  hraPercentOfBasic: 0.5,
  paidDaysBasis: 26,
  epf: { enabled: true, employeeRate: 0.12, wageCeiling: 15000 },
  esic: { enabled: true, employeeRate: 0.0075, grossCeiling: 21000 },
  professionalTax: {
    state: "Karnataka",
    slabs: [
      { upto: 10000, monthly: 0 },
      { upto: 15000, monthly: 150 },
      { upto: null, monthly: 200 },
    ],
  },
  tds: {
    mode: "new-regime slab approximation",
    annualStandardDeduction: 75000,
    slabs: [
      { upto: 400000, rate: 0 },
      { upto: 800000, rate: 0.05 },
      { upto: 1200000, rate: 0.1 },
      { upto: 1600000, rate: 0.15 },
      { upto: 2000000, rate: 0.2 },
      { upto: 2400000, rate: 0.25 },
      { upto: null, rate: 0.3 },
    ],
  },
};

/**
 * Deep-merge a stored tenant payroll config (JSON string or parsed object)
 * over the defaults, section by section, so partial/stale configs can never
 * produce NaN during a run. Unknown or invalid fields fall back to defaults.
 */
export function mergePayrollConfig(raw: string | null | undefined): PayrollConfigDto {
  const d = DEFAULT_PAYROLL_CONFIG;
  let parsed: unknown = null;
  if (raw && raw.trim() !== "" && raw.trim() !== "{}") {
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = null; // corrupt JSON -> pure defaults
    }
  }
  if (!parsed || typeof parsed !== "object") return { ...d };
  const r = parsed as Partial<PayrollConfigDto>;
  const numOr = (v: unknown, fallback: number) =>
    typeof v === "number" && Number.isFinite(v) ? v : fallback;
  const strOr = (v: unknown, fallback: string) => (typeof v === "string" ? v : fallback);
  const ptSlabs = Array.isArray(r.professionalTax?.slabs) && r.professionalTax.slabs.length > 0
    ? r.professionalTax.slabs
    : d.professionalTax.slabs;
  const tdsSlabs = Array.isArray(r.tds?.slabs) && r.tds.slabs.length > 0
    ? r.tds.slabs
    : d.tds.slabs;
  return {
    effectiveFrom: strOr(r.effectiveFrom, d.effectiveFrom),
    currency: strOr(r.currency, d.currency),
    note: strOr(r.note, d.note),
    basicPercentOfCtc: numOr(r.basicPercentOfCtc, d.basicPercentOfCtc),
    hraPercentOfBasic: numOr(r.hraPercentOfBasic, d.hraPercentOfBasic),
    paidDaysBasis: numOr(r.paidDaysBasis, d.paidDaysBasis),
    epf: {
      enabled: r.epf?.enabled ?? d.epf.enabled,
      employeeRate: numOr(r.epf?.employeeRate, d.epf.employeeRate),
      wageCeiling: numOr(r.epf?.wageCeiling, d.epf.wageCeiling),
    },
    esic: {
      enabled: r.esic?.enabled ?? d.esic.enabled,
      employeeRate: numOr(r.esic?.employeeRate, d.esic.employeeRate),
      grossCeiling: numOr(r.esic?.grossCeiling, d.esic.grossCeiling),
    },
    professionalTax: {
      state: strOr(r.professionalTax?.state, d.professionalTax.state),
      slabs: ptSlabs,
    },
    tds: {
      mode: strOr(r.tds?.mode, d.tds.mode),
      annualStandardDeduction: numOr(r.tds?.annualStandardDeduction, d.tds.annualStandardDeduction),
      slabs: tdsSlabs,
    },
  };
}

export interface PayslipComponents {
  basic: number;
  hra: number;
  specialAllowance: number;
  gross: number;
  pf: number;
  esic: number;
  pt: number;
  tds: number;
  otherDeductions: number;
  net: number;
  daysPaid: number;
  lopDays: number;
  /** Rounded gross lost to loss-of-pay this month — reported for transparency
   *  (the DB payslip row persists lopDays/daysPaid instead). */
  lopAmount: number;
}

const round = (n: number) => Math.round(n);

export function computePayslip(
  annualCtc: number,
  lopDays: number,
  config: PayrollConfigDto = DEFAULT_PAYROLL_CONFIG
): PayslipComponents {
  const monthlyGross = annualCtc / 12;

  // Loss-of-pay: proportional reduction on the configured paid-days basis.
  // Every earning component is prorated by the paid-days factor so that
  // basic + hra + specialAllowance reconciles with gross EXACTLY.
  const basis = Math.max(1, config.paidDaysBasis);
  const effectiveLop = Math.max(0, Math.min(lopDays, basis));
  const factor = (basis - effectiveLop) / basis;
  const basic = round(monthlyGross * config.basicPercentOfCtc * factor);
  const hra = round(basic * config.hraPercentOfBasic);
  const specialAllowance = round(monthlyGross * factor - basic - hra);
  const gross = basic + hra + specialAllowance; // reconciles exactly
  const lopAmount = round((monthlyGross / basis) * effectiveLop); // reporting only

  // EPF — employee share on basic, capped at the statutory wage ceiling
  const pf = config.epf.enabled
    ? round(Math.min(basic, config.epf.wageCeiling) * config.epf.employeeRate)
    : 0;

  // ESIC — employee share on post-LOP gross wages; the eligibility ceiling
  // check uses the contracted monthly gross.
  const esic =
    config.esic.enabled && monthlyGross <= config.esic.grossCeiling
      ? round(gross * config.esic.employeeRate)
      : 0;

  // Professional tax — monthly slab on gross
  let pt = 0;
  for (const slab of config.professionalTax.slabs) {
    if (slab.upto === null || gross <= slab.upto) {
      pt = slab.monthly;
      break;
    }
  }

  // TDS — indicative monthly deduction using configured annual slabs
  const annualTaxable = Math.max(0, annualCtc - config.tds.annualStandardDeduction);
  let remaining = annualTaxable;
  let lower = 0;
  let annualTax = 0;
  for (const slab of config.tds.slabs) {
    const upper = slab.upto ?? Infinity;
    const taxedAtSlab = Math.min(remaining, upper - lower);
    if (taxedAtSlab > 0) {
      annualTax += taxedAtSlab * slab.rate;
      remaining -= taxedAtSlab;
    }
    lower = upper;
    if (remaining <= 0) break;
  }
  // 4% health & education cess approximation
  annualTax *= 1.04;
  const tds = round(annualTax / 12);

  const otherDeductions = 0;
  const net = round(gross - pf - esic - pt - tds - otherDeductions);

  return {
    basic,
    hra,
    specialAllowance,
    gross,
    pf,
    esic,
    pt,
    tds,
    otherDeductions,
    net,
    daysPaid: Math.max(0, basis - effectiveLop),
    lopDays: effectiveLop,
    lopAmount,
  };
}

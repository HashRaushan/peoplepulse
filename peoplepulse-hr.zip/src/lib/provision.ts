/**
 * PeoplePulse HR — starter-data provisioning for newly registered tenants.
 * Real mode: the workspace starts with ONLY the owner's employee record plus
 * sensible editable defaults (departments, leave types, holidays, policies,
 * workflows). No fictional demo employees are ever created.
 */
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/crypto";
import { AVATAR_COLORS } from "@/lib/constants";
import { tenantCodePrefix } from "@/app/api/_lib/mappers";

const IN_HOLIDAYS_2025: [string, string][] = [
  ["2025-01-26", "Republic Day"],
  ["2025-03-14", "Holi"],
  ["2025-03-31", "Eid-ul-Fitr"],
  ["2025-04-14", "Ambedkar Jayanti"],
  ["2025-05-01", "Labour Day"],
  ["2025-08-15", "Independence Day"],
  ["2025-08-27", "Ganesh Chaturthi"],
  ["2025-10-02", "Gandhi Jayanti"],
  ["2025-10-21", "Dussehra"],
  ["2025-11-01", "Diwali"],
  ["2025-12-25", "Christmas"],
];

const IN_HOLIDAYS_2026: [string, string][] = [
  ["2026-01-26", "Republic Day"],
  ["2026-03-04", "Holi"],
  ["2026-03-20", "Eid-ul-Fitr"],
  ["2026-04-14", "Ambedkar Jayanti"],
  ["2026-05-01", "Labour Day"],
  ["2026-08-15", "Independence Day"],
  ["2026-10-02", "Gandhi Jayanti"],
  ["2026-11-08", "Diwali"],
  ["2026-12-25", "Christmas"],
];

export async function provisionTenant(opts: {
  tenantId: string;
  ownerUserId: string;
  ownerName: string;
  ownerEmail: string;
  companyName: string;
}) {
  const { tenantId, ownerName, ownerEmail, companyName } = opts;
  const year = new Date().getFullYear();
  const firstName = ownerName.split(" ")[0] || "Owner";
  const lastName = ownerName.split(" ").slice(1).join(" ") || "";

  // Departments
  const departments = await Promise.all(
    ["Engineering", "Sales", "Operations", "People & HR", "Finance"].map((name) =>
      db.department.create({ data: { tenantId, name, description: `${name} department` } })
    )
  );

  // Leave types
  const leaveTypes = await Promise.all(
    [
      { name: "Casual Leave", code: "CL", annualQuota: 12, paid: true, carryForward: false },
      { name: "Sick Leave", code: "SL", annualQuota: 8, paid: true, carryForward: false },
      { name: "Earned Leave", code: "EL", annualQuota: 15, paid: true, carryForward: true },
      { name: "Compensatory Off", code: "CO", annualQuota: 6, paid: true, carryForward: false },
    ].map((lt) => db.leaveType.create({ data: { tenantId, ...lt } }))
  );

  // Holidays (skip past dates of current year). Dates use local midnight to
  // match the app-wide "YYYY-MM-DDT00:00:00" convention (not UTC midnight).
  const now = new Date();
  const holidays = [...IN_HOLIDAYS_2025, ...IN_HOLIDAYS_2026].filter(
    ([d]) => new Date(`${d}T00:00:00`) > now
  );
  await Promise.all(
    holidays.map(([date, name]) =>
      db.holiday.create({ data: { tenantId, name, date: new Date(`${date}T00:00:00`), type: "public" } })
    )
  );

  // Owner employee record (real data only — no placeholder phone/CTC)
  const ownerEmployee = await db.employee.create({
    data: {
      tenantId,
      code: `${tenantCodePrefix(companyName)}-001`,
      firstName,
      lastName,
      email: ownerEmail,
      phone: "",
      department: "Operations",
      designation: "Founder",
      location: "Bengaluru",
      joinDate: new Date(),
      status: "active",
      employmentType: "full_time",
      ctc: 0,
      avatarColor: AVATAR_COLORS[0],
    },
  });
  await db.user.update({ where: { id: opts.ownerUserId }, data: { employeeId: ownerEmployee.id } });

  // Leave balances for the owner
  await Promise.all(
    leaveTypes.map((lt) =>
      db.leaveBalance.create({
        data: {
          tenantId,
          employeeId: ownerEmployee.id,
          leaveTypeId: lt.id,
          year,
          entitled: lt.annualQuota,
          used: 0,
          pending: 0,
        },
      })
    )
  );

  // Policies
  await Promise.all([
    db.policyDocument.create({
      data: {
        tenantId,
        title: "Leave & Time Off Policy",
        category: "HR Policy",
        version: "1.0",
        content:
          "## Overview\nThis policy describes leave entitlements for all employees.\n\n### Casual Leave (CL)\n12 days per calendar year. Maximum 3 days at a stretch. Cannot be carried forward.\n\n### Sick Leave (SL)\n8 days per calendar year. Medical certificate required for 3+ consecutive days.\n\n### Earned Leave (EL)\n15 days per year, accrued 1.25 days per completed month. Unused EL can be carried forward up to 30 days and is encashable at basic pay on exit.\n\n### Approval\nAll leave requires manager approval. Apply at least 3 days in advance except for emergencies.\n\n### Holidays\n10 public holidays per year are published in the company calendar. Two optional holidays may be availed.",
        updatedBy: ownerName,
      },
    }),
    db.policyDocument.create({
      data: {
        tenantId,
        title: "Work From Home Policy",
        category: "HR Policy",
        version: "1.0",
        content:
          "## Work From Home\nEmployees may work from home up to 8 days per month with manager intimation.\n\n### Expectations\n- Core hours 10:00–16:00 IST with daily attendance check-in\n- Camera-on for scheduled meetings\n- Manager may recall WFH for workshops, clients or team events\n\n### Remote attendance\nMark attendance with the WFH status from the self-service dashboard.",
        updatedBy: ownerName,
      },
    }),
    db.policyDocument.create({
      data: {
        tenantId,
        title: "Code of Conduct",
        category: "Company Policy",
        version: "1.0",
        content:
          "## Code of Conduct\nAll employees are expected to act with integrity, respect and professionalism.\n\n- Treat colleagues, candidates and customers with respect\n- Protect confidential company and personal data\n- Report concerns through the HR helpdesk or to your manager\n- Violations are handled per the disciplinary procedure",
        updatedBy: ownerName,
      },
    }),
  ]);

  // Welcome announcement
  await db.announcement.create({
    data: {
      tenantId,
      title: `Welcome to PeoplePulse HR at ${companyName}`,
      body: `Welcome to ${companyName} on PeoplePulse HR. Apply for leave, mark daily attendance, read company policies and reach the People team from one place. Add your teammates under Employees so everyone can sign in and self-serve.`,
      category: "company",
      authorName: ownerName,
      pinned: true,
    },
  });

  // Default workflows (conditions/actions default to "[]" in the schema)
  await Promise.all([
    db.workflow.create({
      data: {
        tenantId,
        name: "New joiner onboarding",
        description: "When an employee is added, generate the onboarding checklist and notify HR.",
        category: "onboarding",
        triggerCode: "employee.joined",
        triggerLabel: "Employee joins",
        active: true,
      },
    }),
    db.workflow.create({
      data: {
        tenantId,
        name: "Leave approval routing",
        description: "Notify the manager when a leave request is submitted; update balances on approval.",
        category: "leave",
        triggerCode: "leave.submitted",
        triggerLabel: "Leave request submitted",
        active: true,
      },
    }),
    db.workflow.create({
      data: {
        tenantId,
        name: "Leave approval completion",
        description:
          "Records completed approvals, updates balances and notifies the employee when a leave request is approved.",
        category: "leave",
        triggerCode: "leave.approved",
        triggerLabel: "Leave request approved",
        active: true,
      },
    }),
    db.workflow.create({
      data: {
        tenantId,
        name: "Payroll readiness alert",
        description: "When a payroll run enters review, notify authorised approvers.",
        category: "payroll",
        triggerCode: "payroll.in_review",
        triggerLabel: "Payroll run ready for review",
        active: true,
      },
    }),
  ]);

  await db.auditLog.create({
    data: {
      tenantId,
      actorName: ownerName,
      actorRole: "owner",
      action: "tenant.created",
      entity: "Tenant",
      entityId: tenantId,
      summary: `Organisation "${companyName}" registered and provisioned.`,
      severity: "info",
    },
  });

  return { ownerEmployee, departments, leaveTypes };
}

/** Slugify a company name into a tenant slug. */
export function slugify(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 30) || "org";
  return `${base}-${Math.random().toString(36).slice(2, 6)}`;
}

/**
 * PeoplePulse HR — Shared constants.
 */
import type { ModuleKey, PlanKey, Role } from "./types";
import {
  LayoutDashboard, BarChart3, Users, Network, CalendarClock, PlaneTakeoff,
  UserRoundSearch, Wallet, Target, Megaphone, Contact, LifeBuoy, Workflow,
  Sparkles, Settings, ReceiptText, Boxes, GraduationCap, ClipboardList, FileText,
} from "lucide-react";

// ---------- Pricing ----------

export interface PricingPlan {
  key: PlanKey;
  name: string;
  tagline: string;
  monthlyPerEmployee: number; // INR
  annualPerEmployee: number; // INR / month when billed annually
  seatsIncluded: number;
  features: string[];
  highlight?: boolean;
  cta: string;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    key: "starter",
    name: "Starter",
    tagline: "For startups and small teams getting organised.",
    monthlyPerEmployee: 49,
    annualPerEmployee: 39,
    seatsIncluded: 25,
    features: [
      "Core HR & employee database",
      "Attendance & shift management",
      "Leave management with policies",
      "Employee self-service portal",
      "Announcements & documents",
      "Email support",
    ],
    cta: "Start free trial",
  },
  {
    key: "growth",
    name: "Growth",
    tagline: "For growing companies that need real HR operations.",
    monthlyPerEmployee: 99,
    annualPerEmployee: 79,
    seatsIncluded: 100,
    features: [
      "Everything in Starter",
      "Payroll processing & payslips",
      "Configurable statutory components (PF, ESI, PT, TDS)",
      "HR helpdesk with SLAs",
      "Recruitment pipeline (ATS)",
      "Workflows & approvals",
    ],
    highlight: true,
    cta: "Start free trial",
  },
  {
    key: "professional",
    name: "Professional",
    tagline: "For mid-size orgs needing analytics, performance & AI.",
    monthlyPerEmployee: 179,
    annualPerEmployee: 149,
    seatsIncluded: 500,
    features: [
      "Everything in Growth",
      "Performance reviews & goals",
      "Advanced people analytics",
      "AI HR copilot (monthly credits)",
      "Custom report builder & exports",
      "Priority support",
    ],
    cta: "Start free trial",
  },
  {
    key: "enterprise",
    name: "Enterprise",
    tagline: "For large orgs with governance & integration needs.",
    monthlyPerEmployee: 0,
    annualPerEmployee: 0,
    seatsIncluded: 0,
    features: [
      "Everything in Professional",
      "SSO & advanced security controls",
      "Audit exports & retention policies",
      "Dedicated success manager",
      "Custom integrations & SLAs",
      "Data residency options",
    ],
    cta: "Talk to sales",
  },
];

export const PLAN_CREDITS: Record<PlanKey, { label: string; monthly: number | "custom" }> = {
  trial: { label: "Trial", monthly: "custom" },
  starter: { label: "Starter", monthly: 49 },
  growth: { label: "Growth", monthly: 99 },
  professional: { label: "Professional", monthly: 179 },
  enterprise: { label: "Enterprise", monthly: "custom" },
};

// ---------- Navigation ----------

export interface NavItem {
  key: ModuleKey;
  label: string;
  icon: typeof Users;
  roles: Role[]; // which roles can see it
}

export interface NavSection {
  label: string;
  items: NavItem[];
}

const ALL: Role[] = ["owner", "admin", "hr", "manager", "employee"];
const HR_ONLY: Role[] = ["owner", "admin", "hr"];
const MGMT: Role[] = ["owner", "admin", "hr", "manager"];

export const NAV_SECTIONS: NavSection[] = [
  {
    label: "Overview",
    items: [
      { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ALL },
      { key: "analytics", label: "Analytics", icon: BarChart3, roles: HR_ONLY },
    ],
  },
  {
    label: "People",
    items: [
      { key: "employees", label: "Employees", icon: Users, roles: MGMT },
      { key: "orgchart", label: "Org Chart", icon: Network, roles: MGMT },
      { key: "directory", label: "Directory", icon: Contact, roles: ALL },
      { key: "attendance", label: "Attendance", icon: CalendarClock, roles: ALL },
      { key: "leave", label: "Leave", icon: PlaneTakeoff, roles: ALL },
      { key: "recruitment", label: "Recruitment", icon: UserRoundSearch, roles: MGMT },
      { key: "training", label: "Training", icon: GraduationCap, roles: ALL },
      { key: "performance", label: "Performance", icon: Target, roles: ALL },
    ],
  },
  {
    label: "Operations",
    items: [
      { key: "payroll", label: "Payroll", icon: Wallet, roles: ALL },
      { key: "expenses", label: "Expenses", icon: ReceiptText, roles: ALL },
      { key: "assets", label: "Assets", icon: Boxes, roles: ALL },
      { key: "workflows", label: "Workflows", icon: Workflow, roles: HR_ONLY },
      { key: "helpdesk", label: "Helpdesk", icon: LifeBuoy, roles: ALL },
    ],
  },
  {
    label: "Engagement",
    items: [
      { key: "announcements", label: "Announcements", icon: Megaphone, roles: ALL },
      { key: "surveys", label: "Surveys", icon: ClipboardList, roles: ALL },
      { key: "documents", label: "Documents", icon: FileText, roles: ALL },
    ],
  },
  {
    label: "Intelligence",
    items: [
      { key: "assistant", label: "AI Assistant", icon: Sparkles, roles: ALL },
    ],
  },
  {
    label: "Configure",
    items: [
      { key: "settings", label: "Settings", icon: Settings, roles: ALL },
    ],
  },
];

// ---------- Labels & colors ----------

export const STATUS_LABELS: Record<string, string> = {
  active: "Active", probation: "On Probation", notice: "On Notice", exited: "Exited",
  pending: "Pending", approved: "Approved", rejected: "Rejected", cancelled: "Cancelled",
  present: "Present", wfh: "WFH", late: "Late", absent: "Absent", leave: "On Leave",
  holiday: "Holiday", half_day: "Half Day",
  open: "Open", in_progress: "In Progress", resolved: "Resolved", closed: "Closed",
  low: "Low", medium: "Medium", high: "High", urgent: "Urgent",
  draft: "Draft", in_review: "In Review", paid: "Paid",
  full_time: "Full-time", part_time: "Part-time", contract: "Contract", intern: "Intern",
  on_hold: "On Hold", applied: "Applied", screening: "Screening", interview: "Interview",
  offer: "Offer", hired: "Hired",
  self_review: "Self Review", manager_review: "Manager Review", completed: "Completed",
  onboarding: "Onboarding",
  company: "Company", department: "Department", policy: "Policy",
  event: "Event", celebration: "Celebration",
  submitted: "Submitted", available: "Available", allocated: "Allocated",
  maintenance: "Maintenance", retired: "Retired", enrolled: "Enrolled",
  on_track: "On Track", at_risk: "At Risk", behind: "Behind",
  online: "Online", in_person: "In Person", hybrid: "Hybrid",
  enps: "eNPS", pulse: "Pulse", mandatory: "Mandatory",
  // Workflow executions, billing, pipelines & holidays
  done: "Done", due: "Due",
  trialing: "Trialing", past_due: "Past Due",
  success: "Success", failed: "Failed", running: "Running",
  new: "New", contacted: "Contacted", qualified: "Qualified",
  public: "Public Holiday", optional: "Optional",
  // Platform approval & payment proofs
  // ("active" and "pending" reuse the labels above)
  suspended: "Suspended",
  verified: "Verified", superseded: "Superseded", renewal_due: "Renewal due",
  trial_expired: "Trial expired", annual: "Annual", monthly: "Monthly",
  upi: "UPI", bank: "Bank transfer",
};

export const EXPENSE_CATEGORIES = [
  "Travel", "Food", "Accommodation", "Internet & Phone",
  "Office Supplies", "Training", "Client Entertainment", "Other",
];

export const ASSET_CATEGORIES = [
  "Laptop", "Desktop", "Monitor", "Phone", "Tablet",
  "Headset", "Access Card", "Furniture", "Other",
];

export const TRAINING_CATEGORIES = [
  "General", "Compliance", "Technical", "Leadership", "Safety", "Onboarding",
];

export const DOCUMENT_CATEGORIES = [
  "HR Policy", "Legal", "IT & Security", "Finance", "SOP", "Forms", "Other",
];

export const AVATAR_COLORS = [
  "#059669", "#0D9488", "#D97706", "#DC2626", "#7C3AED",
  "#DB2777", "#65A30D", "#EA580C", "#0891B2", "#4F46E5",
  "#9333EA", "#B45309",
];

export const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export const AI_SUGGESTIONS = [
  "What is our current headcount by department?",
  "How many leave requests are pending approval?",
  "How much have we spent on expenses this month?",
  "Draft an announcement for the upcoming holiday",
  "Which employees are on leave this week?",
  "Summarise our training compliance status",
];

export const TICKET_CATEGORIES = ["Payroll", "Leave", "IT & Access", "Facilities", "Policy", "Other"];
export const SOURCES = ["Careers Page", "Referral", "LinkedIn", "Naukri", "Recruiter", "Campus"];

/**
 * PeoplePulse HR — pure plan/approval state helpers.
 * Safe to import from both client components and server routes (no side effects).
 */
import type { BlockedState, PlanKey } from "./types";

export const PAID_PLAN_KEYS = ["starter", "growth", "professional"] as const;
export type PaidPlanKey = (typeof PAID_PLAN_KEYS)[number];

export function isPaidPlan(plan: string): plan is PaidPlanKey {
  return (PAID_PLAN_KEYS as readonly string[]).includes(plan);
}

export function isBillingCycle(cycle: string): cycle is "monthly" | "annual" {
  return cycle === "monthly" || cycle === "annual";
}

/** Raw tenant fields needed to compute the access block state. */
export interface PlanStateInput {
  planStatus: string; // pending | trialing | active | past_due | cancelled | rejected
  trialEndsAt: Date | string | null;
  paidUntil: Date | string | null;
}

function toDate(v: Date | string | null | undefined): Date | null {
  if (v == null) return null;
  const d = v instanceof Date ? v : new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

/**
 * Compute why (if at all) a tenant's workspace is blocked. Returns null when the
 * workspace is fully usable. The platform super admin is never blocked (checked
 * by callers, since this pure helper has no user context).
 */
export function blockState(t: PlanStateInput): BlockedState | null {
  const now = Date.now();
  switch (t.planStatus) {
    case "pending":
      return "pending";
    case "rejected":
      return "rejected";
    case "cancelled":
    case "past_due":
      return "suspended";
    case "trialing": {
      const ends = toDate(t.trialEndsAt);
      return ends && ends.getTime() < now ? "trial_expired" : null;
    }
    case "active": {
      const until = toDate(t.paidUntil);
      return until && until.getTime() < now ? "renewal_due" : null;
    }
    default:
      return null;
  }
}

/** Human-readable explanation for each blocked state (used in API 403s and UI). */
export function blockedMessage(state: BlockedState): string {
  switch (state) {
    case "pending":
      return "Your workspace is awaiting activation. The platform administrator reviews every new signup — you will receive an email as soon as your workspace is approved.";
    case "rejected":
      return "Your signup request was declined by the platform administrator. Please contact support if you believe this is a mistake.";
    case "suspended":
      return "Your workspace has been suspended by the platform administrator. Please contact support to restore access.";
    case "trial_expired":
      return "Your free trial has ended. Choose a plan and submit your payment reference (UTR) to continue using PeoplePulse HR.";
    case "renewal_due":
      return "Your subscription period has ended. Submit your renewal payment reference (UTR) to continue using PeoplePulse HR.";
    default:
      return "Your workspace is not active.";
  }
}

/** Months a billing cycle covers. */
export function cycleMonths(cycle: string): number {
  return cycle === "annual" ? 12 : 1;
}

/** All plans a buyer can pick on the payment screen (excludes trial & enterprise). */
export const PURCHASABLE_PLANS: PlanKey[] = ["starter", "growth", "professional"];

/**
 * PeoplePulse HR — shared helpers for API route handlers.
 */
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { AuthError } from "@/lib/auth";

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json(data, init);
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

/** Wrap route handler bodies: converts AuthError and unexpected errors into JSON responses. */
export async function handle(fn: () => Promise<Response>): Promise<Response> {
  try {
    return await fn();
  } catch (e) {
    if (e instanceof AuthError) return fail(e.message, e.status);
    const message = e instanceof Error ? e.message : "Unexpected server error";
    console.error("[api]", message);
    return fail(message, 500);
  }
}

// ---------- Side-effect helpers (audit trail, notifications, workflow automation) ----------

export async function audit(
  tenantId: string,
  entry: {
    actorName: string;
    actorRole: string;
    action: string;
    entity: string;
    entityId?: string | null;
    summary: string;
    severity?: "info" | "warning" | "critical";
  }
) {
  try {
    await db.auditLog.create({
      data: {
        tenantId,
        actorName: entry.actorName,
        actorRole: entry.actorRole,
        action: entry.action,
        entity: entry.entity,
        entityId: entry.entityId ?? null,
        summary: entry.summary,
        severity: entry.severity ?? "info",
      },
    });
  } catch (e) {
    console.error("[audit] failed", e);
  }
}

export async function notify(
  tenantId: string,
  entry: { title: string; body: string; type?: string; userId?: string | null }
) {
  try {
    await db.notification.create({
      data: {
        tenantId,
        userId: entry.userId ?? null,
        title: entry.title,
        body: entry.body,
        type: entry.type ?? "info",
      },
    });
  } catch (e) {
    console.error("[notify] failed", e);
  }
}

/**
 * Trigger a workflow automation: finds an ACTIVE workflow in the tenant with the
 * given triggerCode and records a successful execution with steps + context.
 * Used by leave/attendance/payroll/ticket routes to demonstrate real automation.
 */
export async function triggerWorkflow(
  tenantId: string,
  triggerCode: string,
  context: { trigger: string; summary: string; steps: { name: string; detail: string; ok: boolean }[] }
) {
  try {
    const wf = await db.workflow.findFirst({
      where: { tenantId, triggerCode, active: true },
    });
    if (!wf) return;
    const now = new Date();
    await db.workflowExecution.create({
      data: {
        tenantId,
        workflowId: wf.id,
        status: "success",
        trigger: context.trigger,
        summary: context.summary,
        startedAt: now,
        finishedAt: now,
        steps: JSON.stringify(context.steps),
      },
    });
    await db.workflow.update({
      where: { id: wf.id },
      data: { lastRunAt: now, executionCount: { increment: 1 } },
    });
  } catch (e) {
    console.error("[workflow] trigger failed", e);
  }
}

// ---------- Misc ----------

export function num(v: string | null | undefined, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function dateOnly(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/**
 * PeoplePulse HR — server-side session helpers for API routes.
 */
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { signSession, verifySessionToken } from "@/lib/crypto";
import { blockState, blockedMessage } from "@/lib/plan-state";
import type { Role, SessionUser } from "@/lib/types";

export const SESSION_COOKIE = "pp_session";

export async function setSessionCookie(userId: string) {
  const store = await cookies();
  store.set(SESSION_COOKIE, signSession(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 7 * 24 * 60 * 60,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

/** Returns the signed-in user (with tenant context) or null. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const payload = verifySessionToken(store.get(SESSION_COOKIE)?.value);
  if (!payload) return null;

  const user = await db.user.findUnique({
    where: { id: payload.userId },
    include: { tenant: true, employee: true },
  });
  if (!user || !user.tenant) return null;

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role as Role,
    superAdmin: user.superAdmin,
    tenantId: user.tenantId,
    tenantName: user.tenant.name,
    tenantSlug: user.tenant.slug,
    plan: user.tenant.plan as SessionUser["plan"],
    planStatus: user.tenant.planStatus,
    blocked: user.superAdmin ? null : blockState(user.tenant),
    statusReason: user.tenant.statusReason,
    billingCycle: user.tenant.billingCycle === "annual" ? "annual" : "monthly",
    paidUntil: user.tenant.paidUntil ? user.tenant.paidUntil.toISOString() : null,
    trialEndsAt: user.tenant.trialEndsAt ? user.tenant.trialEndsAt.toISOString() : null,
    brandColor: user.tenant.brandColor,
    logoText: user.tenant.logoText,
    seats: user.tenant.seats,
    employeeId: user.employee?.id ?? null,
    employeeCode: user.employee?.code ?? null,
    jobTitle: user.employee?.designation ?? null,
    department: user.employee?.department ?? null,
  };
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

/**
 * Use at the top of every protected API route:
 *   const session = await requireAuth();            // any signed-in user
 *   const session = await requireAuth(["owner","admin","hr"]); // role-restricted
 *   const session = await requireAuth(undefined, { pendingOk: true }); // billing routes
 *
 * Throws AuthError(401) if not signed in, AuthError(403) if the role is not
 * allowed, and AuthError(403) when the caller's workspace is blocked (pending
 * approval / rejected / suspended / expired). The platform super admin is
 * never blocked. Routes that must stay reachable for blocked workspaces
 * (payment submission, billing overview) pass { pendingOk: true }.
 */
export async function requireAuth(
  roles?: Role[],
  opts?: { pendingOk?: boolean }
): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new AuthError("Authentication required. Please sign in.", 401);
  if (roles && roles.length > 0 && !roles.includes(user.role)) {
    throw new AuthError("You do not have permission to perform this action.", 403);
  }
  if (user.blocked && !opts?.pendingOk) {
    throw new AuthError(blockedMessage(user.blocked), 403);
  }
  return user;
}

/**
 * PeoplePulse HR — Shared type contract.
 * This file is the single source of truth shared by the API routes and the UI.
 * Both backend and frontend code MUST import types from here.
 */

// ===================== Core enums =====================

export type Role = "owner" | "admin" | "hr" | "manager" | "employee";
export type PlanKey = "trial" | "starter" | "growth" | "professional" | "enterprise";

export type ModuleKey =
  | "dashboard"
  | "analytics"
  | "employees"
  | "orgchart"
  | "attendance"
  | "leave"
  | "recruitment"
  | "payroll"
  | "expenses"
  | "assets"
  | "training"
  | "performance"
  | "surveys"
  | "announcements"
  | "documents"
  | "directory"
  | "helpdesk"
  | "workflows"
  | "assistant"
  | "platform"
  | "settings";

export const ADMIN_MODULES: ModuleKey[] = [
  "dashboard", "analytics", "employees", "orgchart", "attendance", "leave",
  "recruitment", "payroll", "expenses", "assets", "training", "performance", "surveys",
  "announcements", "documents", "directory", "helpdesk", "workflows", "assistant", "platform", "settings",
];

export const EMPLOYEE_MODULES: ModuleKey[] = [
  "dashboard", "attendance", "leave", "payroll", "expenses", "assets", "training",
  "performance", "surveys", "announcements", "documents", "directory", "helpdesk",
  "assistant", "settings",
];

/** Roles allowed to see admin-level modules (anything beyond employee self-service). */
export const HR_ROLES: Role[] = ["owner", "admin", "hr", "manager"];
export const PAYROLL_ROLES: Role[] = ["owner", "admin", "hr"];

/** Why a workspace is blocked (null = fully active). Platform admins are never blocked. */
export type BlockedState =
  | "pending" // awaiting platform approval
  | "rejected" // signup declined
  | "suspended" // cancelled by platform admin
  | "trial_expired" // trial ended, must pick a plan & pay
  | "renewal_due"; // paid period ended, must renew

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  superAdmin: boolean;
  tenantId: string;
  tenantName: string;
  tenantSlug: string;
  plan: PlanKey;
  planStatus: string;
  blocked: BlockedState | null;
  statusReason: string | null;
  billingCycle: "monthly" | "annual";
  paidUntil: string | null;
  trialEndsAt: string | null;
  brandColor: string;
  logoText: string;
  seats: number;
  employeeId: string | null;
  employeeCode: string | null;
  jobTitle: string | null;
  department: string | null;
}

// ===================== Employees =====================

export type EmployeeStatus = "active" | "probation" | "notice" | "exited";
export type EmploymentType = "full_time" | "part_time" | "contract" | "intern";

export interface EmployeeListItem {
  id: string;
  code: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  location: string;
  managerName: string | null;
  joinDate: string; // YYYY-MM-DD
  employmentType: EmploymentType;
  status: EmployeeStatus;
  ctc: number; // annual INR
  avatarColor: string; // hex
  hasLogin: boolean; // true when a user account is linked to this employee
}

export interface EmployeeListResponse {
  items: EmployeeListItem[];
  total: number;
  page: number;
  pageSize: number;
  departments: string[];
  locations: string[];
}

export interface OnboardingTaskDto {
  id: string;
  title: string;
  category: string;
  assignee: string;
  dueDate: string;
  status: "pending" | "in_progress" | "done";
  order: number;
}

export interface EmployeeDetail extends EmployeeListItem {
  loginEmail: string | null;
  loginRole: string | null;
  dob: string | null;
  gender: string | null;
  emergencyContact: string | null;
  managerId: string | null;
  exitDate: string | null;
  createdAt: string;
  balances: LeaveBalanceDto[];
  attendance30d: {
    date: string;
    status: string;
    checkIn: string | null;
    checkOut: string | null;
  }[];
  payslipCount: number;
  lastPayslipNet: number | null;
  reviewStatus: string | null;
  onboardingTasks: OnboardingTaskDto[];
}

export interface BulkImportRow {
  row: number;
  name: string;
  email: string;
  status: "ok" | "error";
  message?: string;
}

export interface BulkImportResponse {
  created: number;
  failed: number;
  rows: BulkImportRow[];
  /** Present when bulk login creation was requested. */
  loginsCreated?: number;
  /** The shared initial password used for created logins (shown once). */
  loginPassword?: string;
}

export interface OrgChartNode {
  id: string;
  code: string;
  name: string;
  designation: string;
  department: string;
  avatarColor: string;
  children: OrgChartNode[];
}

export interface DepartmentDto {
  id: string;
  name: string;
  description: string | null;
  headName: string | null;
  employeeCount: number;
}

// ===================== Leave =====================

export interface LeaveTypeDto {
  id: string;
  name: string;
  code: string;
  annualQuota: number;
  paid: boolean;
  carryForward: boolean;
}

export interface LeaveBalanceDto {
  leaveTypeId: string;
  name: string;
  code: string;
  entitled: number;
  used: number;
  pending: number;
  available: number;
}

export type LeaveRequestStatus = "pending" | "approved" | "rejected" | "cancelled";

export interface LeaveRequestDto {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  avatarColor: string;
  leaveTypeId: string;
  typeName: string;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: LeaveRequestStatus;
  approverName: string | null;
  comment: string | null;
  decidedAt: string | null;
  createdAt: string;
}

export interface LeaveCalendarDay {
  date: string; // YYYY-MM-DD
  isWeekend: boolean;
  holiday?: { name: string; type: string };
  leaves: { employeeName: string; typeName: string; avatarColor: string }[];
}

// ===================== Attendance =====================

export type AttendanceStatus =
  | "present" | "wfh" | "late" | "absent" | "leave" | "holiday" | "half_day";

export interface AttendanceDto {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  avatarColor: string;
  date: string;
  checkIn: string | null; // "HH:MM"
  checkOut: string | null;
  status: AttendanceStatus;
  hours: number | null;
  note: string | null;
  // Geo-fencing — captured at check-in
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null;
  distanceMeters: number | null;
  geoStatus: string | null; // inside | outside | unverified
}

export interface AttendanceSummary {
  present: number;
  wfh: number;
  late: number;
  absent: number;
  leave: number;
  holiday: number;
  total: number;
}

export interface MyAttendanceResponse {
  month: string; // YYYY-MM
  summary: AttendanceSummary;
  records: AttendanceDto[];
  avgHours: number;
}

// ===================== Recruitment =====================

export type OpeningStatus = "open" | "on_hold" | "closed";

export interface JobOpeningDto {
  id: string;
  title: string;
  department: string;
  location: string;
  employmentType: EmploymentType;
  openings: number;
  status: OpeningStatus;
  hiringManager: string;
  minExpYears: number;
  maxSalary: number | null; // annual INR
  skills: string[];
  description: string;
  candidateCount: number;
  createdAt: string;
}

export type CandidateStage =
  | "applied" | "screening" | "interview" | "offer" | "hired" | "rejected";

export interface CandidateDto {
  id: string;
  openingId: string;
  openingTitle: string;
  name: string;
  email: string;
  phone: string | null;
  source: string;
  stage: CandidateStage;
  rating: number | null; // 1-5
  expectedSalary: number | null;
  noticePeriod: string | null;
  resumeSummary: string | null;
  notes: string | null;
  appliedAt: string;
  updatedAt: string;
}

export interface RecruitmentAnalytics {
  funnel: { stage: string; count: number }[];
  avgTimeToHireDays: number | null;
  sourceSplit: { name: string; value: number }[];
  openRoles: number;
  activeCandidates: number;
  offersPending: number;
}

// ===================== Payroll =====================

export type PayrollStatus = "draft" | "in_review" | "approved" | "paid";

export interface PayslipDto {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  department: string;
  designation: string;
  daysPaid: number;
  lopDays: number;
  basic: number;
  hra: number;
  specialAllowance: number;
  gross: number;
  pf: number;
  esic: number;
  pt: number;
  tds: number;
  otherDeductions: number;
  net: number;
}

export interface PayrollRunSummary {
  id: string;
  month: number;
  year: number;
  label: string; // "November 2025"
  status: PayrollStatus;
  employeeCount: number;
  grossTotal: number;
  netTotal: number;
  processedAt: string | null;
  approvedBy: string | null;
  approvedAt: string | null;
}

export interface PayrollRunDto extends PayrollRunSummary {
  payslips: PayslipDto[];
}

export interface PayrollConfigDto {
  effectiveFrom: string;
  currency: string;
  note: string;
  basicPercentOfCtc: number;
  hraPercentOfBasic: number;
  paidDaysBasis: number;
  epf: { enabled: boolean; employeeRate: number; wageCeiling: number };
  esic: { enabled: boolean; employeeRate: number; grossCeiling: number };
  professionalTax: { state: string; slabs: { upto: number | null; monthly: number }[] };
  tds: {
    mode: string;
    annualStandardDeduction: number;
    slabs: { upto: number | null; rate: number }[];
  };
}

// ===================== Performance =====================

export type ReviewStatus = "draft" | "self_review" | "manager_review" | "completed";

export interface ReviewGoal {
  title: string;
  progress: number; // 0-100
}

export interface ReviewDto {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  designation: string;
  avatarColor: string;
  cycle: string;
  periodLabel: string;
  status: ReviewStatus;
  selfRating: number | null; // 1-5
  managerRating: number | null;
  finalRating: number | null;
  goals: ReviewGoal[];
  reviewerName: string | null;
  dueDate: string;
  summary: string | null;
  strengths: string | null;
  improvements: string | null;
  completedAt: string | null;
}

export interface PerformanceSummary {
  distribution: { rating: string; count: number }[];
  avgRating: number | null;
  byDepartment: { name: string; avg: number | null; count: number }[];
  cycleProgress: { status: string; count: number }[];
}

// ===================== Engagement =====================

export interface AnnouncementDto {
  id: string;
  title: string;
  body: string;
  category: string; // company | department | policy | event | celebration
  authorName: string;
  pinned: boolean;
  acknowledgedCount: number;
  createdAt: string;
  /** Whether the CURRENT user has acknowledged this announcement. Populated
   *  per-caller by the announcements list/ack routes (base DTO mappers that
   *  have no caller context leave it undefined). */
  hasAcked?: boolean;
}

export type TicketStatus = "open" | "in_progress" | "resolved" | "closed";
export type TicketPriority = "low" | "medium" | "high" | "urgent";

export interface TicketMessage {
  author: string;
  role: "requester" | "hr";
  content: string;
  at: string;
}

export interface TicketDto {
  id: string;
  ticketNo: string;
  subject: string;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  requesterName: string;
  requesterEmail: string | null;
  assignedTo: string | null;
  slaHours: number;
  createdAt: string;
  resolvedAt: string | null;
  ageHours: number;
  messages: TicketMessage[];
}

// ===================== Workflows =====================

export interface WorkflowDto {
  id: string;
  name: string;
  description: string;
  category: string;
  triggerCode: string;
  triggerLabel: string;
  active: boolean;
  lastRunAt: string | null;
  executionCount: number;
}

export interface WorkflowExecutionStep {
  name: string;
  detail: string;
  ok: boolean;
}

export interface WorkflowExecutionDto {
  id: string;
  workflowId: string;
  workflowName: string;
  status: "success" | "failed" | "running";
  trigger: string;
  summary: string;
  startedAt: string;
  finishedAt: string | null;
  steps: WorkflowExecutionStep[];
}

// ===================== Platform =====================

/** GET /api/org/setup — first-run workspace checklist (owner | admin | hr). */
export interface OrgSetupDto {
  employees: number;
  withLogins: number;
  departments: number;
  leaveTypes: number;
  announcements: number;
  complete: boolean;
}

export interface AuditLogDto {
  id: string;
  actorName: string;
  actorRole: string;
  action: string;
  entity: string;
  entityId: string | null;
  summary: string;
  severity: "info" | "warning" | "critical";
  createdAt: string;
}

export interface InvoiceDto {
  id: string;
  number: string;
  plan: string;
  periodLabel: string;
  seats: number;
  amount: number;
  tax: number;
  total: number;
  status: "paid" | "due";
  issuedAt: string;
  paidAt: string | null;
  method: string | null;
}

// ===================== Platform payments (manual UTR flow) =====================

/** A payment channel owned by the platform operator (bank account / UPI ID). */
export interface PaymentMethodDto {
  id: string;
  label: string;
  type: "upi" | "bank";
  upiId: string | null;
  accountHolder: string | null;
  accountNumber: string | null;
  ifsc: string | null;
  bankName: string | null;
  accountType: string | null;
  instructions: string | null;
  active: boolean;
  sortOrder: number;
}

/** A buyer-submitted payment reference awaiting manual verification. */
export interface PaymentProofDto {
  id: string;
  tenantId: string;
  utr: string;
  amount: number;
  payerName: string;
  paidAt: string; // ISO date
  method: "upi" | "bank";
  note: string | null;
  plan: string;
  cycle: "monthly" | "annual";
  seats: number;
  status: "submitted" | "verified" | "rejected" | "superseded";
  reviewNote: string | null;
  reviewedAt: string | null;
  createdAt: string;
}

/** Price breakdown for a plan/cycle/seats selection. */
export interface PlanPriceDto {
  rate: number;
  months: number;
  amount: number;
  tax: number;
  total: number;
}

/** Everything the buyer's payment screen needs in one call. */
export interface BillingOverviewDto {
  methods: PaymentMethodDto[];
  proofs: PaymentProofDto[]; // this workspace's submissions, newest first
  config: {
    plan: string;
    cycle: "monthly" | "annual";
    seats: number;
    planStatus: string;
    blocked: BlockedState | null;
    statusReason: string | null;
    trialEndsAt: string | null;
    paidUntil: string | null;
  };
  price: PlanPriceDto | null; // null for trial/enterprise plans
}

/** One row in the Platform Admin tenant table. */
export interface AdminTenantDto {
  id: string;
  name: string;
  slug: string;
  plan: string;
  cycle: "monthly" | "annual";
  seats: number;
  planStatus: string;
  blocked: BlockedState | null;
  statusReason: string | null;
  trialEndsAt: string | null;
  paidUntil: string | null;
  approvedAt: string | null;
  ownerName: string;
  ownerEmail: string;
  employeeCount: number;
  createdAt: string;
  latestProof: PaymentProofDto | null;
  price: PlanPriceDto | null;
}

export interface AdminStatsDto {
  total: number;
  pending: number;
  active: number;
  trialing: number;
  rejected: number;
  cancelled: number;
  pendingProofs: number;
  mrr: number; // approximate monthly recurring revenue (INR)
}

export interface PolicyDto {
  id: string;
  title: string;
  category: string;
  version: string;
  audience: string;
  content: string;
  updatedBy: string;
  updatedAt: string;
}

export interface HolidayDto {
  id: string;
  name: string;
  date: string; // YYYY-MM-DD
  type: "public" | "optional";
}

export interface NotificationDto {
  id: string;
  title: string;
  body: string;
  type: string;
  read: boolean;
  createdAt: string;
}

export interface LeadDto {
  id: string;
  name: string;
  email: string;
  company: string;
  companySize: string;
  plan: string;
  message: string;
  status: "new" | "contacted" | "qualified";
  createdAt: string;
}

export interface OrgProfileDto {
  id: string;
  name: string;
  slug: string;
  plan: PlanKey;
  planStatus: string;
  trialEndsAt: string | null;
  seats: number;
  employeeCount: number;
  brandColor: string;
  logoText: string;
  country: string;
  currency: string;
  timezone: string;
  createdAt: string;
  onboardingStep: number;
}

/** GET /api/org/geo-fence — attendance geo-fence config (any signed-in user). */
export interface GeoFenceConfigDto {
  enabled: boolean;
  officeLabel: string | null;
  officeLatitude: number | null;
  officeLongitude: number | null;
  officeRadiusMeters: number;
}

// ===================== Dashboards =====================

export interface KpiTiles {
  totalEmployees: number;
  activeToday: number;
  presentPct: number;
  onLeaveToday: number;
  pendingApprovals: number;
  openTickets: number;
  attritionRate: number; // annualised %
  headcountChange30d: number;
  newJoiners30d: number;
  exits30d: number;
  monthlyPayrollCost: number;
  openRoles: number;
}

export interface AdminDashboard {
  kpis: KpiTiles;
  headcountTrend: { month: string; count: number }[];
  attritionTrend: { month: string; exits: number }[];
  departmentSplit: { name: string; value: number }[];
  attendanceTrend: { date: string; presentPct: number }[];
  leaveUtilization: { name: string; used: number; entitled: number }[];
  pendingLeaveRequests: LeaveRequestDto[];
  upcomingHolidays: HolidayDto[];
  recentAnnouncements: AnnouncementDto[];
  payroll: { label: string; status: PayrollStatus; netTotal: number; employeeCount: number };
  engagement: { pulseScore: number | null; participation: number };
}

export interface EmployeeDashboard {
  greeting: { firstName: string; designation: string; department: string };
  myAttendance: {
    present: number;
    wfh: number;
    late: number;
    leave: number;
    absent: number;
    avgHours: number;
    todayStatus: string | null;
  };
  myBalances: LeaveBalanceDto[];
  myPayslips: { id: string; label: string; net: number; status: PayrollStatus }[];
  myPendingRequests: LeaveRequestDto[];
  upcomingHolidays: HolidayDto[];
  announcements: AnnouncementDto[];
  onboardingTasks: OnboardingTaskDto[];
}

export interface AnalyticsResponse {
  headcountTrend: { month: string; hired: number; exited: number; total: number }[];
  tenureBuckets: { name: string; value: number }[];
  genderSplit: { name: string; value: number }[];
  deptAttendance: { name: string; rate: number }[];
  leaveUtilizationByType: { name: string; used: number; entitled: number }[];
  hiringFunnel: { stage: string; count: number }[];
  sourceOfHire: { name: string; value: number }[];
  payrollCostTrend: { month: string; gross: number; net: number }[];
  ticketMetrics: {
    avgResolutionHours: number | null;
    openCount: number;
    resolvedCount: number;
    byCategory: { name: string; value: number }[];
  };
  ratingDistribution: { rating: string; count: number }[];
}

// ===================== AI =====================

export interface AiChatMessageDto {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

/** POST /api/ai/screen — AI resume screening result. */
export interface AiScreenResultDto {
  verdict: "strong" | "moderate" | "weak";
  score: number; // 0-100
  summary: string;
  strengths: string[];
  concerns: string[];
}

// ===================== Expenses =====================

export type ExpenseStatus = "submitted" | "approved" | "rejected" | "paid" | "cancelled";

export interface ExpenseClaimDto {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  avatarColor: string;
  title: string;
  category: string;
  amount: number; // INR
  expenseDate: string; // YYYY-MM-DD
  description: string;
  status: ExpenseStatus;
  approverName: string | null;
  comment: string | null;
  decidedAt: string | null;
  paidAt: string | null;
  createdAt: string;
}

export interface ExpensesSummaryDto {
  mySubmitted: number;
  myApprovedMonthTotal: number; // INR approved in current calendar month
  pendingApprovalCount: number; // visible to approvers, else 0
  orgMonthTotal: number; // INR approved org-wide this month (hr/admin/owner), else 0
}

// ===================== Assets =====================

export type AssetStatus = "available" | "allocated" | "maintenance" | "retired";

export interface AssetDto {
  id: string;
  name: string;
  category: string;
  assetTag: string;
  serialNumber: string | null;
  value: number; // INR
  purchaseDate: string | null; // YYYY-MM-DD
  status: AssetStatus;
  notes: string | null;
  currentAllocation: {
    employeeId: string;
    employeeName: string;
    allocatedAt: string;
  } | null;
  createdAt: string;
}

export interface MyAssetDto {
  id: string; // allocation id
  assetId: string;
  name: string;
  category: string;
  assetTag: string;
  serialNumber: string | null;
  value: number;
  allocatedAt: string;
}

// ===================== Training =====================

export interface TrainingCourseDto {
  id: string;
  title: string;
  description: string;
  category: string;
  mode: string; // online | in_person | hybrid
  durationHours: number;
  provider: string | null;
  mandatory: boolean;
  published: boolean;
  enrolledCount: number;
  completedCount: number;
  myEnrollment: {
    id: string;
    status: string;
    progress: number;
    score: number | null;
    completedAt: string | null;
  } | null;
}

export interface MyLearningDto {
  id: string; // enrollment id
  courseId: string;
  title: string;
  category: string;
  mode: string;
  durationHours: number;
  mandatory: boolean;
  status: string;
  progress: number;
  score: number | null;
  enrolledAt: string;
  completedAt: string | null;
}

// ===================== Surveys =====================

export interface SurveyQuestionDto {
  id: string;
  text: string;
  type: "rating_10" | "choice" | "text";
  options: string[];
  order: number;
}

export interface SurveyListItemDto {
  id: string;
  title: string;
  description: string;
  type: string; // enps | pulse | custom
  status: string; // draft | active | closed
  anonymous: boolean;
  questionCount: number;
  responseCount: number;
  hasResponded: boolean;
  createdAt: string;
  closesAt: string | null;
}

export interface SurveyResultsDto {
  participation: number; // 0-100
  totalEmployees: number;
  perQuestion: {
    questionId: string;
    type: string;
    average: number | null;
    distribution: { label: string; count: number }[];
    textAnswers: string[];
  }[];
}

export interface SurveyDetailDto {
  survey: SurveyListItemDto;
  questions: SurveyQuestionDto[];
  results: SurveyResultsDto | null;
  myAnswers: { questionId: string; value: string }[] | null;
}

// ===================== Documents =====================

export interface DocumentDto {
  id: string;
  title: string;
  category: string;
  content: string;
  excerpt: string;
  version: number;
  audience: string;
  tags: string[];
  updatedBy: string;
  updatedAt: string;
}

// ===================== Goals (OKR) =====================

export type GoalStatus = "on_track" | "at_risk" | "behind" | "completed";

export interface GoalDto {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  avatarColor: string;
  cycle: string;
  title: string;
  description: string;
  metric: string | null;
  targetValue: number;
  currentValue: number;
  unit: string | null;
  progress: number; // 0-100 computed
  status: GoalStatus;
  dueDate: string | null;
  createdAt: string;
  updatedAt: string;
}

// ===================== API conventions =====================

/** All error responses use this shape: { error: string } */
export interface ApiErrorBody {
  error: string;
}

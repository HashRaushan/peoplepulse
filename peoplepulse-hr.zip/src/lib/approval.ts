/**
 * PeoplePulse HR — server-side platform approval & billing helpers.
 * (Server only — imports Prisma & auth.)
 */
import { db } from "@/lib/db";
import { requireAuth, AuthError } from "@/lib/auth";
import { audit, notify } from "@/lib/api-helpers";
import { computePlanPrice } from "@/lib/billing";
import { isPaidPlan } from "@/lib/plan-state";
import type { SessionUser } from "@/lib/types";

/** Throws 403 unless the caller is the platform super admin. */
export async function requirePlatformAdmin(): Promise<SessionUser> {
  const session = await requireAuth();
  if (!session.superAdmin) {
    throw new AuthError("Platform administrator access required.", 403);
  }
  return session;
}

/** The platform super admin user (first one found), if any exists yet. */
export async function findPlatformAdminUser() {
  return db.user.findFirst({ where: { superAdmin: true }, orderBy: { createdAt: "asc" } });
}

/** In-app notification for the platform admin (bell icon + Platform Admin panel). */
export async function notifyPlatformAdmin(title: string, body: string) {
  try {
    const admin = await findPlatformAdminUser();
    if (!admin) return;
    await notify(admin.tenantId, { title, body, type: "billing", userId: admin.id });
  } catch (e) {
    console.error("[notifyPlatformAdmin] failed", e);
  }
}

/** Platform-level audit entry, written against the super admin's own tenant. */
export async function platformAudit(entry: {
  actorName: string;
  action: string;
  entity: string;
  entityId?: string | null;
  summary: string;
  severity?: "info" | "warning" | "critical";
}) {
  try {
    const admin = await findPlatformAdminUser();
    if (!admin) return;
    await audit(admin.tenantId, {
      actorName: entry.actorName,
      actorRole: "platform_admin",
      action: entry.action,
      entity: entry.entity,
      entityId: entry.entityId ?? null,
      summary: entry.summary,
      severity: entry.severity ?? "info",
    });
  } catch (e) {
    console.error("[platformAudit] failed", e);
  }
}

/**
 * Seed the platform payment methods from env vars the very first time the
 * table is read (fresh deployments). Afterwards the DB rows are the source of
 * truth — the admin edits them in Platform Admin → Payment methods.
 *
 * The bank details fall back to hard-coded defaults so a fresh deployment
 * ALWAYS shows the correct account to buyers, even when the environment does
 * not carry the PLATFORM_BANK_* variables (some deployment pipelines strip
 * .env). Env vars still win when set.
 */
const DEFAULT_BANK_HOLDER = "Raushan Kumar Pathak";
const DEFAULT_BANK_ACCOUNT = "08100200000616";
const DEFAULT_BANK_IFSC = "BARB0PHAGWA";
const DEFAULT_BANK_NAME = "Bank of Baroda";
const DEFAULT_BANK_TYPE = "Current Account";

export async function ensureDefaultPaymentMethods() {
  const count = await db.paymentMethod.count();
  if (count > 0) return;

  const holder = (process.env.PLATFORM_BANK_HOLDER ?? DEFAULT_BANK_HOLDER).trim();
  const account = (process.env.PLATFORM_BANK_ACCOUNT ?? DEFAULT_BANK_ACCOUNT).trim();
  const ifsc = (process.env.PLATFORM_BANK_IFSC ?? DEFAULT_BANK_IFSC).trim().toUpperCase();
  const bankName = (process.env.PLATFORM_BANK_NAME ?? DEFAULT_BANK_NAME).trim();
  const accountType = (process.env.PLATFORM_BANK_TYPE ?? DEFAULT_BANK_TYPE).trim();
  const upiId = (process.env.PLATFORM_UPI_ID ?? "").trim();

  if (account && ifsc) {
    await db.paymentMethod.create({
      data: {
        label: "Bank transfer (NEFT / IMPS / RTGS)",
        type: "bank",
        accountHolder: holder || null,
        accountNumber: account,
        ifsc,
        bankName: bankName || null,
        accountType: accountType || null,
        instructions:
          "Transfer the exact amount shown, then submit the transaction reference (UTR) below. " +
          "Please mention your company name in the payment remarks.",
        active: true,
        sortOrder: 10,
      },
    });
  }
  if (upiId) {
    await db.paymentMethod.create({
      data: {
        label: "UPI",
        type: "upi",
        upiId,
        accountHolder: holder || null,
        instructions:
          "Pay via any UPI app, then submit the 12-digit UPI transaction reference (UTR) below.",
        active: true,
        sortOrder: 5,
      },
    });
  }
}

// ============================== Invoices ==============================

function invoiceNumber(): string {
  const now = new Date();
  const ym = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}`;
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `INV-${ym}-${rand}`;
}

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export function periodLabelFor(cycle: string, from: Date): string {
  const months = cycle === "annual" ? 12 : 1;
  const to = new Date(from);
  to.setMonth(to.getMonth() + months);
  const sameYear = from.getFullYear() === to.getFullYear();
  const startLabel = `${MONTH_NAMES[from.getMonth()]} ${from.getFullYear()}`;
  const endLabel = sameYear
    ? MONTH_NAMES[to.getMonth() === from.getMonth() ? from.getMonth() : (to.getMonth() - 1 + 12) % 12]
    : `${MONTH_NAMES[(to.getMonth() - 1 + 12) % 12]} ${to.getFullYear()}`;
  return cycle === "annual" ? `Annual — ${startLabel} to ${endLabel}` : `Monthly — ${startLabel}`;
}

/**
 * Create a PAID invoice for a verified payment. Amount comes from the proof
 * snapshot when available (what the buyer actually paid), else is computed
 * from the tenant's plan/cycle/seats.
 */
export async function createPaidInvoice(tenant: {
  id: string;
  plan: string;
  billingCycle: string;
  seats: number;
}, proof: { amount: number; plan: string; cycle: string; seats: number; method: string } | null) {
  const plan = proof?.plan ?? tenant.plan;
  const cycle = proof?.cycle ?? tenant.billingCycle;
  const seats = proof?.seats ?? tenant.seats;
  const computed = isPaidPlan(plan)
    ? computePlanPrice(plan, cycle === "annual" ? "annual" : "monthly", seats)
    : null;
  // proof.amount is GST-INCLUSIVE (it is what the buyer actually transferred);
  // computed.amount is pre-tax. Normalise both to a GST-inclusive gross and back
  // out the 18% GST so the invoice never double-taxes a submitted payment.
  const gross = proof?.amount ?? computed?.total ?? 0;
  const amount = Math.round(gross / 1.18);
  const tax = gross - amount;
  const issuedAt = new Date();

  let number = invoiceNumber();
  for (let i = 0; i < 4; i += 1) {
    const clash = await db.invoice.findFirst({ where: { tenantId: tenant.id, number }, select: { id: true } });
    if (!clash) break;
    number = invoiceNumber();
  }

  return db.invoice.create({
    data: {
      tenantId: tenant.id,
      number,
      plan,
      periodLabel: periodLabelFor(cycle, issuedAt),
      seats,
      amount,
      tax,
      total: gross,
      status: "paid",
      issuedAt,
      paidAt: issuedAt,
      method: proof?.method === "upi" ? "UPI" : "Bank transfer",
    },
  });
}

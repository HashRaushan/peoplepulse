/**
 * PeoplePulse HR — API client.
 * All frontend data fetching MUST go through this module.
 */

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = init ?? {};
  const res = await fetch(path, {
    ...rest,
    headers: {
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(rest.headers ?? {}),
    },
    ...(json !== undefined ? { body: JSON.stringify(json) } : {}),
  });
  const text = await res.text();
  let body: unknown = null;
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = { error: text };
    }
  }
  if (!res.ok) {
    const message =
      (body && typeof body === "object" && "error" in body && typeof body.error === "string"
        ? body.error
        : `Request failed (${res.status})`);
    throw new ApiError(message, res.status);
  }
  return body as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, json?: unknown) => request<T>(path, { method: "POST", json }),
  patch: <T>(path: string, json?: unknown) => request<T>(path, { method: "PATCH", json }),
  delete: <T>(path: string) => request<T>(path, { method: "DELETE" }),
};

/** TanStack Query key factories (use these for consistency). */
export const qk = {
  me: ["me"] as const,
  dashboard: ["dashboard"] as const,
  analytics: ["analytics"] as const,
  employees: (filters?: Record<string, unknown>) => ["employees", filters ?? {}] as const,
  employee: (id: string) => ["employee", id] as const,
  orgChart: ["org-chart"] as const,
  departments: ["departments"] as const,
  orgProfile: ["org-profile"] as const,
  orgSetup: ["org-setup"] as const,
  attendance: (filters: Record<string, unknown>) => ["attendance", filters] as const,
  myAttendance: (month: string) => ["my-attendance", month] as const,
  leaveTypes: ["leave-types"] as const,
  leaveRequests: (filters?: Record<string, unknown>) => ["leave-requests", filters ?? {}] as const,
  leaveBalances: (employeeId?: string) => ["leave-balances", employeeId ?? "me"] as const,
  leaveCalendar: (month: string) => ["leave-calendar", month] as const,
  openings: ["job-openings"] as const,
  candidates: (filters?: Record<string, unknown>) => ["candidates", filters ?? {}] as const,
  recruitmentAnalytics: ["recruitment-analytics"] as const,
  payrollRuns: ["payroll-runs"] as const,
  payrollRun: (id: string) => ["payroll-run", id] as const,
  payrollConfig: ["payroll-config"] as const,
  myPayslips: ["my-payslips"] as const,
  reviews: (filters?: Record<string, unknown>) => ["reviews", filters ?? {}] as const,
  performanceSummary: ["performance-summary"] as const,
  announcements: ["announcements"] as const,
  tickets: (filters?: Record<string, unknown>) => ["tickets", filters ?? {}] as const,
  workflows: ["workflows"] as const,
  workflowExecutions: (id: string) => ["workflow-executions", id] as const,
  audit: (filters?: Record<string, unknown>) => ["audit", filters ?? {}] as const,
  policies: ["policies"] as const,
  holidays: ["holidays"] as const,
  notifications: ["notifications"] as const,
  invoices: ["invoices"] as const,
  leads: ["leads"] as const,
  aiHistory: ["ai-history"] as const,
  expenses: (filters?: Record<string, unknown>) => ["expenses", filters ?? {}] as const,
  assets: (filters?: Record<string, unknown>) => ["assets", filters ?? {}] as const,
  myAssets: ["my-assets"] as const,
  trainingCourses: (filters?: Record<string, unknown>) => ["training-courses", filters ?? {}] as const,
  myLearning: ["my-learning"] as const,
  surveys: ["surveys"] as const,
  survey: (id: string) => ["survey", id] as const,
  documents: (filters?: Record<string, unknown>) => ["documents", filters ?? {}] as const,
  goals: (filters?: Record<string, unknown>) => ["goals", filters ?? {}] as const,
  geoFence: ["geo-fence"] as const,
  // Platform payments (manual UTR flow)
  billingOverview: ["billing-overview"] as const,
  adminTenants: ["admin-tenants"] as const,
  adminPaymentMethods: ["admin-payment-methods"] as const,
};

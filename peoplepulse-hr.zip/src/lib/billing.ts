/**
 * PeoplePulse HR — pricing computation (shared by API routes and UI).
 * Rates come from PRICING_PLANS in constants.ts — never duplicate them here.
 */
import { PRICING_PLANS } from "./constants";
import type { PaidPlanKey } from "./plan-state";

export interface PlanPrice {
  /** Per-employee per-month rate in INR for the chosen cycle. */
  rate: number;
  /** Months covered (1 monthly, 12 annual). */
  months: number;
  /** Pre-tax total in INR: rate x seats x months. */
  amount: number;
  /** GST @ 18% in INR. */
  tax: number;
  /** Amount + tax. */
  total: number;
}

export function computePlanPrice(plan: PaidPlanKey, cycle: "monthly" | "annual", seats: number): PlanPrice {
  const p = PRICING_PLANS.find((x) => x.key === plan);
  const rate = cycle === "annual" ? (p?.annualPerEmployee ?? 0) : (p?.monthlyPerEmployee ?? 0);
  const months = cycle === "annual" ? 12 : 1;
  const safeSeats = Number.isFinite(seats) ? Math.max(1, Math.floor(seats)) : 1;
  const amount = Math.round(rate * safeSeats * months);
  const tax = Math.round(amount * 0.18);
  return { rate, months, amount, tax, total: amount + tax };
}

/** Format INR for emails and plain-text contexts (₹1,23,456). */
export function inrPlain(n: number): string {
  return `₹${n.toLocaleString("en-IN")}`;
}

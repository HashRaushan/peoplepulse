"use client";

/**
 * PeoplePulse HR — global client store (view routing + session mirror).
 */
import { create } from "zustand";
import type { ModuleKey, PlanKey, SessionUser } from "./types";

export type AppView = "site" | "auth" | "app";

interface AppState {
  view: AppView;
  authTab: "login" | "register";
  user: SessionUser | null;
  module: ModuleKey;
  booted: boolean;
  /** Plan pre-selected from the pricing page (registration plan step). */
  regPlan: PlanKey;
  setView: (view: AppView) => void;
  setAuthTab: (tab: "login" | "register") => void;
  setUser: (user: SessionUser | null) => void;
  setModule: (module: ModuleKey) => void;
  setBooted: (booted: boolean) => void;
  setRegPlan: (plan: PlanKey) => void;
  signOut: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  view: "auth",
  authTab: "login",
  user: null,
  module: "dashboard",
  booted: false,
  regPlan: "trial",
  setView: (view) => set({ view }),
  setAuthTab: (authTab) => set({ authTab }),
  setUser: (user) =>
    set({
      user,
      view: user ? "app" : "auth",
      module: "dashboard",
    }),
  setModule: (module) => set({ module }),
  setBooted: (booted) => set({ booted }),
  setRegPlan: (regPlan) => set({ regPlan }),
  signOut: () =>
    set({ user: null, view: "auth", authTab: "login", module: "dashboard" }),
}));

/**
 * PeoplePulse HR — pure crypto helpers (no Next.js imports; safe for seed scripts).
 * Passwords: scrypt with per-user salt. Sessions: HMAC-signed tokens.
 */
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

/**
 * Directory holding runtime data (the SQLite db). Same candidate logic as
 * src/lib/db.ts so the secret file lands next to the database in any layout.
 */
function dataDir(): string {
  const candidates = [
    path.join(process.cwd(), "db"),
    path.join(process.cwd(), ".next", "standalone", "db"),
    path.join(process.cwd(), "..", "db"),
  ];
  for (const dir of candidates) {
    try {
      if (existsSync(dir)) return dir;
    } catch {
      /* ignore */
    }
  }
  return candidates[0];
}

/**
 * Second-tier secret store: a key file next to the database. Lets sessions
 * survive server restarts in production even when no SESSION_SECRET env var
 * exists — the key is generated once and reused thereafter.
 */
function persistedSecret(): string | null {
  const file = path.join(dataDir(), "session-secret.key");
  try {
    const existing = readFileSync(file, "utf8").trim();
    if (existing.length >= 32) return existing;
  } catch {
    /* not there yet */
  }
  const generated = randomBytes(32).toString("hex");
  try {
    writeFileSync(file, generated, { mode: 0o600 });
    return generated;
  } catch {
    return null; // read-only filesystem — fall through to ephemeral
  }
}

/**
 * Session signing secret, resolved LAZILY (never at module scope).
 *
 * Why lazy: the Next.js production build imports this module while collecting
 * page data for API routes — a module-scope throw ("refusing to run") would
 * fail the deploy build in any environment that does not carry SESSION_SECRET.
 *
 * Resolution order:
 *   1. SESSION_SECRET env var — persistent, survives restarts (recommended).
 *   2. Production without it: a key file persisted next to the database —
 *      generated once, reused across restarts.
 *   3. Read-only filesystem: an ephemeral CSPRNG secret. Never a known
 *      constant, so tokens stay unforgeable; sessions reset on restart.
 *   4. Dev: fixed dev secret for convenience.
 */
let cachedSecret: string | null = null;
function sessionSecret(): string {
  if (cachedSecret) return cachedSecret;
  const fromEnv = process.env.SESSION_SECRET?.trim();
  if (fromEnv) {
    cachedSecret = fromEnv;
    return cachedSecret;
  }
  if (process.env.NODE_ENV === "production") {
    const persisted = persistedSecret();
    if (persisted) {
      cachedSecret = persisted;
      return cachedSecret;
    }
    console.warn(
      "[peoplepulse] SESSION_SECRET is not set and no key file could be written — " +
        "using an ephemeral random secret. Sessions reset when the server restarts."
    );
    cachedSecret = randomBytes(32).toString("hex");
  } else {
    cachedSecret = "peoplepulse-hr-dev-secret-change-in-production";
  }
  return cachedSecret;
}
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split(":");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

/** Uniform random index in [0, maxExclusive) drawn from the Node CSPRNG.
 *  Rejection sampling avoids the modulo bias a naive `% randomBytes` would have. */
function secureIndex(maxExclusive: number): number {
  const limit = 256 - (256 % maxExclusive);
  for (;;) {
    const b = randomBytes(1)[0];
    if (b < limit) return b % maxExclusive;
  }
}

/** Strong human-typable password: guaranteed char classes, 14 chars.
 *  Seeded entirely from the Node CSPRNG — never Math.random. */
export function generatePassword(): string {
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "23456789";
  const symbols = "!@#$%^&*";
  const all = lower + upper + digits + symbols;
  const pick = (set: string) => set[secureIndex(set.length)];
  const chars = [pick(lower), pick(upper), pick(digits), pick(symbols)];
  for (let i = 0; i < 10; i += 1) chars.push(pick(all));
  for (let i = chars.length - 1; i > 0; i -= 1) {
    const j = secureIndex(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

export interface SessionPayload {
  userId: string;
  issuedAt: number;
  expiresAt: number;
}

export function signSession(userId: string): string {
  const payload: SessionPayload = {
    userId,
    issuedAt: Date.now(),
    expiresAt: Date.now() + SESSION_TTL_MS,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = createHmac("sha256", sessionSecret()).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = createHmac("sha256", sessionSecret()).update(body).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as SessionPayload;
    if (payload.expiresAt < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/**
 * PeoplePulse HR — OpenRouter AI gateway (server-only).
 *
 * - Primary model from OPENROUTER_MODEL, fallbacks from OPENROUTER_FALLBACK_MODELS.
 * - Each model is tried in order; a non-200 response, network error or timeout
 *   moves on to the next model in the chain.
 * - The API key is NEVER logged or exposed — this module is imported only by
 *   API routes (backend), never from client components.
 */

export interface OpenRouterMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const REQUEST_TIMEOUT_MS = 45_000;

/** Whether an OpenRouter API key is present in the environment. */
export function openrouterConfigured(): boolean {
  return Boolean(process.env.OPENROUTER_API_KEY);
}

/** Model chain: primary first, then fallbacks, deduplicated (order preserved). */
function modelChain(): string[] {
  const primary = process.env.OPENROUTER_MODEL?.trim();
  const fallbacks = (process.env.OPENROUTER_FALLBACK_MODELS ?? "")
    .split(",")
    .map((m) => m.trim())
    .filter(Boolean);
  return [...(primary ? [primary] : []), ...fallbacks].filter(
    (m, i, arr) => arr.indexOf(m) === i
  );
}

/** Human-friendly label for the configured primary model, e.g. "DeepSeek v3". */
export function primaryModelLabel(): string {
  const id = process.env.OPENROUTER_MODEL?.trim() ?? "";
  if (!id) return "AI";
  if (id.includes("deepseek")) return "DeepSeek v3";
  if (id.includes("meta-llama")) return "Llama 3.3 70B";
  return id.split("/").pop() || id;
}

/**
 * Chat completion through OpenRouter with automatic model fallback.
 * Throws when the key is missing, no models are configured, or every model
 * in the chain fails (network error, non-200 status, timeout, empty reply).
 */
export async function openrouterChat(opts: {
  messages: OpenRouterMessage[];
  maxTokens?: number; // default 1500
  temperature?: number; // default 0.4
}): Promise<string> {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw new Error("OpenRouter key not configured");

  const models = modelChain();
  if (models.length === 0) throw new Error("No OpenRouter models configured");

  const maxTokens = opts.maxTokens ?? 1500;
  const temperature = opts.temperature ?? 0.4;

  let lastError = "unknown error";
  for (const model of models) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const res = await fetch(OPENROUTER_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "HTTP-Referer": "https://peoplepulse-hr.app",
          "X-Title": "PeoplePulse HR",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          messages: opts.messages,
          max_tokens: maxTokens,
          temperature,
        }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const detail = await res.text().catch(() => "");
        throw new Error(
          `model ${model} failed (${res.status})${detail ? `: ${detail.slice(0, 200)}` : ""}`
        );
      }

      const data = (await res.json()) as {
        choices?: { message?: { content?: unknown } }[];
      };
      const content = data.choices?.[0]?.message?.content;
      if (typeof content !== "string" || !content.trim()) {
        throw new Error(`model ${model} returned an empty response`);
      }
      return content;
    } catch (e) {
      lastError = e instanceof Error ? e.message : "unknown error";
      // Try the next model in the chain.
    } finally {
      clearTimeout(timer);
    }
  }

  throw new Error(`All OpenRouter models failed: ${lastError}`);
}

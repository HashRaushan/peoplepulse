import { PrismaClient } from '@prisma/client'
import path from 'node:path'
import { existsSync } from 'node:fs'

/**
 * DATABASE_URL resolution — resilient by design.
 *
 * The deployed app must boot in environments that carry no .env at all
 * (deployment pipelines commonly strip env files). Resolution order:
 *
 *   1. Explicit DATABASE_URL env var — used as-is when present.
 *   2. First existing candidate file among:
 *        - <cwd>/db/custom.db                  (bun run start / dev from project root)
 *        - <cwd>/.next/standalone/db/custom.db (db copied into the standalone bundle)
 *        - <cwd>/../db/custom.db               (cwd = .next/standalone)
 *      The build ships db/custom.db in the repository AND copies it into the
 *      standalone bundle, so at least one candidate always exists.
 *   3. Fallback: <cwd>/db/custom.db (Prisma creates the SQLite file on connect).
 *
 * Resolved BEFORE `new PrismaClient()` — Prisma reads the URL at construction.
 */
function resolveDatabaseUrl(): string {
  const fromEnv = process.env.DATABASE_URL?.trim();
  if (fromEnv) return fromEnv;

  const candidates = [
    path.join(process.cwd(), 'db', 'custom.db'),
    path.join(process.cwd(), '.next', 'standalone', 'db', 'custom.db'),
    path.join(process.cwd(), '..', 'db', 'custom.db'),
  ];
  for (const file of candidates) {
    if (existsSync(file)) {
      console.log(`[peoplepulse] using database: ${file}`);
      return `file:${file}`;
    }
  }
  const fallback = candidates[0];
  console.warn(`[peoplepulse] no database file found — will create: ${fallback}`);
  return `file:${fallback}`;
}

process.env.DATABASE_URL = resolveDatabaseUrl()

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

/**
 * PeoplePulse HR — outbound email (SMTP via nodemailer).
 *
 * Configure with env vars (see .env.example):
 *   SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS
 *   MAIL_FROM              — e.g. "PeoplePulse HR <billing@yourdomain.com>"
 *   PLATFORM_NOTIFY_EMAIL  — where signup / payment notifications are sent
 *
 * When SMTP is not configured, sendMail() logs and returns false — the app
 * keeps working and every notification is also delivered in-app (Platform
 * Admin panel + notification bell), so nothing is ever lost.
 */
import nodemailer, { type Transporter } from "nodemailer";

export const APP_URL = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");

export const PLATFORM_NOTIFY_EMAIL = (
  process.env.PLATFORM_NOTIFY_EMAIL ?? process.env.SMTP_USER ?? ""
).trim();

function mailFrom(): string {
  const raw = (process.env.MAIL_FROM ?? "").trim();
  if (raw) return raw;
  const user = (process.env.SMTP_USER ?? "").trim();
  return user ? `PeoplePulse HR <${user}>` : "";
}

let transporter: Transporter | null | undefined; // undefined = not initialised

function getTransporter(): Transporter | null {
  if (transporter !== undefined) return transporter;
  const host = (process.env.SMTP_HOST ?? "").trim();
  const user = (process.env.SMTP_USER ?? "").trim();
  const pass = (process.env.SMTP_PASS ?? "").trim();
  if (!host || !user || !pass) {
    transporter = null;
    return transporter;
  }
  const port = Number(process.env.SMTP_PORT ?? 587);
  transporter = nodemailer.createTransport({
    host,
    port: Number.isFinite(port) ? port : 587,
    secure: process.env.SMTP_SECURE === "true" || port === 465,
    auth: { user, pass },
  });
  return transporter;
}

export async function sendMail(opts: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<boolean> {
  const tx = getTransporter();
  const from = mailFrom();
  if (!tx || !opts.to || !from) {
    console.log(
      `[mailer] skipped (SMTP not configured) — would have sent "${opts.subject}" to ${opts.to || "(no recipient)"}`
    );
    return false;
  }
  try {
    await tx.sendMail({
      from,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text ?? opts.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(),
    });
    console.log(`[mailer] sent "${opts.subject}" to ${opts.to}`);
    return true;
  } catch (e) {
    console.error("[mailer] failed", e instanceof Error ? e.message : e);
    return false;
  }
}

// ============================== Branding helpers ==============================

const BRAND_ACCENT = "#059669";

function layout(title: string, bodyHtml: string): string {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#f4f5f5;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f5;padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e5e7eb;">
        <tr><td style="background:${BRAND_ACCENT};padding:18px 28px;">
          <span style="color:#ffffff;font-size:17px;font-weight:700;letter-spacing:0.2px;">PeoplePulse HR</span>
        </td></tr>
        <tr><td style="padding:28px;">
          <h2 style="margin:0 0 14px;font-size:18px;color:#111827;">${title}</h2>
          ${bodyHtml}
        </td></tr>
        <tr><td style="padding:16px 28px;border-top:1px solid #f0f0f0;color:#9ca3af;font-size:11px;">
          Sent by PeoplePulse HR · <a href="${APP_URL}" style="color:${BRAND_ACCENT};text-decoration:none;">${APP_URL}</a>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

function detailTable(rows: [string, string][]): string {
  return `<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border:1px solid #e5e7eb;border-radius:10px;margin:14px 0;">
    ${rows
      .map(
        ([k, v]) =>
          `<tr><td style="padding:9px 14px;border-bottom:1px solid #f3f4f6;color:#6b7280;font-size:12px;width:42%;">${k}</td><td style="padding:9px 14px;border-bottom:1px solid #f3f4f6;color:#111827;font-size:13px;font-weight:600;">${v}</td></tr>`
      )
      .join("")}
  </table>`;
}

function inrEmail(n: number): string {
  return `₹${n.toLocaleString("en-IN")}`;
}

// ============================== Notification emails ==============================

export function emailAdminNewSignup(params: {
  companyName: string;
  ownerName: string;
  ownerEmail: string;
  companySize: string;
  plan: string;
  cycle: string;
  seats: number;
}) {
  const isTrial = params.plan === "trial";
  return sendMail({
    to: PLATFORM_NOTIFY_EMAIL,
    subject: `[PeoplePulse] New ${isTrial ? "trial signup" : "paid signup"}: ${params.companyName}`,
    html: layout(
      isTrial ? "New trial signup awaiting approval" : "New paid signup awaiting approval",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        A new workspace was just registered and is <strong>awaiting your approval</strong>.
        ${isTrial ? "No payment is required — review and approve the trial." : "The buyer will submit their payment reference (UTR) after transferring money to your account — verify it against your bank statement, then approve."}
      </p>
      ${detailTable([
        ["Company", params.companyName],
        ["Owner", `${params.ownerName} (${params.ownerEmail})`],
        ["Company size", params.companySize],
        ["Requested plan", isTrial ? "14-day free trial" : `${params.plan} (${params.cycle})`],
        ...(isTrial ? [] : ([["Seats", String(params.seats)]] as [string, string][])),
      ])}
      <p style="margin:0;color:#374151;font-size:13px;">Open <a href="${APP_URL}" style="color:${BRAND_ACCENT};font-weight:600;">PeoplePulse HR</a>, sign in and go to <strong>Platform Admin → Tenants</strong> to approve or decline.</p>`
    ),
  });
}

export function emailAdminPaymentSubmitted(params: {
  companyName: string;
  ownerName: string;
  ownerEmail: string;
  utr: string;
  amount: number;
  payerName: string;
  paidAt: string;
  method: string;
  plan: string;
  cycle: string;
  seats: number;
  note?: string | null;
}) {
  return sendMail({
    to: PLATFORM_NOTIFY_EMAIL,
    subject: `[PeoplePulse] Payment UTR submitted: ${params.companyName} — ${inrEmail(params.amount)}`,
    html: layout(
      "Payment reference submitted for verification",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        <strong>${params.companyName}</strong> reports having paid <strong>${inrEmail(params.amount)}</strong>.
        Verify the transaction reference against your bank statement / UPI app, then approve the workspace
        (or verify the renewal) in <strong>Platform Admin</strong>.
      </p>
      ${detailTable([
        ["Transaction ref (UTR)", `<span style="font-family:monospace;font-size:14px;">${params.utr}</span>`],
        ["Amount claimed", inrEmail(params.amount)],
        ["Paid via", params.method === "upi" ? "UPI" : "Bank transfer (NEFT/IMPS)"],
        ["Payer name", params.payerName],
        ["Paid on", params.paidAt],
        ["Company", params.companyName],
        ["Buyer", `${params.ownerName} (${params.ownerEmail})`],
        ["Plan", `${params.plan} · ${params.cycle} · ${params.seats} seats`],
        ...(params.note ? ([["Buyer note", params.note]] as [string, string][]) : []),
      ])}
      <p style="margin:0;color:#374151;font-size:13px;">Open <a href="${APP_URL}" style="color:${BRAND_ACCENT};font-weight:600;">PeoplePulse HR</a> → <strong>Platform Admin → Tenants</strong> to take action.</p>`
    ),
  });
}

export function emailBuyerApproved(params: {
  to: string;
  companyName: string;
  plan: string;
  cycle?: string;
  seats?: number;
  validUntilLabel: string;
}) {
  const paid = !!params.cycle;
  return sendMail({
    to: params.to,
    subject: "Your PeoplePulse HR workspace is live",
    html: layout(
      "Welcome to PeoplePulse HR",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        Great news — <strong>${params.companyName}</strong> has been approved and your workspace is now active.
        Sign in to start onboarding your team.
      </p>
      ${detailTable([
        ["Workspace", params.companyName],
        ["Plan", paid ? `${params.plan} (${params.cycle})` : "Free trial (all features)"],
        ...(paid && params.seats ? ([["Seats", String(params.seats)]] as [string, string][]) : []),
        [paid ? "Paid until" : "Trial ends", params.validUntilLabel],
      ])}
      <p style="margin:14px 0 0;"><a href="${APP_URL}" style="display:inline-block;background:${BRAND_ACCENT};color:#ffffff;text-decoration:none;font-weight:600;font-size:13px;padding:11px 22px;border-radius:9px;">Open my workspace</a></p>`
    ),
  });
}

export function emailBuyerRejected(params: { to: string; companyName: string; reason: string }) {
  return sendMail({
    to: params.to,
    subject: "Your PeoplePulse HR signup was declined",
    html: layout(
      "Signup declined",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        Unfortunately your signup for <strong>${params.companyName}</strong> was declined.
      </p>
      ${params.reason ? detailTable([["Reason", params.reason]]) : ""}
      <p style="margin:0;color:#374151;font-size:13px;">If you believe this is a mistake, reply to this email or sign in to your workspace and resubmit.</p>`
    ),
  });
}

export function emailBuyerSuspended(params: { to: string; companyName: string; reason: string }) {
  return sendMail({
    to: params.to,
    subject: "Your PeoplePulse HR workspace has been suspended",
    html: layout(
      "Workspace suspended",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        Your workspace <strong>${params.companyName}</strong> has been suspended by the platform administrator.
      </p>
      ${params.reason ? detailTable([["Reason", params.reason]]) : ""}
      <p style="margin:0;color:#374151;font-size:13px;">Contact support to restore access.</p>`
    ),
  });
}

export function emailBuyerPaymentVerified(params: {
  to: string;
  companyName: string;
  utr: string;
  amount: number;
  paidUntilLabel: string;
  invoiceNumber: string;
}) {
  return sendMail({
    to: params.to,
    subject: "Payment verified — your subscription is renewed",
    html: layout(
      "Payment verified",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        We have verified your payment for <strong>${params.companyName}</strong>. Your subscription is active again.
      </p>
      ${detailTable([
        ["Transaction ref", `<span style="font-family:monospace;">${params.utr}</span>`],
        ["Amount", inrEmail(params.amount)],
        ["Invoice", params.invoiceNumber],
        ["Active until", params.paidUntilLabel],
      ])}
      <p style="margin:14px 0 0;"><a href="${APP_URL}" style="display:inline-block;background:${BRAND_ACCENT};color:#ffffff;text-decoration:none;font-weight:600;font-size:13px;padding:11px 22px;border-radius:9px;">Open my workspace</a></p>`
    ),
  });
}

export function emailBuyerProofRejected(params: {
  to: string;
  companyName: string;
  utr: string;
  reason: string;
}) {
  return sendMail({
    to: params.to,
    subject: "We could not verify your payment",
    html: layout(
      "Payment could not be verified",
      `<p style="margin:0;color:#374151;font-size:14px;line-height:1.6;">
        We could not verify the payment submitted for <strong>${params.companyName}</strong>.
      </p>
      ${detailTable([
        ["Transaction ref", `<span style="font-family:monospace;">${params.utr}</span>`],
        ...(params.reason ? ([["Reason", params.reason]] as [string, string][]) : []),
      ])}
      <p style="margin:0;color:#374151;font-size:13px;">Please sign in, check the reference number against your bank/UPI app and submit it again.</p>`
    ),
  });
}

/**
 * PeoplePulse HR service worker.
 *
 * Strategy:
 *  - App shell (HTML navigations): network-first, fall back to cached shell offline.
 *  - Static assets (JS/CSS/icons/manifest): stale-while-revalidate.
 *  - API responses (/api/*): network-only (NEVER cache — HR data must be live).
 *  - Non-GET requests: never cached.
 *
 * Install: pre-cache the app shell + manifest + offline fallback.
 * Activate: clean up old caches.
 */
const CACHE_VERSION = "pp-hr-v1";
const SHELL_CACHE = `${CACHE_VERSION}-shell`;
const ASSET_CACHE = `${CACHE_VERSION}-assets`;

const SHELL_URLS = [
  "/",
  "/manifest.webmanifest",
  "/icon.svg",
  "/icons/icon-192x192.png",
  "/icons/icon-512x512.png",
  "/offline.html",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      await Promise.all(
        SHELL_URLS.map(async (url) => {
          try {
            const res = await fetch(url, { cache: "no-cache" });
            if (res.ok) await cache.put(url, res.clone());
          } catch {
            // ignore — will be cached on first successful fetch
          }
        })
      );
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => !k.startsWith(CACHE_VERSION))
          .map((k) => caches.delete(k))
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle GET; never cache mutations or non-GET.
  if (request.method !== "GET") return;

  // NEVER intercept API calls — they must always hit the network for live data.
  if (url.pathname === "/api" || url.pathname.startsWith("/api/")) return;

  // Same-origin only (don't cache cross-origin fonts/CDN etc.).
  if (url.origin !== self.location.origin) return;

  // HTML navigations: network-first with offline fallback to cached shell.
  if (request.mode === "navigate" || (request.headers.get("accept") || "").includes("text/html")) {
    event.respondWith(
      (async () => {
        try {
          const net = await fetch(request);
          const cache = await caches.open(SHELL_CACHE);
          cache.put("/", net.clone()).catch(() => {});
          return net;
        } catch {
          const cached = await caches.match("/");
          return cached || (await caches.match("/offline.html")) || Response.error();
        }
      })()
    );
    return;
  }

  // Static assets: stale-while-revalidate.
  event.respondWith(
    (async () => {
      const cache = await caches.open(ASSET_CACHE);
      const cached = await cache.match(request);
      const network = fetch(request)
        .then((res) => {
          if (res.ok) cache.put(request, res.clone()).catch(() => {});
          return res;
        })
        .catch(() => cached ?? caches.match("/offline.html"));
      return cached || network;
    })()
  );
});

self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

# Deploying PeoplePulse HR on Oracle Cloud Free VM + Cloudflare Tunnel — ₹0 forever

This is the genuinely-free, commercial-use-allowed deployment path for PeoplePulse HR.
Your SQLite database works as-is (no migration needed). Total one-time setup: ~30–45 minutes.
After that, the app runs forever at ₹0, auto-restarts on crashes, and survives VM reboots.

## Why this works for your app

| Component | Cost | Why it fits |
|---|---|---|
| Oracle Cloud Always-Free VM (Ampere A1 ARM) | ₹0 forever | 24GB RAM, 4 cores, 200GB disk — commercial use allowed, never expires |
| Cloudflare Tunnel | ₹0 forever | Free HTTPS on your domain, no inbound ports needed, unlimited bandwidth |
| SQLite (existing) | ₹0 | File-based, persists on VM disk — zero code changes from dev |

---

## Phase 1 — Create the Oracle Cloud account (15 min + 1–2 day verification wait)

1. Go to **https://cloud.oracle.com** → click **Start for free**.
2. Sign up with a permanent email (use your company email if you have one).
3. Choose **Home Region: Mumbai** (closest for Indian users; avoids the "out of capacity" issues some US regions have).
4. Account type: **Company** (or Personal — both work for the free tier).
5. Enter a credit card — **Oracle will not charge it**. It's only for identity verification. The Always Free tier is genuinely free forever and the card is never billed unless you explicitly upgrade.
6. Wait for the verification email — usually arrives in 1–2 business days. You'll get an email titled "Your Oracle Cloud account is ready".

### If you hit "Out of host capacity" when creating the VM later

This is a known Oracle issue — the free ARM VMs are popular. Three fixes:
- **Retry every few hours** — capacity frees up as other people's free VMs get deleted.
- **Try a different region** — Singapore, Tokyo, or Hyderabad often have capacity.
- **Use a smaller shape** — request 1 OCPU + 6GB RAM instead of the full 4 OCPU + 24GB. You can always resize later.

---

## Phase 2 — Create the Always-Free VM (10 min)

Once logged into Oracle Cloud:

### Step 1 — Generate an SSH key pair (on your local computer)

```bash
# On Mac/Linux/Windows-Git-Bash
ssh-keygen -t ed25519 -C "peoplepulse-vm" -f ~/.ssh/peoplepulse_key
# Press Enter for no passphrase (or set one — your choice)
```

This creates two files:
- `~/.ssh/peoplepulse_key` (private — NEVER share this)
- `~/.ssh/peoplepulse_key.pub` (public — you'll paste this into Oracle)

### Step 2 — Create the VM

1. In Oracle Cloud Console, click the hamburger menu → **Compute** → **Instances** → **Create instance**.
2. Fill in:
   - **Name:** `peoplepulse-hr`
   - **Image:** Canonical Ubuntu 22.04 (click "Change image" if it's not Ubuntu)
   - **Shape:** Click "Edit" → **Ampere** → `VM.Standard.A1.Flex` → set **1 OCPU** + **6 GB RAM** (you can resize to 4 OCPU/24GB later if needed; 1/6 is enough for hundreds of employees)
   - **SSH keys:** Select "Save private key" if you didn't generate your own, OR select "Choose SSH key files" and upload the `peoplepulse_key.pub` you just generated.
   - **Click Create.**
3. Wait ~2 minutes for the VM to provision. You'll see the public IP address on the instance page — **copy it**.

### Step 3 — Connect via SSH

```bash
# From your local computer
ssh -i ~/.ssh/peoplepulse_key ubuntu@YOUR_VM_PUBLIC_IP
# Replace YOUR_VM_PUBLIC_IP with the IP from the Oracle console
# First connection: type "yes" to accept the host fingerprint
```

You're now logged into your VM. All the following commands run on the VM (inside that SSH session).

---

## Phase 3 — Install Bun + clone the app (5 min on the VM)

```bash
# Update the system
sudo apt update && sudo apt upgrade -y

# Install essential tools
sudo apt install -y git curl build-essential python3

# Install Bun (the JavaScript runtime your app uses)
curl -fsSL https://bun.sh/install | bash

# Load Bun into your current shell
source ~/.bashrc

# Verify Bun is installed
bun --version
# Should print something like "1.3.x"

# Clone your app (replace with YOUR GitHub repo URL after you push to GitHub)
git clone https://github.com/YOUR_USERNAME/peoplepulse-hr.git
cd peoplepulse-hr

# Install all dependencies
bun install
```

### If you haven't pushed to GitHub yet

From your local computer (not the VM):
```bash
cd /home/z/my-project  # or wherever your project is
git init
git add -A
git commit -m "PeoplePulse HR — production ready"
# Create an empty repo on github.com first, then:
git remote add origin https://github.com/YOUR_USERNAME/peoplepulse-hr.git
git push -u origin main
```

Then the `git clone` command on the VM will work.

---

## Phase 4 — Configure the environment (3 min on the VM)

Create the `.env` file on the VM. **Use the same values as your local `.env`** — especially the `SESSION_SECRET` (if you change it, all existing login sessions are invalidated, which is fine for a fresh deploy but matters if you're migrating an existing tenant's data).

```bash
cat > .env << 'EOF'
DATABASE_URL=file:/home/ubuntu/peoplepulse-hr/db/custom.db
SESSION_SECRET=YOUR_64_HEX_CHAR_SECRET_HERE
OPENROUTER_API_KEY=sk-or-v1-YOUR_OPENROUTER_KEY_HERE
OPENROUTER_MODEL=deepseek/deepseek-chat-v3-0324
OPENROUTER_FALLBACK_MODELS=meta-llama/llama-3.3-70b-instruct

# --- Payments & approvals (manual UTR flow — see PAYMENTS.md) ---
APP_URL=https://your-domain.com
# IMPORTANT: set this to YOUR email so only you become the platform admin
PLATFORM_ADMIN_EMAIL=you@yourdomain.com
# Seeds the bank account buyers pay into (editable later in Platform Admin)
PLATFORM_BANK_HOLDER=Your Name
PLATFORM_BANK_ACCOUNT=XXXXXXXXXXXXXXX
PLATFORM_BANK_IFSC=XXXXXXXXXXX
PLATFORM_BANK_NAME=Your Bank
PLATFORM_BANK_TYPE=Current Account
PLATFORM_UPI_ID=

# --- Email notifications (optional; in-app notifications always work) ---
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
MAIL_FROM=
PLATFORM_NOTIFY_EMAIL=
EOF

# Generate a fresh 64-char hex secret if you don't have one:
openssl rand -hex 32
# Copy the output and paste it into the SESSION_SECRET line above

# Verify the file
cat .env
```

### Initialize the database

For a **fresh start** (no existing data — recommended for a new production deploy):

```bash
# Create the database directory
mkdir -p db

# Push the schema to create all tables
bun run db:push

# The database is now ready. The first person to register via the app
# becomes the organisation Owner (per the real-mode provisioning).
```

For **migrating existing data** (if you already have tenants on your dev machine and want to keep them):

```bash
# From your LOCAL computer (not the VM), copy the database file up:
scp -i ~/.ssh/peoplepulse_key db/custom.db ubuntu@YOUR_VM_PUBLIC_IP:~/peoplepulse-hr/db/custom.db

# Then on the VM, still run db:push to make sure the schema is in sync:
bun run db:push
```

---

## Phase 5 — Build the app (3 min on the VM)

```bash
# Build for production
bun run build

# This takes 1–3 minutes. It produces .next/standalone/ which is a
# self-contained server that doesn't need the dev server.

# Test it runs (press Ctrl+C to stop after you see "Ready")
bun run start
# Should print: "PeoplePulse HR running on http://localhost:3000"
# Open a second SSH session and test:
#   curl http://localhost:3000/
#   Should return HTML starting with "<!DOCTYPE html>"
# Stop the test server with Ctrl+C in the first session.
```

---

## Phase 6 — Run the app as a systemd service (auto-restart, survives reboot) (5 min on the VM)

Create a systemd service so the app starts automatically on boot and restarts if it crashes:

```bash
sudo tee /etc/systemd/system/peoplepulse.service > /dev/null << 'EOF'
[Unit]
Description=PeoplePulse HR Production Server
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/peoplepulse-hr
Environment=NODE_ENV=production
EnvironmentFile=/home/ubuntu/peoplepulse-hr/.env
ExecStart=/home/ubuntu/.bun/bin/bun /home/ubuntu/peoplepulse-hr/.next/standalone/server.js
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Enable + start the service
sudo systemctl daemon-reload
sudo systemctl enable peoplepulse
sudo systemctl start peoplepulse

# Verify it's running
sudo systemctl status peoplepulse
# Should show "active (running)" in green

# Check the logs (useful for debugging)
sudo journalctl -u peoplepulse -f
# Press Ctrl+C to exit the log view
```

The app is now running on `http://localhost:3000` on the VM, auto-restarting on crash, and will start automatically when the VM reboots.

---

## Phase 7 — Expose it publicly with Cloudflare Tunnel (10 min)

You have two options:

### Option A — Quick tunnel (testing today, random URL that changes on restart)

```bash
# Install cloudflared
sudo apt install -y cloudflared

# Run a quick tunnel (prints a random https://*.trycloudflare.com URL)
cloudflared tunnel --url http://localhost:3000
```

Copy the URL it prints. Open it in your browser. Your app is now live on the internet with HTTPS.

**Downsides:** The URL changes every time you restart cloudflared. Not suitable for production. Use this only to verify everything works, then set up Option B.

### Option B — Named tunnel with your own domain (stable URL, for production)

#### Step 1 — Get a domain (if you don't have one)

- **Free:** Get a `.xyz` or `.tk` domain (search "free domain" — some registrars offer first year free)
- **Cheap:** A `.in` domain costs ~₹500–800/year at GoDaddy, Hostinger, or Namecheap
- **For a real business:** Budget ₹1000/year for a proper `.in` or `.com` — it's the only cost you'll have

#### Step 2 — Add the domain to Cloudflare (free)

1. Go to **https://cloudflare.com** → sign up (free).
2. Click **Add a site** → enter your domain → select the **Free plan**.
3. Cloudflare gives you two nameservers like `aida.ns.cloudflare.com` and `bob.ns.cloudflare.com`.
4. Go to your domain registrar (GoDaddy/Namecheap/etc.) → find "Nameservers" → replace theirs with Cloudflare's.
5. Wait 1–24 hours for the nameserver change to propagate (Cloudflare emails you when it's done).

#### Step 3 — Create the tunnel on the VM

```bash
# Authenticate cloudflared with your Cloudflare account
cloudflared tunnel login
# This prints a URL — open it in your browser, select your domain, authorize.
# This saves a certificate to ~/.cloudflared/cert.pem

# Create a named tunnel
cloudflared tunnel create peoplepulse
# This prints a tunnel UUID and creates ~/.cloudflared/<UUID>.json

# Create the config file
cat > ~/.cloudflared/config.yml << 'EOF'
tunnel: PEOPLEPULSE_TUNNEL_UUID
credentials-file: /home/ubuntu/.cloudflared/PEOPLEPULSE_TUNNEL_UUID.json

ingress:
  - hostname: hr.yourdomain.com
    service: http://localhost:3000
  - service: http_status:404
EOF

# Replace PEOPLEPULSE_TUNNEL_UUID with the UUID from the create command above.
# Replace hr.yourdomain.com with the subdomain you want (e.g. hr.acme.in).

# Point a DNS record at the tunnel (Cloudflare does this automatically)
cloudflared tunnel route dns peoplepulse hr.yourdomain.com

# Test the tunnel
cloudflared tunnel run peoplepulse
# Should print "Registered tunnel connection" — leave it running.
# In another SSH session, test:
#   curl https://hr.yourdomain.com
#   Should return your app's HTML.
# Stop the test with Ctrl+C.
```

#### Step 4 — Run cloudflared as a service (auto-start on boot)

```bash
# Install cloudflared as a system service
sudo cloudflared service install
sudo systemctl enable cloudflared
sudo systemctl start cloudflared

# Verify
sudo systemctl status cloudflared
# Should show "active (running)"
```

Your app is now live at **`https://hr.yourdomain.com`** — stable URL, free HTTPS, auto-restarts, survives reboots.

---

## Phase 8 — Final verification (2 min)

From any browser, on any device:

1. Open `https://hr.yourdomain.com` — should show the PeoplePulse HR sign-in page.
2. Click **Create your workspace** → register your real company → you become the Owner.
3. Add an employee with login access → share the one-time password → have them sign in.
4. Test geo-fenced attendance check-in from your phone (browser will prompt for location permission — HTTPS is required, which Cloudflare provides).
5. Test leave request → approval → payroll.

If all of that works, you're live in production at ₹0.

---

## Ongoing operations

### Updating the app after a code change

From your local computer:
```bash
# Make changes, commit, push to GitHub
git add -A && git commit -m "your change" && git push
```

On the VM (via SSH):
```bash
cd ~/peoplepulse-hr
git pull
bun install          # only if package.json changed
bun run build
sudo systemctl restart peoplepulse
```

The whole update takes ~2 minutes. Zero downtime — the restart is nearly instant.

### Optional: auto-deploy on git push

If you want the VM to auto-pull and rebuild on every git push (like Vercel does), set up a simple webhook. But for a business app you update maybe weekly, the manual 4-line update above is fine.

### Backing up your data

Your SQLite database is at `~/peoplepulse-hr/db/custom.db`. Back it up regularly:

```bash
# Manual backup (download to your local computer)
# From your local computer:
scp -i ~/.ssh/peoplepulse_key ubuntu@YOUR_VM_PUBLIC_IP:~/peoplepulse-hr/db/custom.db ./backup-$(date +%Y%m%d).db

# Or set up a daily cron job on the VM to copy it to a backup folder:
# On the VM:
crontab -e
# Add this line (backs up at 2am daily, keeps 7 days):
0 2 * * * cp ~/peoplepulse-hr/db/custom.db ~/backups/custom-$(date +\%Y\%m\%d).db && find ~/backups/ -mtime +7 -delete
```

You can also use the in-app **Settings → Security → Download backup** button (owner only) to download a consistent SQLite snapshot from the browser.

### Monitoring (optional, free)

Oracle Cloud's free tier includes basic monitoring (CPU, memory, disk) in the console. For app-level monitoring, the app already logs to journald — view with:
```bash
sudo journalctl -u peoplepulse -f       # live tail
sudo journalctl -u peoplepulse --since "1 hour ago"
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `ssh: connect to host ... port 22: Connection refused` | Oracle's default security list blocks SSH. In the Oracle console: Instance → VCN → Security List → Add Ingress Rule: Source 0.0.0.0/0, IP Protocol TCP, Destination Port 22. |
| `bun: command not found` after reconnecting SSH | Run `source ~/.bashrc` or close/reopen the SSH session. |
| `bun run build` fails with memory error | Edit the shape in Oracle console → increase RAM to 12GB or 24GB (free tier allows up to 24GB). |
| App works on `localhost:3000` but tunnel shows 502 | Check `sudo systemctl status peoplepulse` — if it's failed, check `sudo journalctl -u peoplepulse -n 50`. Most common cause: .env not loaded (check EnvironmentFile path in the systemd unit). |
| Cloudflare tunnel shows "connection registered" but domain returns 502 | Wait 1–2 minutes for DNS to propagate. Check `cloudflared tunnel run peoplepulse` logs for errors. Verify the ingress hostname in `~/.cloudflared/config.yml` matches your domain exactly. |
| Geo-fenced check-in doesn't work (no location prompt) | The app requires HTTPS for geolocation. Cloudflare Tunnel provides this automatically. If you're using a custom domain, make sure the tunnel is serving over HTTPS (it does by default). |
| "Out of host capacity" when creating the VM | Retry in a few hours, or choose a different region (Singapore/Hyderabad), or request a smaller shape (1 OCPU / 6GB). |

---

## What this deployment gives you

| Feature | Status |
|---|---|
| Public HTTPS URL | Yes (via Cloudflare Tunnel) |
| Commercial use allowed | Yes (Oracle free tier + Cloudflare free tier both allow it) |
| Cost | ₹0 forever (the only cost is your domain, ~₹500–1000/year if you don't have one) |
| Auto-restart on crash | Yes (systemd) |
| Survives VM reboot | Yes (systemd enabled) |
| SQLite database persists | Yes (on VM disk, backed up via cron or in-app button) |
| Geo-fencing works | Yes (HTTPS provided by Cloudflare) |
| AI features (OpenRouter + fallback) | Yes (outbound HTTPS works from the VM) |
| Can sell subscriptions | Yes — point your billing (Razorpay/UPI) at this URL |
| Play Store TWA can wrap this URL | Yes — use `https://hr.yourdomain.com` as the TWA host |

---

## Quick reference — every command in order

```bash
# === On your local computer ===
ssh-keygen -t ed25519 -C "peoplepulse-vm" -f ~/.ssh/peoplepulse_key

# === After creating the VM in Oracle console ===
ssh -i ~/.ssh/peoplepulse_key ubuntu@YOUR_VM_PUBLIC_IP

# === On the VM (one-time setup) ===
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl build-essential python3 cloudflared
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc
git clone https://github.com/YOUR_USERNAME/peoplepulse-hr.git
cd peoplepulse-hr
bun install
cat > .env << 'EOF'
DATABASE_URL=file:/home/ubuntu/peoplepulse-hr/db/custom.db
SESSION_SECRET=PASTE_OUTPUT_OF_openssl_rand_hex_32
OPENROUTER_API_KEY=sk-or-v1-YOUR_KEY
OPENROUTER_MODEL=deepseek/deepseek-chat-v3-0324
OPENROUTER_FALLBACK_MODELS=meta-llama/llama-3.3-70b-instruct
EOF
mkdir -p db
bun run db:push
bun run build

# === systemd service ===
sudo tee /etc/systemd/system/peoplepulse.service > /dev/null << 'EOF'
[Unit]
Description=PeoplePulse HR Production Server
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/peoplepulse-hr
Environment=NODE_ENV=production
EnvironmentFile=/home/ubuntu/peoplepulse-hr/.env
ExecStart=/home/ubuntu/.bun/bin/bun /home/ubuntu/peoplepulse-hr/.next/standalone/server.js
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable peoplepulse
sudo systemctl start peoplepulse

# === Cloudflare Tunnel (named, stable URL) ===
cloudflared tunnel login
cloudflared tunnel create peoplepulse
# Edit ~/.cloudflared/config.yml with your UUID + hostname
cloudflared tunnel route dns peoplepulse hr.yourdomain.com
sudo cloudflared service install
sudo systemctl enable cloudflared
sudo systemctl start cloudflared

# === Updates (after git push from local) ===
cd ~/peoplepulse-hr && git pull && bun install && bun run build && sudo systemctl restart peoplepulse
```

That's it. Total one-time work: ~30–45 minutes. After that, ₹0 forever, commercial use allowed, and you can start selling subscriptions the moment it's live.

# PeoplePulse HR — Payments & Approvals (Manual UTR Flow)

This is the complete monetisation loop: buyers register, pay you directly via
bank transfer / UPI, submit the transaction reference (UTR), and you approve
them. Works identically on the website and in the Android/iOS app (the app is
the same PWA codebase).

---

## 1. How the money flows

```
Buyer registers (trial or paid plan)
        │
        ▼  workspace created in PENDING state (locked)
Buyer sees YOUR payment details (bank account / UPI ID)
        │
        ▼  buyer transfers money from their bank/UPI app
Buyer submits the transaction reference (UTR) in the app
        │
        ├──► you get an EMAIL with all details (if SMTP configured)
        ├──► you get an in-app notification (always)
        ▼
YOU verify the UTR against your bank statement / UPI app
        │
        ▼  Approve in Platform Admin → Tenants
Workspace activated (paidUntil set, PAID invoice generated)
        │
        ▼  buyer gets "Your workspace is live" email
Subscription runs until paidUntil → renewal-due screen → repeat
```

**Every signup — trial AND paid — requires your approval.** Trial approvals
grant 14 days of full access, then the buyer must pay to continue.

## 2. One-time setup (as platform owner)

1. **Register first** on your deployment. The first registered user becomes
   the **platform super admin** — that's you. Your own workspace is active
   immediately (lifetime Professional).
   - On a public deployment, also set `PLATFORM_ADMIN_EMAIL=your@email.com`
     in `.env` so only your email can ever claim the platform admin role.
2. **Check your payment channels**: sign in → sidebar **Platform Admin →
   Payment methods**. Your bank account is seeded from the `PLATFORM_BANK_*`
   env vars on first boot. Add your UPI ID there (Add payment method → UPI)
   if you want a UPI channel. Edits take effect immediately for buyers.
3. **Configure email notifications** (optional but recommended) — see §4.

## 3. Daily operation (Platform Admin module)

Visible in the sidebar only to you. Three tabs:

| Tab | What you do |
|---|---|
| **Overview** | Stat tiles + an "Inbox" of everything needing action: pending signups and submitted UTRs, each with a one-click Approve/Verify button. |
| **Tenants** | Every workspace with plan, status, valid-until date, latest UTR and actions: Approve, Reject (reason), Verify UTR, Reject UTR (reason), Suspend, Extend (grant months). |
| **Payment methods** | CRUD your bank/UPI channels shown to buyers. |

Anti-fraud built in:

- **UTRs are globally unique** — the same reference number can never be
  claimed by two workspaces (or twice by the same one).
- Amounts shown to buyers are computed server-side; what they *claim* to have
  paid is recorded and highlighted to you for cross-checking.
- Every admin action is written to your workspace audit log (Settings → Audit log).

## 4. Email notifications

You are emailed when someone registers and when a UTR is submitted; buyers are
emailed on approval, rejection, suspension and successful verification.
Without SMTP the emails are skipped — **in-app notifications always work**.

Gmail setup (free, ~500 mails/day):

1. Enable 2-Step Verification on your Google account.
2. Create an App Password: myaccount.google.com → Security → 2-Step
   Verification → App passwords.
3. Set in `.env`:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=yourgmail@gmail.com
SMTP_PASS=your16charapppassword
PLATFORM_NOTIFY_EMAIL=yourgmail@gmail.com
APP_URL=https://your-domain.com
```

4. Restart the service (`sudo systemctl restart peoplepulse`).

## 5. Environment variables (all optional except noted)

| Variable | Purpose |
|---|---|
| `APP_URL` | Public URL used in email links |
| `PLATFORM_ADMIN_EMAIL` | Locks the super-admin role to this email |
| `PLATFORM_BANK_HOLDER/_ACCOUNT/_IFSC/_NAME/_TYPE` | Seeds your bank channel on first boot |
| `PLATFORM_UPI_ID` | Seeds a UPI channel on first boot |
| `SMTP_HOST/PORT/SECURE/USER/PASS` | Outbound email |
| `MAIL_FROM` | From-address (defaults to SMTP_USER) |
| `PLATFORM_NOTIFY_EMAIL` | Where admin alerts go (defaults to SMTP_USER) |

## 6. Plan matrix

| Plan | Price (INR) | Seats | Trial |
|---|---|---|---|
| Starter | ₹49/emp/mo (₹39 annual) | 25+ | 14 days |
| Growth | ₹99/emp/mo (₹79 annual) | 100+ | 14 days |
| Professional | ₹179/emp/mo (₹149 annual) | 500+ | 14 days |
| Enterprise | Custom (demo request) | — | — |

GST 18% is added on top at checkout. Annual billing is per month, invoiced
for 12 months upfront.

## 7. Renewals & expiry

- Approving a paid plan sets `paidUntil` = today + 1 month (monthly) or
  + 12 months (annual).
- When `paidUntil` passes, the workspace locks with a **"Renewal due"** screen
  showing the payment flow. The buyer submits a new UTR; you press **Verify
  UTR** in Platform Admin; the subscription extends from the current date and
  a new PAID invoice appears in their Settings → Plan & billing.
- Trials expire the same way (14 days) with a "Trial expired" screen.
- **Extend** lets you grant extra months manually (goodwill, downtime, etc.).

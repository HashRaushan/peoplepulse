/**
 * PeoplePulse HR — database seed.
 * Creates two fully-populated demo tenants to showcase the platform and
 * verify multi-tenant isolation. Run with: bun prisma/seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/crypto";
import { computePayslip, DEFAULT_PAYROLL_CONFIG } from "../src/lib/payroll";

const db = new PrismaClient();

const DEMO_PASSWORD = hashPassword("Demo@123");
const HOLIDAYS_2025: [string, string][] = [
  ["2025-01-26", "Republic Day"], ["2025-03-14", "Holi"], ["2025-03-31", "Eid-ul-Fitr"],
  ["2025-04-14", "Ambedkar Jayanti"], ["2025-05-01", "Labour Day"], ["2025-08-15", "Independence Day"],
  ["2025-08-27", "Ganesh Chaturthi"], ["2025-10-02", "Gandhi Jayanti"], ["2025-10-21", "Dussehra"],
  ["2025-11-01", "Diwali"], ["2025-12-25", "Christmas"],
];
const HOLIDAYS_2026: [string, string][] = [
  ["2026-01-26", "Republic Day"], ["2026-03-04", "Holi"], ["2026-03-20", "Eid-ul-Fitr"],
  ["2026-04-14", "Ambedkar Jayanti"], ["2026-05-01", "Labour Day"], ["2026-08-15", "Independence Day"],
  ["2026-10-02", "Gandhi Jayanti"], ["2026-11-08", "Diwali"], ["2026-12-25", "Christmas"],
];

const COLORS = ["#059669", "#0D9488", "#D97706", "#DC2626", "#7C3AED", "#DB2777", "#65A30D", "#EA580C", "#0891B2", "#4F46E5", "#9333EA", "#B45309"];
const date = (s: string) => new Date(`${s}T00:00:00`);
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const pick = <T,>(arr: T[], seed: number) => arr[seed % arr.length];
const rand = (seed: number) => {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
};

interface SeedEmployee {
  first: string; last: string; dept: string; designation: string; ctc: number;
  join: string; status?: string; employmentType?: string; gender?: string;
}

async function seedTenant(opts: {
  name: string; slug: string; plan: string; planStatus: string; codePrefix: string;
  domain: string; location: string; employees: SeedEmployee[]; owner: { name: string; email: string; first: string; last: string };
  hrEmails: { name: string; email: string }[];
  managerEmail: { name: string; email: string };
  employeeUserEmails: { name: string; email: string }[];
  now: Date;
}) {
  const { now } = opts;
  const tenant = await db.tenant.create({
    data: {
      name: opts.name, slug: opts.slug, plan: opts.plan, planStatus: opts.planStatus,
      trialEndsAt: opts.plan === "trial" ? new Date(now.getTime() + 11 * 86400000) : null,
      seats: 100, brandColor: "#059669", logoText: opts.name[0], country: "IN", currency: "INR",
      timezone: "Asia/Kolkata", payrollConfig: JSON.stringify(DEFAULT_PAYROLL_CONFIG),
      onboardingStep: 5, createdAt: new Date(now.getTime() - 400 * 86400000),
    },
  });
  const t = tenant.id;

  // Departments
  const deptNames = [...new Set(opts.employees.map((e) => e.dept))];
  await Promise.all(
    deptNames.map((name) =>
      db.department.create({
        data: { tenantId: t, name, description: `${name} at ${opts.name}` },
      })
    )
  );

  // Leave types
  const leaveTypes = await Promise.all(
    [
      { name: "Casual Leave", code: "CL", annualQuota: 12, paid: true, carryForward: false },
      { name: "Sick Leave", code: "SL", annualQuota: 8, paid: true, carryForward: false },
      { name: "Earned Leave", code: "EL", annualQuota: 15, paid: true, carryForward: true },
      { name: "Maternity/Paternity", code: "MP", annualQuota: 26, paid: true, carryForward: false },
      { name: "Compensatory Off", code: "CO", annualQuota: 6, paid: true, carryForward: false },
    ].map((lt) => db.leaveType.create({ data: { tenantId: t, ...lt } }))
  );

  // Holidays
  await Promise.all(
    [...HOLIDAYS_2025.filter(([d]) => new Date(d) > now), ...HOLIDAYS_2026].map(([d, name]) =>
      db.holiday.create({ data: { tenantId: t, name, date: date(d), type: "public" } })
    )
  );

  // Owner employee first
  const ownerEmp = await db.employee.create({
    data: {
      tenantId: t, code: `${opts.codePrefix}-001`,
      firstName: opts.owner.first, lastName: opts.owner.last,
      email: opts.owner.email, phone: "+91 98450 10001",
      department: "People & HR", designation: "Founder & CEO", location: opts.location,
      joinDate: date(opts.employees[0].join), status: "active", employmentType: "full_time",
      ctc: 4800000, dob: date("1985-04-12"), gender: "female",
      emergencyContact: "+91 98450 90001", avatarColor: COLORS[0],
    },
  });

  // Employees (owner is manager of leads)
  const emps: Awaited<ReturnType<typeof db.employee.create>>[] = [];
  for (let i = 0; i < opts.employees.length; i++) {
    const e = opts.employees[i];
    const mgr = i < 3 ? ownerEmp.id : emps[Math.max(0, i - 3)]?.id ?? ownerEmp.id;
    const emp = await db.employee.create({
      data: {
        tenantId: t, code: `${opts.codePrefix}-${String(i + 2).padStart(3, "0")}`,
        firstName: e.first, lastName: e.last,
        email: `${e.first.toLowerCase()}.${e.last.toLowerCase()}@${opts.domain}`,
        phone: `+91 9${String(700000000 + i * 137)}`,
        department: e.dept, designation: e.designation, location: opts.location,
        joinDate: date(e.join), status: e.status ?? "active",
        employmentType: e.employmentType ?? "full_time",
        ctc: e.ctc, dob: date(`${1990 + (i % 12)}-0${(i % 9) + 1}-1${i % 9}`),
        gender: e.gender ?? (i % 2 === 0 ? "male" : "female"),
        emergencyContact: "+91 90000 00000",
        avatarColor: COLORS[(i + 1) % COLORS.length], managerId: mgr,
      },
    });
    emps.push(emp);
  }

  // Users: owner, hr(s), manager, employees (first 3 emps get accounts)
  const mkUser = (name: string, email: string, role: string, employeeId?: string) =>
    db.user.create({ data: { tenantId: t, email, name, password: DEMO_PASSWORD, role, employeeId } });
  await mkUser(opts.owner.name, opts.owner.email, "owner", ownerEmp.id);
  for (const hr of opts.hrEmails) await mkUser(hr.name, hr.email, "hr");
  await mkUser(opts.managerEmail.name, opts.managerEmail.email, "manager", emps[0]?.id);
  for (const eu of opts.employeeUserEmails) {
    const emp = emps.find((e) => e.email === eu.email);
    await mkUser(eu.name, eu.email, "employee", emp?.id);
  }

  // Leave balances (current year)
  const year = now.getFullYear();
  const allEmps = [ownerEmp, ...emps];
  for (const emp of allEmps) {
    for (const lt of leaveTypes) {
      const seedNum = parseInt(emp.id.slice(-4) || "7", 36) + lt.annualQuota;
      const used = lt.code === "MP" ? 0 : Math.floor(rand(seedNum) * Math.min(4, lt.annualQuota / 3));
      const pending = rand(seedNum + 1) > 0.75 ? 1 : 0;
      await db.leaveBalance.create({
        data: { tenantId: t, employeeId: emp.id, leaveTypeId: lt.id, year, entitled: lt.annualQuota, used, pending },
      });
    }
  }

  // Attendance: last 30 days
  for (const [ei, emp] of allEmps.entries()) {
    for (let d = 29; d >= 0; d--) {
      const day = new Date(now); day.setDate(day.getDate() - d);
      if (day.getDay() === 0) continue; // Sundays off
      const r = rand(ei * 31 + d);
      let status = "present";
      let checkIn: string | null = `0${9 + (r > 0.85 ? 1 : 0)}:${String(Math.floor(rand(ei + d) * 25) + 10).padStart(2, "0")}`;
      let checkOut: string | null = `1${8 + (r > 0.5 ? 1 : 0)}:${String(Math.floor(rand(d + 5) * 55) + 5).padStart(2, "0")}`;
      if (r > 0.93) { status = "absent"; checkIn = null; checkOut = null; }
      else if (r > 0.88) { status = "leave"; checkIn = null; checkOut = null; }
      else if (r > 0.78) { status = "wfh"; }
      else if (r > 0.72) { status = "late"; }
      const hours = checkIn && checkOut ? 8 + Math.round(rand(d + ei) * 10) / 10 : null;
      await db.attendanceRecord.create({
        data: { tenantId: t, employeeId: emp.id, date: day, status, checkIn, checkOut, hours,
          note: status === "late" ? "Traffic delay" : null },
      });
    }
  }

  // Leave requests: mix of pending/approved/rejected
  const lrs = [
    { ei: 1, lt: 0, days: 2, reason: "Family function in Kerala", status: "pending" },
    { ei: 4, lt: 1, days: 1, reason: "Fever and cold", status: "pending" },
    { ei: 7, lt: 2, days: 3, reason: "Trip to Coorg", status: "approved" },
    { ei: 9, lt: 0, days: 1, reason: "Personal errand", status: "approved" },
    { ei: 12, lt: 2, days: 5, reason: "Wedding in the family", status: "approved" },
    { ei: 3, lt: 0, days: 2, reason: "Not well", status: "rejected" },
    { ei: 15, lt: 3, days: 1, reason: "Comp-off for weekend release", status: "pending" },
  ];
  for (const [i, lr] of lrs.entries()) {
    const emp = allEmps[Math.min(lr.ei, allEmps.length - 1)];
    const start = new Date(now); start.setDate(start.getDate() + (i % 3) + (lr.status === "approved" ? -10 : 2) + (i * 2));
    const end = new Date(start); end.setDate(end.getDate() + lr.days - 1);
    const approverEmp = allEmps[Math.max(0, Math.min(lr.ei - 1, allEmps.length - 1))];
    await db.leaveRequest.create({
      data: {
        tenantId: t, employeeId: emp.id, leaveTypeId: leaveTypes[lr.lt].id,
        startDate: start, endDate: end, days: lr.days, reason: lr.reason,
        status: lr.status,
        approverName: lr.status !== "pending" ? `${approverEmp.firstName} ${approverEmp.lastName}` : null,
        comment: lr.status === "rejected" ? "Team has a release deadline that week." : lr.status === "approved" ? "Approved. Enjoy!" : null,
        decidedAt: lr.status !== "pending" ? new Date(now.getTime() - 86400000 * 3) : null,
        createdAt: new Date(now.getTime() - 86400000 * (5 + i)),
      },
    });
  }

  // Payroll runs: last 3 months (paid), current month draft
  for (let mBack = 3; mBack >= 0; mBack--) {
    const d = new Date(now.getFullYear(), now.getMonth() - mBack, 1);
    const isCurrent = mBack === 0;
    const activeEmps = allEmps.filter((e) => e.status === "active");
    const run = await db.payrollRun.create({
      data: {
        tenantId: t, month: d.getMonth() + 1, year: d.getFullYear(),
        status: isCurrent ? "draft" : mBack === 1 ? "approved" : "paid",
        processedBy: "Priya Nair", processedAt: isCurrent ? null : new Date(d.getFullYear(), d.getMonth() + 1, 2),
        approvedBy: isCurrent ? null : opts.owner.name,
        approvedAt: isCurrent ? null : new Date(d.getFullYear(), d.getMonth() + 1, 3),
        createdAt: new Date(d.getFullYear(), d.getMonth(), 28),
      },
    });
    let gross = 0, net = 0;
    for (const emp of activeEmps) {
      const lop = rand(parseInt(emp.id.slice(-3), 36) + mBack) > 0.85 ? 1 : 0;
      // lopAmount stays in-memory only — the payslip row persists lopDays/daysPaid.
      const { lopAmount, ...p } = computePayslip(emp.ctc, lop);
      await db.payslip.create({
        data: { tenantId: t, runId: run.id, employeeId: emp.id, ...p },
      });
      gross += p.gross; net += p.net;
    }
    if (!isCurrent) {
      await db.payrollRun.update({ where: { id: run.id }, data: { employeeCount: activeEmps.length, grossTotal: gross, netTotal: net } });
    }
  }

  // Recruitment
  const openings = await Promise.all([
    db.jobOpening.create({ data: { tenantId: t, title: "Senior Frontend Engineer", department: "Engineering", location: opts.location, employmentType: "full_time", openings: 2, status: "open", hiringManager: opts.managerEmail.name, minExpYears: 4, maxSalary: 3200000, skills: JSON.stringify(["React", "TypeScript", "Next.js", "Tailwind"]), description: "Build delightful product surfaces for our HR platform. You will own features end-to-end across the stack with a strong frontend bias.", createdAt: new Date(now.getTime() - 30 * 86400000) } }),
    db.jobOpening.create({ data: { tenantId: t, title: "Product Designer", department: "Engineering", location: opts.location, employmentType: "full_time", openings: 1, status: "open", hiringManager: opts.managerEmail.name, minExpYears: 3, maxSalary: 2400000, skills: JSON.stringify(["Figma", "Design Systems", "Prototyping"]), description: "Shape the design language of the product — from information architecture to polished interface details.", createdAt: new Date(now.getTime() - 21 * 86400000) } }),
    db.jobOpening.create({ data: { tenantId: t, title: "Payroll Specialist", department: "Finance", location: opts.location, employmentType: "full_time", openings: 1, status: "on_hold", hiringManager: opts.owner.name, minExpYears: 3, maxSalary: 900000, skills: JSON.stringify(["Indian Payroll", "PF/ESI", "TDS"]), description: "Own payroll operations and statutory compliance for our customers.", createdAt: new Date(now.getTime() - 45 * 86400000) } }),
    db.jobOpening.create({ data: { tenantId: t, title: "Enterprise Account Executive", department: "Sales", location: "Mumbai", employmentType: "full_time", openings: 3, status: "open", hiringManager: opts.owner.name, minExpYears: 5, maxSalary: 2000000, skills: JSON.stringify(["B2B SaaS", "Enterprise Sales", "Solutioning"]), description: "Drive new enterprise logo acquisition in West India.", createdAt: new Date(now.getTime() - 12 * 86400000) } }),
  ]);

  const candidateSeed = [
    ["Aarav Sharma", "aarav.sharma@gmail.com", 0, "applied", 4, "Referral"],
    ["Neha Kulkarni", "neha.k@gmail.com", 0, "screening", 5, "LinkedIn"],
    ["Rohan Gupta", "rohan.g@gmail.com", 0, "interview", 4, "Naukri"],
    ["Ishaani Desai", "ishaani.d@gmail.com", 0, "offer", 5, "Careers Page"],
    ["Farhan Ali", "farhan.ali@gmail.com", 0, "rejected", 2, "Naukri"],
    ["Tanvi Joshi", "tanvi.j@gmail.com", 1, "applied", 4, "Careers Page"],
    ["Aditya Rao", "aditya.rao@gmail.com", 1, "interview", 3, "LinkedIn"],
    ["Meera Pillai", "meera.p@gmail.com", 1, "screening", 4, "Referral"],
    ["Sanjay Kumar", "sanjay.k@gmail.com", 3, "applied", 3, "LinkedIn"],
    ["Lisa Fernandes", "lisa.f@gmail.com", 3, "screening", 5, "Recruiter"],
    ["Vivek Anand", "vivek.a@gmail.com", 0, "hired", 5, "Referral"],
    ["Priyanka Reddy", "priyanka.r@gmail.com", 2, "applied", 3, "Naukri"],
  ] as const;
  for (const [i, c] of candidateSeed.entries()) {
    await db.candidate.create({
      data: {
        tenantId: t, openingId: openings[c[2]].id, name: c[0], email: c[1],
        phone: `+91 9${String(800000000 + i * 31337)}`, source: c[5], stage: c[3], rating: c[4],
        expectedSalary: 1200000 + i * 150000, noticePeriod: pick(["Immediate", "30 days", "60 days", "90 days"], i),
        resumeSummary: `${c[0]} — ${pick(["5", "4", "6", "3"], i)} years experience. Strong in ${pick(["React ecosystems", "design systems", "payroll compliance", "enterprise sales"], i)}. Previous role at ${pick(["Zeta", "Freshworks", "Razorpay", "Postman", "Swiggy"], i)}.`,
        notes: c[3] === "rejected" ? "Required deeper systems experience for the role scope." : null,
        appliedAt: new Date(now.getTime() - (40 - i * 3) * 86400000),
        hiredAt: c[3] === "hired" ? new Date(now.getTime() - 10 * 86400000) : null,
      },
    });
  }

  // Performance reviews (current cycle)
  const cycle = `H1 ${year}`;
  const reviewEmps = allEmps.slice(0, Math.min(12, allEmps.length));
  for (const [i, emp] of reviewEmps.entries()) {
    const status = i < 5 ? "completed" : i < 8 ? "manager_review" : "self_review";
    const selfR = 3 + Math.floor(rand(i + 3) * 3);
    const mgrR = status === "completed" ? Math.max(1, Math.min(5, selfR + (rand(i) > 0.6 ? 1 : 0) - (rand(i + 1) > 0.8 ? 1 : 0))) : null;
    await db.performanceReview.create({
      data: {
        tenantId: t, employeeId: emp.id, cycle, periodLabel: `Jan – Jun ${year}`,
        status, selfRating: status !== "self_review" ? selfR : null,
        managerRating: mgrR, finalRating: status === "completed" ? mgrR : null,
        goals: JSON.stringify([
          { title: "Ship quarterly roadmap commitments", progress: 70 + Math.floor(rand(i) * 30) },
          { title: "Improve cross-team collaboration score", progress: 55 + Math.floor(rand(i + 2) * 40) },
          { title: "Mentor one junior team member", progress: 40 + Math.floor(rand(i + 1) * 55) },
        ]),
        reviewerName: emp.managerId ? (allEmps.find((m) => m.id === emp.managerId)?.firstName + " " + allEmps.find((m) => m.id === emp.managerId)?.lastName) : opts.owner.name,
        summary: status === "completed" ? "Consistently delivers with high quality. Strong ownership across the review period." : null,
        strengths: status === "completed" ? "Reliable execution; excellent stakeholder communication." : null,
        improvements: status === "completed" ? "Delegate more; deepen expertise in adjacent domains." : null,
        dueDate: new Date(now.getTime() + 14 * 86400000),
        completedAt: status === "completed" ? new Date(now.getTime() - 5 * 86400000) : null,
      },
    });
  }

  // Announcements
  await Promise.all([
    db.announcement.create({ data: { tenantId: t, title: `Welcome to ${opts.name} on PeoplePulse HR`, body: `We are live on PeoplePulse HR! From today, all leave applications, attendance, payslips and HR requests happen here. Explore your dashboard and update your profile. The People team is available on the HR Helpdesk for any questions.`, category: "company", authorName: opts.hrEmails[0].name, pinned: true, acknowledgedCount: Math.floor(allEmps.length * 0.8), createdAt: new Date(now.getTime() - 20 * 86400000) } }),
    db.announcement.create({ data: { tenantId: t, title: "New: Flexible work-from-home policy", body: "Starting this month, everyone can work from home up to 8 days a month with a simple intimation to your manager. Core hours remain 10:00–16:00. Read the full policy in Settings → Policies.", category: "policy", authorName: opts.hrEmails[0].name, acknowledgedCount: Math.floor(allEmps.length * 0.5), createdAt: new Date(now.getTime() - 9 * 86400000) } }),
    db.announcement.create({ data: { tenantId: t, title: "Quarterly all-hands — Friday 4:30 PM", body: "Join us for the quarterly business review and product roadmap session. Anchor Hall and video link on the calendar invite. Bring your questions — we will have open Q&A with the leadership team.", category: "event", authorName: opts.owner.name, acknowledgedCount: Math.floor(allEmps.length * 0.3), createdAt: new Date(now.getTime() - 2 * 86400000) } }),
    db.announcement.create({ data: { tenantId: t, title: "Congratulations to the release team!", body: "A big thank you to the engineering team for shipping the platform release ahead of schedule with zero critical issues. Celebrating with team lunch this Friday.", category: "celebration", authorName: opts.managerEmail.name, acknowledgedCount: Math.floor(allEmps.length * 0.6), createdAt: new Date(now.getTime() - 1 * 86400000) } }),
  ]);

  // HR tickets
  const tickets = [
    ["Payroll", "urgent", "open", "Payslip shows incorrect PF amount", "My October payslip seems to deduct more PF than usual. Could you please check?"],
    ["Leave", "medium", "in_progress", "Carry-forward of earned leave", "I had 6 unused EL days from last year. Where can I see if they were carried forward?"],
    ["IT & Access", "high", "open", "Laptop setup for new joiner", "Requesting IT to prepare a laptop for the new designer joining Monday."],
    ["Policy", "low", "resolved", "Where is the WFH policy?", "Could someone point me to the work-from-home policy document?"],
    ["Facilities", "medium", "resolved", "AC too cold on 4th floor", "The 4th floor meeting rooms are extremely cold in the afternoons."],
    ["Payroll", "high", "in_progress", "Reimbursement not credited", "My travel reimbursement from the Pune visit has not been credited yet."],
    ["Leave", "low", "closed", "Half-day leave application", "How do I apply for a half-day leave?"],
    ["IT & Access", "medium", "open", "Email alias change after marriage", "I would like to update my email alias, please advise the process."],
  ] as const;
  for (const [i, tk] of tickets.entries()) {
    const emp = allEmps[(i * 2 + 1) % allEmps.length];
    const created = new Date(now.getTime() - (i * 19 + 3) * 3600000);
    const msgs: { author: string; role: string; content: string; at: string }[] = [
      { author: `${emp.firstName} ${emp.lastName}`, role: "requester", content: tk[4], at: created.toISOString() },
    ];
    if (tk[2] !== "open") {
      msgs.push({ author: opts.hrEmails[0].name, role: "hr", content: `Hi ${emp.firstName}, thanks for reaching out. We are looking into this and will update you shortly. Ticket reference: ${opts.codePrefix}-HR-${String(1000 + i)}.`, at: new Date(created.getTime() + 7200000).toISOString() });
    }
    if (tk[2] === "resolved" || tk[2] === "closed") {
      msgs.push({ author: opts.hrEmails[0].name, role: "hr", content: "This has been resolved. Closing the ticket — feel free to reopen if you still need help.", at: new Date(created.getTime() + 26 * 3600000).toISOString() });
    }
    await db.hrTicket.create({
      data: {
        tenantId: t, ticketNo: `${opts.codePrefix}-HR-${String(1001 + i)}`,
        subject: tk[3], category: tk[0], priority: tk[1], status: tk[2],
        requesterName: `${emp.firstName} ${emp.lastName}`, requesterEmail: emp.email,
        assignedTo: tk[2] === "open" ? null : opts.hrEmails[0].name,
        slaHours: tk[1] === "urgent" ? 8 : tk[1] === "high" ? 24 : 48,
        messages: JSON.stringify(msgs), createdAt: created,
        resolvedAt: tk[2] === "resolved" || tk[2] === "closed" ? new Date(created.getTime() + 30 * 3600000) : null,
      },
    });
  }

  // Workflows + executions
  const wfs = await Promise.all([
    db.workflow.create({ data: { tenantId: t, name: "New joiner onboarding", description: "When an employee is added, generate the onboarding checklist, IT access request and welcome announcement.", category: "onboarding", triggerCode: "employee.joined", triggerLabel: "Employee joins", active: true, lastRunAt: new Date(now.getTime() - 86400000) } }),
    db.workflow.create({ data: { tenantId: t, name: "Leave approval routing", description: "Notify the reporting manager when a leave request is submitted; debit balances and mark attendance on approval.", category: "leave", triggerCode: "leave.submitted", triggerLabel: "Leave request submitted", active: true, lastRunAt: new Date(now.getTime() - 3600000) } }),
    db.workflow.create({ data: { tenantId: t, name: "Probation completion review", description: "When probation ends, create a confirmation review task for the manager.", category: "performance", triggerCode: "employee.probation_end", triggerLabel: "Probation period ends", active: true, lastRunAt: new Date(now.getTime() - 3 * 86400000) } }),
    db.workflow.create({ data: { tenantId: t, name: "Payroll readiness alert", description: "When a payroll run enters review, notify authorised approvers and prepare the register.", category: "payroll", triggerCode: "payroll.in_review", triggerLabel: "Payroll run ready for review", active: true, lastRunAt: new Date(now.getTime() - 5 * 86400000) } }),
    db.workflow.create({ data: { tenantId: t, name: "SLA breach escalation", description: "When an HR ticket breaches its SLA, escalate to the Head of People.", category: "helpdesk", triggerCode: "ticket.sla_breach", triggerLabel: "Ticket SLA breached", active: true, lastRunAt: new Date(now.getTime() - 15 * 3600000) } }),
    db.workflow.create({ data: { tenantId: t, name: "Exit clearance checklist", description: "When an employee resigns, create offboarding tasks: asset return, access revocation, knowledge transfer.", category: "offboarding", triggerCode: "employee.resigned", triggerLabel: "Employee resigns", active: false } }),
  ]);

  const execSeed: [number, string, string, [string, string, boolean][]][] = [
    [1, "Leave request submitted by Rohan Gupta", "leave.requested", [["Condition: is request within balance?", "Yes — 12 days CL available", true], ["Notify manager", "Notification sent to reporting manager", true], ["Pending balance debit", "1 day marked pending until approval", true]]],
    [0, "New employee added: Kavya Suresh", "employee.created", [["Generate onboarding checklist", "8 tasks created for the new joiner", true], ["Request IT access", "Laptop + email access ticket raised", true], ["Schedule welcome session", "Invitation sent for Day 1 orientation", true]]],
    [3, "Payroll run moved to review", "payroll.in_review", [["Validate payslips", "All payslips generated without errors", true], ["Notify approvers", "Owner notified for approval", true]]],
    [4, "Ticket SLA breached", "ticket.sla_breached", [["Check ticket age", "Ticket #1001 exceeded 8h SLA", true], ["Escalate to Head of People", "Escalation notification sent", true]]],
    [2, "Probation ending for 2 employees", "employee.probation_end", [["Find employees in probation window", "2 employees found", true], ["Create confirmation reviews", "Review tasks assigned to managers", true]]],
    [1, "Leave request approved", "leave.approved", [["Debit leave balance", "2 days CL debited", true], ["Mark leave attendance", "Attendance marked for leave dates", true], ["Notify employee", "Approval confirmation sent", true]]],
  ];
  for (const [i, ex] of execSeed.entries()) {
    const start = new Date(now.getTime() - (i * 7 + 1) * 3600000);
    await db.workflowExecution.create({
      data: {
        tenantId: t, workflowId: wfs[ex[0]].id, status: "success", trigger: ex[2],
        summary: ex[1], startedAt: start, finishedAt: new Date(start.getTime() + 240000),
        steps: JSON.stringify(ex[3].map(([name, detail, ok]) => ({ name, detail, ok }))),
      },
    });
  }
  await db.workflow.update({ where: { id: wfs[1].id }, data: { executionCount: 47 } });
  await db.workflow.update({ where: { id: wfs[0].id }, data: { executionCount: 32 } });
  await db.workflow.update({ where: { id: wfs[3].id }, data: { executionCount: 12 } });
  await db.workflow.update({ where: { id: wfs[4].id }, data: { executionCount: 9 } });
  await db.workflow.update({ where: { id: wfs[2].id }, data: { executionCount: 14 } });

  // Onboarding tasks for the newest joiner
  const newest = emps[emps.length - 1];
  if (newest) {
    const tasks = [
      ["Sign employment contract", "documentation", "New Joiner", 2],
      ["Submit ID proofs & address proof", "documentation", "New Joiner", 2],
      ["Bank account details submission", "documentation", "New Joiner", 3],
      ["Laptop & email access", "it", "IT Admin", 1],
      ["Tool accounts (Slack, Jira, GitHub)", "it", "IT Admin", 3],
      ["Meet the team — introductions", "hr", "People Team", 1],
      ["Compliance & policy training", "training", "People Team", 7],
      ["First 30-day goals discussion", "hr", "Reporting Manager", 5],
    ] as const;
    for (const [i, tk] of tasks.entries()) {
      const due = new Date(newest.joinDate); due.setDate(due.getDate() + tk[3]);
      await db.onboardingTask.create({
        data: {
          tenantId: t, employeeId: newest.id, title: tk[0], category: tk[1], assignee: tk[2],
          dueDate: due, status: i < 3 ? "done" : i < 4 ? "in_progress" : "pending", order: i,
        },
      });
    }
  }

  // Audit logs
  const audits: [string, string, string, string, string][] = [
    [opts.hrEmails[0].name, "hr", "leave.approved", "LeaveRequest", "Approved 3-day Earned Leave for Rohan Gupta"],
    [opts.owner.name, "owner", "payroll.approved", "PayrollRun", "Approved payroll run for last month"],
    [opts.hrEmails[0].name, "hr", "employee.created", "Employee", "Added new employee Kavya Suresh (SWE-215)"],
    [opts.managerEmail.name, "manager", "review.completed", "PerformanceReview", "Completed manager review for Aditya Nair"],
    [opts.hrEmails[0].name, "hr", "announcement.published", "Announcement", "Published the flexible WFH policy announcement"],
    [opts.owner.name, "owner", "settings.updated", "Tenant", "Updated payroll statutory configuration (PT state)"],
    [opts.hrEmails[0].name, "hr", "ticket.resolved", "HrTicket", "Resolved ticket NIM-HR-1004 (WFH policy query)"],
    [opts.owner.name, "owner", "plan.upgraded", "Tenant", "Subscription upgraded from Growth to Professional"],
  ];
  for (const [i, a] of audits.entries()) {
    await db.auditLog.create({
      data: { tenantId: t, actorName: a[0], actorRole: a[1], action: a[2], entity: a[3], entityId: null, summary: a[4], severity: "info", createdAt: new Date(now.getTime() - (i * 11 + 2) * 3600000) },
    });
  }

  // Invoices
  const invMonths = [3, 2, 1].map((back) => new Date(now.getFullYear(), now.getMonth() - back, 1));
  for (const [i, d] of invMonths.entries()) {
    const seats = 40 + i * 3;
    const amount = seats * 149;
    const tax = Math.round(amount * 0.18);
    await db.invoice.create({
      data: {
        tenantId: t, number: `PP-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}-${String(101 + i)}`,
        plan: "professional", periodLabel: d.toLocaleString("en-IN", { month: "long", year: "numeric" }),
        seats, amount, tax, total: amount + tax, status: "paid",
        issuedAt: d, paidAt: new Date(d.getTime() + 3 * 86400000), method: "UPI / HDFC",
      },
    });
  }

  // Policies
  await Promise.all([
    db.policyDocument.create({ data: { tenantId: t, title: "Leave & Time Off Policy", category: "HR Policy", version: "2.1", audience: "All Employees", content: "## Overview\nThis policy describes leave entitlements for all employees.\n\n### Casual Leave (CL)\n12 days per calendar year. Maximum 3 days at a stretch. Cannot be carried forward.\n\n### Sick Leave (SL)\n8 days per calendar year. Medical certificate required for 3+ consecutive days.\n\n### Earned Leave (EL)\n15 days per year, accrued 1.25 days per completed month. Unused EL can be carried forward up to 30 days and is encashable at basic pay on exit.\n\n### Compensatory Off (CO)\nGranted for approved weekend/holiday work, within 90 days.\n\n### Approval\nAll leave requires manager approval. Apply at least 3 days in advance except emergencies.", updatedBy: opts.hrEmails[0].name } }),
    db.policyDocument.create({ data: { tenantId: t, title: "Work From Home Policy", category: "HR Policy", version: "1.4", audience: "All Employees", content: "## Work From Home\nEmployees may work from home up to 8 days per month with manager intimation.\n\n### Expectations\n- Core hours 10:00–16:00 IST with daily attendance check-in\n- Camera-on for scheduled meetings\n- Manager may recall WFH for workshops, clients or team events\n\n### Remote attendance\nMark attendance with the WFH status from the self-service dashboard.", updatedBy: opts.hrEmails[0].name } }),
    db.policyDocument.create({ data: { tenantId: t, title: "Attendance & Working Hours", category: "HR Policy", version: "1.2", audience: "All Employees", content: "## Working Hours\nStandard working hours are 9.5 hours including breaks, five days a week (Mon–Fri).\n\n### Check-in\nEmployees must check in through the web or mobile app. Three or more late arrivals in a month trigger an automatic HR review conversation.\n\n### Regularisation\nMissed punches can be regularised with manager approval within 7 days.", updatedBy: opts.hrEmails[0].name } }),
    db.policyDocument.create({ data: { tenantId: t, title: "Code of Conduct", category: "Company Policy", version: "1.0", audience: "All Employees", content: "## Code of Conduct\nAll employees are expected to act with integrity, respect and professionalism.\n\n- Treat colleagues, candidates and customers with respect\n- Protect confidential company and personal data\n- Report concerns through the HR helpdesk or to your manager\n- Violations are handled per the disciplinary procedure", updatedBy: opts.owner.name } }),
    db.policyDocument.create({ data: { tenantId: t, title: "Exit & Full & Final Policy", category: "HR Policy", version: "1.0", audience: "All Employees", content: "## Resignation\nNotice period is 60 days for full-time employees. Resignations are submitted through the platform and require manager + HR approval.\n\n### Clearance\nExit involves asset return, access revocation, knowledge transfer sign-off and no-dues from all departments.\n\n### Settlement\nFull & final settlement, including leave encashment, is processed within 45 days of the last working day.", updatedBy: opts.hrEmails[0].name } }),
  ]);

  // Notifications
  await Promise.all([
    db.notification.create({ data: { tenantId: t, title: "Payroll approved", body: "Last month's payroll was approved and disbursed. Payslips are now available in your payroll section.", type: "payroll", createdAt: new Date(now.getTime() - 4 * 86400000) } }),
    db.notification.create({ data: { tenantId: t, title: "Pending leave approvals", body: "3 leave requests await your decision.", type: "leave", createdAt: new Date(now.getTime() - 3600000) } }),
    db.notification.create({ data: { tenantId: t, title: "Performance cycle open", body: `The H1 ${year} review cycle is live. Complete your self-assessment before the deadline.`, type: "performance", createdAt: new Date(now.getTime() - 2 * 86400000) } }),
    db.notification.create({ data: { tenantId: t, title: "New announcement", body: "Quarterly all-hands scheduled for Friday, 4:30 PM.", type: "announcement", createdAt: new Date(now.getTime() - 2 * 86400000) } }),
  ]);

  console.log(`Seeded tenant ${opts.name}: ${allEmps.length} employees, ${opts.employees.length + 1} codes, 4 payroll runs, ${candidateSeed.length} candidates, 8 tickets, 6 workflows.`);
  return tenant;
}

async function main() {
  // Safety guard: this seed WIPES all tenants and is meant for demo/dev only.
  if (process.env.NODE_ENV === "production" && process.env.SEED_DEMO !== "yes-i-will-wipe-data") {
    console.error("Refusing to seed: destructive demo seed in production. Set SEED_DEMO=yes-i-will-wipe-data to override.");
    process.exit(1);
  }

  const now = new Date();
  console.log("Seeding PeoplePulse HR demo data…");

  // Idempotent: wipe prior seed data (tenants cascade to all business records)
  await db.lead.deleteMany();
  await db.tenant.deleteMany();

  // ---- Tenant 1: Nimbus Technologies (rich demo) ----
  const nimbusEmployees: SeedEmployee[] = [
    { first: "Vikram", last: "Mehta", dept: "Engineering", designation: "Engineering Manager", ctc: 3600000, join: "2021-03-15" },
    { first: "Aditya", last: "Nair", dept: "Engineering", designation: "Staff Software Engineer", ctc: 3000000, join: "2021-06-01" },
    { first: "Kavya", last: "Suresh", dept: "Engineering", designation: "Senior Software Engineer", ctc: 2200000, join: "2024-11-18" },
    { first: "Rahul", last: "Bose", dept: "Engineering", designation: "Software Engineer II", ctc: 1600000, join: "2022-08-22" },
    { first: "Sneha", last: "Kulkarni", dept: "Engineering", designation: "Software Engineer II", ctc: 1550000, join: "2022-11-07" },
    { first: "Arjun", last: "Pillai", dept: "Engineering", designation: "Software Engineer I", ctc: 1100000, join: "2023-07-03" },
    { first: "Diya", last: "Menon", dept: "Engineering", designation: "QA Engineer", ctc: 1250000, join: "2023-01-16" },
    { first: "Karthik", last: "Rao", dept: "Engineering", designation: "DevOps Engineer", ctc: 1900000, join: "2022-04-11" },
    { first: "Meera", last: "Krishnan", dept: "Engineering", designation: "Product Designer", ctc: 1700000, join: "2023-09-25" },
    { first: "Rohan", last: "Gupta", dept: "Sales", designation: "Head of Sales", ctc: 3200000, join: "2021-02-01" },
    { first: "Nisha", last: "Agarwal", dept: "Sales", designation: "Senior Account Executive", ctc: 1500000, join: "2022-05-19" },
    { first: "Sameer", last: "Khan", dept: "Sales", designation: "Account Executive", ctc: 1100000, join: "2023-10-09" },
    { first: "Pooja", last: "Shetty", dept: "Sales", designation: "Sales Development Rep", ctc: 800000, join: "2024-06-10" },
    { first: "Aakash", last: "Jain", dept: "Sales", designation: "Account Executive", ctc: 1200000, join: "2024-02-05" },
    { first: "Lakshmi", last: "Narayan", dept: "Operations", designation: "Operations Manager", ctc: 1600000, join: "2021-09-13" },
    { first: "Farhan", last: "Sheikh", dept: "Operations", designation: "Executive Assistant", ctc: 700000, join: "2023-04-17" },
    { first: "Ritu", last: "Malhotra", dept: "Operations", designation: "Executive Assistant", ctc: 720000, join: "2023-12-04" },
    { first: "Priya", last: "Nair", dept: "People & HR", designation: "Head of People", ctc: 2600000, join: "2021-01-11" },
    { first: "Arjun", last: "Krishnan", dept: "People & HR", designation: "People Operations Associate", ctc: 850000, join: "2024-07-22" },
    { first: "Sanjana", last: "Dubey", dept: "People & HR", designation: "Recruiter", ctc: 950000, join: "2024-01-08" },
    { first: "Nikhil", last: "Sharma", dept: "Finance", designation: "Finance Controller", ctc: 2400000, join: "2021-08-02" },
    { first: "Anita", last: "Desai", dept: "Finance", designation: "Accountant", ctc: 900000, join: "2022-10-24" },
    { first: "Vivek", last: "Iyer", dept: "Finance", designation: "Payroll Executive", ctc: 780000, join: "2023-05-29" },
    { first: "Zoya", last: "Khan", dept: "Engineering", designation: "Software Engineer I", ctc: 1050000, join: "2024-09-02", status: "probation" },
    { first: "Dev", last: "Patel", dept: "Engineering", designation: "Software Engineer I", ctc: 1000000, join: "2025-08-18", status: "probation" },
    { first: "Riya", last: "Sinha", dept: "Sales", designation: "Account Executive", ctc: 950000, join: "2024-03-11", status: "notice" },
    { first: "Manoj", last: "Kumar", dept: "Operations", designation: "Operations Associate", ctc: 620000, join: "2022-02-14", status: "exited" },
    { first: "Gaurav", last: "Tandon", dept: "Engineering", designation: "Software Engineer II", ctc: 1500000, join: "2021-12-06", status: "exited" },
    { first: "Isha", last: "Bhatt", dept: "Engineering", designation: "Engineering Intern", ctc: 360000, join: "2025-09-01", employmentType: "intern" },
  ];

  await seedTenant({
    name: "Nimbus Technologies", slug: "nimbustech", plan: "professional", planStatus: "active",
    codePrefix: "NIM", domain: "nimbustech.in", location: "Bengaluru",
    owner: { name: "Ananya Rao", email: "ananya.rao@nimbustech.in", first: "Ananya", last: "Rao" },
    hrEmails: [
      { name: "Priya Nair", email: "priya.nair@nimbustech.in" },
      { name: "Sanjana Dubey", email: "sanjana.dubey@nimbustech.in" },
    ],
    managerEmail: { name: "Vikram Mehta", email: "vikram.mehta@nimbustech.in" },
    employeeUserEmails: [
      { name: "Arjun Krishnan", email: "arjun.krishnan@nimbustech.in" },
      { name: "Aditya Nair", email: "aditya.nair@nimbustech.in" },
    ],
    employees: nimbusEmployees,
    now,
  });

  // ---- Tenant 2: Meridian Retail (isolation demo) ----
  const meridianEmployees: SeedEmployee[] = [
    { first: "Suresh", last: "Babu", dept: "Store Operations", designation: "Regional Operations Head", ctc: 1800000, join: "2020-07-20" },
    { first: "Rekha", last: "Sharma", dept: "Store Operations", designation: "Store Manager", ctc: 720000, join: "2021-05-03" },
    { first: "Imran", last: "Qureshi", dept: "Store Operations", designation: "Store Manager", ctc: 700000, join: "2022-01-17" },
    { first: "Divya", last: "Reddy", dept: "Merchandising", designation: "Merchandise Planner", ctc: 950000, join: "2022-09-08" },
    { first: "Tarun", last: "Sachdeva", dept: "Merchandising", designation: "Category Assistant", ctc: 520000, join: "2023-11-20" },
    { first: "Lavanya", last: "Rao", dept: "People & HR", designation: "HR Manager", ctc: 1100000, join: "2021-10-04" },
    { first: "Mohit", last: "Verma", dept: "Finance", designation: "Accounts Executive", ctc: 540000, join: "2023-03-27" },
  ];

  await seedTenant({
    name: "Meridian Retail", slug: "meridianretail", plan: "growth", planStatus: "active",
    codePrefix: "MER", domain: "meridianretail.in", location: "Hyderabad",
    owner: { name: "Kavitha Reddy", email: "admin@meridianretail.in", first: "Kavitha", last: "Reddy" },
    hrEmails: [{ name: "Lavanya Rao", email: "lavanya.rao@meridianretail.in" }],
    managerEmail: { name: "Suresh Babu", email: "suresh.babu@meridianretail.in" },
    employeeUserEmails: [],
    employees: meridianEmployees,
    now,
  });

  // ---- Website leads ----
  await Promise.all([
    db.lead.create({ data: { name: "Rajeshwari Iyer", email: "rajeshwari@brightlabs.io", company: "Bright Labs", companySize: "51-200", plan: "growth", message: "Need payroll + attendance for a 120-person product company.", source: "demo", status: "new" } }),
    db.lead.create({ data: { name: "Amit Chawla", email: "amit.chawla@sunriseindustries.in", company: "Sunrise Industries", companySize: "501-2000", plan: "enterprise", message: "Manufacturing plant with 900 workers, biometric integration needed.", source: "demo", status: "contacted" } }),
    db.lead.create({ data: { name: "Sarah Thomas", email: "sarah@fintrust.co", company: "FinTrust Advisors", companySize: "11-50", plan: "starter", message: "Small consulting firm, mostly leave and attendance.", source: "pricing", status: "qualified" } }),
  ]);

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

#!/usr/bin/env python3
"""Double-fork spawner: fully detaches a command so it survives the parent."""
import os
import sys

if len(sys.argv) < 2:
    print("usage: detach.py <command> [args...]")
    sys.exit(1)

pid = os.fork()
if pid == 0:
    # Child: new session, then fork again so this intermediate parent exits
    # while the outer command is still running — the grandchild reparents to
    # PID 1 and is fully detached from the tool session's process tree.
    os.setsid()
    pid2 = os.fork()
    if pid2 == 0:
        # Grandchild: run the command with stdio to /dev/null
        devnull_r = os.open("/dev/null", os.O_RDONLY)
        devnull_w = os.open("/dev/null", os.O_WRONLY)
        os.dup2(devnull_r, 0)
        os.dup2(devnull_w, 1)
        os.dup2(devnull_w, 2)
        os.close(devnull_r)
        os.close(devnull_w)
        os.execvp(sys.argv[1], sys.argv[1:])
    os._exit(0)

# Outer parent: reap the intermediate child and exit while the command runs.
os.waitpid(pid, 0)
print(f"detached pid for {' '.join(sys.argv[1:])}: launched")

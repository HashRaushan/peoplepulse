/**
 * Generate all PWA + Android icons from the source SVG.
 * Run: bun scripts/generate-icons.ts
 */
import sharp from "sharp";
import { mkdir } from "node:fs/promises";
import path from "node:path";

const PUBLIC = path.resolve(process.cwd(), "public");
const ICONS = path.join(PUBLIC, "icons");
await mkdir(ICONS, { recursive: true });

const sourceSvg = path.join(PUBLIC, "icon.svg");

// Maskable version: the "P" needs to sit inside the inner 80% safe zone.
// We render the same SVG but on a larger canvas with padding, so the icon
// looks correct when Android masks it into a circle/squircle/rounded square.
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#059669"/>
      <stop offset="100%" stop-color="#047857"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" fill="url(#bg)"/>
  <g transform="translate(51 51) scale(0.8)">
    <circle cx="256" cy="256" r="170" fill="#fff" opacity="0.08"/>
    <text x="256" y="262" font-family="Arial, Helvetica, sans-serif" font-size="280" font-weight="800" fill="#fff" text-anchor="middle" dominant-baseline="central">P</text>
  </g>
</svg>`;

// Standard PWA sizes
const standard = [16, 32, 48, 72, 96, 144, 152, 180, 192, 384, 512];
// Maskable sizes (Android adaptive icon safe zone)
const maskable = [192, 512];

console.log("Generating standard icons…");
for (const size of standard) {
  await sharp(sourceSvg)
    .resize(size, size)
    .png()
    .toFile(path.join(ICONS, `icon-${size}x${size}.png`));
  console.log(`  icon-${size}x${size}.png`);
}

console.log("Generating maskable icons…");
for (const size of maskable) {
  await sharp(Buffer.from(maskableSvg))
    .resize(size, size)
    .png()
    .toFile(path.join(ICONS, `maskable-${size}x${size}.png`));
  console.log(`  maskable-${size}x${size}.png`);
}

// Apple touch Icon (180x180, no transparency — Apple requires solid bg)
await sharp(sourceSvg).resize(180, 180).png().toFile(path.join(PUBLIC, "apple-touch-icon.png"));
console.log("  apple-touch-icon.png (public/)");

// Favicons
await sharp(sourceSvg).resize(32, 32).png().toFile(path.join(PUBLIC, "favicon-32x32.png"));
await sharp(sourceSvg).resize(16, 16).png().toFile(path.join(PUBLIC, "favicon-16x16.png"));
console.log("  favicon-32x32.png, favicon-16x16.png (public/)");

// ICO favicon (32x32 — most browsers accept PNG renamed, but we'll also keep a 32px PNG as favicon.ico proxy)
await sharp(sourceSvg).resize(32, 32).png().toFile(path.join(PUBLIC, "favicon.ico"));
console.log("  favicon.ico (public/)");

console.log("Done. All icons in public/icons/ + public root.");

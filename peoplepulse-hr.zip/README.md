# PeoplePulse HR

A complete, multi-tenant HRMS platform for modern teams — core HR, attendance
(with optional geo-fencing), leave, payroll, expenses, assets, training & LMS,
recruitment (ATS), performance & OKR goals, surveys & eNPS, document center,
announcements, HR helpdesk, workflow automation, people analytics, and an AI
copilot grounded on live company data.

## Stack

- **Next.js 16** (App Router) + TypeScript (strict)
- **Tailwind CSS 4** + shadcn/ui component library
- **Prisma ORM** with SQLite (file-based — easy backups, zero external DB)
- **TanStack Query** for server state
- PWA-ready (installable, offline app shell, Play Store TWA support)

## Quick start

```bash
bun install
cp .env.example .env        # then fill SESSION_SECRET (openssl rand -hex 32)
bun run db:push             # create the database schema
bun run dev                 # http://localhost:3000
```

The first person to register via **Create your workspace** becomes the
organisation Owner. No demo accounts exist.

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `DATABASE_URL` | Yes | SQLite file path |
| `SESSION_SECRET` | Yes (production) | 64-char hex; signs session tokens. The server refuses to boot in production without it. |
| `OPENROUTER_API_KEY` | Optional | Enables Pulse AI via OpenRouter; falls back to the built-in provider when unset |
| `OPENROUTER_MODEL` | Optional | Primary AI model id |
| `OPENROUTER_FALLBACK_MODELS` | Optional | Comma-separated fallback model ids |

## Scripts

| Command | Purpose |
|---|---|
| `bun run dev` | Development server (port 3000) |
| `bun run build` | Production build (standalone output) |
| `bun run start` | Run the production build |
| `bun run lint` | ESLint |
| `bun run db:push` | Sync Prisma schema to SQLite |
| `bun run db:generate` | Regenerate Prisma Client |

## Deploying

- **Recommended (free, commercial use allowed):** see `ORACLE_DEPLOY.md` —
  Oracle Cloud Always-Free VM + Cloudflare Tunnel, SQLite as-is.
- **Hobby/personal:** see `DEPLOYMENT.md` — Vercel + Neon (requires switching
  Prisma to Postgres; Vercel's free tier prohibits commercial use).
- **Android / Google Play:** see `PLAYSTORE_GUIDE.md` — wrap the deployed URL
  as a Trusted Web Activity with Bubblewrap.

## Security notes

- Passwords hashed with scrypt (per-user salt, timing-safe comparison)
- Sessions are HMAC-signed httpOnly cookies (7-day expiry)
- Every query is tenant-scoped — data is isolated per organisation
- All mutating actions write to an append-only audit log
- Attendance geo-fencing captures GPS only at check-in (no continuous tracking)

## Data safety

- Owner-only **Download backup** (Settings → Security) produces a full SQLite snapshot
- The database is a single file (`db/custom.db`) — copy it to back up
- Never commit `db/` or `.env` (both gitignored)

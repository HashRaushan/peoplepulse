# Publishing PeoplePulse HR — Free Deployment Guide

Two genuinely free paths. For a real business, **Path B (Oracle) is recommended** —
it allows commercial use at ₹0 and keeps SQLite as-is. Path A (Vercel) is fine for
hobby/personal projects but its free tier prohibits commercial use.

> **Recommended for production:** see `ORACLE_DEPLOY.md` — Oracle Cloud Always-Free
> VM + Cloudflare Tunnel. Free forever, commercial use allowed, zero code changes.

> Vercel (free Hobby plan) hosts the Next.js app. Neon (free plan) hosts a real
> Postgres database, because SQLite files do NOT survive on serverless hosts.
> Requires switching the Prisma provider from `sqlite` to `postgresql` (5-minute change, steps below).

### Step 1 — Push the code to GitHub (free)
```bash
git init && git add -A && git commit -m "PeoplePulse HR"
# Create an empty repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/peoplepulse-hr.git
git push -u origin main
```
> Add a `.gitignore` first: `node_modules`, `.next`, `db/`, `.env`, `dev.log`, `server.log`.

### Step 2 — Create the free database (Neon)
1. Sign up at **neon.tech** (free plan: 0.5 GB, enough for thousands of employees).
2. Create a project → copy the **connection string** (`postgresql://...?sslmode=require`).

### Step 3 — Switch Prisma to Postgres
1. In `prisma/schema.prisma`, change the datasource:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
   (SQLite-specific types: none — this schema has no `@db.Date`, so it ports cleanly.)
2. Point your local `.env` `DATABASE_URL` at the Neon string, then create tables:
   ```bash
   bun run db:push
   ```
   > Real deployment: do NOT run the demo seed script. Register your own
   > organisation via **Create your workspace** on the sign-in page instead —
   > it provisions a clean workspace (departments, leave policy, holidays,
   > policies, workflows) with zero fictional data.

### Step 4 — Deploy to Vercel (free)
1. Sign up at **vercel.com** with GitHub → **Add New → Project** → import the repo.
2. Framework preset: **Next.js** (auto-detected).
3. Environment Variables → add:
   | Key | Value |
   |---|---|
   | `DATABASE_URL` | your Neon connection string |
   | `SESSION_SECRET` | output of `openssl rand -hex 32` |
   | Z.ai key vars | credentials for your z-ai-web-dev-sdk account (enables Pulse AI) |
4. Deploy. You get a free HTTPS URL: `peoplepulse-hr.vercel.app`.
5. Optional: attach a domain you own in Vercel settings (free, HTTPS automatic).

**Cost: ₹0.** Limits: Hobby plan is for non-commercial/personal use — if this becomes a real business, Vercel Pro is $20/mo (Neon stays free up to its storage cap).

---

## Path B: Keep SQLite exactly as-is — host it yourself for free

> Only choose this if you don't want to touch the database code. You need a machine
> that stays on (your PC, an old laptop, or an always-free cloud VM) plus a free
> Cloudflare Tunnel for a public HTTPS URL.

### Option B1 — Your own computer + Cloudflare Tunnel (₹0)
```bash
# 1. Build & run
bun install && bun run build && bun run start

# 2. Expose it publicly with a free tunnel
#    (install: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)
cloudflared tunnel --url http://localhost:3000
```
You get a public `https://random-name.trycloudflare.com` URL instantly. For a stable
URL, create a free named tunnel in the Cloudflare Zero Trust dashboard (free plan).

### Option B2 — Oracle Cloud Always-Free VM (₹0 forever, more setup)
Oracle's free tier includes a 24 GB-RAM ARM VM that never expires:
1. Create an Ubuntu VM, open port 3000 in the firewall/security list.
2. Install Bun (`curl -fsSL https://bun.sh/install | bash`), clone the repo,
   `bun install && bun run build && bun run start`.
3. Add Cloudflare Tunnel or Caddy for HTTPS on a domain (optional — `http://VM_IP:3000` works as-is).

The SQLite file (`db/custom.db`) persists on the VM disk — zero code changes needed.

---

## After publishing (both paths)
- **Built-in resilience**: the app now boots and builds even with zero environment
  configuration. If `SESSION_SECRET` is missing in production, an ephemeral random
  secret is used (sessions reset when the server restarts — still fully secure,
  never a known constant); if `DATABASE_URL` is missing, the SQLite file that ships
  with the project (`db/custom.db`, schema-synced during the build) is used.
- **Set a strong `SESSION_SECRET`** in your environment (64-char random hex) so
  sessions survive restarts. All sessions are signed with it; rotating it signs
  everyone out.
- Register your company via **Create your workspace** on the sign-in page. You
  become the organisation Owner. No demo accounts exist in real mode.
- Add your employees under **Employees** and tick *Create login access* so they
  can sign in immediately (the initial password is shown once — share it
  securely). Bulk import supports the same option with one shared initial
  password.
- Schedule regular backups: **Settings → Security → Download backup** (owner
  only) produces a full SQLite snapshot of all HR data.

## Sharing the pitch deck
`download/PeoplePulse-HR-Pitch.pptx` — upload to Google Drive (set to "Anyone with the link → Viewer") or import into Google Slides (`File → Import slides`) for a shareable web link.
